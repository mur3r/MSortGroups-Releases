"""GitHub Releases client and preparation. Activation belongs to the supervisor."""
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import threading
import time
from urllib.parse import urlsplit
from uuid import uuid4

import httpx

from . import __version__
from .update_format import MAX_METADATA, MAX_PACKAGE, UpdateError, extract_package, verify_manifest, verify_tree, version_tuple

CODE_ROOT = Path(__file__).resolve().parent.parent
MANIFEST_NAME = 'murer-update.json'
SIGNATURE_NAME = 'murer-update.sig'
VAULT_SERVICE = 'Murer Group Stats Updates'


def read_json(path, default=None):
    try:
        return json.loads(Path(path).read_text(encoding='utf-8'))
    except FileNotFoundError:
        return {} if default is None else default


def atomic_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + '.' + uuid4().hex + '.tmp')
    try:
        with temporary.open('x', encoding='utf-8', newline='\n') as out:
            json.dump(value, out, ensure_ascii=False, allow_nan=False)
            out.flush()
            os.fsync(out.fileno())
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


class GitHubDownloads:
    def __init__(self, repository, token='', transport=None, public=False):
        self.repository, self.token, self.transport = repository, token, transport
        self.public = public

    def download(self, url, limit, destination=None, progress=None, octet=False):
        # Authorize the API request only. Signed storage redirects get no token.
        total = 0
        chunks = []
        out = None
        try:
            with httpx.Client(timeout=httpx.Timeout(30, read=60), transport=self.transport,
                              follow_redirects=False, trust_env=False) as client:
                for _ in range(6):
                    parsed = urlsplit(url)
                    if (parsed.scheme != 'https' or parsed.username or parsed.password or parsed.port not in (None, 443)
                            or parsed.hostname not in {'api.github.com', 'github.com', 'release-assets.githubusercontent.com', 'objects.githubusercontent.com'}):
                        raise UpdateError('GitHub вернул небезопасный адрес скачивания.')
                    headers = {'User-Agent': 'MurerGroupStats-Updater', 'Accept': 'application/octet-stream' if octet else 'application/vnd.github+json'}
                    if parsed.hostname == 'api.github.com' and self.token:
                        headers['Authorization'] = 'Bearer ' + self.token
                    with client.stream('GET', url, headers=headers) as response:
                        if response.status_code in (301, 302, 303, 307, 308):
                            url = response.headers.get('location', '')
                            continue
                        if response.status_code == 404:
                            raise UpdateError('Релиз не найден. Для приватного репозитория настройте доступ GitHub; возможно, первая версия ещё не опубликована.')
                        if response.status_code in (401, 403):
                            if response.headers.get('x-ratelimit-remaining') == '0':
                                raise UpdateError('Достигнут лимит запросов GitHub. Повторите проверку позже или настройте доступ GitHub.')
                            raise UpdateError('GitHub отказал в доступе. Проверьте срок токена и право Contents: read для репозитория обновлений.')
                        if response.status_code != 200:
                            raise UpdateError('GitHub временно недоступен. Повторите попытку позже.')
                        length = response.headers.get('content-length')
                        if length and (not length.isdigit() or int(length) > limit):
                            raise UpdateError('Файл обновления превышает допустимый размер.')
                        if destination:
                            out = Path(destination).open('xb')
                        for chunk in response.iter_bytes(256 * 1024):
                            total += len(chunk)
                            if total > limit:
                                raise UpdateError('Загрузка превысила ожидаемый размер.')
                            if out:
                                out.write(chunk)
                            else:
                                chunks.append(chunk)
                            if progress:
                                progress(total)
                        if length and total != int(length):
                            raise UpdateError('Загрузка оборвалась. Повторите попытку.')
                        return b''.join(chunks) if not destination else total
                raise UpdateError('Слишком много перенаправлений при скачивании.')
        except (httpx.HTTPError, OSError) as error:
            raise UpdateError('Не удалось скачать обновление. Проверьте интернет, свободное место и права на папку программы.') from error
        finally:
            if out:
                out.close()

    def release(self, release_id=None):
        if self.public:
            # Public release downloads avoid the anonymous REST API rate limit
            # shared by computers behind the same internet connection.
            raw = self.download(f'https://github.com/{self.repository}/releases/latest/download/{MANIFEST_NAME}', MAX_METADATA, octet=True)
            try:
                metadata = json.loads(raw)
                version = metadata['version']
                parts = version_tuple(version)
                identifier = (parts[0] * 1000000 + parts[1]) * 1000000 + parts[2]
                if release_id is not None and identifier != release_id:
                    raise UpdateError('Релиз отозван или вышла новая версия. Проверьте обновления заново.')
                return {'id': identifier, 'tag_name': 'v' + version, 'body': str(metadata.get('notes') or '')[:12000],
                        'draft': False, 'prerelease': False, 'public_version': version}
            except (KeyError, ValueError, TypeError) as error:
                if isinstance(error, UpdateError):
                    raise
                raise UpdateError('Описание публичного релиза повреждено.') from error
        suffix = str(int(release_id)) if release_id is not None else 'latest'
        raw = self.download(f'https://api.github.com/repos/{self.repository}/releases/{suffix}', MAX_METADATA)
        try:
            release = json.loads(raw)
            if release['draft'] or release['prerelease']:
                raise UpdateError('Тестовые и отозванные релизы не устанавливаются.')
            return release
        except (KeyError, TypeError, ValueError) as error:
            if isinstance(error, UpdateError):
                raise
            raise UpdateError('GitHub вернул некорректное описание релиза.') from error

    def asset(self, release, name):
        if self.public:
            version = release['public_version']
            version_tuple(version)
            if name not in {MANIFEST_NAME, SIGNATURE_NAME, f'MurerGroupStats-{version}.zip'}:
                raise UpdateError('Неизвестное вложение публичного релиза.')
            return f'https://github.com/{self.repository}/releases/download/v{version}/{name}'
        matches = [a for a in release.get('assets', []) if a.get('name') == name and a.get('state') == 'uploaded']
        if len(matches) != 1 or type(matches[0].get('id')) is not int:
            raise UpdateError('Релиз опубликован не полностью. Нужны архив, манифест и цифровая подпись.')
        return f"https://api.github.com/repos/{self.repository}/releases/assets/{matches[0]['id']}"


class UpdateManager:
    def __init__(self, store, vault, busy, publish, root=None, transport=None):
        self.root = Path(root or os.environ.get('MURER_INSTALL_ROOT', CODE_ROOT)).resolve()
        self.directory = self.root / '.murer-updates'
        self.store, self.vault, self.busy, self.publish, self.transport = store, vault, busy, publish, transport
        self.lock = threading.RLock()
        self.stop_event = threading.Event()
        self.worker = None
        self.auto_thread = None
        self.offer = None
        self.state = {'phase': 'idle', 'message': '', 'progress': 0}
        self.last_check = 0
        try:
            self.config = read_json(CODE_ROOT / 'config' / 'updates.json')
            if not re.fullmatch(r'[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+', self.config.get('repository', '')):
                raise ValueError('repository')
            if not isinstance(self.config.get('public_keys'), dict):
                raise ValueError('public_keys')
        except (OSError, ValueError):
            self.config = {'repository': '', 'public_keys': {}}
            self.state.update(phase='error', message='Источник обновлений не настроен или повреждён.')
        try:
            previous = read_json(self.directory / 'status.json')
            if previous.get('phase') == 'ready':
                self.state = previous
            elif previous.get('phase') in ('checking', 'downloading', 'preparing', 'installing'):
                self.state['message'] = 'Предыдущая операция была прервана. Проверку и скачивание можно повторить.'
        except (OSError, ValueError):
            self.state['message'] = 'Состояние прошлой загрузки повреждено. Проверьте обновления заново.'

    @property
    def trial(self):
        nonce = os.environ.get('MURER_UPDATE_NONCE')
        if not nonce:
            return False
        try:
            transaction = read_json(self.directory / 'transaction.json')
            return transaction.get('nonce') == nonce and transaction.get('phase') != 'committed'
        except (OSError, ValueError):
            return True

    def token(self):
        try:
            return self.vault.get_password(VAULT_SERVICE, 'github:' + self.config['repository']) or ''
        except Exception as error:
            raise UpdateError('Хранилище доступа GitHub недоступно. Запустите программу в своём профиле Windows.') from error

    def client(self):
        public = bool(self.config.get('public', False))
        return GitHubDownloads(self.config['repository'], '' if public else self.token(), self.transport, public=public)

    def status(self):
        with self.lock:
            result = dict(self.state)
            result.pop('candidate', None)
            result.pop('receipt', None)
            try:
                last = read_json(self.directory / 'result.json')
                active = read_json(self.directory / 'active.json')
                preferences = read_json(self.directory / 'preferences.json', {'auto_check': True})
            except (OSError, ValueError):
                last, active, preferences = {}, {}, {'auto_check': True}
            try:
                has_token = bool(self.token())
            except UpdateError:
                has_token = False
            result.update(current_version=__version__, repository=self.config['repository'], has_token=has_token,
                          is_public=bool(self.config.get('public', False)),
                          auto_check=preferences.get('auto_check', True), trial=self.trial,
                          developer_checkout=(self.root / '.git').exists(),
                          managed_launch=bool(os.environ.get('MURER_LAUNCHER_SESSION')),
                          last_result=last, rollback_available=bool(active.get('previous')), busy_reason=self.busy())
            if last.get('version') == __version__ and result['phase'] == 'idle':
                result['message'] = last.get('message', result['message'])
            return result

    def configure(self, body):
        if not isinstance(body, dict) or set(body) - {'token', 'clear_token', 'auto_check'}:
            raise UpdateError('Неизвестные настройки обновлений.')
        with self.lock:
            if self.worker and self.worker.is_alive():
                raise UpdateError('Дождитесь завершения текущей операции обновления.')
            if 'token' in body and (not isinstance(body['token'], str) or len(body['token']) > 500 or any(c.isspace() for c in body['token'])):
                raise UpdateError('Некорректный формат токена GitHub.')
            if 'clear_token' in body and type(body['clear_token']) is not bool:
                raise UpdateError('Некорректный запрос удаления доступа.')
            if 'auto_check' in body and type(body['auto_check']) is not bool:
                raise UpdateError('Некорректная настройка проверки.')
            if body.get('clear_token') and body.get('token'):
                raise UpdateError('Выберите сохранение или удаление доступа.')
            try:
                key = 'github:' + self.config['repository']
                if body.get('clear_token'):
                    if self.token():
                        self.vault.delete_password(VAULT_SERVICE, key)
                elif body.get('token'):
                    self.vault.set_password(VAULT_SERVICE, key, body['token'])
                if 'auto_check' in body:
                    atomic_json(self.directory / 'preferences.json', {'auto_check': body['auto_check']})
            except Exception as error:
                raise UpdateError('Не удалось сохранить настройки доступа. Секреты не записываются в файлы программы.') from error
            self.offer = None
        return self.status()

    def _set(self, **changes):
        with self.lock:
            self.state.update(changes)
            atomic_json(self.directory / 'status.json', self.state)
        self.publish({'type': 'updates'})

    def _begin(self, operation):
        with self.lock:
            if self.worker and self.worker.is_alive():
                raise UpdateError('Операция обновления уже выполняется.')
            if self.trial or self.state['phase'] == 'installing':
                raise UpdateError('Программа уже устанавливает обновление.')
            self.worker = threading.Thread(target=self._run, args=(operation,), name='murer-updates', daemon=True)
            self.worker.start()
        return self.status()

    def _run(self, operation):
        try:
            operation()
        except UpdateError as error:
            self._error(str(error))
        except Exception:
            self._error('Обновление не подготовлено. Рабочая версия сохранена; повторите попытку.')

    def _error(self, message):
        try:
            self._set(phase='error', message=message, progress=0)
        except OSError:
            # Disk-full / read-only errors must still become visible in the live UI.
            with self.lock:
                self.state.update(phase='error', message=message, progress=0)

    def check(self):
        with self.lock:
            if time.monotonic() - self.last_check < 5:
                raise UpdateError('Подождите несколько секунд перед повторной проверкой.')
            self.last_check = time.monotonic()
        return self._begin(self._check)

    def _read_offer(self, client, release):
        raw = client.download(client.asset(release, MANIFEST_NAME), MAX_METADATA, octet=True)
        signature = client.download(client.asset(release, SIGNATURE_NAME), 4096, octet=True)
        manifest = verify_manifest(raw, signature, self.config['public_keys'])
        if release.get('tag_name') != 'v' + manifest['version']:
            raise UpdateError('Тег GitHub не соответствует подписанной версии.')
        client.asset(release, manifest['package']['name'])
        return {'manifest': manifest, 'raw': raw, 'signature': signature, 'release_id': release['id'],
                'notes': str(manifest.get('notes', release.get('body')) or '')[:12000]}

    def _check(self):
        self._set(phase='checking', message='Проверяем GitHub Releases…', progress=0)
        client = self.client()
        release = client.release()
        offer = self._read_offer(client, release)
        with self.lock:
            self.offer = offer
        version = offer['manifest']['version']
        newer = version_tuple(version) > version_tuple(__version__)
        self._set(phase='available' if newer else 'current', latest_version=version, notes=offer['notes'],
                  message='Доступна новая версия.' if newer else 'Установлена актуальная версия. Понижение версии автоматически не выполняется.',
                  checked_at=time.time(), candidate=None, receipt=None)

    def download(self):
        with self.lock:
            if not self.offer or version_tuple(self.offer['manifest']['version']) <= version_tuple(__version__):
                raise UpdateError('Сначала проверьте наличие новой версии.')
        return self._begin(self._prepare)

    def _prepare(self):
        offer = self.offer
        manifest = offer['manifest']
        client = self.client()
        # Re-fetch by immutable release id: withdrawn/draft releases cannot install.
        fresh = self._read_offer(client, client.release(offer['release_id']))
        if fresh['raw'] != offer['raw'] or fresh['signature'] != offer['signature']:
            raise UpdateError('Состав релиза изменён. Проверьте обновления заново.')
        self.directory.mkdir(parents=True, exist_ok=True)
        if shutil.disk_usage(self.directory).free < max(1024 * 1024 * 1024, manifest['package']['size'] * 8):
            raise UpdateError('Для безопасной подготовки нужно минимум 1 ГБ свободного места.')
        identifier = manifest['version'] + '-' + uuid4().hex
        work = self.directory / 'downloads' / identifier
        work.mkdir(parents=True)
        archive = work / manifest['package']['name']
        self._set(phase='downloading', message='Скачиваем подписанный пакет…', progress=0)
        client.download(client.asset(client.release(offer['release_id']), manifest['package']['name']),
                        manifest['package']['size'], archive,
                        lambda count: self._set(progress=min(65, int(65 * count / manifest['package']['size']))), octet=True)
        candidate = self.directory / 'releases' / identifier
        self._set(phase='preparing', message='Проверяем файлы и готовим отдельное окружение Python…', progress=65)
        extract_package(archive, candidate, manifest)
        (work / MANIFEST_NAME).write_bytes(offer['raw'])
        (work / SIGNATURE_NAME).write_bytes(offer['signature'])
        self._prepare_runtime(candidate, work / 'prepare.log')
        verify_tree(candidate, manifest)
        receipt = {'candidate': str(candidate.relative_to(self.root)), 'metadata': str(work.relative_to(self.root)),
                   'version': manifest['version'], 'release_id': offer['release_id']}
        atomic_json(work / 'receipt.json', receipt)
        self._set(phase='ready', message='Обновление скачано и проверено. Можно установить с перезапуском.', progress=100,
                  latest_version=manifest['version'], candidate=receipt['candidate'], receipt=str((work / 'receipt.json').relative_to(self.root)))

    def _prepare_runtime(self, candidate, log):
        flags = subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0
        runtime = candidate / '.venv'
        python = runtime / ('Scripts/python.exe' if os.name == 'nt' else 'bin/python')
        # The final environment path never moves; Windows venv launchers contain absolute paths.
        commands = [[sys.executable, '-m', 'venv', str(runtime)],
                    [str(python), '-m', 'pip', '--disable-pip-version-check', 'install', '--no-input', '-r', str(candidate / 'requirements-lock.txt')],
                    [str(python), '-c', 'import murer.api, murer.updates; import selenium, keyring, openpyxl; print("imports-ok")']]
        with Path(log).open('wb') as output:
            for command in commands:
                try:
                    subprocess.run(command, cwd=candidate, stdout=output, stderr=subprocess.STDOUT,
                                   check=True, timeout=900, creationflags=flags)
                except (subprocess.SubprocessError, OSError) as error:
                    raise UpdateError('Не удалось подготовить зависимости Python. Рабочая версия не изменена. Проверьте интернет и файл prepare.log в папке обновлений.') from error

    def request_install(self, rollback=False):
        with self.lock:
            if self.worker and self.worker.is_alive():
                raise UpdateError('Дождитесь подготовки обновления.')
            if not os.environ.get('MURER_LAUNCHER_SESSION'):
                raise UpdateError('Для установки запустите программу через start.cmd.')
            if (self.root / '.git').exists():
                raise UpdateError('Это папка разработки с Git. Для обновления используйте отдельную установленную копию из ZIP релиза; исходники здесь сохраняются.')
            reason = self.busy()
            if reason:
                raise UpdateError(reason)
            if rollback:
                active = read_json(self.directory / 'active.json')
                previous = active.get('previous')
                if not previous:
                    raise UpdateError('Предыдущая версия для возврата отсутствует.')
                candidate = self.root / previous['slot']
                supported = max((int(p.name.split('_')[0]) for p in (candidate / 'murer' / 'migrations').glob('*.sql')), default=0)
                current = max((r['version'] for r in self.store.rows('SELECT version FROM schema_migrations')), default=0)
                if supported < current:
                    raise UpdateError('Предыдущая версия не поддерживает текущую схему базы. Автовозврат запрещён, чтобы не потерять новые данные. Нужны экспорт и отдельное восстановление резервной копии.')
                target = previous
            else:
                if self.state['phase'] != 'ready' or not self.state.get('receipt'):
                    raise UpdateError('Сначала скачайте и подготовьте обновление.')
                receipt_path = self.root / self.state['receipt']
                receipt = read_json(receipt_path)
                metadata = self.root / receipt['metadata']
                raw, signature = (metadata / MANIFEST_NAME).read_bytes(), (metadata / SIGNATURE_NAME).read_bytes()
                manifest = verify_manifest(raw, signature, self.config['public_keys'])
                if manifest['version'] != receipt['version'] or version_tuple(manifest['version']) <= version_tuple(__version__):
                    raise UpdateError('Подготовленная версия больше не является новой. Проверьте обновления заново.')
                fresh = self._read_offer(self.client(), self.client().release(receipt['release_id']))
                if fresh['raw'] != raw or fresh['signature'] != signature:
                    raise UpdateError('Релиз изменён или отозван. Проверьте обновления заново.')
                verify_tree(self.root / receipt['candidate'], manifest)
                target = {'slot': receipt['candidate'], 'version': receipt['version'], 'receipt': self.state['receipt']}
            request = {'id': uuid4().hex, 'session': os.environ['MURER_LAUNCHER_SESSION'],
                       'kind': 'rollback' if rollback else 'update', 'target': target,
                       'database': str(self.store.path.resolve()), 'created_at': time.time()}
            atomic_json(self.directory / 'pending.json', request)
            self._set(phase='installing', message='Перезапускаем программу для установки…')
            return {'status': 'installing', 'version': target['version']}

    def start_auto_check(self):
        if not os.environ.get('MURER_LAUNCHER_SESSION'):
            return
        def run():
            if self.stop_event.wait(15):
                return
            while not self.stop_event.is_set():
                try:
                    if self.status()['auto_check'] and not self.trial:
                        self.check()
                except (ValueError, OSError):
                    pass
                self.stop_event.wait(6 * 60 * 60)
        self.auto_thread = threading.Thread(target=run, name='murer-update-check', daemon=True)
        self.auto_thread.start()

    def close(self):
        self.stop_event.set()
        if self.auto_thread:
            self.auto_thread.join(timeout=1)
