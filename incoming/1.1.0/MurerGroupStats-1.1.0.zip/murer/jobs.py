"""Durable safe-step workers. Every session has a single ordered command stream."""
import asyncio
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone, timedelta
import json
import threading
import time
from uuid import uuid4

from xgenius.config import Config
from xgenius.logger import Logger
from xgenius.models import AccountCredentials
from .runtime import FileLease
from .secrets import redact
from .storage import encode, utcnow


class StopRequested(Exception):
    pass


class SafeLogger:
    def __init__(self, base, values):
        self.base, self.values = base, values

    def info(self, message, account=None):
        self.base.info(redact(message, self.values), account)

    def warning(self, message, account=None):
        self.base.warning(redact(message, self.values), account)

    def error(self, message, account=None):
        self.base.error(redact(message, self.values), account)


class JobControl:
    def __init__(self):
        self.condition = threading.Condition()
        self.paused = False
        self.stopped = False
        self.manual_generation = 0
        self.profiles = {}
        self.profile_lock = threading.Lock()
        self.progress_lock = threading.Lock()
        self.counters = {'unique_profiles': 0, 'cache_hits': 0, 'errors': 0, 'skipped': 0}
        self.checked_ids = set()
        self.accounts = {}
        self.pending_checkpoints = {}
        self.checkpoint_times = {}
        self.checkpoint_lock = threading.Lock()
        self.started_at = time.monotonic()
        self.launch_lock = threading.Lock()
        self.last_account_start = None
        self.priority_requested = False
        self.cleanup_failed = False

    def checkpoint(self):
        with self.condition:
            while self.paused and not self.stopped and not self.priority_requested:
                self.condition.wait(0.5)
            if self.stopped or self.priority_requested:
                raise StopRequested()

    def wait_manual(self, generation):
        with self.condition:
            while self.manual_generation == generation and not self.stopped and not self.priority_requested:
                self.condition.wait(0.5)
        self.checkpoint()


class JobManager:
    def __init__(self, store, secrets, configuration, publish, session_factory=None):
        self.store, self.secrets, self.configuration = store, secrets, configuration
        self.publish = publish
        self.session_factory = session_factory
        self.controls = {}
        self.threads = {}
        self.lock = threading.RLock()
        self.priority_owner = None
        self.closing = False
        self.browser_cleanup_failed = False
        self.snapshot_callback = lambda job_id: None
        self.recover_store()

    def recover_store(self):
        """Recover both startup and a first-run attachment of an existing DB."""
        self.store.execute("UPDATE jobs SET status='interrupted',error='Приложение перезапущено. Продолжите с сохранённого шага.' WHERE status IN ('running','queued','paused','requires_manual','stopping','yielding_trade','suspended_trade')")
        self.store.execute("UPDATE accounts SET status='session_expired',reason='Проверьте сессию после перезапуска' WHERE status IN ('active','login','collecting','paused','requires_manual')")

    def assert_browser_cleanup(self):
        if self.browser_cleanup_failed:
            raise ValueError('Закрытие предыдущего браузера не подтверждено. Перезапустите приложение перед новым сбором или Trade.')

    def start(self, account_ids, mode, group_ids=None):
        if mode not in ('collect', 'login', 'discover', 'retry'):
            raise ValueError('Неизвестный режим задания')
        if not account_ids:
            raise ValueError('Выберите хотя бы один аккаунт')
        if len(set(account_ids)) != len(account_ids):
            raise ValueError('Аккаунты в задании не должны повторяться')
        for aid in account_ids:
            account = self.store.account(aid)
            if not account or account['archived']:
                raise ValueError('Выбранный аккаунт отсутствует в рабочем списке')
        with self.lock:
            self.assert_browser_cleanup()
            if self.priority_owner or any(t.is_alive() for t in self.threads.values()):
                raise ValueError('Уже выполняется задание. Дождитесь окончания или остановите его.')
            settings, version = self.store.settings()
            job_id = str(uuid4())
            now = utcnow()
            self.store.execute('INSERT INTO jobs VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',
                (job_id, mode, encode(account_ids), encode(group_ids or []), 'queued', now, now,
                 encode(settings), version, encode({}), None, None))
            self._launch(job_id)
        return self.store.job(job_id)

    def _launch(self, job_id):
        control = JobControl()
        self.controls[job_id] = control
        thread = threading.Thread(target=self._run, args=(job_id, control), name='collection-'+job_id, daemon=False)
        self.threads[job_id] = thread
        thread.start()
        self.publish({'type': 'jobs'})

    def command(self, job_id, action):
        with self.lock:
            if self.priority_owner and action != 'stop':
                raise ValueError('Сейчас работает Trade. Сбор возобновится после обмена.')
            job = self.store.job(job_id)
            if not job:
                raise ValueError('Задание не найдено')
            control = self.controls.get(job_id)
            alive = self.threads.get(job_id) and self.threads[job_id].is_alive()
            if action in ('resume', 'retry', 'continue') and not alive:
                self.assert_browser_cleanup()
                if any(t.is_alive() for t in self.threads.values()):
                    raise ValueError('Сначала завершите текущее задание')
                if action == 'retry':
                    self.store.execute("DELETE FROM job_steps WHERE job_id=? AND status!='done'", (job_id,))
                self.store.job_update(job_id, status='queued', error=None, finished_at=None)
                self._launch(job_id)
            elif not alive:
                if action == 'stop':
                    self.store.job_update(job_id, status='stopped', finished_at=utcnow())
                else:
                    raise ValueError('Это задание уже завершено')
            else:
                with control.condition:
                    if action == 'pause':
                        control.paused = True
                        self.store.job_update(job_id, status='paused')
                        for aid in control.accounts:
                            if self.store.account(aid)['status'] == 'collecting':
                                self.store.account_status(aid, 'paused')
                    elif action in ('resume', 'continue', 'retry'):
                        control.paused = False
                        for aid in control.accounts:
                            if self.store.account(aid)['status'] == 'paused':
                                self.store.account_status(aid, 'collecting')
                        if action == 'continue':
                            control.manual_generation += 1
                        self.store.job_update(job_id, status='running')
                    elif action == 'stop':
                        control.stopped = True
                        self.store.job_update(job_id, status='stopping')
                    else:
                        raise ValueError('Неизвестная команда')
                    control.condition.notify_all()
        self.publish({'type': 'jobs'})
        return self.store.job(job_id)

    def _progress(self, job_id, control, account_id, values):
        values = dict(values)
        checkpoint_data = values.pop('checkpoint_data', None)
        if checkpoint_data:
            target = checkpoint_data.get('group_x_id') or checkpoint_data.get('participant_id') or ''
            with control.checkpoint_lock:
                control.pending_checkpoints[(account_id, checkpoint_data['kind'], target)] = checkpoint_data
            self._persist_checkpoints(job_id, control, account_id)
        with control.progress_lock:
            control.accounts[account_id] = {**control.accounts.get(account_id, {}), **values}
            progress = {**control.counters, 'accounts': dict(control.accounts), **control.accounts[account_id]}
            progress['elapsed_seconds'] = round(time.monotonic() - control.started_at)
            current = control.accounts[account_id]
            if (current.get('profile_index') or 0) > 1 and current.get('profile_total'):
                done = max(1, control.counters['unique_profiles'] + control.counters['cache_hits'])
                limit = self.store.job(job_id)['settings']['collection'].get('profiles_limit', 0)
                expected = min(current['profile_total'], limit) if limit else current['profile_total']
                remaining = max(0, expected - current['profile_index'])
                progress['eta_seconds'] = round(progress['elapsed_seconds'] / done * remaining)
                progress['eta_scope'] = 'Текущая группа; приблизительно, без ещё не открытых групп'
            current_status = self.store.job(job_id)['status']
            values = {'progress': progress}
            if current_status in ('running', 'requires_manual', 'paused') and not control.stopped and not control.priority_requested:
                # A manual gate belongs to an account, not every worker. After
                # continuation clear it, but keep the button for other waiters.
                manual = any(a.get('manual_reason') and a.get('launch_state') != 'finished'
                             for a in control.accounts.values())
                values['status'] = 'paused' if control.paused else 'requires_manual' if manual else 'running'
            self.store.job_update(job_id, **values)
        self.publish({'type': 'progress', 'job_id': job_id, 'progress': progress})

    def _persist_checkpoints(self, job_id, control, account_id, force=False):
        job = self.store.job(job_id)
        interval = job['settings']['collection']['save_interval_seconds']
        changed = False
        with control.checkpoint_lock:
            for key, data in list(control.pending_checkpoints.items()):
                if key[0] != account_id:
                    continue
                now = time.monotonic()
                if not force and now - control.checkpoint_times.get(key, 0) < interval:
                    continue
                if data['kind'] == 'groups':
                    for group in data.get('groups', []):
                        self.store.upsert_group(group, account_id)
                elif data['kind'] == 'members':
                    rows = self.store.rows('SELECT id FROM groups WHERE x_id=?', (str(data['group_x_id']),))
                    if not rows:
                        continue
                    self.store.save_members(job_id, rows[0]['id'], account_id,
                        {**data, 'status': 'partial', 'reason': 'Промежуточное сохранение списка; окончание ещё не подтверждено'})
                elif data['kind'] == 'profile' and data.get('participant_id'):
                    observation = dict(data['result'])
                    if observation.get('status') in ('full', 'partial', None):
                        observation['status'] = 'partial'
                    self.store.save_profile(job_id, data['participant_id'], account_id, observation)
                else:
                    continue
                control.checkpoint_times[key] = now
                control.pending_checkpoints.pop(key, None)
                changed = True
        if changed:
            self.publish({'type': 'analysis'})

    def _checkpoint(self, job_id, control, account_id):
        if control.paused or control.stopped or control.priority_requested:
            self._persist_checkpoints(job_id, control, account_id, force=True)
        control.checkpoint()

    def _run(self, job_id, control):
        job = self.store.job(job_id)
        self.store.job_update(job_id, status='running')
        outcomes = []
        try:
            workers = job['settings']['collection']['concurrent_accounts']
            for index, aid in enumerate(job['account_ids'], 1):
                self._progress(job_id, control, aid, {'account_id': aid, 'account_index': index,
                    'account_total': len(job['account_ids']), 'launch_state': 'queued', 'operation': 'Аккаунт в очереди'})
            with ThreadPoolExecutor(max_workers=workers, thread_name_prefix='account') as pool:
                futures = [pool.submit(self._account_thread, job, control, aid, index) for index, aid in enumerate(job['account_ids'], 1)]
                for future in futures:
                    outcomes.append(future.result())
            status = 'stopped' if control.stopped else 'suspended_trade' if control.priority_requested else ('partial' if any(x != 'full' for x in outcomes) else 'completed')
            self.store.job_update(job_id, status=status, finished_at=utcnow())
        except Exception as error:
            self.store.job_update(job_id, status='error', error=redact(error), finished_at=utcnow())
        finally:
            try:
                self.snapshot_callback(job_id)
            except Exception as error:
                self.store.error(job_id, None, '', 'snapshot', redact(error))
            self.publish({'type': 'jobs'})
            self.publish({'type': 'analysis'})

    def _account_thread(self, job, control, account_id, index):
        loop = asyncio.new_event_loop()
        # Foundation run_in_executor calls stay ordered and run on one command thread.
        loop.set_default_executor(ThreadPoolExecutor(max_workers=1, thread_name_prefix='webdriver-'+account_id))
        asyncio.set_event_loop(loop)
        try:
            return loop.run_until_complete(self._collect_account(job, control, account_id, index))
        finally:
            loop.run_until_complete(loop.shutdown_default_executor())
            loop.close()

    def _wait_account_start(self, job, control, account_id, progress):
        """One launch gate per run; waiting never creates an extra browser.

        The executor bounds all live sessions, including manual confirmation.
        The interval is between admission to launch, not browser page load times.
        """
        interval = job['settings']['collection'].get('account_start_interval_seconds', 0)
        reported = False
        with control.launch_lock:
            while True:
                control.checkpoint()
                remaining = 0 if control.last_account_start is None else interval - (time.monotonic() - control.last_account_start)
                if remaining <= 0:
                    progress({'operation': 'Запуск аккаунта', 'launch_state': 'started',
                              'account_started_at': utcnow(), 'launch_wait_seconds': 0})
                    control.last_account_start = time.monotonic()
                    return
                if not reported:
                    progress({'operation': 'Ожидание интервала запуска аккаунтов',
                              'launch_state': 'waiting', 'launch_wait_seconds': round(remaining, 1)})
                    reported = True
                with control.condition:
                    control.condition.wait(min(.25, remaining))

    async def _collect_account(self, job, control, account_id, index):
        from .collector import SeleniumSession
        account = self.store.account(account_id)
        private = self.secrets.get(account_id)
        credentials = AccountCredentials(username=account['username'], password=private['password'],
            proxy=private['proxy'] or None, user_agent=account.get('user_agent'), headless=account['headless'],
            group=account.get('group'), auth_token=private['auth_token'] or None, ct0_token=private['ct0_token'] or None,
            ichat_password=private.get('ichat_password') or None)
        config = Config(self.store.data_dir)
        config.profile_key = account.get('profile_key') or account['username']
        config.chrome_path = self.configuration['chrome_path']
        config.chromedriver_path = self.configuration['driver_path']
        logger = SafeLogger(Logger(config), private.values())
        session, lease = None, None
        progress = lambda values: self._progress(job['id'], control, account_id,
            {'account_id': account_id, 'username': account['username'], 'account_index': index,
             'account_total': len(job['account_ids']), **values})
        def synchronize_identity(identity):
            old_username=account['username']
            updated,changed=self.store.sync_account_identity(account_id,identity)
            account.update(updated)
            if changed:
                progress({'operation':f'Логин обновлён: @{old_username} → @{updated["username"]}',
                          'username':updated['username'],'account':updated['username'],'previous_username':old_username})
            self.publish({'type':'accounts'})
        config.account_identity_handler=synchronize_identity
        try:
            control.checkpoint()
            lease = FileLease(config.get_profile_dir(credentials.username) / '.murer-profile.lock')
            self._wait_account_start(job, control, account_id, progress)
            factory = self.session_factory or SeleniumSession
            checkpoint = lambda: self._checkpoint(job['id'], control, account_id)
            session = factory(config, logger, job['settings'], checkpoint, progress)
            self.store.account_status(account_id, 'login')
            progress({'operation': 'Вход в аккаунт'})
            result = await session.login(credentials)
            while result.get('status') == 'requires_manual':
                generation = control.manual_generation
                manual_reason = redact(result.get('reason', 'Требуется ручное действие'),
                    (credentials.password,credentials.auth_token,credentials.ct0_token,credentials.proxy,credentials.ichat_password))
                self.store.account_status(account_id, 'requires_manual', manual_reason)
                self.store.job_update(job['id'], status='requires_manual')
                progress({'operation': 'Продолжить после ручного подтверждения','manual_reason':manual_reason})
                control.wait_manual(generation)
                credentials.ichat_password = self.secrets.get(account_id).get('ichat_password') or None
                logger.values = tuple(logger.values) + (credentials.ichat_password,)
                result = await session.continue_login(credentials)
            progress({'manual_reason':None})
            if result.get('status') not in ('active', 'full', 'ok'):
                self.store.account_status(account_id, result.get('status', 'error'), result.get('reason', 'Вход не выполнен'))
                self.store.error(job['id'], account_id, '', 'login', redact(result.get('reason', ''), private.values()))
                return 'partial'
            self.store.account_status(account_id, 'active')
            if job['mode'] == 'login':
                return 'full'
            self.store.account_status(account_id, 'collecting')
            groups_step = f'{account_id}:groups'
            discovery = self.store.done_step(job['id'], groups_step)
            if discovery is None:
                discovery = await self._retry(session, lambda: session.discover_groups(credentials), job, control, account_id, credentials)
                self.store.step(job['id'], groups_step, 'done' if discovery.get('status') == 'full' else 'partial', discovery)
            # A final result supersedes its pending intermediate checkpoint.
            with control.checkpoint_lock:
                control.pending_checkpoints.pop((account_id, 'groups', ''), None)
            group_rows = []
            self.store.save_discovery(account_id, discovery.get('groups', []), discovery.get('status', 'partial'))
            for group in discovery.get('groups', []):
                group_id = self.store.upsert_group(group, account_id)
                if not job['group_ids'] or group_id in job['group_ids'] or group['x_id'] in job['group_ids']:
                    group_rows.append({**group, 'id': group_id})
            outcome = 'full' if discovery.get('status') == 'full' else 'partial'
            if job['mode'] == 'discover':
                self.store.account_status(account_id, 'active')
                return outcome
            processed_ids, skipped_ids = set(), set()
            profile_limit = job['settings']['collection'].get('profiles_limit', 0)
            for group_index, group in enumerate(group_rows, 1):
                control.checkpoint()
                progress({'group_index': group_index, 'group_total': len(group_rows), 'group_name': group['name'],
                          'profile_index': None, 'profile_total': None, 'operation': 'Список участников'})
                key = f'{account_id}:members:{group["id"]}'
                saved = self.store.done_step(job['id'], key)
                if saved is None:
                    members = await self._retry(session, lambda: session.members(group), job, control, account_id, credentials)
                    participant_ids = self.store.save_members(job['id'], group['id'], account_id, members)
                    with control.checkpoint_lock:
                        control.pending_checkpoints.pop((account_id, 'members', str(group['x_id'])), None)
                    self.store.step(job['id'], key, 'done' if members.get('status') == 'full' else 'partial', {'participant_ids': participant_ids})
                    if members.get('status') != 'full':
                        outcome = 'partial'
                else:
                    participant_ids = saved['participant_ids']
                for profile_index, pid in enumerate(participant_ids, 1):
                    control.checkpoint()
                    if profile_limit and pid not in processed_ids and len(processed_ids) >= profile_limit:
                        outcome = 'partial'
                        with control.progress_lock:
                            control.counters['skipped'] += int(pid not in skipped_ids)
                        skipped_ids.add(pid)
                        continue
                    processed_ids.add(pid)
                    progress({'profile_index': profile_index, 'profile_total': len(participant_ids), 'operation': 'Просмотр профиля'})
                    if not await self._profile(session, job, control, account_id, pid, credentials):
                        outcome = 'partial'
                    await self._delay(control, job['settings']['collection']['profile_delay_seconds'])
                await self._delay(control, job['settings']['collection']['group_delay_seconds'])
            await self._delay(control, job['settings']['collection']['account_delay_seconds'])
            self.store.account_status(account_id, 'active')
            progress({'operation': 'Сбор завершён' if outcome == 'full' else 'Сбор завершён частично'})
            return outcome
        except StopRequested:
            self.store.account_status(account_id, 'paused', 'Сбор уступил очередь Trade' if control.priority_requested else 'Сбор остановлен на сохранённом шаге')
            return 'partial'
        except Exception as error:
            message = redact(error, private.values())
            self.store.account_status(account_id, 'error', message)
            self.store.error(job['id'], account_id, '', 'account', message)
            with control.progress_lock:
                control.counters['errors'] += 1
            progress({'operation': 'Ошибка аккаунта', 'reason': message})
            return 'partial'
        finally:
            try:
                self._persist_checkpoints(job['id'], control, account_id, force=True)
            finally:
                try:
                    if session:
                        await session.close()
                except Exception:
                    control.cleanup_failed = True
                    self.browser_cleanup_failed = True
                    raise
                finally:
                    if lease:
                        lease.close()
                    logger.base.close()
                    progress({'launch_state': 'finished'})

    async def _retry(self, session, operation, job, control, account_id, credentials):
        recoveries = 0
        for attempt in range(job['settings']['collection']['retries'] + 1):
            control.checkpoint()
            try:
                result = await operation()
                while result.get('status') in ('requires_manual', 'session_expired'):
                    status = result['status']
                    safe_reason = redact(result.get('reason',''),
                        (credentials.password,credentials.auth_token,credentials.ct0_token,credentials.proxy,credentials.ichat_password))
                    self.store.account_status(account_id, status, safe_reason)
                    if status == 'session_expired':
                        recoveries += 1
                        if recoveries > job['settings']['collection']['retries'] + 1:
                            return {**result, 'status': 'error', 'reason': 'Сессия повторно истекает; сохранены доступные данные. Повторите вход вручную.'}
                        login = await session.login(credentials)
                    else:
                        generation = control.manual_generation
                        self.store.job_update(job['id'], status='requires_manual')
                        self._progress(job['id'], control, account_id, {'operation': 'Продолжить после ручного подтверждения','manual_reason':safe_reason or 'Требуется ручное действие'})
                        control.wait_manual(generation)
                        credentials.ichat_password = self.secrets.get(account_id).get('ichat_password') or None
                        login = await session.continue_login(credentials)
                    if login.get('status') not in ('active', 'full', 'ok'):
                        result = login
                        if result.get('status') not in ('requires_manual', 'session_expired'):
                            return result
                    else:
                        self._progress(job['id'],control,account_id,{'manual_reason':None})
                        self.store.account_status(account_id, 'collecting')
                        result = await operation()
                if result.get('status') != 'error' or attempt == job['settings']['collection']['retries']:
                    return result
            except StopRequested:
                raise
            except Exception:
                if attempt == job['settings']['collection']['retries']:
                    raise
            await self._delay(control, job['settings']['collection']['load_wait_seconds'])

    async def _profile(self, session, job, control, account_id, pid, credentials):
        key = f'{account_id}:profile:{pid}'
        saved = self.store.done_step(job['id'], key)
        if saved is not None:
            with control.progress_lock:
                control.counters['cache_hits'] += 1
            return saved.get('full', saved.get('status') == 'full')
        # Concurrent accounts wait for the same unique profile to finish, then use its observation.
        with control.profile_lock:
            entry = control.profiles.setdefault(pid, {'lock': threading.Lock(), 'available': False, 'full': False})
        while not entry['lock'].acquire(timeout=0.5):
            control.checkpoint()
        try:
            control.checkpoint()
            if entry['available']:
                with control.progress_lock:
                    control.counters['cache_hits'] += 1
                self.store.step(job['id'], key, 'done', {'cached_in_run': True, 'full': entry['full']})
                return entry['full']
            participant = self.store.participant(pid)
            collection = job['settings']['collection']
            if collection['refresh_mode'] != 'all':
                fresh_since = datetime.now(timezone.utc) - timedelta(hours=collection['cache_hours'])
                for obs in participant['observations']:
                    try:
                        fresh = collection['refresh_mode'] == 'missing' or datetime.fromisoformat(obs['observed_at'].replace('Z', '+00:00')) >= fresh_since
                    except ValueError:
                        fresh = False
                    required_days = max(collection['period_days'], job['settings']['evaluation']['reposts_days'], job['settings']['evaluation']['active_days'])
                    metrics_available = all((obs.get(field) or {}).get('value') is not None for field in ('followers', 'posts_total'))
                    volume_available = obs.get('viewed_count', len(obs.get('posts', []))) >= collection['posts_limit'] or (obs.get('period_complete') and obs.get('chronology_confirmed'))
                    if fresh and metrics_available and volume_available and obs['status'] in ('full', 'partial') and obs.get('requested_n', 0) >= collection['posts_limit'] and obs.get('requested_days', 0) >= required_days:
                        entry['available'] = True
                        entry['full'] = obs['status'] == 'full'
                        with control.progress_lock:
                            control.counters['cache_hits'] += 1
                        self.store.step(job['id'], key, 'done', {'cached': True, 'full': entry['full']})
                        return entry['full']
            observation = await self._retry(session, lambda: session.profile(participant), job, control, account_id, credentials)
            if observation.get('x_id') or observation.get('username'):
                identity = {**participant, 'x_id': observation.get('x_id') or participant.get('x_id'),
                            'username': observation.get('username') or participant['username'],
                            'name': observation.get('name') or participant.get('name'),
                            'url': observation.get('url') or participant['url']}
                actual_pid = self.store.identify(identity)
                if actual_pid != pid:
                    # A stable ID contradicting a reused handle stays separate;
                    # do not silently transfer membership between identities.
                    warning = 'Стабильный ID профиля отличается от участника в списке; сопоставление требует проверки'
                    self.store.save_profile(job['id'], actual_pid, account_id, observation)
                    self.store.error(job['id'], account_id, participant['url'], 'identity', warning)
                    observation = {'status': 'error', 'observed_at': observation['observed_at'],
                        'identity_warning': warning, 'reason': warning, 'resolved_participant_id': actual_pid,
                        'followers': {'raw': None, 'value': None, 'approximate': False},
                        'posts_total': {'raw': None, 'value': None, 'approximate': False}, 'posts': []}
            self.store.save_profile(job['id'], pid, account_id, observation)
            with control.checkpoint_lock:
                control.pending_checkpoints.pop((account_id, 'profile', pid), None)
            successful = observation.get('status') in ('full', 'partial')
            volume_available = observation.get('viewed_count', len(observation.get('posts', []))) >= collection['posts_limit'] or (observation.get('period_complete') and observation.get('chronology_confirmed'))
            entry['available'] = successful and volume_available and all((observation.get(field) or {}).get('value') is not None for field in ('followers', 'posts_total'))
            entry['full'] = observation.get('status') == 'full'
            with control.progress_lock:
                control.counters['unique_profiles'] += int(successful and pid not in control.checked_ids)
                if successful:
                    control.checked_ids.add(pid)
                control.counters['errors'] += int(not successful)
            self.store.step(job['id'], key, 'done' if successful else 'error', {'status': observation.get('status'), 'full': entry['full']})
            if not successful:
                self.store.error(job['id'], account_id, participant['url'], 'profile', redact(observation.get('reason', 'Профиль недоступен')))
            self.publish({'type': 'analysis'})
            return observation.get('status') == 'full'
        finally:
            entry['lock'].release()

    async def _delay(self, control, seconds):
        end = time.monotonic() + seconds
        while time.monotonic() < end:
            control.checkpoint()
            await asyncio.sleep(min(0.25, max(0, end-time.monotonic())))

    def close(self):
        self.closing = True
        for control in self.controls.values():
            with control.condition:
                control.stopped = True
                control.condition.notify_all()
        for thread in self.threads.values():
            thread.join(timeout=55)

    def reserve_priority(self, owner):
        """Stop browser work at a durable boundary and release its profiles."""
        with self.lock:
            self.assert_browser_cleanup()
            if self.priority_owner or self.closing:
                raise ValueError('Другой приоритетный процесс уже выполняется')
            self.priority_owner = owner
            previous = []
            for jid, thread in self.threads.items():
                if not thread.is_alive():
                    continue
                control = self.controls[jid]
                job = self.store.job(jid)
                previous.append({'id': jid, 'auto_resume': not control.paused and job['status'] != 'requires_manual'})
                with control.condition:
                    control.priority_requested = True
                    control.condition.notify_all()
                self.store.job_update(jid, status='yielding_trade')
            self.publish({'type': 'jobs'})
            return previous

    def release_priority(self, owner, previous, resume=True):
        with self.lock:
            if self.priority_owner != owner:
                return
            self.priority_owner = None
            for entry in previous:
                job = self.store.job(entry['id'])
                if not job or job['status'] not in ('suspended_trade', 'interrupted'):
                    continue
                if resume and not self.closing and not self.browser_cleanup_failed and entry['auto_resume']:
                    self.store.job_update(job['id'], status='queued', error=None, finished_at=None)
                    self._launch(job['id'])
                else:
                    self.store.job_update(job['id'], status='interrupted', error='Trade завершён. Продолжите сбор с сохранённого шага вручную.')
            self.publish({'type': 'jobs'})
