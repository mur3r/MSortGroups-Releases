"""Read-only Selenium actions. These helpers never press Enter or send messages."""
from __future__ import annotations

import asyncio
import inspect
import random
from typing import Callable

from human1 import Humanizer
from selenium.webdriver.support.ui import WebDriverWait
from xgenius.core.dom import DEEP_QUERY_JS


async def invoke(callback: Callable | None, *args):
    if callback is None:
        return None
    result = callback(*args)
    return await result if inspect.isawaitable(result) else result


class SafeActions:
    def __init__(self, browser, settings, checkpoint=None):
        self.browser = browser
        self.settings = settings
        self.checkpoint = checkpoint
        self.baseline = Humanizer()

    async def boundary(self):
        await invoke(self.checkpoint)

    async def call(self, function):
        await self.boundary()
        # Caller owns this browser's sequential queue; every call is awaited.
        return await asyncio.get_running_loop().run_in_executor(None, function)

    async def sleep(self, seconds):
        remaining = max(0.0, float(seconds))
        while remaining > 0:
            await self.boundary()
            portion = min(remaining, 0.25)
            await asyncio.sleep(portion)
            remaining -= portion

    async def delay(self):
        human = self.settings.get("humanization", {})
        collection = self.settings.get("collection", self.settings)
        if human.get("enabled", False):
            low = float(human.get("action_delay_min", self.baseline.pause_between_actions[0]))
            high = float(human.get("action_delay_max", self.baseline.pause_between_actions[1]))
            await self.sleep(random.uniform(low, high))
        else:
            await self.sleep(collection.get("action_delay_seconds", 0.5))

    async def get(self, url):
        await self.call(lambda: self.browser.get(url))
        await self.delay()

    async def script(self, script, *args):
        return await self.call(lambda: self.browser.execute_script(script, *args))

    async def wait(self, selector, timeout=15):
        return await self.call(lambda: WebDriverWait(self.browser, timeout).until(
            lambda browser: browser.execute_script(DEEP_QUERY_JS +
                'return deepQuery(arguments[0]);', selector) or False))

    async def find_all(self, selector):
        return await self.script(DEEP_QUERY_JS + 'return deepQueryAll(arguments[0]);', selector)

    async def click(self, element):
        # Deliberately reject known write controls even if a selector is wrong.
        label = await self.call(lambda: " ".join(str(element.get_attribute(key) or "")
            for key in ("data-testid", "aria-label", "title")))
        if any(token in label.lower() for token in ("send", "отправ", "retweet", "repost", "like", "follow", "leave", "join")):
            raise ValueError("Действие изменяет аккаунт и запрещено сборщиком")
        await self.call(element.click)
        await self.delay()

    async def search_input(self, element, text):
        """Character input for search only; rejects composers and line breaks."""
        if "\n" in text or "\r" in text or any(0xE000 <= ord(char) <= 0xF8FF for char in text):
            raise ValueError("Поисковый запрос не может содержать перевод строки")
        attrs = await self.call(lambda: {
            key: str(element.get_attribute(key) or "")
            for key in ("type", "role", "data-testid", "aria-label", "placeholder")})
        marker = " ".join(attrs.values()).lower()
        if any(value in marker for value in ("composer", "message", "сообщен")) or not (
            attrs["type"] == "search" or "search" in marker or "поиск" in marker):
            raise ValueError("Безопасный ввод разрешён только в поле поиска")
        await self.call(element.clear)
        human = self.settings.get("humanization", {})
        speed = self.baseline.typing_speed["normal"]
        for char in text:
            await self.call(lambda char=char: element.send_keys(char))
            if human.get("enabled", False):
                await self.sleep(random.uniform(float(human.get("typing_delay_min", speed[0])),
                                               float(human.get("typing_delay_max", speed[1]))))

    async def unlock_input(self, element, text, *, segmented=False):
        """Only IChatUnlock's verified gate calls this; never press Enter.

        Recheck the element immediately before input, since a page may change
        between detecting an unlock form and operating on its fields.
        """
        if not text or any(ord(char) < 32 or ord(char) == 127 or 0xE000 <= ord(char) <= 0xF8FF for char in text):
            raise ValueError("Некорректные символы пароля/PIN iChat")
        attrs = await self.call(lambda: {key: str(element.get_attribute(key) or "")
            for key in ("type", "maxlength", "inputmode", "name", "id", "autocomplete", "data-testid", "aria-label", "placeholder")})
        marker = " ".join(attrs.values()).lower()
        if any(value in marker for value in ("one-time-code", "verif", "otp", "captcha", "composer", "recovery", "confirm", "new-password")):
            raise ValueError("Поле не является существующим паролем/PIN iChat")
        if segmented:
            if attrs["maxlength"] != "1" or not text.isascii() or not text.isdigit() or len(text) != 1:
                raise ValueError("Сегмент PIN должен содержать одну цифру")
            if attrs["type"] not in ("password", "text", "tel", "number") or not (
                attrs["inputmode"] in ("numeric", "decimal") or any(value in marker for value in ("pin", "пин", "digit", "цифр"))):
                raise ValueError("Поле не является сегментом PIN")
        elif attrs["type"] != "password":
            raise ValueError("Ожидалось поле пароля iChat")
        await self.call(element.clear)
        human = self.settings.get("humanization", {})
        speed = self.baseline.typing_speed["normal"]
        for char in text:
            await self.call(lambda char=char: element.send_keys(char))
            if human.get("enabled", False):
                await self.sleep(random.uniform(float(human.get("typing_delay_min", speed[0])),
                                               float(human.get("typing_delay_max", speed[1]))))

    async def scroll(self, scope_selector=None):
        human = self.settings.get("humanization", {})
        collection = self.settings.get("collection", self.settings)
        pixels = int(random.uniform(human.get("scroll_step_min", 300), human.get("scroll_step_max", 700))) if human.get("enabled", False) else int(collection.get("scroll_step_pixels", 600))
        result = await self.script(DEEP_QUERY_JS + r"""
const root = arguments[0] ? deepQuery(arguments[0]) : document.scrollingElement;
if (!root) return {found:false};
let scroller = root;
if (root !== document.scrollingElement && root.scrollHeight <= root.clientHeight + 4) {
  const candidates = deepQueryAll('*', root).filter(el => {
    const style = getComputedStyle(el);
    return /(auto|scroll)/.test(style.overflowY) && el.scrollHeight > el.clientHeight + 4;
  });
  if (candidates.length) scroller = candidates[0];
}
const before = scroller.scrollTop;
scroller.scrollTop += arguments[1];
return {found:true, before,after:scroller.scrollTop,height:scroller.scrollHeight,
  at_bottom:scroller.scrollTop + scroller.clientHeight >= scroller.scrollHeight - 4};
""", scope_selector, pixels)
        await self.sleep(random.uniform(human.get("scroll_pause_min", 0.5), human.get("scroll_pause_max", 1.5)) if human.get("enabled", False) else float(collection.get("scroll_pause_seconds", 0.2)))
        return result
