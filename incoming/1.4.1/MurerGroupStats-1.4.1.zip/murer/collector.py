"""Sequential, read-only Selenium adapter for the preserved X-Genius foundation.

Group discovery, member expansion and profile headers were checked on a live
test account; post cards and additional layouts use explicit HTML fixtures.
See COLLECTION_VALIDATION.md for the exact scope. A changed/unsupported page
returns partial or unavailable data rather than invented members or zeroes.
"""
from __future__ import annotations

import asyncio
from copy import deepcopy
from contextlib import asynccontextmanager
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
from datetime import datetime, timedelta, timezone

from selenium.common.exceptions import TimeoutException

from xgenius.accounts import AccountManager
from xgenius.collectors.groups import GroupCollector
from xgenius.cookies import save_cookies
from xgenius.models import AccountCredentials, AuthStatus
from xgenius.process_utils import hard_close_browser
from xgenius.core import classify_driver_error
from xgenius.core.network import connection_failure, probe_connection
from xgenius.core.dom import DEEP_QUERY_JS
from murer.safe_actions import SafeActions, invoke
from murer.eventlog import session_step
from murer.ichat_unlock import IChatUnlock
from murer.parsing import parse_count, normalize_username, classify_card


def utcnow():
    return datetime.now(timezone.utc).isoformat()


MEMBERS_PROBE_JS = DEEP_QUERY_JS + r"""
const visible = el => !!el && !!(el.offsetWidth || el.offsetHeight || el.getClientRects().length);
const scopes = deepQueryAll('[role="dialog"], [data-testid="DMConversationDetails"], [data-testid="DmConversationDetails"], [data-testid="members-list"]');
const panel = scopes.find(el => visible(el) && /members|participants|people|участник|люди/i.test(el.innerText || ''));
if (!panel) return {panel_found:false,participants:[],loading:!!deepQuery('[role="progressbar"]')};
const text = panel.innerText || '';
const countMatch = text.match(/([\d\s,.]+)\s*(?:members|participants|people|участник(?:ов|а|и)?)/i)
  || text.match(/(?:members|participants|участники)\s*[:(]?\s*([\d\s,.]+)/i);
const cells = deepQueryAll('[data-testid="UserCell"], [data-user-id], [data-testid="member-row"]', panel);
const candidates = cells.length ? cells : deepQueryAll('a[href]', panel).filter(a => /^\/[^/]+\/?$/.test(new URL(a.href).pathname));
const excluded = new Set(['home','explore','notifications','messages','i','settings','compose','search','login','logout','premium','jobs']);
const participants = [];
for (const cell of candidates) {
  const links = cell.matches('a[href]') ? [cell] : deepQueryAll('a[href]', cell);
  let x_id = cell.getAttribute('data-user-id') || null;
  let username = null, url = null;
  for (const a of links) {
    const path = new URL(a.href).pathname;
    const id = path.match(/^\/i\/user\/(\d+)\/?$/);
    if (id) x_id = id[1];
    const handle = path.match(/^\/([A-Za-z0-9_]{1,15})\/?$/);
    if (handle && !excluded.has(handle[1].toLowerCase())) {username=handle[1];url='https://x.com/'+username;break;}
  }
  if (!username && !x_id) continue;
  const name = (cell.innerText || '').split('\n').find(line => line.trim() && !line.trim().startsWith('@')) || username || x_id;
  participants.push({x_id,username,name:name.trim(),url:url || 'https://x.com/i/user/'+x_id,
      identity_origin:x_id ? 'dom_stable_id' : 'profile_link_username'});
}
const endText = deepQueryAll('[role="status"], [data-testid="members-end"]', panel).map(el=>el.innerText || '').join(' ');
return {panel_found:true,participants,declared_raw:countMatch ? countMatch[1].trim() : null,
  confirmed_end:/all members loaded|end of members|все участники загружены|конец списка участников/i.test(endText),
  loading:!!deepQuery('[role="progressbar"]', panel), title:text.split('\n')[0]};
"""


PROFILE_PROBE_JS = DEEP_QUERY_JS + r"""
const q = s => deepQuery(s);
const main = q('[data-testid="primaryColumn"]') || q('main') || document.body;
const nameNode = main.querySelector('[data-testid="UserName"]');
const handleMatch = nameNode ? (nameNode.innerText || '').match(/@([A-Za-z0-9_]{1,15})\b/) : null;
const profilePath = location.pathname.match(/^\/([A-Za-z0-9_]{1,15})\/?$/);
const username = handleMatch ? handleMatch[1] : profilePath ? profilePath[1] : null;
const header = main.querySelector('h2');
const headerText = header && header.parentElement ? header.parentElement.innerText || '' : '';
const explicitPosts = main.querySelector('[data-testid="profile-posts-count"]');
const postsMatch = headerText.match(/([\d\s.,]+\s*(?:K|M|B|тыс\.?|млн\.?|млрд\.?)?)\s*(?:posts|tweets|публикац\w*|пост\w*|твито\w*)/i);
const followers = main.querySelector("a[href$='/verified_followers'], a[href$='/followers']");
const countText = el => el ? (el.getAttribute('title') || el.innerText || '') : null;
const idNode = nameNode && nameNode.closest('[data-user-id]');
const identityRoot = nameNode && (nameNode.closest('[data-testid="UserProfileHeader_Items"]') || nameNode.parentElement);
const idLink = identityRoot ? identityRoot.querySelector('a[href^="/i/user/"]') : null;
let x_id = idNode ? idNode.getAttribute('data-user-id') : null;
if (!x_id && idLink) {const match = new URL(idLink.href).pathname.match(/^\/i\/user\/(\d+)/);if(match)x_id=match[1];}
let identity_origin=x_id ? 'dom_stable_id' : null;
// Verified live profile toolbar. Do not inspect recommendation follow buttons:
// only the sibling actions next to this profile's userActions menu identify it.
const actionsNode=main.querySelector('[data-testid="userActions"]');
const actionsRoot=actionsNode ? actionsNode.parentElement : null;
const actionIds=actionsRoot ? [...new Set(Array.from(actionsRoot.querySelectorAll('[data-testid]'))
  .map(el => (el.getAttribute('data-testid') || '').match(/^(\d+)-(?:follow|unfollow)$/))
  .filter(Boolean).map(match=>match[1]))] : [];
if(!x_id && actionIds.length===1) {x_id=actionIds[0];identity_origin='profile_header_action_id';}
const cards = deepQueryAll('article[data-testid="tweet"]', main).map(card => {
  const time = card.querySelector('a[href*="/status/"] time');
  const statusLink = time ? time.closest('a') : card.querySelector('a[href*="/status/"]');
  const match = statusLink ? new URL(statusLink.href).pathname.match(/^\/([^/]+)\/status\/(\d+)/) : null;
  const context = card.querySelector('[data-testid="socialContext"]');
  const social_context = context ? context.innerText || '' : '';
  const pinned = /pinned|закреплен|закреплён/i.test(social_context);
  const quote = !!card.querySelector('[data-testid="quoteTweet"], [data-testid="quote-tweet"]') ||
    Array.from(card.querySelectorAll('div[role="link"]')).some(el => el.querySelector('a[href*="/status/"]'));
  const reply = Array.from(card.querySelectorAll('span,div')).some(el => /^replying to$|^в ответ$|^ответ для$/i.test((el.innerText || '').trim()));
  return {id:match ? match[2] : null,url:statusLink ? statusLink.href.split('?')[0] : null,
    author:match ? match[1] : null,original_at:time ? time.getAttribute('datetime') : null,
    event_at:null,social_context,pinned,quote,reply,text:(card.innerText || '').slice(0,1500)};
});
const body = (main.innerText || '').slice(0,12000).toLowerCase();
const unavailable = /this account doesn't exist|this account doesn’t exist|account suspended|э[тт]ой учетной записи не существует|аккаунт заблокирован/.test(body);
const protectedProfile = /these posts are protected|эти публикации защищены|эти посты защищены/.test(body);
const end = main.querySelector('[data-testid="timeline-end"], [data-testid="emptyState"]');
const endText = end ? end.innerText || '' : '';
return {url:location.href,x_id,identity_origin,username,name:nameNode ? (nameNode.innerText || '').split('\n')[0] : null,
  header_found:!!nameNode || !!header, followers_raw:countText(followers),
  posts_raw:explicitPosts ? countText(explicitPosts) : postsMatch ? postsMatch[0].trim() : null,
  cards,unavailable,protected:protectedProfile,loading:!!main.querySelector('[role="progressbar"]'),
  confirmed_end:/no more posts|no posts yet|hasn't posted|hasn’t posted|больше нет публикаций|нет публикаций|ещё не публиковал/i.test(endText),
  chronology_confirmed:!!main.querySelector('[data-chronological="true"]')};
"""


class ProfileLock:
    """OS advisory lock; a crashed process automatically releases it."""
    def __init__(self, path: Path):
        self.path = path
        self.file = None

    def acquire(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.file = self.path.open("a+b")
        try:
            if self.path.stat().st_size == 0:
                self.file.write(b"0")
                self.file.flush()
            self.file.seek(0)
            if os.name == "nt":
                import msvcrt
                msvcrt.locking(self.file.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(self.file, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            self.file.close()
            self.file = None
            raise RuntimeError("Профиль Chrome уже используется другим процессом приложения") from None

    def release(self):
        if self.file:
            self.file.seek(0)
            if os.name == "nt":
                import msvcrt
                msvcrt.locking(self.file.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                import fcntl
                fcntl.flock(self.file, fcntl.LOCK_UN)
            self.file.close()
            self.file = None


class RedactedLogger:
    def __init__(self, logger):
        self.logger = logger
        self.secrets = []

    def configure(self, credentials):
        self.secrets = [str(value) for value in (credentials.password, credentials.auth_token,
            credentials.ct0_token, credentials.proxy, getattr(credentials, "ichat_password", None)) if value]

    def __getattr__(self, method):
        def log(message, *args, **kwargs):
            message = str(message)
            for secret in sorted(self.secrets, key=len, reverse=True):
                message = message.replace(secret, "[скрыто]")
            target = getattr(self.logger, method, None)
            if target:
                return target(message, *args, **kwargs)
        return log


class LocalAccountManager(AccountManager):
    def load_accounts(self):
        # Legacy JSON is imported by the application; do not write new tokens back.
        return []

    def save_accounts(self, accounts):
        raise RuntimeError("Новые секреты сохраняются в хранилище ОС")

    async def _check_login_locks(self, browser):
        found = await super()._check_login_locks(browser)
        if found:
            return found
        loop = asyncio.get_running_loop()
        challenge = await loop.run_in_executor(None, lambda: browser.execute_script(DEEP_QUERY_JS + r"""
const visible=el=>!!(el.offsetWidth || el.offsetHeight || el.getClientRects().length);
const challenge=deepQueryAll('input[name="verif_code"], input[autocomplete="one-time-code"], iframe[src*="captcha"], iframe[src*="arkose"], input[data-testid="ocfEnterTextTextInput"]').some(visible);
const chatPin=location.pathname.startsWith('/i/chat') && deepQueryAll('input[type="password"], input[inputmode="numeric"], [data-testid*="pin" i] input').some(visible);
return challenge || chatPin;
"""))
        return "MANUAL CONFIRMATION" if challenge else None


class SeleniumSession:
    def __init__(self, config, logger, settings, checkpoint=None, progress=None):
        self.config = config
        self.settings = settings
        self.checkpoint = checkpoint
        self.progress = progress
        # Optional application overrides; foundation-only callers retain its
        # original timeouts and character input delays.
        for key, default in {
            "page_load_timeout_seconds": 45, "script_timeout_seconds": 30,
            "login_typing_delay_min": 0.05, "login_typing_delay_max": 0.15,
            "login_element_timeout_seconds": 15, "login_poll_rounds": 12,
            "login_poll_seconds": 2.5, "login_page_wait_seconds": 2,
            "login_step_wait_seconds": 1, "login_button_timeout_seconds": 10,
        }.items():
            setattr(config, key, self.collection.get(key, default))
        config.login_checkpoint = checkpoint
        self.logger = RedactedLogger(logger)
        self.manager = LocalAccountManager(config, self.logger)
        self.username = None
        self.actions = None
        self._member_declared_count = None
        self.profile_lock = None
        self.queue = asyncio.Lock()
        self._ichat_password = None
        self._reset_ichat_unlock()

    @property
    def collection(self):
        return self.settings.get("collection", self.settings)

    @property
    def browser(self):
        state = self.manager.accounts.get(self.username)
        return state.browser if state else None

    async def _check(self):
        await invoke(self.checkpoint)

    async def _report(self, **values):
        await invoke(self.progress, values)

    def _reset_ichat_unlock(self):
        self._ichat_unlock_events = []
        self._ichat_password_used = False
        self._ichat_auto_unlock_pending = False
        self._ichat_auto_unlock_candidate = False
        self._ichat_real_auto_unlock_confirmed = False
        self._ichat_unlock = IChatUnlock(on_event=self._ichat_unlock_event)

    async def _ichat_unlock_event(self, observation):
        # Only fixed public enum names and timestamps enter progress storage.
        event = observation.get('event')
        if event not in IChatUnlock.EVENTS | {'chat_ready'}:
            return
        if event == 'input_completed':
            self._ichat_password_used = True
            self._ichat_auto_unlock_pending = True
        elif event == 'gate_absent' and self._ichat_auto_unlock_pending:
            self._ichat_auto_unlock_candidate = True
        elif event == 'manual':
            self._ichat_auto_unlock_pending = False
            self._ichat_auto_unlock_candidate = False
        elif event == 'chat_ready':
            self._ichat_real_auto_unlock_confirmed = self._ichat_password_used and self._ichat_auto_unlock_candidate
        self._ichat_unlock_events.append({'event': event, 'timestamp': utcnow()})
        self._ichat_unlock_events = self._ichat_unlock_events[-100:]
        await self._report(ichat_unlock_event=event,
            ichat_unlock_events=deepcopy(self._ichat_unlock_events),
            ichat_password_used=self._ichat_password_used,
            real_auto_unlock_confirmed=self._ichat_real_auto_unlock_confirmed,
            operation={
                'gate_ready': 'iChat: распознана форма разблокировки',
                'input_completed': 'iChat: ввод завершён',
                'submit_clicked': 'iChat: нажато продолжение',
                'auto_advanced': 'iChat: форма перешла к следующему экрану',
                'gate_absent': 'iChat: форма блокировки отсутствует',
                'manual': 'iChat: требуется ручное действие',
                'chat_ready': 'iChat: доступны групповые чаты',
            }[event])

    @asynccontextmanager
    async def _scanning(self):
        state = self.manager.accounts.get(self.username)
        if state:
            state.is_scanning = True
        try:
            yield
        finally:
            if state:
                state.is_scanning = False

    def _bind(self):
        if self.browser:
            self.actions = SafeActions(self.browser, self.settings, self.checkpoint, audit=self.logger.event,
                                       proxy_configured=getattr(self,'_proxy_configured',False))

    async def _identity_after_login(self, credentials, result):
        if result.get('status')!='active':
            return result
        from .account_identity import read_signed_in_identity
        from .storage import AccountIdentityConflict
        async with self.queue, self._scanning():
            identity=await read_signed_in_identity(self.actions,self.browser,self.collection,self._page_gate)
            if identity.get('verified') is not True:
                return identity
            actual=identity['username']
            previous=self.username
            state=self.manager.accounts.get(previous)
            if actual in self.manager.accounts and self.manager.accounts[actual] is not state:
                return {'status':'error','reason':'Открытая сессия конфликтует с другим аккаунтом; объединение отменено'}
            handler=getattr(self.config,'account_identity_handler',None)
            try:
                if handler:
                    handler(identity)
            except AccountIdentityConflict as error:
                return {'status':'error','reason':str(error)}
            if state and previous!=actual:
                self.manager.accounts.pop(previous)
                state.username=actual
                self.manager.accounts[actual]=state
            self.username=actual
            credentials.username=actual
            return {**result,'identity':identity}

    @session_step('auth', 'Вход в X')
    async def login(self, credentials: AccountCredentials):
        if not getattr(self.config,'profile_key',None):
            self.config.profile_key=credentials.username
        return await self._identity_after_login(credentials,await self._login(credentials))

    async def _login(self, credentials: AccountCredentials):
        async with self.queue:
            await self._check()
            if self.username and normalize_username(credentials.username) != normalize_username(self.username):
                raise RuntimeError("Одна сессия обслуживает только один аккаунт")
            self.username = credentials.username
            self._proxy_configured = bool(credentials.proxy)
            self.logger.configure(credentials)
            self._ichat_password = getattr(credentials, "ichat_password", None)
            if not self.profile_lock:
                self.profile_lock = ProfileLock(self.config.get_profile_dir(self.username) / ".murer.lock")
                try:
                    self.profile_lock.acquire()
                except RuntimeError as exc:
                    self.profile_lock = None
                    return {"status": "error", "reason": str(exc)}
            await self._report(operation="Вход в аккаунт", account=self.username)
            try:
                # Preserve cookie/profile -> auth_token/ct0 -> password and typing.
                self._reset_ichat_unlock()
                await self.manager.login_account(credentials, fetch_followers=False, notify=True)
                self._bind()
                return {"status": "active", "reason": "Авторизация подтверждена"}
            except Exception as exc:
                if type(exc).__name__ in ("StopRequested", "PauseRequested", "JobStopped"):
                    raise
                self._bind()
                state = self.manager.accounts.get(self.username)
                reason = state.status_reason if state else ""
                failure = connection_failure(exc,self._proxy_configured) or connection_failure(reason,self._proxy_configured)
                if failure:
                    return failure
                if self.browser:
                    try:
                        failure = await self.actions.call(lambda: probe_connection(self.browser,self._proxy_configured))
                    except Exception as probe_error:
                        if type(probe_error).__name__ in ('StopRequested','PauseRequested','JobStopped'):
                            raise
                        if classify_driver_error(probe_error)=='closed':
                            return {'status':'session_expired','reason':'Окно Chrome закрыто; повторите вход'}
                        failure = connection_failure(probe_error,self._proxy_configured)
                    if failure:
                        return failure
                if self.browser:
                    # The foundation can stop at an iChat gate before discovery
                    # gets to call _page_gate. Try the existing safe unlock path
                    # first; do not label a supported PIN form as manual early.
                    try:
                        current_url = await self.actions.call(lambda: self.browser.current_url)
                    except Exception as probe_error:
                        if type(probe_error).__name__ in ('StopRequested','PauseRequested','JobStopped'):
                            raise
                        current_url = ''
                    if isinstance(current_url,str) and re.match(r"^https://(?:www\.)?x\.com/i/chat(?:/|$)", current_url):
                        gate = await self._page_gate()
                        if gate:
                            return gate
                        if state and await self.manager._check_auth_state(self.browser) == AuthStatus.OK:
                            await self.manager._finalize_login(state, credentials, self.browser, "chat_unlock",
                                fetch_followers=False, notify=True, persist_cookies=True)
                            return {"status":"active","reason":"Авторизация подтверждена после проверки разблокировки iChat"}
                    try:
                        lock = await self.manager._check_login_locks(self.browser)
                    except Exception:
                        lock = None
                    if lock:
                        if lock == "BROWSER CLOSED":
                            return {"status": "session_expired", "reason": "Окно Chrome закрыто; повторите вход"}
                        if lock == "SUSPENDED":
                            return {"status": "error", "reason": "X сообщает о блокировке аккаунта; проверьте открытое окно"}
                        return {"status": "requires_manual", "reason": "Требуется ручное подтверждение; окно Chrome оставлено открытым"}
                text = str(exc).lower()
                if "proxy" in text or "proxy" in reason.lower():
                    return {"status": "proxy_error", "reason": "Не удалось подключиться через прокси; проверьте адрес и авторизацию"}
                # Login form may ask for phone/email/2FA without an explicit lock URL.
                if self.browser and ("поле пароля" in text or "таймаут" in text):
                    return {"status": "requires_manual", "reason": "Завершите вход в открытом окне Chrome и нажмите «Продолжить»"}
                return {"status": "error", "reason": "Вход не подтверждён. Проверьте учётные данные и открытое окно Chrome"}

    @session_step('auth', 'Продолжение входа после ручного действия')
    async def continue_login(self, credentials):
        if not getattr(self.config,'profile_key',None):
            self.config.profile_key=credentials.username
        return await self._identity_after_login(credentials,await self._continue_login(credentials))

    async def _continue_login(self, credentials):
        async with self.queue:
            await self._check()
            if not self.browser:
                return {"status": "not_authorized", "reason": "Окно Chrome закрыто; запустите вход снова"}
            self._ichat_password = getattr(credentials, "ichat_password", None)
            self.logger.configure(credentials)
            self._bind()
            gate = await self._page_gate()
            if gate:
                return gate
            status = await self.manager._check_auth_state(self.browser)
            if status == AuthStatus.OK:
                state = self.manager.accounts[self.username]
                await self.manager._finalize_login(state, credentials, self.browser, "manual",
                    fetch_followers=False, notify=True, persist_cookies=True)
                self._bind()
                return {"status": "active", "reason": "Ручной вход подтверждён; сессия сохранена"}
            return {"status": "requires_manual", "reason": "Авторизация ещё не подтверждена; завершите проверку в Chrome"}

    async def _page_gate(self):
        if not self.browser:
            return {"status": "error", "reason": "Браузер закрыт; повторите вход"}
        try:
            url = await self.actions.call(lambda: self.browser.current_url)
            failure = await self.actions.call(lambda: probe_connection(self.browser,getattr(self,'_proxy_configured',False)),
                                              action='Проверка сетевой ошибки Chrome',record=False)
            if failure:
                return failure
        except Exception as exc:
            if classify_driver_error(exc) == "closed":
                return {"status": "session_expired", "reason": "Браузер закрыт; восстановите сессию"}
            raise
        # Unlock only an existing, recognized chat gate, before the foundation
        # lock check treats it as manual confirmation. Both share this queue.
        if re.match(r"^https://(?:www\.)?x\.com/i/chat(?:/|$)", url):
            gate = await self._ichat_unlock.check(self.actions, self._ichat_password)
            if gate:
                return gate
            url = await self.actions.call(lambda: self.browser.current_url)
            # Verified live: after the last PIN digit the fields disappear
            # before X leaves /pin/recovery (key decryption is asynchronous).
            # Wait for navigation without replaying the secret or declaring
            # a manual gate solely from this transitional URL.
            if '/i/chat/pin/' in url and self._ichat_auto_unlock_candidate:
                await self._report(operation='iChat: ожидание загрузки после ввода PIN')
                rounds = max(1, int(self.collection.get('login_poll_rounds', 12)))
                for _ in range(rounds):
                    await self.actions.sleep(float(self.collection.get('login_poll_seconds', 2.5)))
                    url = await self.actions.call(lambda: self.browser.current_url)
                    if '/i/chat/pin/' not in url:
                        break
        lock = await self.manager._check_login_locks(self.browser)
        if lock:
            if lock == "BROWSER CLOSED":
                return {"status": "session_expired", "reason": "Браузер закрыт; восстановите сессию"}
            # A suspended participant profile is not a lock on our own account.
            participant_page = bool(re.fullmatch(r"https://(?:www\.)?x\.com/[A-Za-z0-9_]{1,15}/?", url))
            if lock not in ("SUSPENDED", "ACCESS DENIED") or not participant_page:
                return {"status": "requires_manual", "reason": "Требуется ручное подтверждение в Chrome"}
        if any(path in url for path in ("/i/flow/login", "/login", "/logout")):
            return {"status": "session_expired", "reason": "Сессия истекла; повторите вход"}
        if "/i/chat/pin/" in url:
            return {"status": "requires_manual", "reason": "XChat требует ручного подтверждения PIN. Завершите его в Chrome и нажмите «Продолжить после ручного подтверждения»"}
        if url.startswith("chrome-error:"):
            return connection_failure('CHROME_NETWORK_ERROR',getattr(self,'_proxy_configured',False))
        return None

    @session_step('collection', 'Поиск групп')
    async def discover_groups(self, credentials):
        async with self.queue, self._scanning():
            await self._check()
            if not self.actions:
                return {"groups": [], "status": "error", "reason": "Сначала авторизуйте аккаунт"}
            result = await GroupCollector(self.logger).discover_groups(self.browser, credentials.username,
                settings=self.settings, checkpoint=self.checkpoint, progress=self.progress, actions=self.actions,
                page_gate=self._page_gate)
            gate = await self._page_gate()
            if gate:
                result.update(gate)
            elif result.get('groups'):
                await self._ichat_unlock_event({'event': 'chat_ready'})
            result.update(ichat_password_used=self._ichat_password_used,
                real_auto_unlock_confirmed=self._ichat_real_auto_unlock_confirmed,
                ichat_unlock_events=deepcopy(self._ichat_unlock_events))
            for group in result["groups"]:
                group["observed_at"] = utcnow()
            return result

    async def _click_first(self, selectors):
        for selector in selectors:
            elements = await self.actions.find_all(selector)
            for element in elements:
                if await self.actions.call(element.is_displayed):
                    await self.actions.click(element)
                    return True
        return False

    async def _open_members(self):
        self._member_declared_count = None
        current = await self.actions.script(MEMBERS_PROBE_JS)
        if not current.get("panel_found"):
            clicked = await self._click_first([
                # Verified live XChat header: name/avatar opens details.
                '[data-testid="dm-conversation-header"] div.cursor-pointer',
                '[data-testid="DMConversationInfoButton"]', '[data-testid="dmConversationInfo"]',
                'button[aria-label="Conversation info"]', 'button[aria-label="Group info"]',
                'button[aria-label="Conversation details"]', 'button[aria-label="Информация о группе"]',
                '[data-testid="conversation-header"] button[data-testid="group-info"]',
                '[data-testid="DmConversationHeader"] button[aria-label*="info" i]',
            ])
            if not clicked:
                return False
            try:
                await self.actions.wait('[role="dialog"], [data-testid="DMConversationDetails"], [data-testid="DmConversationDetails"]',
                    float(self.collection.get("element_timeout_seconds", 15)))
            except TimeoutException:
                return False
            await self.actions.sleep(self.collection.get("load_wait_seconds", 1))
            current = await self.actions.script(MEMBERS_PROBE_JS)
        # The full roster dialog omits the count which is visible in details.
        # Carry that fresh observation across this read-only navigation.
        raw_count = parse_count(current.get("declared_raw"))
        if raw_count["value"] is not None and not raw_count["approximate"]:
            self._member_declared_count = int(raw_count["value"])
        expanded = await self._click_first([
            '[role="dialog"] [data-testid="members-button"]',
            '[data-testid="DMConversationDetails"] [data-testid="members-button"]',
            '[role="dialog"] button[aria-label="Members"]',
            '[role="dialog"] button[aria-label="Participants"]',
            '[role="dialog"] button[aria-label="Участники"]',
        ])
        if not expanded:
            # Verified live XChat: details show a 10-person preview and a
            # "View All" button next to the Members heading. Opening that
            # preview is necessary; it is never a complete roster by itself.
            buttons = await self.actions.script(DEEP_QUERY_JS + r"""
return deepQueryAll('[role="dialog"] button').filter(button => {
  const label=(button.innerText || '').trim();
  const section=button.parentElement ? button.parentElement.innerText || '' : '';
  return /^(?:view all|show all|показать всех|показать все|все участники)$/i.test(label)
    && /members|participants|участник/i.test(section);
});
""")
            for button in buttons:
                if await self.actions.call(button.is_displayed):
                    await self.actions.click(button)
                    expanded = True
                    break
        if expanded:
            await self.actions.sleep(self.collection.get("load_wait_seconds", 1))
        return bool((await self.actions.script(MEMBERS_PROBE_JS)).get("panel_found"))

    @session_step('collection', 'Чтение состава группы')
    async def members(self, group):
        async with self.queue, self._scanning():
            await self._check()
            participants, declared, reason = {}, None, "Достигнут предел прокрутки участников"
            if not self.actions:
                return {"participants": [], "status": "error", "reason": "Сначала авторизуйте аккаунт", "declared_count": None}
            try:
                await self.actions.get(group["url"])
                await self.actions.sleep(self.collection.get("load_wait_seconds", 1))
                try:
                    await self.actions.wait('[data-testid="dm-conversation-header"], [data-testid="DMConversationInfoButton"], [data-testid="dmConversationInfo"], [role="dialog"], [data-testid="DMConversationDetails"], [data-testid="members-list"]',
                        float(self.collection.get("element_timeout_seconds", 15)))
                except TimeoutException:
                    pass
                gate = await self._page_gate()
                if gate:
                    return {"participants": [], "declared_count": None, **gate}
                if not await self._open_members():
                    return {"participants": [], "status": "unavailable", "declared_count": None,
                        "reason": "Список участников не найден. Откройте сведения группы в Chrome и повторите; селекторы текущего iChat требуют проверки"}
                declared = self._member_declared_count
                idle, limit = 0, int(self.collection.get("member_scroll_limit", 100))
                for step in range(limit):
                    probe = await self.actions.script(MEMBERS_PROBE_JS)
                    before = len(participants)
                    raw_count = parse_count(probe.get("declared_raw"))
                    if raw_count["value"] is not None and not raw_count["approximate"]:
                        declared = int(raw_count["value"])
                    for person in probe.get("participants", []):
                        person["username"] = normalize_username(person.get("username")) or None
                        if not person.get("x_id") and not person["username"]:
                            continue
                        key = "id:" + str(person["x_id"]) if person.get("x_id") else "username:" + str(person["username"])
                        participants[key] = person
                    await self._report(operation="Сбор участников", group=group.get("name"),
                        members_found=len(participants), declared_count=declared, scroll=step + 1,
                        checkpoint_data={"kind": "members", "group_x_id": group.get("x_id"),
                            "participants": deepcopy(list(participants.values())), "declared_count": declared,
                            "status": "partial", "observed_at": utcnow(),
                            "reason": "Промежуточный состав; сбор ещё не завершён"})
                    # Publish the completed read before the next checkpoint:
                    # pausing during the gate must not discard this DOM batch.
                    gate = await self._page_gate()
                    if gate:
                        return {"participants": list(participants.values()), "declared_count": declared,
                            "observed_at": utcnow(), **gate}
                    if not probe.get("loading") and (probe.get("confirmed_end") or (declared is not None and len(participants) == declared)):
                        return {"participants": list(participants.values()), "status": "full", "declared_count": declared,
                            "observed_at": utcnow(), "reason": "Окончание списка подтверждено"}
                    idle = 0 if len(participants) > before else idle + 1
                    if idle >= int(self.collection.get("idle_scroll_limit", 4)) and not probe.get("loading"):
                        reason = "Загрузка участников остановилась; окончание списка не подтверждено"
                        break
                    await self.actions.scroll('[role="dialog"], [data-testid="DMConversationDetails"], [data-testid="members-list"]')
                    await self.actions.sleep(self.collection.get("load_wait_seconds", 1))
                return {"participants": list(participants.values()), "status": "partial", "declared_count": declared,
                    "observed_at": utcnow(), "reason": reason}
            except Exception as exc:
                if type(exc).__name__ in ("StopRequested", "PauseRequested", "JobStopped"):
                    raise
                failure = connection_failure(exc,getattr(self,'_proxy_configured',False))
                if failure:
                    return {"participants":list(participants.values()),"declared_count":declared,**failure}
                closed = classify_driver_error(exc) == "closed"
                return {"participants": list(participants.values()), "status": "session_expired" if closed else "partial" if participants else "error",
                    "declared_count": declared, "observed_at": utcnow(), "reason": "Ошибка чтения списка участников; сохранены уже найденные связи"}

    @session_step('collection', 'Чтение профиля и публикаций')
    async def profile(self, participant):
        async with self.queue, self._scanning():
            await self._check()
            n = int(self.collection.get("posts_limit", 100))
            evaluation = self.settings.get("evaluation", {})
            days = max(int(self.collection.get("period_days", 30)), int(evaluation.get("reposts_days", 30)), int(evaluation.get("active_days", 7)))
            result = {"observed_at": utcnow(), "status": "partial", "followers": parse_count(None),
                "posts_total": parse_count(None), "requested_n": n, "requested_days": days,
                "viewed_count": 0, "period_complete": False, "chronology_confirmed": False, "posts": [],
                "reason": "Хронологическая полнота периода интерфейсом не подтверждена"}
            if not self.actions:
                return {**result, "status": "error", "reason": "Сначала авторизуйте аккаунт"}
            try:
                username = normalize_username(participant.get("username"))
                profile_url = (f"https://x.com/i/user/{participant['x_id']}" if participant.get("x_id") else
                    participant.get("url")) or (f"https://x.com/{username}" if username else
                    f"https://x.com/i/user/{participant['x_id']}" if participant.get("x_id") else None)
                if not profile_url:
                    return {**result, "status": "unavailable", "reason": "У профиля нет подтверждённого идентификатора или ссылки"}
                await self.actions.get(profile_url)
                try:
                    await self.actions.wait('[data-testid="UserName"], [data-testid="primaryColumn"] h2, [data-testid="emptyState"]',
                        float(self.collection.get("element_timeout_seconds", 15)))
                except TimeoutException:
                    pass
                gate = await self._page_gate()
                if gate:
                    return {**result, **gate}
                posts, idle, profile_seen = {}, 0, False
                limit = int(self.collection.get("profile_scroll_limit", 50))
                for step in range(limit):
                    probe = await self.actions.script(PROFILE_PROBE_JS)
                    profile_seen = profile_seen or bool(probe.get("header_found") or probe.get("cards"))
                    if probe.get("unavailable"):
                        result.update(status="unavailable", reason="Интерфейс сообщает, что профиль недоступен")
                        break
                    # A virtualized page can remove its header while scrolling.
                    # Retain already readable fields, never replace them with null.
                    if probe.get("followers_raw") is not None:
                        result["followers"] = parse_count(probe.get("followers_raw"))
                    if probe.get("posts_raw") is not None:
                        result["posts_total"] = parse_count(probe.get("posts_raw"))
                    result["x_id"] = probe.get("x_id") or result.get("x_id") or participant.get("x_id")
                    username = normalize_username(probe.get("username")) or username
                    result["username"] = username
                    result["url"] = probe.get("url") or participant.get("url")
                    result["identity_origin"] = (probe.get("identity_origin") or
                        ("dom_stable_id" if probe.get("x_id") else result.get("identity_origin")) or
                        participant.get("identity_origin") or
                        ("dom_stable_id" if result["x_id"] else "profile_link_username"))
                    result["name"] = probe.get("name") or result.get("name") or participant.get("name")
                    before = len(posts)
                    for card in probe.get("cards", []):
                        item = classify_card(card, username)
                        # Anonymous cards are retained with stable local content identity.
                        key = item.get("id") or item.get("url") or json.dumps([item.get("original_at"), item.get("text")], ensure_ascii=False)
                        if key not in posts and len(posts) < n:
                            posts[key] = item
                        elif key in posts and posts[key]["type"] == "unknown" and item["type"] != "unknown":
                            posts[key] = item
                    result["viewed_count"] = len(posts)
                    result["posts"] = list(posts.values())
                    result["classified_count"] = sum(item["type"] != "unknown" for item in posts.values())
                    result["observed_at"] = utcnow()
                    await self._report(operation="Просмотр профиля", participant=username,
                        posts_viewed=len(posts), posts_limit=n, scroll=step + 1,
                        checkpoint_data={"kind": "profile", "participant_id": participant.get("id"),
                            "result": deepcopy(result)})
                    gate = await self._page_gate()
                    if gate:
                        result.update(gate)
                        break
                    chronology = bool(probe.get("chronology_confirmed"))
                    result["chronology_confirmed"] = chronology
                    cutoff = datetime.now(timezone.utc) - timedelta(days=days)
                    dated = [item for item in posts.values() if not item.get("pinned") and item.get("event_at")]
                    older = any(_before(item["event_at"], cutoff) for item in dated)
                    if not probe.get("loading") and (probe.get("confirmed_end") or (chronology and older)):
                        result["period_complete"] = chronology or (probe.get("confirmed_end") and len(posts) == 0)
                        # Empty, explicitly confirmed timeline proves zero events.
                        if len(posts) == 0 and probe.get("confirmed_end"):
                            result["chronology_confirmed"] = True
                        result["reason"] = "Период подтверждён" if result["period_complete"] else "Конец ленты достигнут, хронология периода не подтверждена"
                        break
                    if probe.get("protected"):
                        result["reason"] = "Публикации защищены; показатели шапки сохранены"
                        break
                    if len(posts) >= n:
                        result["reason"] = f"Просмотрено {n} элементов; период покрыт частично"
                        break
                    idle = 0 if len(posts) > before else idle + 1
                    if idle >= int(self.collection.get("idle_scroll_limit", 4)) and not probe.get("loading"):
                        result["reason"] = "Лента перестала загружаться; полнота периода не подтверждена"
                        break
                    await self.actions.scroll()
                    await self.actions.sleep(self.collection.get("load_wait_seconds", 1))
                result["posts"] = list(posts.values())
                result["classified_count"] = sum(item["type"] != "unknown" for item in posts.values())
                if not profile_seen and result["status"] == "partial":
                    result.update(status="unavailable", reason="Данные профиля не доступны через этот аккаунт")
                if result["status"] not in ("unavailable", "requires_manual", "session_expired", "proxy_error"):
                    result["status"] = "full" if result["period_complete"] and all(result[key]["value"] is not None for key in ("followers", "posts_total")) else "partial"
                result["observed_at"] = utcnow()
                return result
            except Exception as exc:
                if type(exc).__name__ in ("StopRequested", "PauseRequested", "JobStopped"):
                    raise
                failure = connection_failure(exc,getattr(self,'_proxy_configured',False))
                if failure:
                    return {**result,**failure}
                closed = classify_driver_error(exc) == "closed"
                result["status"] = "session_expired" if closed else "error"
                result["reason"] = "Браузер закрыт; восстановите сессию" if closed else "Ошибка чтения профиля; можно повторить через другой аккаунт"
                return result

    @session_step('browser', 'Сохранение сессии и закрытие браузера')
    async def close(self):
        async with self.queue:
            for state in self.manager.accounts.values():
                state.is_scanning = False
                if state.browser:
                    browser, state.browser = state.browser, None
                    try:
                        await asyncio.get_running_loop().run_in_executor(None,
                            lambda browser=browser: save_cookies(browser, self.config, state.username))
                    except Exception:
                        self.logger.warning('Не удалось сохранить cookies при закрытии браузера')
                    await asyncio.get_running_loop().run_in_executor(None, hard_close_browser, browser)
                state.humanizer.shutdown()
            for path in getattr(self.manager.browser_manager, "_proxy_temp_dirs", []):
                # Paths were created by this browser manager under its data folder.
                resolved = path.resolve()
                root = (self.config.base_dir / "temp_proxy_extension").resolve()
                if root in resolved.parents:
                    shutil.rmtree(resolved, ignore_errors=True)
            if self.profile_lock:
                self.profile_lock.release()
                self.profile_lock = None
            self.actions = None
            self._ichat_password = None


def _before(value, cutoff):
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
        if parsed.tzinfo is None:
            return False
        return parsed <= cutoff
    except (TypeError, ValueError):
        return False


def browser_versions(chrome_path, driver_path):
    """Read Windows binary version without launching a user's browser profile."""
    result = {"chrome_path": str(chrome_path), "chromedriver_path": str(driver_path),
        "chrome_version": None, "driver_version": None, "compatible": False, "errors": []}
    for key, value in (("chrome", chrome_path), ("driver", driver_path)):
        path = Path(value) if value else None
        if path is None or not path.is_file():
            result["errors"].append("Chrome не найден" if key == "chrome" else "ChromeDriver не найден")
            continue
        try:
            if key == "chrome" and os.name == "nt":
                escaped = str(path).replace("'", "''")
                output = subprocess.check_output(["powershell", "-NoProfile", "-Command",
                    "(Get-Item -LiteralPath '" + escaped + "').VersionInfo.ProductVersion"],
                    text=True, timeout=10, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            else:
                output = subprocess.check_output([str(path), "--version"], text=True, timeout=10,
                    creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            match = re.search(r"\d+\.\d+\.\d+\.\d+", output)
            result["chrome_version" if key == "chrome" else "driver_version"] = match.group(0) if match else None
        except Exception:
            result["errors"].append("Не удалось определить версию " + key)
    if result["chrome_version"] and result["driver_version"]:
        result["compatible"] = result["chrome_version"].split(".")[0] == result["driver_version"].split(".")[0]
        if not result["compatible"]:
            result["errors"].append("Основные версии Chrome и ChromeDriver различаются")
    result["proxy_note"] = "Прокси с авторизацией использует Manifest V3; для автозагрузки расширения нужен Chrome for Testing/Chromium. Требуется проверка реального подключения."
    return result
