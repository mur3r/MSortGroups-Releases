"""Read-only preparation of a fixed, per-recipient Trade contract."""
import json
from datetime import datetime, timedelta, timezone
from urllib.parse import urlsplit
from uuid import uuid4

from .storage import encode, utcnow
from xgenius.core.network import connection_failure


def group_key(group):
    """The same XChat link is one group across accounts and legacy DB IDs."""
    url = urlsplit(group.get('url') or '')
    if url.hostname in ('x.com', 'www.x.com') and url.path.startswith('/i/chat/'):
        return url.path.rstrip('/')
    return str(group.get('x_id') or group['id'])


async def prepare_plan(manager, run, operation, discover, discovered, checkpoint):
    store, config = manager.store, run['config']
    receive_id = config['receive_account_id']
    identities, errors, excluded, assignments = {}, [], [], []
    remaining = manager.run(run['id'])['remaining'].copy()

    async def profile(aid, name):
        manager.update(run['id'],progress={'operation':'Подготовка: определяем стабильный ID получателя','username':name,'source_account_id':aid})
        value = await operation(aid, lambda browser: browser.relationship(name))
        store.execute('INSERT OR REPLACE INTO trade_relationships VALUES(?,?,?,?,?,?)',
                      (aid,name,value.get('following'),value.get('follows_us'),utcnow(),encode(value)))
        store.event('trade','result','Проверен профиль получателя при подготовке',account_id=aid,run_id=run['id'],
                    details={'recipient':name,'x_id':value.get('x_id'),'follows_us':value.get('follows_us')})
        return value

    for name in config['recipients']:
        checkpoint()
        value = await profile(receive_id, name)
        xid = str(value.get('x_id') or '')
        if not xid.isdigit():
            errors.append({'recipient':name,'reason':'Стабильный ID получателя не подтверждён. Проверьте логин и доступность профиля.'})
        else:
            identities[name] = {'username':name,'x_id':xid,'checked_at':utcnow()}

    candidates = (store.accounts(False) if config.get('sender_mode')=='auto' else
                  run['plan'].get('candidate_accounts') or run['plan'].get('send_accounts',[]))
    candidates = [a for a in candidates if (store.account(a['id']) or {}).get('archived') is False
                  and store.account(a['id'])['username'] not in config['recipients']]
    # Cached access only determines order; every used source is refreshed and inspected.
    if config.get('sender_mode')=='auto':
        candidates, _, _ = manager._sources(config, candidates)
    elif run['plan'].get('preferred_source_id'):
        candidates.sort(key=lambda a:a['id']!=run['plan']['preferred_source_id'])
    run['plan']['candidate_accounts']=candidates
    manager.update(run['id'],plan=run['plan'])
    used, checked, recent = {}, {}, {}
    if run['plan'].get('preparation',{}).get('state')!='invalidated':
        for entry in run['plan'].get('preparation_checks',[]):
            try:
                observed = datetime.fromisoformat(entry['checked_at'])
                if (entry.get('observation',{}).get('status')=='eligible' and observed.tzinfo and
                        datetime.now(timezone.utc)-timedelta(minutes=15)<=observed<=datetime.now(timezone.utc)):
                    recent[(entry['group_key'],entry['target_x_id'])] = entry
            except (KeyError,TypeError,ValueError):
                continue
    # Persist an audit of this preparation. A new explicit preparation retries
    # temporary failures; confirmed membership is retained in the shared store.
    run['plan']['preparation_checks'] = []
    manager.update(run['id'],plan=run['plan'])
    known = {name:manager._known_members(name,identity['x_id']) for name,identity in identities.items()}
    for source in candidates:
        if errors and not identities:
            break
        if not any(remaining.values()):
            break
        aid = source['id']
        checkpoint()
        manager.update(run['id'],progress={'operation':'Подготовка: обновляем список групп исходящего аккаунта','source_account_id':aid})
        try:
            if aid not in discovered:
                await discover(aid)
            if store.account(aid)['username'] in config['recipients']:
                excluded.append({'source_account_id':aid,'reason':'Фактический логин исходящего аккаунта совпал с получателем'})
                continue
            pool, rejected = manager._pool(aid,config['quality'],ignore_unavailable=True)
            excluded.extend(rejected)
            for name in config['recipients']:
                if not remaining[name] or name not in identities:
                    continue
                value = await profile(aid,name)
                if str(value.get('x_id') or '') != identities[name]['x_id']:
                    excluded.append({'source_account_id':aid,'recipient':name,'reason':'ID профиля на исходящем аккаунте не совпал с получателем'})
                    continue
                for original in pool:
                    checkpoint()
                    if not remaining[name]:
                        break
                    key = (group_key(original),identities[name]['x_id'])
                    if key in checked:
                        store.event('trade','cache','Повторная группа пропущена: получатель уже проверен при подготовке',
                                    account_id=aid,run_id=run['id'],details={'group_id':original['id'],
                                    'recipient':name,'checked_source_account_id':checked[key]})
                        continue
                    remembered = known[name].get(original['id'])
                    if remembered and str(remembered.get('x_id') or '')==identities[name]['x_id']:
                        checked[key] = aid
                        manager._remember_existing(run,original,name,aid,remembered)
                        excluded.append({**original,'recipient':name,'reason':'Сохранена проверка по ID: получатель уже состоит в группе',
                                         'cached':True})
                        store.event('trade','cache','Группа пропущена: сохранено подтверждённое участие получателя',
                                    account_id=aid,run_id=run['id'],details={'group_id':original['id'],'recipient':name})
                        continue
                    previous = store.rows("SELECT id FROM trade_items WHERE run_id=? AND group_id=? AND recipient=? AND status='confirmed'",
                                          (run['id'],original['id'],name))
                    if previous:
                        continue
                    group = {**original,'target_x_id':identities[name]['x_id']}
                    manager.update(run['id'],progress={'operation':'Подготовка: проверяем ID получателя и доступность группы',
                                                       'username':name,'group_name':group['name'],'source_account_id':aid})
                    cached = recent.get(key)
                    if cached and cached['source_account_id']==aid:
                        value = cached['observation']
                        store.event('trade','cache','Использована недавняя проверка группы по точному ID',
                                    account_id=aid,run_id=run['id'],details={'group_id':group['id'],'recipient':name,
                                    'checked_at':cached['checked_at']})
                    else:
                        cached = None
                        value = await operation(aid,lambda browser:browser.inspect_candidate(group,name))
                    checked[key] = aid
                    run['plan']['preparation_checks'].append({'group_id':group['id'],'group_key':key[0],
                        'recipient':name,'target_x_id':identities[name]['x_id'],'source_account_id':aid,
                        'status':value.get('status'),'reason':value.get('reason'),
                        'checked_at':cached['checked_at'] if cached else utcnow(),'observation':value})
                    manager.update(run['id'],plan=run['plan'])
                    store.event('trade','result','Проверена группа для точного плана',account_id=aid,run_id=run['id'],
                                details={'group_id':group['id'],'recipient':name,'target_x_id':identities[name]['x_id'],
                                         'status':value.get('status'),'reason':value.get('reason')})
                    if value.get('status') not in ('eligible','already_member') or str(value.get('x_id') or '')!=identities[name]['x_id']:
                        if value.get('status')=='unavailable':
                            store.execute('INSERT OR REPLACE INTO trade_capabilities VALUES(?,?,?,?,?)',
                                          (group['id'],aid,'unavailable',value.get('reason','Добавление недоступно'),utcnow()))
                        excluded.append({**group,'recipient':name,'reason':value.get('reason','Возможность добавления не подтверждена')})
                        continue
                    store.execute('INSERT OR REPLACE INTO trade_capabilities VALUES(?,?,?,?,?)',
                                  (group['id'],aid,'allowed','Доступность добавления проверена при подготовке',utcnow()))
                    # A closed historic intent must be reconciled, not silently discarded or retried.
                    pending = store.rows("SELECT * FROM trade_items WHERE group_id=? AND recipient=? AND status IN ('sending','uncertain')",
                                         (group['id'],name))
                    mismatch = False
                    for item in pending:
                        evidence = json.loads(item['evidence'])
                        old_id = evidence.get('target_x_id') or evidence.get('x_id')
                        if old_id and str(old_id)!=identities[name]['x_id']:
                            mismatch = True
                            excluded.append({**group,'recipient':name,'blocking_run_id':item['run_id'],
                                             'reason':'У старой неподтверждённой попытки другой ID; нужна отдельная сверка истории'})
                            break
                        manager.resolve_observation(item, {'status':'confirmed' if value['status']=='already_member' else 'not_added',
                                                          'x_id':value['x_id'],'reason':'Свежая сверка ID при подготовке нового плана'})
                    if mismatch:
                        continue
                    if value['status']=='already_member':
                        manager._remember_existing(run,group,name,aid,value)
                        excluded.append({**group,'recipient':name,'reason':'Получатель уже состоит: проверено по ID, новым добавлением не считается'})
                        continue
                    # A freshly confirmed old intent may have filled this run's quota.
                    remaining[name] = max(0,manager.run(run['id'])['remaining'][name]-sum(a['recipient']==name for a in assignments))
                    if not remaining[name]:
                        break
                    account = store.account(aid)
                    assignments.append({**group,'recipient':name,'source_username':account['username'],
                                        'checked_at':utcnow(),'target_x_id':identities[name]['x_id'],'trade_access':'allowed',
                                        'invitation_ready':value.get('invitation_ready',True),'membership_evidence':value.get('membership_evidence','exact_id_picker')})
                    used[aid] = {'id':aid,'username':account['username'],'url':'https://x.com/'+account['username']}
                    remaining[name]-=1
        except Exception as error:
            if type(error).__name__=='StopRequested':
                raise
            if getattr(manager.controls[run['id']],'cleanup_failed',False):
                raise
            failure = connection_failure(error)
            excluded.append({'source_account_id':aid,'reason':failure['reason'] if failure else
                             'Не удалось проверить исходящий аккаунт: '+type(error).__name__})
    required = []
    for source in used.values():
        own = [a for a in assignments if a['source_account_id']==source['id']]
        required.append({**source,'recipients':sorted({a['recipient'] for a in own}),'groups_count':len(own)})
    state = 'blocked' if errors else 'shortage' if any(remaining.values()) else 'ready'
    preparation = {'id':str(uuid4()),'state':state,'created_at':utcnow(),'identities':identities,
                   'assignments':assignments,'required_accounts':required,'missing':remaining,'errors':errors,
                   'subscription_checks':[]}
    return {**run['plan'],'workflow_version':2,'preparation':preparation,'groups':assignments,'excluded':excluded,
            'candidate_accounts':candidates,'send_accounts':list(used.values()),'shortage':max(remaining.values(),default=0),
            'note':'Группы и исходящие аккаунты проверены без подписок, выбора участников и отправки приглашений. Передайте ссылки получателю, затем нажмите «Начать Trade»: подписки и весь план будут перепроверены до первого добавления.'}
