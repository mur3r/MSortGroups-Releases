"""Durable group exchanges. The only mutating browser path is an explicit plan."""
import asyncio
from datetime import datetime, timedelta, timezone
from concurrent.futures import ThreadPoolExecutor
import json
import re
import threading
import time
from uuid import uuid4

from xgenius.config import Config
from xgenius.logger import Logger
from xgenius.models import AccountCredentials
from xgenius.core.network import ConnectionFailure, connection_failure
from .jobs import JobControl, SafeLogger, StopRequested
from .runtime import FileLease
from .secrets import redact
from .storage import AccountIdentityConflict, encode, utcnow
from .rules import trade_runtime_settings

ACTIVE = {'waiting_priority', 'running', 'requires_manual', 'stopping'}
WAITING = {'awaiting_account', 'awaiting_incoming', 'awaiting_completion', 'awaiting_review', 'interrupted', 'error',
           'prepared', 'preparation_shortage', 'preparation_blocked', 'awaiting_subscriptions'}
QUALITY = {'any': 'Любые', 'good': 'Хорошая', 'medium': 'Средняя', 'bad': 'Плохая'}
CAPABILITY_TTL = timedelta(minutes=15)


def usernames(value):
    values = re.split(r'[\s,;]+', value.strip()) if isinstance(value, str) else value
    if not isinstance(values, list):
        raise ValueError('Укажите ники списком или по одному в строке')
    result = []
    for raw in values:
        if not isinstance(raw, str) or not re.fullmatch(r'@?[A-Za-z0-9_]{1,15}', raw):
            raise ValueError('Ник X должен содержать 1–15 букв, цифр или символов _; без пароля')
        name = raw.lstrip('@').lower()
        if name not in result:
            result.append(name)
    return result


class TradeManager:
    def __init__(self, store, secrets, jobs, configuration, publish, session_factory=None):
        self.store, self.secrets, self.jobs = store, secrets, jobs
        self.configuration, self.publish = configuration, publish
        self.session_factory = session_factory
        self.lock = threading.RLock()
        self.threads, self.controls = {}, {}
        self.closing = False
        self.recover_store()

    def recover_store(self):
        interrupted = self.store.rows("SELECT id FROM trade_runs WHERE status IN ('waiting_priority','running','requires_manual','stopping')")
        self.store.execute("UPDATE trade_items SET status='uncertain',reason='Приложение прервано после намерения добавить. Автоповтор запрещён.' WHERE status='sending'")
        self.store.execute("UPDATE trade_runs SET status='interrupted',error='Приложение перезапущено. Подтверждённые действия сохранены; продолжение только вручную.' WHERE status IN ('waiting_priority','running','requires_manual','stopping')")
        self.store.execute("UPDATE accounts SET status='session_expired',reason='Trade был прерван; проверьте сессию' WHERE status='trade'")
        held = self.store.rows('SELECT id FROM trade_runs WHERE priority_held=1 ORDER BY created_at DESC')
        self.jobs.priority_owner = held[0]['id'] if held else None
        for run in interrupted:
            self.store.event('trade', 'status', 'Обмен прерван перезапуском; неподтверждённые отправки требуют сверки',
                             run_id=run['id'], level='warning')

    def configuration_value(self):
        rows = self.store.rows("SELECT value FROM application_meta WHERE key='trade_config'")
        return json.loads(rows[0]['value']) if rows else {'receive_account_id': '', 'send_account_id': '', 'sender_mode': 'manual', 'donors': [], 'recipients': [], 'count': 1, 'quality': 'any'}

    def validate(self, body):
        allowed = {'receive_account_id', 'send_account_id', 'sender_mode', 'donors', 'recipients', 'count', 'quality'}
        if not isinstance(body, dict) or set(body)-allowed:
            raise ValueError('Неизвестные поля Trade')
        result = {**self.configuration_value(), **body}
        result.setdefault('sender_mode', 'manual')
        if result['sender_mode'] not in ('manual','auto'):
            raise ValueError('Выберите ручной или автоматический подбор аккаунта')
        for key in (('receive_account_id',) if result['sender_mode']=='auto' else ('receive_account_id', 'send_account_id')):
            account = self.store.account(result[key]) if isinstance(result.get(key), str) else None
            if not account or account['archived']:
                raise ValueError('Выберите наши рабочие аккаунты для приёма и передачи групп')
        result['donors'], result['recipients'] = usernames(result['donors']), usernames(result['recipients'])
        if not result['donors']:
            raise ValueError('Укажите хотя бы одного контрагента для входящих групп')
        if not result['recipients']:
            raise ValueError('Укажите хотя бы одного получателя групп')
        if result['sender_mode']=='auto':
            sources = [a for a in self.store.accounts(False) if a['username'] not in result['recipients']]
            if not sources:
                raise ValueError('Нет наших рабочих аккаунтов для автоматической передачи групп')
            if result.get('send_account_id') not in {a['id'] for a in sources}:
                result['send_account_id'] = sources[0]['id']
        for key, names in (('send_account_id', result['recipients']), ('receive_account_id', result['donors'])):
            if self.store.account(result[key])['username'] in names:
                raise ValueError('Аккаунт не может обмениваться группами сам с собой')
        if isinstance(result['count'], bool) or not isinstance(result['count'], int) or not 0 < result['count'] < 2**63:
            raise ValueError('Количество групп каждому получателю должно быть положительным целым числом')
        if result['quality'] not in QUALITY:
            raise ValueError('Выберите Хорошие, Средние, Плохие или Любые группы')
        return result

    def save_config(self, body):
        config = self.validate(body)
        self.store.execute("INSERT OR REPLACE INTO application_meta VALUES('trade_config',?)", (encode(config),))
        return config

    def accounts(self):
        counts = {r['account_id']: r['count'] for r in self.store.rows('SELECT account_id,COUNT(DISTINCT group_id) AS count FROM account_groups WHERE present=1 GROUP BY account_id')}
        return [{'id': a['id'], 'username': a['username'], 'group_count': counts.get(a['id'], 0), 'status': a['status']} for a in self.store.accounts(False)]

    def _pool(self, account_id, quality, ignore_unavailable=False):
        # Trade never scans profiles or recalculates audience quality. Reuse
        # the last saved collection snapshot and label its version explicitly.
        # The newest run can concern a different account. Select the newest
        # saved assessment of EACH candidate group without recalculating it.
        assessments = self.store.rows('''WITH ranked AS (
            SELECT json_extract(j.value,'$.id') AS group_id,j.value AS assessment,
                s.created_at,s.settings_version,
                ROW_NUMBER() OVER (PARTITION BY json_extract(j.value,'$.id') ORDER BY s.created_at DESC,s.rowid DESC) AS rank
            FROM run_snapshots s,json_each(s.analysis,'$.groups') j
            WHERE json_extract(j.value,'$.id') IN
                (SELECT group_id FROM account_groups WHERE account_id=? AND present=1)
        ) SELECT group_id,assessment,created_at,settings_version FROM ranked WHERE rank=1''', (account_id,))
        categories = {r['group_id']: {**json.loads(r['assessment']), 'saved_at':r['created_at'],
                                    'saved_version':r['settings_version']} for r in assessments}
        groups = self.store.rows('SELECT g.* FROM groups g JOIN account_groups ag ON ag.group_id=g.id WHERE ag.account_id=? AND ag.present=1', (account_id,))
        capabilities = {r['group_id']: r for r in self.store.rows('SELECT * FROM trade_capabilities WHERE account_id=?', (account_id,))}
        unavailable = self._unavailable(account_id)
        pool, excluded = [], []
        for group in groups:
            assessed = categories.get(group['id'], {})
            category = assessed.get('category') or 'Недостаточно данных'
            reason = None if ignore_unavailable else unavailable.get(group['id'], {}).get('reason')
            if not reason and quality != 'any' and (assessed.get('preliminary', True) or category != QUALITY[quality]):
                reason = 'Качество не совпадает или оценка предварительная'
            row = {key: group[key] for key in ('id', 'x_id', 'name', 'url')}
            row.update(quality=category, score=assessed.get('score'), preliminary=assessed.get('preliminary', True), source_account_id=account_id,
                quality_checked_at=assessed.get('saved_at'),
                quality_rules_version=assessed.get('saved_version'), trade_access='unavailable' if group['id'] in unavailable else 'allowed' if capabilities.get(group['id'],{}).get('state')=='allowed' else 'unknown')
            (excluded if reason else pool).append({**row, **({'reason': reason} if reason else {})})
        pool.sort(key=lambda g: (-(g['score'] if g['score'] is not None else -1), g['id']))
        return pool, excluded

    def _unavailable(self, account_id):
        fresh = {}
        for row in self.store.rows("SELECT * FROM trade_capabilities WHERE account_id=? AND state='unavailable'",(account_id,)):
            try:
                observed = datetime.fromisoformat(row['observed_at'].replace('Z','+00:00'))
                if observed.tzinfo and observed >= datetime.now(timezone.utc)-CAPABILITY_TTL:
                    fresh[row['group_id']] = row
            except (ValueError, TypeError):
                pass  # Invalid/old observations cannot block a group forever.
        return fresh

    def _known_members(self, username, target_id=None):
        """Reuse positive membership until a complete roster proves departure.

        Ambiguous/reused aliases never join different stable identities.
        This lookup runs before choosing/opening any source browser.
        """
        aliases = self.store.rows('SELECT p.* FROM participants p JOIN participant_aliases a ON a.participant_id=p.id WHERE a.username=?',(username,))
        if target_id is None:
            if len(aliases)>1:
                return {}
            identities = {str(json.loads(r['details']).get('x_id')) for r in self.store.rows('SELECT details FROM trade_relationships WHERE username=?',(username,)) if json.loads(r['details']).get('x_id')}
            if len(identities)>1:
                return {}
            target_id = next(iter(identities), None)
        people = [p for p in aliases if p['username']==username and (not target_id or not p['x_id'] or str(p['x_id'])==str(target_id))]
        if len(people)!=1:
            return {}
        person = people[0]
        rows = self.store.rows('SELECT gm.group_id,gm.last_seen,t.observed_at FROM group_members gm LEFT JOIN trade_member_observations t ON t.group_id=gm.group_id AND t.username=? WHERE gm.participant_id=? AND gm.present=1 AND NOT EXISTS (SELECT 1 FROM trade_member_rechecks r WHERE r.group_id=gm.group_id AND r.username=?)',(username,person['id'],username))
        return {r['group_id']:{'status':'already_member','reason':'Сохранённый состав: получатель уже состоит в группе','x_id':person['x_id'],'cached':True,'observed_at':r['observed_at'] or r['last_seen']} for r in rows}

    def _sources(self, config, candidates=None):
        automatic = config.get('sender_mode')=='auto'
        accounts = candidates if candidates is not None else self.store.accounts(False)
        accounts = [a for a in accounts if not a.get('archived') and a['username'] not in config['recipients'] and (automatic or a['id']==config['send_account_id'])]
        known = {name:self._known_members(name) for name in config['recipients']}
        sources, groups, excluded = [], [], []
        for account in accounts:
            pool, rejected = self._pool(account['id'],config['quality'])
            for group in pool:
                group['eligible_recipients'] = [name for name in config['recipients'] if group['id'] not in known[name]]
            useful = [g for g in pool if g['eligible_recipients']]
            allowed = sum(min(config['count'],sum(g['trade_access']=='allowed' and name in g['eligible_recipients'] for g in useful)) for name in config['recipients'])
            eligible = sum(min(config['count'],sum(name in g['eligible_recipients'] for g in useful)) for name in config['recipients'])
            count = self.store.rows('SELECT COUNT(*) AS count FROM account_groups WHERE account_id=? AND present=1',(account['id'],))[0]['count']
            source = {'id':account['id'],'username':account['username'],'eligible_count':eligible,'allowed_count':allowed,'known_group_count':count,'discover_needed':count==0 and config['quality']=='any'}
            sources.append(source)
            groups.extend(pool)
            excluded.extend(rejected)
        if automatic:
            sources.sort(key=lambda a:(-a['allowed_count'],-a['eligible_count'],not a['discover_needed'],a['username']))
            order = {a['id']:i for i,a in enumerate(sources)}
            groups.sort(key=lambda g:(order[g['source_account_id']],g['trade_access']!='allowed',-(g['score'] if g['score'] is not None else -1),g['id']))
        return sources, groups, excluded

    def _shortage(self, config, pool):
        known = {name:self._known_members(name) for name in config['recipients']}
        return max((max(0,config['count']-len({g['id'] for g in pool if g['id'] not in known[name]})) for name in config['recipients']),default=config['count'])

    def preview(self, body):
        config = self.save_config(body)
        settings, version = self.store.settings()
        sources, pool, excluded = self._sources(config)
        if not sources:
            raise ValueError('Нет подходящих исходящих аккаунтов')
        if config.get('sender_mode')=='auto':
            config['send_account_id'] = sources[0]['id']
        plan = {'groups': pool, 'excluded': excluded, 'quality_label': QUALITY[config['quality']],
                'workflow_version':2,
                'receive_username':self.store.account(config['receive_account_id'])['username'],
                'send_username':self.store.account(config['send_account_id'])['username'],
                'send_accounts':sources, 'sender_mode':config.get('sender_mode','manual'),
                'per_recipient': config['count'], 'total_requested': config['count']*len(config['recipients']),
                'shortage': self._shortage(config,pool),
                'note': 'Пул просматривается по порядку до подтверждённого количества каждому получателю. Уже состоящие в группе не засчитываются. При запуске наши аккаунты подписываются на контрагентов; обратная подписка проверяется перед добавлением. В режиме «Любые» недостающий список групп и ссылки получаем без анализа качества.'}
        rid, now = str(uuid4()), utcnow()
        self.store.execute('INSERT INTO trade_runs(id,created_at,updated_at,status,config,plan,settings,settings_version) VALUES(?,?,?,?,?,?,?,?)',
            (rid, now, now, 'draft', encode(config), encode(plan), encode(settings), version))
        self.publish({'type': 'trade'})
        return self.run(rid)

    def run(self, rid):
        rows = self.store.rows('SELECT * FROM trade_runs WHERE id=?', (rid,))
        if not rows:
            raise ValueError('Обмен не найден')
        result = rows[0]
        for key in ('config', 'plan', 'settings', 'progress', 'resume_jobs', 'baseline', 'incoming'):
            result[key] = json.loads(result[key])
        result['items'] = self.store.rows('SELECT * FROM trade_items WHERE run_id=? ORDER BY updated_at,id', (rid,))
        result['attempts'] = []
        for item in result['items']:
            for index, attempt in enumerate(json.loads(item['evidence']).get('attempts', [])):
                result['attempts'].append({**item,**attempt,'id':item['id']+':'+str(index)})
            result['attempts'].append(item)
        result['confirmed'] = [item for item in result['items'] if item['status'] == 'confirmed']
        result['confirmed_count'] = len(result['confirmed'])
        result['already_members'] = [item for item in result['items'] if item['status'] == 'already_member']
        result['follow_actions'] = self.store.rows('SELECT account_id,username,status,observed_at FROM trade_follow_actions WHERE run_id=?',(rid,))
        result['incoming_checks'] = self.store.rows("SELECT observed_at,json_extract(data,'$.observed_count') AS observed_count,json_extract(data,'$.expected') AS expected,json_extract(data,'$.verdict') AS verdict FROM trade_incoming_checks WHERE run_id=? ORDER BY observed_at DESC",(rid,))
        result['remaining'] = {name:max(0,result['config']['count']-sum(item['recipient']==name for item in result['confirmed'])) for name in result['config']['recipients']}
        result['worker_active'] = bool(self.threads.get(rid) and self.threads[rid].is_alive())
        result['can_finish'] = not any(result['remaining'].values()) and bool(result['incoming'].get('sufficient_confirmed')) and not any(item['status'] in ('sending','uncertain') for item in result['items'])
        result['can_start'] = result['plan'].get('preparation',{}).get('state')=='ready' and not result['worker_active']
        return result

    @staticmethod
    def _previous_attempts(item):
        history = json.loads(item.get('evidence') or '{}').get('attempts', [])
        if item['status'] != 'checking':
            history.append({key:item.get(key) for key in ('status','reason','updated_at','source_account_id')})
        return history

    def history(self):
        # Plans and full per-group evidence are fetched only when opened.
        rows = self.store.rows('SELECT id,created_at,status,config,progress,error,incoming,priority_held FROM trade_runs ORDER BY created_at DESC')
        counts = {r['run_id']: r['count'] for r in self.store.rows("SELECT run_id,COUNT(*) AS count FROM trade_items WHERE status='confirmed' GROUP BY run_id")}
        for row in rows:
            row['config'], row['progress'] = json.loads(row['config']), json.loads(row['progress'])
            row['incoming'] = {key:value for key,value in json.loads(row['incoming']).items() if key not in ('groups',)}
            row['recipient_names'] = ', '.join('@'+name for name in row['config']['recipients'])
            row['partner_names'] = ', '.join('@'+name for name in dict.fromkeys(row['config']['donors']+row['config']['recipients']))
            row['quality'] = QUALITY[row['config']['quality']]
            row['confirmed_count'] = counts.get(row['id'], 0)
        return rows

    def update(self, rid, **values):
        summary = {k: values[k] for k in ('status','error','progress','priority_held','finished_at') if k in values}
        allowed = {'status', 'progress', 'resume_jobs', 'error', 'finished_at', 'baseline', 'incoming', 'plan', 'priority_held', 'settings'}
        assert not set(values)-allowed
        if 'progress' in values:
            current = self.store.rows('SELECT progress FROM trade_runs WHERE id=?',(rid,))
            values['progress'] = {**(json.loads(current[0]['progress']) if current else {}), **values['progress']}
        values = {key: encode(value) if key in ('progress', 'resume_jobs', 'baseline', 'incoming', 'plan', 'settings') else value for key, value in values.items()}
        values['updated_at'] = utcnow()
        self.store.execute('UPDATE trade_runs SET '+','.join(key+'=?' for key in values)+' WHERE id=?', (*values.values(), rid))
        self.store.event('trade', 'error' if summary.get('error') else 'progress',
                         (summary.get('progress') or {}).get('operation') or 'Состояние обмена обновлено',
                         run_id=rid, level='error' if summary.get('error') else 'info', details=summary)
        self.publish({'type': 'trade'})

    def _record_membership(self, run, group_id, target, account_id=None, evidence=None, changed=True):
        account_id = account_id or run['config']['send_account_id']
        evidence = evidence or {}
        composition_changed = changed
        if evidence.get('cached'):
            return  # A remembered skip is not a new observation of membership.
        identity = self.store.rows('SELECT details FROM trade_relationships WHERE account_id=? AND username=?', (account_id, target))
        stable_id = evidence.get('x_id') or (json.loads(identity[0]['details']).get('x_id') if identity else None)
        try:
            pid = self.store.identify({'username':target, 'x_id':stable_id,
                'identity_origin':'trade_profile_id' if stable_id else 'trade_confirmed_membership'})
        except ValueError:
            pid = None  # A reused handle is not silently merged.
        if pid:
            self.store.execute('DELETE FROM trade_member_rechecks WHERE group_id=? AND username=?',(group_id,target))
            present = self.store.rows('SELECT present FROM group_members WHERE group_id=? AND participant_id=?',(group_id,pid))
            composition_changed = changed or not present or not present[0]['present']
            self.store.execute('INSERT INTO group_members VALUES(?,?,?,?,1,0) ON CONFLICT(group_id,participant_id) DO UPDATE SET present=1,uncertain=0,last_seen=excluded.last_seen',
                (group_id,pid,utcnow(),utcnow()))
            self.store.execute('INSERT OR REPLACE INTO trade_member_observations VALUES(?,?,?,?,?,?,?)',
                (group_id,target,stable_id,account_id,run['id'],utcnow(),'added' if changed else 'already_member'))
        if composition_changed:
            self.store.execute("UPDATE groups SET membership_status='partial',reason='После Trade необходимо обновить полный состав' WHERE id=?", (group_id,))

    def _closed_account(self, account_id):
        status = self.store.account(account_id)['status']
        if status == 'trade':
            self.store.account_status(account_id,'active')
        elif status in ('login','requires_manual'):
            self.store.account_status(account_id,'session_expired','Вход Trade не подтверждён; браузер закрыт')

    def _remember_existing(self, run, group, name, aid, observation):
        if not observation.get('cached'):
            self._record_membership(run,group['id'],name,aid,observation,changed=False)
        old = self.store.rows('SELECT * FROM trade_items WHERE run_id=? AND group_id=? AND recipient=?',(run['id'],group['id'],name))
        if old and old[0]['status'] in ('confirmed','sending','uncertain'):
            return
        self.store.execute('''INSERT INTO trade_items(id,run_id,group_id,recipient,status,reason,group_name,url,quality,score,updated_at,source_account_id,evidence)
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(run_id,group_id,recipient) DO UPDATE SET
            status=excluded.status,reason=excluded.reason,source_account_id=excluded.source_account_id,updated_at=excluded.updated_at,evidence=excluded.evidence''',
            (old[0]['id'] if old else str(uuid4()),run['id'],group['id'],name,'already_member',observation.get('reason','Уже состоит'),
             group['name'],group['url'],group['quality'],group.get('score'),utcnow(),aid,
             encode({**observation,'attempts':self._previous_attempts(old[0]) if old else []})))

    def resolve_observation(self, item, value):
        if value.get('status') not in ('confirmed','not_added'):
            return
        old_run = self.run(item['run_id'])
        evidence = json.loads(item['evidence'])
        evidence.update(value,attempts=self._previous_attempts(item))
        self.store.execute('UPDATE trade_items SET status=?,reason=?,updated_at=?,evidence=? WHERE id=?',
                           (value['status'],value.get('reason',''),utcnow(),encode(evidence),item['id']))
        if value['status']=='confirmed':
            self._record_membership(old_run,item['group_id'],item['recipient'],item['source_account_id'],value)
        self.store.event('trade','result','Сохранённая попытка сверена: '+value['status'],run_id=item['run_id'],
                         details={'group_id':item['group_id'],'recipient':item['recipient'],'x_id':value.get('x_id')})

    def confirm_incoming(self, rid, acknowledgement):
        if acknowledgement is not True:
            raise ValueError('Подтвердите, что лично проверили новые входящие группы')
        with self.lock:
            run = self.run(rid)
            if run['worker_active']:
                raise ValueError('Дождитесь завершения проверки')
            incoming = run['incoming']
            if not incoming.get('checked_at') or incoming.get('observed_count',0)<run['plan']['total_requested']:
                raise ValueError('Сначала перепроверьте входящие: наблюдаемых новых групп недостаточно')
            incoming = {**incoming,'sufficient_confirmed':True,'verdict':'manual','manually_confirmed_at':utcnow(),
                        'confirmation':'Пользователь лично проверил новые группы; полнота старого снимка не изменялась'}
            self.update(rid,incoming=incoming)
            self.store.event('trade','checkpoint','Входящие группы подтверждены пользователем вручную',run_id=rid,
                             details={'observed_count':incoming['observed_count'],'expected':run['plan']['total_requested']})
            return self.run(rid)

    def add_account(self, rid, account_id):
        with self.lock:
            run = self.run(rid)
            if run['worker_active'] or run['status'] not in WAITING | {'partial','stopped','checked'}:
                raise ValueError('Сначала дождитесь остановки текущего этапа Trade')
            account = self.store.account(account_id)
            if not account or account['archived'] or account['username'] in run['config']['recipients']:
                raise ValueError('Выберите другой наш рабочий аккаунт')
            accounts = run['plan'].get('candidate_accounts') or run['plan'].get('send_accounts', [{'id':run['config']['send_account_id'],'username':run['plan']['send_username']}])
            if any(item['id'] == account_id for item in accounts):
                raise ValueError('Этот аккаунт уже включён в обмен')
            pool, excluded = self._pool(account_id, run['config']['quality'])
            plan = {**run['plan'], 'send_accounts':[*accounts, {'id':account_id,'username':account['username']}],
                    'groups':[*pool,*run['plan']['groups']], 'excluded':[*run['plan']['excluded'],*excluded],
                    'preferred_source_id':account_id}
            plan['candidate_accounts'] = [*plan.get('candidate_accounts',accounts),{'id':account_id,'username':account['username']}]
            plan['preparation'] = {**plan.get('preparation',{}),'state':'invalidated'}
            self.update(rid, plan=plan, status='awaiting_account', progress={'operation':'Аккаунт добавлен. Нажмите «Продолжить обмен».'})
            return self.run(rid)

    def finish(self, rid, accept_unverified=False):
        with self.lock, self.jobs.lock:
            run = self.run(rid)
            if run['worker_active']:
                raise ValueError('Сначала остановите выполняемый этап Trade')
            if run['status'] in ('completed','closed_unverified') and run['can_finish'] and not accept_unverified:
                self.update(rid,status='completed',progress={'operation':'Завершение исторического Trade подтверждено пользователем'})
                return self.run(rid)
            if not run['priority_held'] and run['status'] not in ACTIVE | {'completed','closed_unverified'}:
                if not accept_unverified and not run['can_finish']:
                    raise ValueError('Обмен ещё не подтверждён')
                self.update(rid,status='completed' if run['can_finish'] else 'closed_unverified',finished_at=utcnow(),
                            progress={'operation':'Trade явно завершён пользователем; сохранённая история доступна для сверки'})
                return self.run(rid)
            if not run['priority_held'] or self.jobs.priority_owner != rid:
                raise ValueError('Этот Trade уже завершён или не владеет очередью')
            if getattr(self.controls.get(rid), 'cleanup_failed', False):
                raise ValueError('Закрытие браузера не подтверждено; перезапустите приложение перед продолжением сбора')
            if not accept_unverified and not run['can_finish']:
                raise ValueError('Обмен ещё не подтверждён: проверьте входящие группы и исходящие добавления')
            status = 'completed' if run['can_finish'] else 'closed_unverified'
            self.update(rid, status=status, priority_held=0, finished_at=utcnow(), progress={'operation':'Trade завершён пользователем; очередь сбора освобождена'})
            self.jobs.release_priority(rid, run['resume_jobs'])
            return self.run(rid)

    def start(self, rid, checks_only=False, verify_only=False, incoming_only=False, prepare_only=False, preparation_id=None):
        with self.lock, self.jobs.lock:
            run = self.run(rid)
            self.jobs.assert_browser_cleanup()
            if self.closing or any(t.is_alive() for t in self.threads.values()):
                raise ValueError('Trade уже выполняется')
            final_recheck = (incoming_only or verify_only) and run['status'] in ('completed','closed_unverified')
            if not final_recheck and run['status'] not in WAITING | {'draft', 'partial', 'stopped', 'checked'}:
                raise ValueError('Этот обмен уже завершён или выполняется')
            readonly = checks_only or verify_only or incoming_only
            if not readonly and not prepare_only:
                preparation = run['plan'].get('preparation',{})
                if preparation.get('state')!='ready' or not preparation_id or preparation.get('id')!=preparation_id:
                    raise ValueError('Сначала подготовьте точный план групп и аккаунтов, передайте ссылки получателю и запускайте именно этот план')
                assignments = preparation.get('assignments',[])
                keys = {(a['id'],a['recipient']) for a in assignments}
                confirmed = {(a['group_id'],a['recipient']) for a in run['confirmed']}
                required = {(a['id'],name) for a in preparation.get('required_accounts',[]) for name in a['recipients']}
                if (len(keys)!=len(assignments) or any((a['source_account_id'],a['recipient']) not in required for a in assignments)
                        or any(sum(a['recipient']==name and (a['id'],name) not in confirmed for a in assignments)!=count for name,count in run['remaining'].items())):
                    raise ValueError('Точный план не соответствует оставшимся квотам. Подготовьте план заново.')
            if incoming_only:
                account = self.store.account(run['config']['receive_account_id'])
                if not account or account['archived']:
                    raise ValueError('Аккаунт приёма недоступен для перепроверки')
            elif not verify_only:
                self.validate(run['config'])
            for direction in (() if verify_only else ('receive',) if incoming_only or prepare_only or run['config'].get('sender_mode')=='auto' else ('receive', 'send')):
                frozen = run['plan'].get(direction+'_username')
                current = self.store.account(run['config'][direction+'_account_id'])['username']
                if frozen and frozen != current:
                    raise ValueError('Логин нашего аккаунта изменён. Подготовьте новый план обмена.')
            for account in ([] if incoming_only or verify_only or prepare_only else run['plan'].get('send_accounts', [])):
                current = self.store.account(account['id'])
                if not current or current['archived'] or current['username'] != account['username']:
                    raise ValueError('Один из исходящих аккаунтов изменён или удалён; проверьте план')
            previous = run['resume_jobs']
            if self.jobs.priority_owner != rid:
                previous = self.jobs.reserve_priority(rid)
            control = JobControl()
            control.run_id, control.domain = rid, 'trade'
            control.return_status = run['status'] if final_recheck else None
            control.original_finished_at = run['finished_at']
            control.prepare_only = prepare_only
            self.controls[rid] = control
            # Keep the plan's quality rules, but freeze current pacing at every explicit start/resume.
            current_settings, speed_version = self.store.settings()
            frozen_settings = {**run['settings'], 'trade': current_settings['trade']}
            if prepare_only:
                self.update(rid,plan={**run['plan'],'preparation':{**run['plan'].get('preparation',{}),'state':'preparing'}})
            self.update(rid, status='waiting_priority', resume_jobs=previous, error=None, finished_at=None,
                        settings=frozen_settings,
                        priority_held=0 if prepare_only else int(bool(run['priority_held']) or (not readonly and not final_recheck)),
                progress={'operation':'Ожидание освобождения браузеров','donors':{},'recipients':{},'relationship_blocks':[],'source_errors':[],'manual_reason':None,'manual_kind':None,'trade_phase':None,'speed_settings_version':speed_version})
            self.store.event('trade', 'settings', 'Зафиксирована скорость запуска Trade', run_id=rid,
                             details={'settings_version': speed_version, 'trade': current_settings['trade']})
            thread = threading.Thread(target=self._worker, args=(rid, control, previous, checks_only, verify_only, incoming_only), name='trade-'+rid, daemon=False)
            self.threads[rid] = thread
            thread.start()
        return self.run(rid)

    def command(self, rid, action):
        self.store.event('trade', 'request', 'Команда Trade: ' + action, run_id=rid)
        with self.lock:
            control = self.controls.get(rid)
            if not control or not self.threads[rid].is_alive():
                if action == 'stop':
                    run = self.run(rid)
                    if run['status'] in ('completed','closed_unverified'):
                        raise ValueError('Этот Trade уже завершён')
                    self.update(rid,status='stopped',priority_held=0,finished_at=utcnow(),
                                progress={'operation':'Trade остановлен. План и результаты сохранены; продолжение возможно из истории.'})
                    self.jobs.release_priority(rid,run['resume_jobs'])
                    return self.run(rid)
                raise ValueError('Обмен уже не выполняется')
            if self.run(rid)['status'] not in ACTIVE:
                raise ValueError('Действия обмена завершены; ожидается закрытие браузеров')
            with control.condition:
                if action == 'stop':
                    control.stopped = True
                    self.update(rid, status='stopping')
                elif action == 'continue':
                    if self.run(rid)['status'] != 'requires_manual':
                        raise ValueError('Trade сейчас не ожидает ручного подтверждения')
                    control.manual_generation += 1
                else:
                    raise ValueError('Неизвестная команда Trade')
                control.condition.notify_all()
        return self.run(rid)

    def _worker(self, rid, control, previous, checks_only, verify_only, incoming_only):
        loop = asyncio.new_event_loop()
        loop.set_default_executor(ThreadPoolExecutor(max_workers=1, thread_name_prefix='trade-webdriver'))
        try:
            # Even cancellation waits for old drivers to release ownership.
            for entry in previous:
                thread = self.jobs.threads.get(entry['id'])
                while thread and thread.is_alive():
                    thread.join(.2)
            self.jobs.assert_browser_cleanup()
            control.checkpoint()
            self.update(rid, status='running')
            loop.run_until_complete(self._exchange(rid, control, checks_only, verify_only, incoming_only))
            control.checkpoint()
        except StopRequested:
            self.update(rid, status=control.return_status or ('interrupted' if self.closing else 'stopped'),
                        finished_at=control.original_finished_at if control.return_status else None if self.closing else utcnow())
        except Exception as error:
            self.store.event('trade','error','Сбой рабочего цикла Trade',level='error',run_id=rid,
                             details={'error_type':type(error).__name__,'reason':str(error)})
            failure = connection_failure(error)
            self.update(rid, status=control.return_status or 'error',
                error='Ошибка перепроверки; предыдущий входящий снимок сохранён.' if control.return_status else
                      failure['reason'] if failure else 'Ошибка Trade. Подтверждённые действия сохранены; неподтверждённые не повторяются автоматически.',
                finished_at=control.original_finished_at if control.return_status else utcnow())
        finally:
            try:
                self.store.execute("UPDATE trade_items SET status='uncertain',reason='Подтверждение не получено; автоповтор запрещён.' WHERE run_id=? AND status='sending'", (rid,))
                if self.store.rows("SELECT id FROM trade_items WHERE run_id=? AND status IN ('confirmed','uncertain') LIMIT 1", (rid,)):
                    for entry in previous:
                        self.store.execute('DELETE FROM job_steps WHERE job_id=? AND (step_key LIKE ? OR step_key LIKE ?)', (entry['id'], '%:groups', '%:members:%'))
            except Exception:
                # A storage failure must not leave the scheduler permanently owned.
                # Do not resume statistics with uncertain durable checkpoints.
                control.cleanup_failed = True
            finally:
                try:
                    loop.run_until_complete(loop.shutdown_default_executor())
                finally:
                    loop.close()
                    run = self.run(rid)
                    if getattr(control, 'cleanup_failed', False):
                        self.jobs.browser_cleanup_failed = True
                    release = not run['priority_held'] or (control.stopped and not self.closing)
                    if release:
                        self.update(rid, priority_held=0)
                        self.jobs.release_priority(rid, previous, resume=not self.closing and not getattr(control, 'cleanup_failed', False))
                    self.publish({'type': 'analysis'})
                    self.publish({'type': 'trade'})

    async def _exchange(self, rid, control, checks_only, verify_only, incoming_only):
        from .trade_browser import TradeSession
        run = self.run(rid)
        run['settings'] = trade_runtime_settings(run['settings'])
        sessions, loggers, leases = {}, {}, {}
        last_launch = None
        discovered = set()
        automatic = run['config'].get('sender_mode')=='auto'
        source_errors = []
        def fail_connection(aid, result=None, error=None):
            failure = (result if result and (result.get('status')=='proxy_error' or result.get('connection_error')) else
                       connection_failure(error,bool(self.secrets.get(aid).get('proxy'))) if error else None)
            if failure:
                failure = ConnectionFailure(failure).result
                self.store.account_status(aid,failure['status'],redact(failure['reason'],self.secrets.get(aid).values()))
                self.publish({'type':'accounts'})
                raise ConnectionFailure(failure)

        async def login_call(aid, action):
            try:
                result = await action()
            except Exception as error:
                fail_connection(aid,error=error)
                raise
            fail_connection(aid,result=result)
            return result

        async def session(aid):
            nonlocal last_launch
            if aid in sessions:
                return sessions[aid]
            # Trade is deliberately sequential even if collection allows more.
            for previous_id, (old_browser, _) in list(sessions.items()):
                self.store.event('trade','lifecycle','Закрываем браузер для перехода к другому аккаунту',
                                 account_id=previous_id,run_id=rid,details={'next_account_id':aid})
                try:
                    await old_browser.close()
                except Exception:
                    control.cleanup_failed = True
                    raise
                self._closed_account(previous_id)
                leases.pop(previous_id).close()
                loggers.pop(previous_id).base.close()
                sessions.pop(previous_id)
            if last_launch is not None:
                await self.jobs._delay(control, max(0, run['settings']['collection']['account_start_interval_seconds']-(time.monotonic()-last_launch)))
            account, private = self.store.account(aid), self.secrets.get(aid)
            credentials = AccountCredentials(username=account['username'], password=private['password'],
                proxy=private['proxy'] or None, user_agent=account.get('user_agent'), headless=False,
                auth_token=private['auth_token'] or None, ct0_token=private['ct0_token'] or None,
                ichat_password=private['ichat_password'] or None)
            config = Config(self.store.data_dir)
            config.profile_key = account.get('profile_key') or account['username']
            config.chrome_path, config.chromedriver_path = self.configuration['chrome_path'], self.configuration['driver_path']
            def synchronize_identity(identity):
                old_username=account['username']
                updated,changed=self.store.sync_account_identity(aid,identity)
                account.update(updated)
                if changed:
                    plan=run['plan']
                    for direction in ('receive','send'):
                        if run['config'][direction+'_account_id']==aid:
                            plan[direction+'_username']=updated['username']
                    for entry in plan.get('send_accounts',[]):
                        if entry['id']==aid:
                            entry['username']=updated['username']
                    plan.setdefault('account_name_updates',[]).append({'account_id':aid,'from':old_username,
                        'to':updated['username'],'observed_at':identity['observed_at']})
                    self.update(rid,plan=plan,progress={'current_account':updated['username'],
                        'operation':f'Логин обновлён: @{old_username} → @{updated["username"]}'})
                self.publish({'type':'accounts'})
                is_sender=any(entry['id']==aid for entry in [*run['plan'].get('send_accounts',[]),*run['plan'].get('candidate_accounts',[])])
                if (aid==run['config']['receive_account_id'] and updated['username'] in run['config']['donors']) or (is_sender and updated['username'] in run['config']['recipients']):
                    raise AccountIdentityConflict('Фактический логин совпал с контрагентом Trade. Логин записи исправлен; создайте план с другим получателем.')
            config.account_identity_handler=synchronize_identity
            lease = FileLease(config.get_profile_dir(account['username']) / '.murer-profile.lock')
            leases[aid] = lease
            self.store.protect(private.values())
            logger = SafeLogger(Logger(config), private.values(), self.store.event, 'trade', aid, rid)
            loggers[aid] = logger
            factory = self.session_factory or TradeSession
            browser = factory(config, logger, run['settings'], control.checkpoint,
                lambda value: self.update(rid, progress={k:v for k,v in value.items() if k in
                    ('operation','ichat_unlock_event','trade_phase','recipient','group_id','attempt')}))
            sessions[aid] = (browser, credentials)
            last_launch = time.monotonic()
            self.store.account_status(aid, 'login', 'Вход для Trade')
            self.update(rid,progress={'current_account':account['username'],'source_account_id':aid})
            result = await login_call(aid,lambda:browser.login(credentials))
            while result.get('status') == 'requires_manual':
                generation = control.manual_generation
                self.update(rid, status='requires_manual', progress={'operation': 'Завершите вход в Chrome и продолжите Trade',
                    'manual_kind':'login',
                    'manual_reason':redact(result.get('reason','Требуется подтверждение'),tuple(private.values())+(credentials.ichat_password,))})
                self.store.account_status(aid, 'requires_manual', 'Trade ожидает подтверждения')
                await asyncio.to_thread(control.wait_manual, generation)
                credentials.ichat_password = self.secrets.get(aid)['ichat_password'] or None
                result = await login_call(aid,lambda:browser.continue_login(credentials))
            if result.get('status') != 'active':
                status = result.get('status')
                self.store.account_status(aid,status if status in ('error','proxy_error','session_expired','not_authorized') else 'error',
                    redact(result.get('reason','Вход для Trade не подтверждён'),private.values()))
                raise RuntimeError('Trade login failed')
            is_sender=any(entry['id']==aid for entry in [*run['plan'].get('send_accounts',[]),*run['plan'].get('candidate_accounts',[])])
            if (aid==run['config']['receive_account_id'] and account['username'] in run['config']['donors']) or (is_sender and account['username'] in run['config']['recipients']):
                raise ValueError('Обновлённый логин совпал с контрагентом Trade; проверьте план обмена')
            self.update(rid, status='running',progress={'manual_reason':None})
            logger.domain = 'trade'
            self.store.account_status(aid, 'trade', 'Аккаунт занят обменом группами')
            return sessions[aid]

        async def relationships(aid, names):
            if not names:
                return {}
            browser, _ = await session(aid)
            result = {}
            for name in names:
                control.checkpoint()
                self.update(rid, progress={'operation': 'Проверка взаимной подписки', 'username': name})
                value = await operation(aid, lambda: browser.relationship(name))
                self.store.execute('INSERT OR REPLACE INTO trade_relationships VALUES(?,?,?,?,?,?)',
                    (aid, name, value.get('following'), value.get('follows_us'), utcnow(), encode(value)))
                result[name] = value.get('following') is True and value.get('follows_us') is True
                await browser.actions.sleep(run['settings']['collection']['profile_delay_seconds'])
            return result

        async def operation(aid, action, verification=None, sent=None, invitation_action=False):
            browser, credentials = await session(aid)
            async def attempt(function):
                for index in range(run['settings']['collection']['retries']+1):
                    control.checkpoint()
                    try:
                        value = await function()
                    except StopRequested:
                        raise
                    except Exception as error:
                        fail_connection(aid,error=error)
                        self.store.event('trade','retry','Ошибка операции Trade',level='warning',account_id=aid,run_id=rid,
                                         details={'attempt':index+1,'error_type':type(error).__name__,'reason':str(error)})
                        if sent and sent():
                            recovery = getattr(browser,'_invitation_manual',None) if invitation_action else None
                            if recovery:
                                return recovery('После нажатия возникла ошибка. Браузер сохранён для проверки результата; повторная отправка отключена.')
                            raise
                        if index == run['settings']['collection']['retries']:
                            raise
                        value = {'status':'error','retryable':True}
                    fail_connection(aid,result=value)
                    if not (value.get('status') == 'error' and value.get('retryable') and not (sent and sent())):
                        return value
                    if index == run['settings']['collection']['retries']:
                        return value
                    self.update(rid,progress={'operation':'Повторяем операцию, которая ещё не отправляла приглашение',
                                             'retry_attempt':index+2,'source_account_id':aid})
                    await browser.actions.sleep(run['settings']['collection']['login_poll_seconds'])
            result = await attempt(action)
            while result.get('status') in ('requires_manual', 'session_expired'):
                invitation = result.get('manual_kind') == 'invitation'
                generation = control.manual_generation
                self.store.account_status(aid,'requires_manual','Trade ожидает ручного подтверждения')
                self.update(rid, status='requires_manual', progress={'operation': 'Проверьте добавление в оставленном открытым браузере' if invitation else 'Завершите подтверждение в Chrome и продолжите Trade',
                    'manual_kind':'invitation' if invitation else 'login',
                    'manual_reason':redact(result.get('reason','Требуется подтверждение'),(credentials.password,credentials.auth_token,credentials.ct0_token,credentials.proxy,credentials.ichat_password))})
                await asyncio.to_thread(control.wait_manual, generation)
                if invitation:
                    # Keep the exact sender open. Do not run login/navigation
                    # that discards its pending picker, and never resend.
                    self.update(rid,status='running',progress={'operation':'Сверяем результат добавления без повторной отправки'})
                    result = await attempt(verification)
                    if result.get('status') == 'confirmed':
                        self.update(rid,progress={'manual_reason':None,'manual_kind':None})
                        self.store.account_status(aid,'trade','Аккаунт занят обменом группами')
                    elif result.get('status') not in ('requires_manual','session_expired'):
                        result = TradeSession._invitation_manual('Добавление всё ещё не подтверждено. Завершите его в браузере и снова проверьте результат или остановите Trade.',result)
                    continue
                credentials.ichat_password = self.secrets.get(aid)['ichat_password'] or None
                login = await login_call(aid,lambda:browser.continue_login(credentials))
                if login.get('status') != 'active':
                    result = login
                    if result.get('status') not in ('requires_manual','session_expired'):
                        self.store.account_status(aid,'session_expired','Повторный вход Trade не подтверждён')
                        return result
                    continue
                self.update(rid, status='running',progress={'manual_reason':None,'manual_kind':None})
                self.store.account_status(aid,'trade','Аккаунт занят обменом группами')
                result = await attempt(verification if verification and sent() else action)
                if invitation_action and sent() and result.get('status') not in ('confirmed','requires_manual','session_expired'):
                    recovery = getattr(browser,'_invitation_manual',None)
                    if recovery:
                        result = recovery('После восстановления входа добавление не подтверждено. Проверьте его в открытом браузере.',result)
            return result

        async def discover(aid):
            browser, credentials = await session(aid)
            value = await operation(aid, lambda: browser.discover_groups(credentials))
            if value.get('status') in ('error','unavailable','session_expired','requires_manual'):
                raise RuntimeError('Trade group list unavailable')
            self.store.save_discovery(aid, value.get('groups', []), value.get('status','partial'))
            discovered.add(aid)
            return value

        async def planning_operation(aid, function):
            browser, _ = await session(aid)
            return await operation(aid,lambda:function(browser))

        async def incoming_check():
            baseline = self.run(rid)['baseline']
            if not baseline:
                raise RuntimeError('No incoming baseline')
            self.update(rid, progress={'operation':'Проверка входящих: только список чатов'})
            value = await discover(run['config']['receive_account_id'])
            old = set(baseline['group_ids'])
            groups = {str(g['x_id']):g for g in value.get('groups',[]) if str(g['x_id']) not in old}
            expected = run['plan']['total_requested']
            complete = baseline.get('complete') is True and value.get('status') == 'full'
            incoming = {'checked_at':utcnow(),'expected':expected,'observed_count':len(groups),
                'difference':len(groups)-expected,'groups':list(groups.values()),
                'baseline_complete':baseline.get('complete',False),'current_complete':value.get('status')=='full',
                'current_end_evidence':value.get('end_evidence'),
                'sufficient_confirmed':complete and len(groups)>=expected,
                'verdict':('enough' if len(groups)>=expected else 'shortage') if complete else 'preliminary',
                'attribution':'Новые чаты относительно начала Trade. Кто именно добавил аккаунт, интерфейс не подтверждает.',
                'reason':value.get('reason','')}
            self.store.execute('INSERT INTO trade_incoming_checks VALUES(?,?,?,?)', (str(uuid4()),rid,incoming['checked_at'],encode(incoming)))
            self.update(rid, incoming=incoming)
            return incoming

        followed = {}

        async def ensure_follow(aid, name):
            key = (aid, name)
            if key in followed:
                return followed[key]
            control.checkpoint()
            browser, _ = await session(aid)
            actions = self.store.rows('SELECT status FROM trade_follow_actions WHERE run_id=? AND account_id=? AND username=?',(rid,aid,name))
            allow_send = not actions or actions[0]['status'] not in ('sending','uncertain')
            def before_follow():
                self.store.execute('INSERT OR REPLACE INTO trade_follow_actions VALUES(?,?,?,?,?)',(rid,aid,name,'sending',utcnow()))
                self.store.event('trade', 'checkpoint', 'Намерение подписаться сохранено перед отправкой',
                                 account_id=aid, run_id=rid, details={'username': name})
            def was_sent():
                return any(row['status'] in ('sending','uncertain') for row in self.store.rows('SELECT status FROM trade_follow_actions WHERE run_id=? AND account_id=? AND username=?',(rid,aid,name)))
            self.update(rid, progress={'operation':'Подписка нашего аккаунта на контрагента','username':name,'source_account_id':aid})
            value = await operation(aid,lambda: browser.follow(name,before_follow,allow_send=allow_send),
                verification=lambda:browser.follow(name,before_follow,allow_send=False),sent=was_sent)
            confirmed = value.get('following') is True
            self.store.execute('INSERT OR REPLACE INTO trade_follow_actions VALUES(?,?,?,?,?)',
                (rid,aid,name,'confirmed' if confirmed else ('uncertain' if was_sent() else 'not_sent'),utcnow()))
            self.store.execute('INSERT OR REPLACE INTO trade_relationships VALUES(?,?,?,?,?,?)',
                (aid,name,value.get('following'),value.get('follows_us'),utcnow(),encode(value)))
            followed[key] = confirmed
            self.store.event('trade', 'result', 'Результат подписки проверен', account_id=aid, run_id=rid,
                             details={'username': name, 'confirmed': confirmed, 'sent': was_sent()})
            return confirmed

        def waiting_status():
            current = self.run(rid)
            uncertain = any(item['status'] in ('sending','uncertain') for item in current['items'])
            if uncertain:
                return 'awaiting_review'
            if any(current['remaining'].values()):
                return 'awaiting_account'
            return 'awaiting_completion' if current['can_finish'] else 'awaiting_incoming'

        try:
            if checks_only:
                incoming = await relationships(run['config']['receive_account_id'], run['config']['donors'])
                outgoing = {}
                for source in run['plan']['send_accounts']:
                    if not automatic or source.get('eligible_count',0)>0:
                        outgoing.update({source['id']+':'+name:ok for name,ok in (await relationships(source['id'], run['config']['recipients'])).items()})
                checked_status='awaiting_subscriptions' if not all(outgoing.values()) else waiting_status()
                self.update(rid, status='checked' if not run['priority_held'] else checked_status,
                    progress={'operation':'Подписки проверены без новых подписок и приглашений','donors':incoming,'recipients':outgoing})
                return
            if incoming_only:
                await incoming_check()
                self.update(rid, status=control.return_status or waiting_status(), finished_at=control.original_finished_at,
                            progress={'operation':'Входящие перепроверены. При необходимости повторите проверку позже.'})
                return
            pending = [item for item in run['items'] if item['status'] in ('sending','uncertain')]
            if verify_only or pending:
                for item in run['items']:
                    if item['status'] not in ('sending','uncertain'):
                        continue
                    control.checkpoint()
                    aid = item.get('source_account_id') or run['config']['send_account_id']
                    account = self.store.account(aid)
                    if not account or account['archived']:
                        self.store.event('trade','error','Источник сохранённой попытки недоступен; сверка не выполнялась',level='warning',run_id=rid,
                                         details={'account_id':aid,'group_id':item['group_id']})
                        continue
                    browser, _ = await session(aid)
                    source = next((dict(group) for group in run['plan']['groups'] if group['id'] == item['group_id'] and
                                       (group.get('source_account_id') or run['config']['send_account_id']) == aid), None)
                    if source is None:
                        # A refreshed chat list can omit a previous uncertain
                        # attempt. Its saved group still permits verification.
                        source = dict(self.store.rows('SELECT * FROM groups WHERE id=?',(item['group_id'],))[0])
                    evidence = json.loads(item['evidence'])
                    source['target_x_id'] = evidence.get('target_x_id') or evidence.get('x_id')
                    value = await operation(aid, lambda: browser.verify_membership(source, item['recipient']))
                    self.store.event('trade','result','Сверка сохранённой попытки: '+str(value.get('status')),
                                     account_id=aid,run_id=rid,details={'group_id':item['group_id'],'recipient':item['recipient'],'reason':value.get('reason')})
                    if value.get('status') in ('confirmed','not_added'):
                        self.resolve_observation(item,value)
                remaining = any(self.run(rid)['remaining'].values())
                status = waiting_status()
                if remaining and status == 'awaiting_account':
                    status = 'awaiting_review'
                self.update(rid, status=control.return_status or status, finished_at=control.original_finished_at if control.return_status else None,
                            progress={'operation':'Сохранённые попытки сверены без повторных приглашений. Для оставшихся добавлений подготовьте план.' if remaining else 'Сохранённые попытки сверены. Исходящие добавления подтверждены; перепроверьте входящие.'})
                if verify_only or not control.prepare_only or any(i['status'] in ('sending','uncertain') for i in self.run(rid)['items']):
                    return
            if not run['baseline']:
                # Take this BEFORE following donors: they may act immediately
                # after seeing the follow. Never reset it when another sender joins.
                self.update(rid, progress={'operation':'Начальный список входящих групп перед подпиской'})
                value = await discover(run['config']['receive_account_id'])
                known = {str(g['x_id']) for g in value.get('groups',[])}
                if value.get('status') != 'full':
                    known.update(str(g['x_id']) for g in self.store.rows('SELECT g.x_id FROM groups g JOIN account_groups a ON a.group_id=g.id WHERE a.account_id=?', (run['config']['receive_account_id'],)))
                run['baseline'] = {'created_at':utcnow(),'group_ids':sorted(known),'complete':value.get('status')=='full',
                    'groups':value.get('groups',[]),'reason':value.get('reason',''),'account_id':run['config']['receive_account_id'],
                    'end_evidence':value.get('end_evidence')}
                self.update(rid, baseline=run['baseline'])
            if control.prepare_only:
                from .trade_planning import prepare_plan
                # New trades cannot send while their initial inventory is incomplete.
                # An old exposed snapshot is immutable; its incoming result can be
                # explicitly confirmed by the user instead of falsifying completeness.
                history = bool(run['items'] or self.store.rows('SELECT username FROM trade_follow_actions WHERE run_id=?',(rid,)))
                if not run['baseline'].get('complete') and not history:
                    if run['config']['receive_account_id'] not in discovered:
                        value = await discover(run['config']['receive_account_id'])
                        if value.get('status')=='full' and not run['plan'].get('preparation',{}).get('created_at'):
                            run['baseline'] = {'created_at':utcnow(),'group_ids':sorted({str(g['x_id']) for g in value['groups']}),
                                               'complete':True,'groups':value['groups'],'reason':value.get('reason',''),'account_id':run['config']['receive_account_id']}
                            run['baseline']['end_evidence']=value.get('end_evidence')
                            self.update(rid,baseline=run['baseline'])
                    if not run['baseline'].get('complete'):
                        self.update(rid,status='preparation_blocked',progress={'operation':'Начальный список чатов неполный. Ничего не отправлено. Повторите подготовку после загрузки списка.'})
                        return
                prepared = await prepare_plan(self,run,planning_operation,discover,discovered,control.checkpoint)
                state = prepared['preparation']['state']
                self.update(rid,plan=prepared,status={'ready':'prepared','shortage':'preparation_shortage','blocked':'preparation_blocked'}[state],
                            progress={'operation':'План готов. Передайте ссылки получателю, дождитесь подписок и нажмите «Начать Trade».' if state=='ready' else 'Точный план не готов. Проверьте недостающие группы и причины исключения; приглашения не отправлялись.'})
                return
            preparation = run['plan'].get('preparation',{})
            assignments = preparation.get('assignments',[])
            prepared_outgoing = {}
            checks, invalid = [], []
            for required in preparation.get('required_accounts',[]):
                aid = required['id']
                for name in required['recipients']:
                    value = await planning_operation(aid,lambda browser:browser.relationship(name))
                    current = self.store.account(aid)
                    identity = preparation['identities'][name]['x_id']
                    same = str(value.get('x_id') or '')==str(identity) and current['username']==required['username']
                    checks.append({'account_id':aid,'account_username':current['username'],'url':'https://x.com/'+current['username'],
                                   'recipient':name,'follows_us':value.get('follows_us') is True,'identity_confirmed':same,'checked_at':utcnow()})
                    if (value.get('x_id') and str(value['x_id'])!=str(identity)) or current['username']!=required['username']:
                        invalid.append('ID получателя или логин исходящего аккаунта изменился')
                    self.store.execute('INSERT OR REPLACE INTO trade_relationships VALUES(?,?,?,?,?,?)',
                        (aid,name,value.get('following'),value.get('follows_us'),utcnow(),encode(value)))
            run['plan']['preparation'] = {**preparation,'subscription_checks':checks}
            self.update(rid,plan=run['plan'])
            if invalid:
                run['plan']['preparation']['state']='invalidated'
                self.update(rid,plan=run['plan'],status='preparation_blocked',progress={'operation':'Личность получателя или наш аккаунт изменились. Подготовьте новый точный план.'})
                return
            unverified = [x for x in checks if not x['identity_confirmed']]
            if unverified:
                self.update(rid,status='awaiting_review',progress={'operation':'Не удалось перепроверить ID получателя на всех выбранных аккаунтах. Ничего не отправлено; повторите запуск после загрузки профиля.'})
                return
            missing = [x for x in checks if not x['follows_us']]
            if missing:
                description='; '.join('@'+x['recipient']+' → @'+x['account_username'] for x in missing)
                self.update(rid,status='awaiting_subscriptions',progress={'operation':'Обратная подписка не подтверждена: '+description+'. Приглашения не отправлялись. Передайте ссылки и повторите запуск.',
                            'relationship_blocks':missing})
                return
            for required in preparation.get('required_accounts',[]):
                for name in required['recipients']:
                    aid = required['id']
                    following = await ensure_follow(aid,name)
                    mutual = await relationships(aid,[name]) if following else {}
                    prepared_outgoing[(aid,name)] = following and mutual.get(name,False)
                    for check in checks:
                        if check['account_id']==aid and check['recipient']==name:
                            check['following']=following
            run['plan']['preparation']['subscription_checks']=checks
            self.update(rid,plan=run['plan'])
            if not all(prepared_outgoing.values()):
                self.update(rid,status='awaiting_subscriptions',progress={'operation':'Взаимная подписка не подтверждена на всех выбранных аккаунтах; приглашения не отправлялись.'})
                return
            # Verify the ENTIRE frozen plan before the first invitation.
            for group in assignments:
                aid,name = group['source_account_id'],group['recipient']
                if self.store.rows("SELECT id FROM trade_items WHERE run_id=? AND group_id=? AND recipient=? AND status='confirmed'",(rid,group['id'],name)):
                    continue
                value = await planning_operation(aid,lambda browser:browser.inspect_candidate(group,name))
                if value.get('status')=='error' and value.get('retryable'):
                    self.update(rid,status='awaiting_review',progress={'operation':'Временная ошибка проверки зафиксированной группы. Ничего не отправлено; повторите запуск после восстановления X.'})
                    return
                if value.get('status')!='eligible' or value.get('invitation_ready') is False or str(value.get('x_id') or '')!=str(group['target_x_id']):
                    if value.get('status')=='already_member':
                        self._remember_existing(run,group,name,aid,value)
                    invalid.append(value.get('reason','Группа больше не подходит'))
                    break
                for item in self.store.rows("SELECT * FROM trade_items WHERE group_id=? AND recipient=? AND status IN ('sending','uncertain') AND run_id!=?",(group['id'],name,rid)):
                    old = json.loads(item['evidence'])
                    if old.get('target_x_id') and str(old['target_x_id'])!=str(group['target_x_id']):
                        invalid.append('В истории есть неподтверждённая попытка с другим ID')
                    else:
                        self.resolve_observation(item,{'status':'not_added','x_id':value['x_id'],'reason':'Свежая сверка до запуска нового Trade'})
            if invalid:
                run['plan']['preparation']['state']='invalidated'
                self.update(rid,plan=run['plan'],status='preparation_blocked',progress={'operation':'План изменился до отправки: '+invalid[0]+'. Пересоберите план и снова передайте актуальные ссылки.'})
                return
            receive_id = run['config']['receive_account_id']
            for name in run['config']['donors']:
                if not await ensure_follow(receive_id, name):
                    self.update(rid,status='awaiting_review',progress={'operation':'Подписка на входящего контрагента не подтверждена. Проверьте профиль и продолжите.', 'username':name})
                    return
            outgoing = prepared_outgoing
            async def send_from(source):
                aid = source['id']
                source_groups = [g for g in assignments if g['source_account_id']==aid]
                for target in run['config']['recipients']:
                    if self.store.rows("SELECT id FROM trade_items WHERE run_id=? AND recipient=? AND status IN ('sending','uncertain')",(rid,target)):
                        continue
                    confirmed = self.store.rows("SELECT COUNT(*) AS count FROM trade_items WHERE run_id=? AND recipient=? AND status='confirmed'",(rid,target))[0]['count']
                    for original_group in source_groups:
                        control.checkpoint()
                        if original_group.get('recipient')!=target:
                            continue
                        if confirmed >= run['config']['count']:
                            break
                        aid = original_group.get('source_account_id') or run['config']['send_account_id']
                        group = dict(original_group)
                        existing = self.store.rows('SELECT * FROM trade_items WHERE run_id=? AND group_id=? AND recipient=?',(rid,group['id'],target))
                        if existing and existing[0]['status'] not in ('checking','error','not_added','unavailable'):
                            continue
                        if self.store.rows("SELECT id FROM trade_items WHERE group_id=? AND recipient=? AND status IN ('uncertain','sending') AND run_id!=?",(group['id'],target,rid)):
                            continue
                        if outgoing.get((aid,target)) is not True:
                            raise RuntimeError('Frozen subscription preflight is missing')
                        target_id = original_group['target_x_id']
                        group['target_x_id'] = target_id
                        item_id = existing[0]['id'] if existing else str(uuid4())
                        previous_attempts = self._previous_attempts(existing[0]) if existing else []
                        if existing:
                            self.store.execute("UPDATE trade_items SET status='checking',reason='',source_account_id=?,updated_at=?,evidence=? WHERE id=?",(aid,utcnow(),encode({'attempts':previous_attempts}),item_id))
                        else:
                            self.store.execute('INSERT INTO trade_items(id,run_id,group_id,recipient,status,reason,group_name,url,quality,score,updated_at,source_account_id) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',
                                (item_id,rid,group['id'],target,'checking','',group['name'],group['url'],group['quality'],group['score'],utcnow(),aid))
                        self.update(rid,progress={'operation':'Поиск получателя в группе','username':target,'group_name':group['name'],
                            'source_account_id':aid,'confirmed_for_recipient':confirmed,'requested_per_recipient':run['config']['count']})
                        def before_send():
                            self.store.execute("UPDATE trade_items SET status='sending',updated_at=?,evidence=? WHERE id=?",
                                (utcnow(),encode({'attempts':previous_attempts,'target_x_id':target_id}),item_id))
                            self.store.execute("UPDATE groups SET membership_status='partial',reason='После попытки Trade необходимо обновить состав' WHERE id=?",(group['id'],))
                            self.store.event('trade', 'checkpoint', 'Намерение пригласить сохранено перед отправкой',
                                             account_id=aid, run_id=rid, details={'group_id': group['id'], 'recipient': target})
                        def was_sent():
                            return self.store.rows('SELECT status FROM trade_items WHERE id=?',(item_id,))[0]['status']=='sending'
                        browser, _ = await session(aid)
                        try:
                            value = await operation(aid,lambda:browser.invite(group,target,before_send),
                                verification=lambda:browser.verify_membership(group,target),sent=was_sent,invitation_action=True)
                        except StopRequested:
                            raise
                        except Exception:
                            value = {'status':'uncertain' if was_sent() else 'error','reason':'Действие не подтверждено; подробности страницы не записывались'}
                        status = value.get('status','error')
                        if status=='confirmed' and not was_sent():
                            status,value='error',{'reason':'Добавление без сохранённого намерения не засчитывается'}
                        elif was_sent() and status not in ('confirmed','uncertain'):
                            status='uncertain'
                        if status not in ('confirmed','already_member','unavailable','uncertain','error'):
                            status='uncertain' if was_sent() else 'error'
                        value['attempts'] = previous_attempts
                        value['target_x_id'] = target_id
                        self.store.execute('UPDATE trade_items SET status=?,reason=?,updated_at=?,evidence=? WHERE id=?',
                            (status,value.get('reason',''),utcnow(),encode(value),item_id))
                        self.store.event('trade', 'result', 'Результат приглашения: ' + status, account_id=aid, run_id=rid,
                                         level='warning' if status in ('uncertain','unavailable') else 'error' if status == 'error' else 'info',
                                         details={'group_id': group['id'], 'recipient': target, 'reason': value.get('reason','')})
                        if status=='unavailable':
                            self.store.execute('INSERT OR REPLACE INTO trade_capabilities VALUES(?,?,?,?,?)',(group['id'],aid,'unavailable',value.get('reason',''),utcnow()))
                        elif status in ('confirmed','already_member'):
                            self._record_membership(run,group['id'],target,aid,value,changed=status=='confirmed')
                            if status=='confirmed':
                                confirmed+=1
                            if not value.get('cached'):
                                self.store.execute('INSERT OR REPLACE INTO trade_capabilities VALUES(?,?,?,?,?)',(group['id'],aid,'allowed','Форма добавления доступна; участник подтверждён',utcnow()))
                        elif status=='uncertain':
                            break
                        await browser.actions.sleep(run['settings']['collection']['group_delay_seconds'])
            sources = list(run['plan']['send_accounts'])
            if not automatic:
                positions = {source['id']:next((i for i,g in enumerate(run['plan']['groups']) if (g.get('source_account_id') or run['config']['send_account_id'])==source['id']),len(run['plan']['groups'])) for source in sources}
                sources.sort(key=lambda source:(source['id']!=run['plan'].get('preferred_source_id'),positions[source['id']]))
            for source in sources:
                control.checkpoint()
                if not any(self.run(rid)['remaining'].values()):
                    break
                try:
                    await send_from(source)
                except StopRequested:
                    raise
                except Exception as error:
                    if not automatic or getattr(control,'cleanup_failed',False):
                        raise
                    self.store.event('trade','error','Исходящий аккаунт не завершил операцию',level='error',
                                     account_id=source['id'],run_id=rid,details={'error_type':type(error).__name__,'reason':str(error)})
                    # The next candidate can still satisfy the same quota.
                    # Any saved sending intent is reconciled, never resent.
                    self.store.execute("UPDATE trade_items SET status='uncertain',reason='Источник прерван после отправки; нужна сверка' WHERE run_id=? AND source_account_id=? AND status='sending'",(rid,source['id']))
                    source_errors.append({'account_id':source['id'],'username':source['username'],'reason':'Источник не завершил проверку или добавление. Другие аккаунты проверены; повтор возможен при продолжении.'})
            run['plan']['shortage'] = max(self.run(rid)['remaining'].values(),default=0)
            self.update(rid,plan=run['plan'])
            await incoming_check()
            status = waiting_status()
            blocked=[{'account_id':aid,'username':target} for (aid,target),confirmed in outgoing.items()
                     if not confirmed and self.run(rid)['remaining'].get(target,0)>0]
            failed_items = [item for item in self.run(rid)['items'] if item['status'] in ('error','not_added')]
            if status=='awaiting_account' and (blocked or source_errors or failed_items):
                status='awaiting_review'
            if status=='awaiting_account':
                status='preparation_blocked'
                run['plan']['preparation']['state']='invalidated'
                self.update(rid,plan=run['plan'])
            text = {'awaiting_account':'Групп не хватило. Выберите ещё один наш аккаунт и продолжите этот Trade.',
                    'awaiting_incoming':'Исходящие добавления выполнены. Ожидаются входящие группы; нажмите «Перепроверить».',
                    'awaiting_completion':'Обмен подтверждён. Нажмите «Завершить Trade».',
                    'awaiting_review':'Есть неподтверждённые попытки. Сверьте их перед продолжением.',
                    'preparation_blocked':'Часть зафиксированных групп больше недоступна. Подготовьте план оставшихся добавлений; новые аккаунты автоматически не подставлялись.'}[status]
            if automatic and status=='awaiting_account':
                text='Доступные аккаунты проверены, новых подходящих групп не хватило. Добавьте аккаунт или повторите после обновления статистики.'
            if source_errors and status=='awaiting_review':
                text='Некоторые исходящие аккаунты не завершили проверку. Проверьте источники и продолжите Trade.'
            if failed_items and status=='awaiting_review' and not (blocked or source_errors):
                text='Часть групп не обработана из-за ошибки до отправки или подтверждённого отсутствия получателя. Нажмите «Продолжить обмен» для повторной попытки на этих аккаунтах. Подробности — во вкладке «Все попытки» и логах.'
            if blocked and status=='awaiting_review' and not any(i['status']=='uncertain' for i in self.run(rid)['items']):
                names=', '.join('@'+name for name in dict.fromkeys(row['username'] for row in blocked))
                accounts=', '.join('@'+self.store.account(row['account_id'])['username'] for row in blocked)
                text=f'Взаимная подписка не подтверждена для {names}. Наши исходящие аккаунты: {accounts}. После обратной подписки нажмите «Продолжить обмен». Подробности — в проверенных подписках.'
            self.update(rid,status=status,progress={'operation':text,'relationship_blocks':blocked,'source_errors':source_errors})
        finally:
            for aid, (browser, _) in sessions.items():
                self.store.event('trade','lifecycle','Освобождаем браузер после этапа Trade',account_id=aid,run_id=rid)
                try:
                    await browser.close()
                    self._closed_account(aid)
                except Exception as error:
                    control.cleanup_failed = True
                    self.store.event('trade','error','Не подтверждено закрытие браузера Trade',level='error',account_id=aid,
                                     run_id=rid,details={'error_type':type(error).__name__,'reason':str(error)})
            for lease in leases.values():
                lease.close()
            for logger in loggers.values():
                logger.base.close()
            if getattr(control, 'cleanup_failed', False):
                raise RuntimeError('Браузер Trade не подтвердил завершение; автоматическое продолжение сбора отключено')

    def close(self):
        self.closing = True
        self.jobs.closing = True
        for control in self.controls.values():
            with control.condition:
                control.stopped = True
                control.condition.notify_all()
        for thread in self.threads.values():
            thread.join(60)
