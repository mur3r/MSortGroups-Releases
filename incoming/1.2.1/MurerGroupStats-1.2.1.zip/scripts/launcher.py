"""Stable supervisor: never overwrite a running release or its Python environment.

This file stays in the original installation. Protocol 1 is intentionally small;
future releases must remain compatible or require a new base installation.
"""
import json
import os
from pathlib import Path
import shutil
import sqlite3
import subprocess
import sys
import time
from urllib.request import ProxyHandler, Request, build_opener
from uuid import uuid4

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

import psutil
from murer.runtime import FileLease, default_data_dir
from murer.update_format import verify_manifest, verify_tree
from murer.updates import atomic_json, read_json


class Supervisor:
    def __init__(self, root=ROOT, global_data=None):
        self.root = Path(root).resolve()
        self.state = self.root / '.murer-updates'
        self.state.mkdir(parents=True, exist_ok=True)
        self.global_data = Path(global_data or default_data_dir()).resolve()
        self.session = uuid4().hex

    def slot(self, value):
        if value == '.':
            return self.root
        candidate = (self.root / value).resolve()
        releases = (self.state / 'releases').resolve()
        if candidate.parent != releases or not candidate.is_dir() or (self.root / value).is_symlink():
            raise RuntimeError('Некорректная папка версии. Рабочие файлы не изменены.')
        return candidate

    def active(self):
        value = read_json(self.state / 'active.json')
        if not value:
            value = {'slot': '.', 'version': (self.root / 'VERSION').read_text(encoding='utf-8').strip()}
        self.slot(value['slot'])
        return value

    def global_lease(self):
        return FileLease(self.global_data / '.application.lock')

    def write_transaction(self, transaction, **changes):
        transaction.update(changes)
        atomic_json(self.state / 'transaction.json', transaction)

    def result(self, transaction, success, message):
        version = transaction['target']['version'] if success else transaction['before']['version']
        atomic_json(self.state / 'result.json', {'id': transaction['id'], 'success': success,
                    'version': version, 'failed_version': None if success else transaction['target']['version'],
                    'message': message, 'at': time.time(), 'backup': transaction.get('backup')})
        atomic_json(self.state / 'status.json', {'phase': 'idle', 'message': message, 'progress': 0})

    @staticmethod
    def owned_process(record):
        try:
            process = psutil.Process(record['pid'])
            return process if abs(process.create_time() - record['created']) < .1 else None
        except (KeyError, psutil.Error):
            return None

    def launch(self, active, arguments, transaction=None):
        slot = self.slot(active['slot'])
        python = slot / '.venv' / ('Scripts/python.exe' if os.name == 'nt' else 'bin/python')
        if not python.is_file():
            raise RuntimeError('Окружение Python отсутствует. Для исходной установки запустите install.cmd.')
        if not (slot / 'frontend' / 'dist' / 'index.html').is_file():
            raise RuntimeError('Интерфейс не собран. Для исходной установки запустите install.cmd.')
        environment = dict(os.environ, MURER_INSTALL_ROOT=str(self.root), MURER_LAUNCHER_SESSION=self.session)
        environment.pop('MURER_UPDATE_NONCE', None)
        if transaction:
            environment['MURER_UPDATE_NONCE'] = transaction['nonce']
        process = subprocess.Popen([str(python), '-m', 'murer', *arguments], cwd=slot, env=environment,
                                   creationflags=subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0)
        record = {'pid': process.pid, 'created': psutil.Process(process.pid).create_time(), 'session': self.session}
        atomic_json(self.state / 'running.json', record)
        if transaction:
            self.write_transaction(transaction, child=record)
        return process

    def snapshot(self, transaction):
        database = Path(transaction['database']).resolve()
        if database.name != 'murer.sqlite3' or not database.is_file():
            raise RuntimeError('База данных для резервной копии не найдена.')
        backup = self.state / 'backups' / transaction['id']
        backup.mkdir(parents=True, exist_ok=False)
        temporary = backup / 'database.partial'
        source = sqlite3.connect(database)
        target = sqlite3.connect(temporary)
        try:
            if source.execute('PRAGMA quick_check').fetchone()[0] != 'ok':
                raise RuntimeError('Проверка базы перед обновлением не пройдена. Обновление отменено.')
            source.backup(target)
        finally:
            target.close()
            source.close()
        os.replace(temporary, backup / 'murer.sqlite3')
        bootstrap = self.global_data / 'bootstrap.json'
        existed = bootstrap.is_file()
        if existed:
            shutil.copy2(bootstrap, backup / 'bootstrap.json')
        self.write_transaction(transaction, backup=str(backup.relative_to(self.root)),
                               bootstrap_existed=existed, phase='backed_up')

    def restore(self, transaction):
        backup = (self.root / transaction['backup']).resolve()
        if backup.parent != (self.state / 'backups').resolve():
            raise RuntimeError('Небезопасный путь резервной копии.')
        database = Path(transaction['database']).resolve()
        if database.name != 'murer.sqlite3':
            raise RuntimeError('Небезопасный путь базы данных.')
        source = backup / 'murer.sqlite3'
        if not source.is_file() or source.stat().st_size < 100:
            raise RuntimeError('Резервная копия отсутствует. Рабочая база не изменена.')
        db = sqlite3.connect(source.as_uri() + '?mode=ro', uri=True)
        try:
            if db.execute('PRAGMA quick_check').fetchone()[0] != 'ok':
                raise RuntimeError('Резервная копия повреждена. Требуется ручное восстановление.')
        finally:
            db.close()
        temporary = database.with_name('murer-restore-' + transaction['id'] + '.tmp')
        shutil.copy2(source, temporary)
        # Exact files only, after the application lease is acquired. No directory deletion.
        for suffix in ('-wal', '-shm'):
            Path(str(database) + suffix).unlink(missing_ok=True)
        os.replace(temporary, database)
        bootstrap = self.global_data / 'bootstrap.json'
        if transaction.get('bootstrap_existed'):
            shutil.copy2(backup / 'bootstrap.json', bootstrap)
        else:
            bootstrap.unlink(missing_ok=True)
        atomic_json(self.state / 'active.json', transaction['before'])

    def recover(self):
        transaction = read_json(self.state / 'transaction.json')
        if not transaction or transaction.get('phase') in ('committed', 'rolled_back', 'cancelled'):
            return
        self.write_transaction(transaction, phase='recovering')
        record = transaction.get('child') or read_json(self.state / 'trial-process.json')
        process = self.owned_process(record)
        if process:
            process.terminate()
            try:
                process.wait(timeout=15)
            except psutil.TimeoutExpired:
                raise RuntimeError('Пробный процесс ещё работает. Восстановление базы отложено до его завершения.')
        lease = self.global_lease()
        try:
            if transaction.get('backup'):
                self.restore(transaction)
            else:
                atomic_json(self.state / 'active.json', transaction['before'])
            self.write_transaction(transaction, phase='rolled_back')
            self.result(transaction, False, 'Установка была прервана. Предыдущая версия и база восстановлены.')
        finally:
            lease.close()

    def verify_target(self, target):
        candidate = self.slot(target['slot'])
        if (candidate / 'VERSION').read_text(encoding='utf-8').strip() != target['version']:
            raise RuntimeError('Версия подготовленного приложения изменилась.')
        if target.get('receipt'):
            receipt_path = (self.root / target['receipt']).resolve()
            if self.state.resolve() not in receipt_path.parents:
                raise RuntimeError('Некорректный путь квитанции обновления.')
            receipt = read_json(receipt_path)
            metadata = (self.root / receipt['metadata']).resolve()
            if metadata.parent != (self.state / 'downloads').resolve() or self.slot(receipt['candidate']) != candidate:
                raise RuntimeError('Некорректная подготовка обновления.')
            keys = read_json(self.root / 'config' / 'updates.json')['public_keys']
            manifest = verify_manifest((metadata / 'murer-update.json').read_bytes(),
                                       (metadata / 'murer-update.sig').read_bytes(), keys)
            if manifest['version'] != target['version']:
                raise RuntimeError('Версия квитанции обновления не совпала.')
            verify_tree(candidate, manifest)

    def wait_ready(self, process, transaction, port, timeout=60):
        opener = build_opener(ProxyHandler({}))
        deadline = time.monotonic() + timeout
        stable_since = None
        while time.monotonic() < deadline and process.poll() is None:
            try:
                with opener.open(f'http://127.0.0.1:{port}/api/health', timeout=1) as response:
                    health = json.load(response)
                if (health.get('status') != 'ok' or health.get('version') != transaction['target']['version']
                        or health.get('startup_nonce') != transaction['nonce'] or not health.get('database_ok')):
                    stable_since = None
                    time.sleep(.2)
                    continue
                with opener.open(f'http://127.0.0.1:{port}/', timeout=1) as response:
                    if response.status == 200 and b'<html' in response.read(1024 * 1024).lower():
                        stable_since = stable_since or time.monotonic()
                        if time.monotonic() - stable_since >= 2:
                            return process.poll() is None
                    else:
                        stable_since = None
            except (OSError, ValueError):
                stable_since = None
            time.sleep(.2)
        return False

    @staticmethod
    def port(arguments):
        if '--port' in arguments:
            return int(arguments[arguments.index('--port') + 1])
        for argument in arguments:
            if argument.startswith('--port='):
                return int(argument.split('=', 1)[1])
        return 8765

    def stop_child(self, process, arguments):
        if process.poll() is not None:
            return
        opener = build_opener(ProxyHandler({}))
        url = f'http://127.0.0.1:{self.port(arguments)}'
        try:
            with opener.open(url + '/api/health', timeout=2) as response:
                health = json.load(response)
            if health.get('launch_session') != self.session:
                raise RuntimeError('Процесс на порту не принадлежит этому запуску.')
            with opener.open(Request(url + '/api/shutdown', data=b'{}', headers={'Content-Type':'application/json'}), timeout=3):
                pass
            process.wait(timeout=130)
        except (OSError, ValueError, subprocess.TimeoutExpired):
            print('Дождитесь завершения программы или остановите её через настройки.', file=sys.stderr)

    def activate(self, request, arguments):
        arguments = list(arguments)
        if '--no-open' not in arguments:
            arguments.append('--no-open')
        before = self.active()
        transaction = {**request, 'before': before, 'phase': 'validating', 'nonce': uuid4().hex}
        self.write_transaction(transaction)
        try:
            self.verify_target(request['target'])
        except Exception:
            self.write_transaction(transaction, phase='cancelled')
            raise
        lease = self.global_lease()
        try:
            self.snapshot(transaction)
        except Exception:
            self.write_transaction(transaction, phase='cancelled')
            self.result(transaction, False, 'Резервная копия не создана. Обновление отменено; рабочая версия сохранена.')
            raise
        finally:
            lease.close()
        process = None
        try:
            self.write_transaction(transaction, phase='trial')
            process = self.launch(request['target'], arguments, transaction)
            port = self.port(arguments)
            if not self.wait_ready(process, transaction, port):
                raise RuntimeError('Новая версия не прошла проверку запуска.')
            active = {**request['target'], 'previous': {key: before[key] for key in ('slot', 'version', 'receipt') if key in before},
                      'backup': transaction['backup']}
            atomic_json(self.state / 'active.json', active)
            self.write_transaction(transaction, phase='committed')
            self.result(transaction, True, 'Версия ' + active['version'] + ' установлена. Резервная копия сохранена.')
            return process
        except Exception:
            if process and process.poll() is None:
                process.terminate()
                process.wait(timeout=15)
            self.write_transaction(transaction, phase='recovering')
            lease = self.global_lease()
            try:
                self.restore(transaction)
                self.write_transaction(transaction, phase='rolled_back')
                self.result(transaction, False, 'Новая версия не запустилась. Предыдущая версия и база автоматически восстановлены.')
            finally:
                lease.close()
            return self.launch(before, arguments)

    def run(self, arguments):
        lease = FileLease(self.state / 'launcher.lock')
        process = None
        try:
            self.recover()
            existing = self.owned_process(read_json(self.state / 'running.json'))
            if existing:
                raise RuntimeError('Предыдущий процесс программы ещё работает. Завершите его перед повторным запуском.')
            # Never execute a stale request after a console crash or power loss.
            (self.state / 'pending.json').unlink(missing_ok=True)
            process = self.launch(self.active(), arguments)
            while True:
                code = process.wait()
                request = read_json(self.state / 'pending.json')
                (self.state / 'pending.json').unlink(missing_ok=True)
                if (not request or request.get('session') != self.session or code != 0
                        or read_json(self.state / 'status.json').get('phase') != 'installing'):
                    return code
                try:
                    process = self.activate(request, arguments)
                except Exception as error:
                    transaction = {'id': request['id'], 'target': request['target'], 'before': self.active()}
                    self.result(transaction, False, 'Обновление отменено. Рабочая версия сохранена; подробности в окне запуска.')
                    print(str(error), file=sys.stderr)
                    # An incomplete recovery must never start against a possibly migrated DB.
                    state = read_json(self.state / 'transaction.json')
                    if state.get('phase') not in ('cancelled', 'rolled_back', 'committed'):
                        raise
                    process = self.launch(self.active(), arguments)
        except KeyboardInterrupt:
            if process:
                self.stop_child(process, arguments)
            return 0
        finally:
            lease.close()


if __name__ == '__main__':
    try:
        raise SystemExit(Supervisor().run(sys.argv[1:]))
    except KeyboardInterrupt:
        raise SystemExit(0)
    except Exception as error:
        print('Не удалось завершить запуск/обновление: ' + str(error), file=sys.stderr)
        print('Повторите start.cmd. Резервные копии находятся в .murer-updates/backups.', file=sys.stderr)
        raise SystemExit(1)
