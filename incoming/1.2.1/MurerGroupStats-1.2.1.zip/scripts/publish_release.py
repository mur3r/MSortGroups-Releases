"""Publish all verified assets as a draft, then make the complete release visible."""
import argparse
import json
import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from release_github import api, publisher_token
from murer.update_format import verify_manifest, sha256


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--artifacts', type=Path, default=ROOT / 'artifacts' / 'release')
    args = parser.parse_args()
    config = json.loads((ROOT / 'config' / 'updates.json').read_text(encoding='utf-8'))
    raw = (args.artifacts / 'murer-update.json').read_bytes()
    manifest = verify_manifest(raw, (args.artifacts / 'murer-update.sig').read_bytes(), config['public_keys'])
    version = manifest['version']
    if (ROOT / 'VERSION').read_text().strip() != version:
        raise RuntimeError('Artifact version differs from the checked-out source.')
    if os.environ.get('GITHUB_REF_TYPE') == 'tag' and os.environ.get('GITHUB_REF_NAME') != 'v' + version:
        raise RuntimeError('Git tag differs from VERSION. Publish a new matching version.')
    archive = args.artifacts / manifest['package']['name']
    if sha256(archive) != manifest['package']['sha256']:
        raise RuntimeError('Artifact changed after signing.')
    repository = config['repository']
    token = publisher_token(repository.split('/')[0])
    existing = api(token, 'GET', f'/repos/{repository}/releases?per_page=100')
    release = next((r for r in existing if r['tag_name'] == 'v' + version), None)
    if release and not release['draft']:
        raise RuntimeError('This version has already been published. Increase VERSION; published releases are never overwritten.')
    notes_path = ROOT / 'RELEASE_NOTES.md'
    notes = notes_path.read_text(encoding='utf-8') if notes_path.is_file() else 'Murer Group Stats ' + version
    if not release:
        release = api(token, 'POST', f'/repos/{repository}/releases', json={
            'tag_name': 'v' + version, 'target_commitish': os.environ.get('GITHUB_SHA', 'main'),
            'name': 'Murer Group Stats ' + version, 'body': notes, 'draft': True, 'prerelease': False})
    for old in release['assets']:
        if old['name'] in {archive.name, 'murer-update.json', 'murer-update.sig'}:
            api(token, 'DELETE', f"/repos/{repository}/releases/assets/{old['id']}")
    for path in (archive, args.artifacts / 'murer-update.json', args.artifacts / 'murer-update.sig'):
        from urllib.parse import quote
        upload = release['upload_url'].split('{')[0] + '?name=' + quote(path.name)
        api(token, 'POST', upload, headers={'Content-Type': 'application/octet-stream'}, content=path.read_bytes())
    published = api(token, 'PATCH', f"/repos/{repository}/releases/{release['id']}", json={'draft': False, 'make_latest': 'true'})
    print('Published complete signed release: ' + published['html_url'])


if __name__ == '__main__':
    main()
