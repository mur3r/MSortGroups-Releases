$ErrorActionPreference = 'Stop'
$taskRoot = Split-Path $PSScriptRoot -Parent
Set-Location -LiteralPath $taskRoot
try {
    if (-not (Get-Command py -ErrorAction SilentlyContinue)) { throw 'Install Python 3.11+ from python.org with the Python launcher.' }
    & py -3 -c "import sys; assert sys.version_info >= (3,11), 'Python 3.11 or newer is required'"
    if ($LASTEXITCODE -ne 0) { throw 'Python 3.11+ is required.' }
    if (-not (Test-Path -LiteralPath '.venv\Scripts\python.exe')) {
        & py -3 -m venv .venv
        if ($LASTEXITCODE -ne 0) { throw 'Could not create Python environment.' }
    }
    $taskPython = Join-Path $taskRoot '.venv\Scripts\python.exe'
    $taskRequirements = if (Test-Path -LiteralPath 'requirements-lock.txt') { 'requirements-lock.txt' } else { 'requirements-app.txt' }
    & $taskPython -m pip install -r $taskRequirements
    if ($LASTEXITCODE -ne 0) { throw 'Python dependency installation failed. Check internet access.' }
    if ((Test-Path -LiteralPath '.git') -or -not (Test-Path -LiteralPath 'frontend\dist\index.html')) {
        if (-not (Get-Command npm.cmd -ErrorAction SilentlyContinue)) { throw 'Install Node.js 22.12+ LTS from nodejs.org to build the interface.' }
        & node -e "let [a,b]=process.versions.node.split('.').map(Number);if(a<22||(a===22&&b<12))process.exit(1)"
        if ($LASTEXITCODE -ne 0) { throw 'Node.js 22.12+ is required to build the interface.' }
        Push-Location -LiteralPath 'frontend'
        try {
            & npm.cmd ci
            if ($LASTEXITCODE -ne 0) { throw 'Frontend dependency installation failed.' }
            & npm.cmd run build
            if ($LASTEXITCODE -ne 0) { throw 'Frontend build failed.' }
        } finally { Pop-Location }
    } else {
        Write-Host 'Using the prebuilt release interface. Node.js is not required.'
    }
    & $taskPython check_setup.py
    if ($LASTEXITCODE -ne 0) { throw 'Foundation import check failed.' }
    Write-Host 'Installation complete. Run start.cmd.' -ForegroundColor Green
} catch {
    Write-Host $_.Exception.Message -ForegroundColor Red
    exit 1
}
