"""Build a portable ZIP with prebuilt UI and an Ed25519-signed manifest."""
import argparse
import base64
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import stat
import zipfile

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives.serialization import Encoding, PublicFormat
from murer.update_format import APP, MAX_PACKAGE, REQUIRED, canonical_json, safe_member, sha256, version_tuple


def build(root, output, signing_key):
    root, output = Path(root), Path(output)
    version = (root / 'VERSION').read_text(encoding='utf-8').strip()
    version_tuple(version)
    config = json.loads((root / 'config' / 'updates.json').read_text(encoding='utf-8'))
    key = Ed25519PrivateKey.from_private_bytes(base64.b64decode(signing_key, validate=True))
    public = base64.b64encode(key.public_key().public_bytes(Encoding.Raw, PublicFormat.Raw)).decode('ascii')
    key_ids = [key_id for key_id, value in config['public_keys'].items() if value == public]
    if len(key_ids) != 1:
        raise ValueError('Signing key does not match the public key shipped to clients.')
    tracked = subprocess.check_output(['git', 'ls-files', '-z'], cwd=root).decode('utf-8').split('\0')
    names = set(name for name in tracked if name)
    tracked_names = set(names)
    names.update(str(path.relative_to(root)).replace('\\', '/') for path in (root / 'frontend' / 'dist').rglob('*') if path.is_file())
    if not REQUIRED.issubset(names):
        raise ValueError('Release is incomplete. Stage new source files and build frontend/dist first.')
    suspicious = re.compile(rb'(?:gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,}|AKIA[0-9A-Z]{16}|-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----)')
    files = {}
    contents = {}
    for name in sorted(names):
        safe_member(name)
        path = root / name
        if path.is_symlink() or not path.is_file():
            raise ValueError('Release contains a missing file or symbolic link: ' + name)
        content = subprocess.check_output(['git', 'show', ':' + name], cwd=root) if name in tracked_names else path.read_bytes()
        if suspicious.search(content):
            raise ValueError('Potential secret in release file (value hidden): ' + name)
        contents[name] = content
        files[name] = hashlib.sha256(content).hexdigest()
    output.mkdir(parents=True, exist_ok=True)
    archive = output / f'MurerGroupStats-{version}.zip'
    with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as target:
        for name in files:
            item = zipfile.ZipInfo(name, date_time=(2020, 1, 1, 0, 0, 0))
            item.create_system = 3
            item.external_attr = (stat.S_IFREG | 0o644) << 16
            item.compress_type = zipfile.ZIP_DEFLATED
            target.writestr(item, contents[name], compresslevel=9)
    if archive.stat().st_size > min(MAX_PACKAGE, 95 * 1024 * 1024):
        raise ValueError('Release package is too large.')
    manifest = {'schema': 1, 'application': APP, 'updater_protocol': 1, 'version': version,
                'notes': contents.get('RELEASE_NOTES.md', b'').decode('utf-8').strip()[:12000],
                'python_min': '3.11', 'files': files,
                'package': {'name': archive.name, 'size': archive.stat().st_size, 'sha256': sha256(archive)}}
    raw = canonical_json(manifest)
    signature = {'key_id': key_ids[0], 'signature': base64.b64encode(key.sign(raw)).decode('ascii')}
    (output / 'murer-update.json').write_bytes(raw)
    (output / 'murer-update.sig').write_bytes(canonical_json(signature))
    print(f'Built {archive.name}: {len(files)} files; signed with key {key_ids[0]}.')
    return manifest


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, default=ROOT / 'artifacts' / 'release')
    args = parser.parse_args()
    signing = os.environ.get('UPDATE_SIGNING_KEY')
    if not signing:
        import keyring
        config = json.loads((ROOT / 'config' / 'updates.json').read_text(encoding='utf-8'))
        signing = keyring.get_password('Murer Group Stats Publisher', 'ed25519:' + config.get('source_repository', config['repository']))
    if not signing:
        raise RuntimeError('Signing key is missing. Run scripts/setup_releases.py on the publisher computer.')
    build(ROOT, args.output, signing)


if __name__ == '__main__':
    main()
