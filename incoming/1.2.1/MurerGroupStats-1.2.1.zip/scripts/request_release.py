"""Convenience command for a clean publisher checkout; never commits unrelated files."""
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from murer.update_format import version_tuple


def git(*arguments):
    return subprocess.check_output(['git', *arguments], cwd=ROOT, text=True).strip()


def main():
    if len(sys.argv) != 2:
        raise RuntimeError('Usage: publish-release.cmd 1.2.3. Commit your application changes first.')
    version = sys.argv[1]
    version_tuple(version)
    if git('branch', '--show-current') != 'main' or git('status', '--porcelain'):
        raise RuntimeError('Commit application changes on main first. The release command never commits unrelated files.')
    current = (ROOT / 'VERSION').read_text().strip()
    existing = git('tag', '--list', 'v' + version)
    if existing:
        if version != current or git('rev-list', '-n', '1', existing) != git('rev-parse', 'HEAD'):
            raise RuntimeError('This tag already belongs to another commit. Choose a new version.')
    else:
        if version_tuple(version) <= version_tuple(current):
            raise RuntimeError('Choose a version newer than ' + current)
        (ROOT / 'VERSION').write_text(version + '\n', encoding='utf-8')
        git('add', '--', 'VERSION')
        git('commit', '--only', 'VERSION', '-m', 'Release ' + version)
        git('tag', '-a', 'v' + version, '-m', 'Murer Group Stats ' + version)
    subprocess.run(['git', 'push', 'origin', 'main'], cwd=ROOT, check=True)
    subprocess.run(['git', 'push', 'origin', 'v' + version], cwd=ROOT, check=True)
    print('GitHub Actions will test, build, sign, and publish version ' + version + '.')


if __name__ == '__main__':
    main()
