"""Send signed artifacts using a deploy key restricted to the public repo.

The public repository's own workflow publishes Releases with its GITHUB_TOKEN.
No owner's personal access token is stored in Actions or distributed to users.
"""
import json
import os
from pathlib import Path
import shlex
import shutil
import subprocess
import sys
import tempfile
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from murer.update_format import sha256, verify_manifest


def main():
    config = json.loads((ROOT / 'config' / 'updates.json').read_text())
    repository = config['repository']
    artifacts = ROOT / 'artifacts' / 'release'
    raw = (artifacts / 'murer-update.json').read_bytes()
    manifest = verify_manifest(raw, (artifacts / 'murer-update.sig').read_bytes(), config['public_keys'])
    version = manifest['version']
    if (ROOT / 'VERSION').read_text().strip() != version:
        raise RuntimeError('Artifact version differs from the source.')
    if os.environ.get('GITHUB_REF_TYPE') == 'tag' and os.environ.get('GITHUB_REF_NAME') != 'v' + version:
        raise RuntimeError('Tag differs from VERSION.')
    archive = artifacts / manifest['package']['name']
    if sha256(archive) != manifest['package']['sha256'] or archive.stat().st_size >= 95 * 1024 * 1024:
        raise RuntimeError('Archive changed or exceeds the public transfer limit (95 MB).')
    with tempfile.TemporaryDirectory(prefix='murer_release_transfer_') as temporary:
        directory = Path(temporary)
        target = directory / 'public'
        subprocess.run(['git','clone','--depth','1','https://github.com/'+repository+'.git',str(target)],check=True)
        deploy = os.environ.get('UPDATE_RELEASE_DEPLOY_KEY')
        if os.environ.get('GITHUB_ACTIONS') == 'true' and not deploy:
            raise RuntimeError('UPDATE_RELEASE_DEPLOY_KEY is not configured in the source repository.')
        environment = dict(os.environ)
        if deploy:
            key = directory / 'deploy-key'
            # OpenSSH private keys require LF, including on Windows.
            key.write_bytes(deploy.rstrip().encode('ascii')+b'\n')
            key.chmod(0o600)
            with urlopen(Request('https://api.github.com/meta', headers={'User-Agent':'MurerGroupStats-Publisher'}),timeout=30) as response:
                hosts = json.load(response)['ssh_keys']
            known = directory / 'known-hosts'
            known.write_text(''.join('github.com '+value+'\n' for value in hosts),encoding='ascii')
            environment['GIT_SSH_COMMAND'] = ('ssh -i '+shlex.quote(key.as_posix())+' -o IdentitiesOnly=yes -o BatchMode=yes -o StrictHostKeyChecking=yes -o UserKnownHostsFile='+shlex.quote(known.as_posix()))
            subprocess.run(['git','remote','set-url','origin','git@github.com:'+repository+'.git'],cwd=target,check=True)
        incoming = target / 'incoming' / version
        if incoming.exists():
            previous = (incoming / 'murer-update.json').read_bytes()
            if previous != raw:
                raise RuntimeError('This version already has different artifacts. Increase VERSION.')
        incoming.mkdir(parents=True,exist_ok=True)
        for name in (archive.name,'murer-update.json','murer-update.sig'):
            shutil.copy2(artifacts/name,incoming/name)
        shutil.copy2(ROOT/'RELEASE_NOTES.md',incoming/'RELEASE_NOTES.md')
        (target/'incoming'/'latest.json').write_text(json.dumps({'version':version})+'\n')
        (target/'public-keys.json').write_text(json.dumps(config['public_keys'])+'\n')
        (target/'.github'/'workflows').mkdir(parents=True,exist_ok=True)
        shutil.copy2(ROOT/'config'/'public-release-workflow.yml',target/'.github'/'workflows'/'publish.yml')
        (target/'scripts').mkdir(exist_ok=True)
        for name in ('public_release.py','release_github.py'):
            shutil.copy2(ROOT/'scripts'/name,target/'scripts'/name)
        subprocess.run(['git','config','user.name','Murer release publisher'],cwd=target,check=True)
        subprocess.run(['git','config','user.email','release-publisher@users.noreply.github.com'],cwd=target,check=True)
        subprocess.run(['git','add','--','.'],cwd=target,check=True)
        dirty = subprocess.check_output(['git','status','--porcelain'],cwd=target,text=True).strip()
        if dirty:
            subprocess.run(['git','commit','-m','Publish signed version '+version],cwd=target,check=True)
            subprocess.run(['git','push','origin','main'],cwd=target,env=environment,check=True)
        else:
            print('Artifacts are already present. Re-run Publish public release in the public repository if needed.')
    print('Public publication queued: https://github.com/'+repository+'/actions')


if __name__=='__main__':
    main()
