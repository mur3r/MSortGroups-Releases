"""Owner-only setup for public releases and a repo-restricted SSH deploy key."""
import base64
import json
from pathlib import Path
import shutil
import subprocess
import sys

import httpx
import keyring
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives.serialization import Encoding, PrivateFormat, NoEncryption, PublicFormat
from nacl.public import PublicKey, SealedBox

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0,str(ROOT))
from murer.updates import atomic_json
from release_github import api, publisher_token


def main():
    source = 'mur3r/MSortGroups'
    public = 'mur3r/MSortGroups-Releases'
    token = publisher_token('mur3r')
    if api(token,'GET','/user')['login'] != 'mur3r':
        raise RuntimeError('Unexpected authenticated GitHub owner.')
    response = httpx.get('https://api.github.com/repos/'+public,headers={'Authorization':'Bearer '+token,'User-Agent':'Murer-Setup'},timeout=30)
    if response.status_code==404:
        repo=api(token,'POST','/user/repos',json={'name':'MSortGroups-Releases','description':'Public signed Murer Group Stats releases. No login needed for updates.',
                    'private':False,'auto_init':True,'has_issues':True,'has_projects':False,'has_wiki':False})
    elif response.status_code==200:
        repo=response.json()
    else:
        raise RuntimeError('Cannot inspect public repository: HTTP '+str(response.status_code))
    if repo['private'] or repo['full_name']!=public:
        raise RuntimeError('Expected a dedicated public releases repository.')
    config=json.loads((ROOT/'config'/'updates.json').read_text())
    config.update(repository=public,source_repository=source,public=True)
    atomic_json(ROOT/'config'/'updates.json',config)
    account='deploy:'+public
    private=keyring.get_password('Murer Group Stats Publisher',account)
    if not private:
        key=Ed25519PrivateKey.generate()
        private=key.private_bytes(Encoding.PEM,PrivateFormat.OpenSSH,NoEncryption()).decode('ascii')
        keyring.set_password('Murer Group Stats Publisher',account,private)
    else:
        from cryptography.hazmat.primitives.serialization import load_ssh_private_key
        key=load_ssh_private_key(private.encode('ascii'),None)
    public_key=key.public_key().public_bytes(Encoding.OpenSSH,PublicFormat.OpenSSH).decode('ascii')
    existing=api(token,'GET',f'/repos/{public}/keys')
    if not any(item['key'].split()[:2]==public_key.split()[:2] for item in existing):
        api(token,'POST',f'/repos/{public}/keys',json={'title':'Signed release delivery from MSortGroups','key':public_key,'read_only':False})
    server=api(token,'GET',f'/repos/{source}/actions/secrets/public-key')
    encrypted=base64.b64encode(SealedBox(PublicKey(base64.b64decode(server['key']))).encrypt(private.encode('ascii'))).decode('ascii')
    api(token,'PUT',f'/repos/{source}/actions/secrets/UPDATE_RELEASE_DEPLOY_KEY',json={'encrypted_value':encrypted,'key_id':server['key_id']})
    checkout=ROOT/'.murer-updates'/'public-repo'
    if not (checkout/'.git').is_dir():
        subprocess.run(['git','clone','https://github.com/'+public+'.git',str(checkout)],check=True)
    (checkout/'.github'/'workflows').mkdir(parents=True,exist_ok=True)
    shutil.copy2(ROOT/'config'/'public-release-workflow.yml',checkout/'.github'/'workflows'/'publish.yml')
    (checkout/'scripts').mkdir(exist_ok=True)
    for name in ('public_release.py','release_github.py'):
        shutil.copy2(ROOT/'scripts'/name,checkout/'scripts'/name)
    (checkout/'public-keys.json').write_text(json.dumps(config['public_keys'])+'\n')
    (checkout/'README.md').write_text('''# Murer Group Stats — публичные обновления

Готовые подписанные сборки: [открыть Releases](https://github.com/mur3r/MSortGroups-Releases/releases/latest).

Скачайте `MurerGroupStats-<версия>.zip` из вложений релиза, распакуйте в отдельную папку и запустите `install.cmd`, затем `start.cmd`. Нужен Python 3.11+ с launcher `py`; интерфейс уже собран, Node.js пользователю релиза не нужен.

В программе: **Настройки → Обновления программы → Проверить обновления → Скачать обновление → Установить и перезапустить**. Вход в GitHub и токены не требуются. Подробная инструкция находится в ZIP: `docs/UPDATES_GITHUB_RU.md`.

Здесь доступны файлы программы, включая Python-код. Данные пользователей, профили браузеров, пароли и закрытые ключи подписи в сборки не включены.

Каталог `incoming` используется автоматической публикацией; для установки выбирайте готовый ZIP из Releases. Изменения проходят тестирование и подписываются в рабочем репозитории владельца, затем этот репозиторий проверяет подпись и публикует все вложения одновременно.
''',encoding='utf-8')
    subprocess.run(['git','add','--','.'],cwd=checkout,check=True)
    if subprocess.check_output(['git','status','--porcelain'],cwd=checkout,text=True).strip():
        subprocess.run(['git','commit','-m','Configure signed public release publication'],cwd=checkout,check=True)
        subprocess.run(['git','push','origin','main'],cwd=checkout,check=True)
    print('Public release repository configured: https://github.com/'+public)
    print('The source repository remains private. The SSH deploy key grants access only to the public releases repository.')


if __name__=='__main__':
    main()
