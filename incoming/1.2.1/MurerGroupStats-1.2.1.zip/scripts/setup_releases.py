"""One-time owner setup. The private key never enters the working tree."""
import base64
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
import keyring
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives.serialization import Encoding, PrivateFormat, NoEncryption, PublicFormat
from nacl.public import PublicKey, SealedBox
from release_github import api, publisher_token
from murer.updates import atomic_json


def main():
    repository = 'mur3r/MSortGroups'
    path = ROOT / 'config' / 'updates.json'
    existing = json.loads(path.read_text(encoding='utf-8')) if path.is_file() else {}
    repository = existing.get('repository', repository)
    source_repository = existing.get('source_repository', repository)
    account = 'ed25519:' + source_repository
    secret = keyring.get_password('Murer Group Stats Publisher', account)
    if not secret:
        if existing.get('public_keys'):
            raise RuntimeError('The publisher key is missing. Restore its backup; do not rotate keys silently.')
        key = Ed25519PrivateKey.generate()
        secret = base64.b64encode(key.private_bytes(Encoding.Raw, PrivateFormat.Raw, NoEncryption())).decode('ascii')
        keyring.set_password('Murer Group Stats Publisher', account, secret)
    key = Ed25519PrivateKey.from_private_bytes(base64.b64decode(secret, validate=True))
    public = base64.b64encode(key.public_key().public_bytes(Encoding.Raw, PublicFormat.Raw)).decode('ascii')
    if existing.get('public_keys') and public not in existing['public_keys'].values():
        raise RuntimeError('Publisher key does not match the existing client trust key.')
    config = existing or {'repository': repository, 'public_keys': {'murer-2026-01': public}}
    atomic_json(path, config)
    token = publisher_token(repository.split('/')[0])
    server_key = api(token, 'GET', f'/repos/{source_repository}/actions/secrets/public-key')
    encrypted = base64.b64encode(SealedBox(PublicKey(base64.b64decode(server_key['key']))).encrypt(secret.encode('ascii'))).decode('ascii')
    api(token, 'PUT', f'/repos/{source_repository}/actions/secrets/UPDATE_SIGNING_KEY', json={'encrypted_value': encrypted, 'key_id': server_key['key_id']})
    # This owner's existing Git credential stays on this machine only.
    if source_repository == repository:
        keyring.set_password('Murer Group Stats Updates', 'github:' + repository, token)
    print('Public verification key saved in config/updates.json.')
    print('Private signing key saved in Windows Credential Manager and encrypted GitHub Actions secret UPDATE_SIGNING_KEY.')
    print('Updater access configured locally for the publisher. No GitHub token is included in the release.')


if __name__ == '__main__':
    main()
