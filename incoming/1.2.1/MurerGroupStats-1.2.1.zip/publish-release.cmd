@echo off
cd /d "%~dp0"
".venv\Scripts\python.exe" scripts\request_release.py %*
if errorlevel 1 pause
