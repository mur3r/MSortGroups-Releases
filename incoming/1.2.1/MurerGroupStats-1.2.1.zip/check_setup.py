"""Offline import check: does not open browsers or access accounts."""
from xgenius.accounts import AccountManager
from xgenius.collectors.groups import GroupCollector
from xgenius.models import AccountCredentials, AccountState

def main():
    for name in ("login_account", "_accept_cookies", "_perform_login", "_login_with_tokens", "_check_login_locks", "auto_relogin_if_needed"):
        assert callable(getattr(AccountManager, name))
    assert callable(GroupCollector.find_groups)
    print("OK: imports and reusable methods are available. No browser was started.")

if __name__ == "__main__":
    main()
