import { useEffect, useMemo, useState } from 'react'
import { ChevronDown, ChevronLeft, ChevronRight, Download, Filter, RefreshCw, Search } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { DropdownMenu, DropdownMenuContent, DropdownMenuCheckboxItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger, DropdownMenuItem } from '@/components/ui/dropdown-menu'
import { api, number, type Row } from '@/lib/api'

type Selection = string[] | null
type Preferences = { tab: string; kinds: Selection; levels: Selection; accounts: Selection }
type Options = { domains: Record<string, string>; levels: Record<string, string>; kinds: Record<string, string> }
type Event = { id: number; at: string; domain: string; level: string; kind: string; message: string; account_id: string; run_id: string; details: Row }
type Page = { items: Event[]; has_more: boolean; next_before: number | null; matching: number; stored: number; latest_id: number; warning: string; max_rows: number; retention_days: number; oldest: string | null; memory_events: number }
const defaults: Preferences = { tab: 'all', kinds: null, levels: null, accounts: null }
function readPreferences(): Preferences {
  try {
    const value = JSON.parse(localStorage.getItem('murer-log-filters') || 'null')
    if (!value || typeof value.tab !== 'string') return defaults
    const selection = (key: string) => Array.isArray(value[key]) ? value[key].filter((v: unknown) => typeof v === 'string').slice(0, 100) : null
    return { tab: value.tab, kinds: selection('kinds'), levels: selection('levels'), accounts: selection('accounts') }
  } catch { return defaults }
}
function MultiFilter({ label, options, selected, onChange }: { label: string; options: Record<string, string>; selected: Selection; onChange: (v: Selection) => void }) {
  const keys = Object.keys(options)
  const count = selected === null ? keys.length : selected.length
  return <DropdownMenu><DropdownMenuTrigger asChild><Button variant="outline" size="sm"><Filter className="size-3.5" />{label}: {selected === null ? 'все' : `${count}/${keys.length}`}<ChevronDown className="size-3.5" /></Button></DropdownMenuTrigger><DropdownMenuContent align="start" className="w-72 max-h-96">
    <DropdownMenuLabel>{label} · можно выбрать несколько</DropdownMenuLabel>
    <DropdownMenuItem onSelect={e => { e.preventDefault(); onChange(null) }}>Выбрать все</DropdownMenuItem>
    <DropdownMenuItem onSelect={e => { e.preventDefault(); onChange([]) }}>Снять все</DropdownMenuItem><DropdownMenuSeparator />
    {Object.entries(options).map(([key, title]) => <DropdownMenuCheckboxItem key={key} checked={selected === null || selected.includes(key)} onSelect={e => e.preventDefault()} onCheckedChange={checked => {
      const values = selected ?? keys
      onChange(checked ? [...new Set([...values, key])] : values.filter(v => v !== key))
    }}>{title}</DropdownMenuCheckboxItem>)}
    {!keys.length && <p className="p-2 text-xs text-muted-foreground">Нет доступных значений</p>}
  </DropdownMenuContent></DropdownMenu>
}
const time = (at: string) => new Date(at).toLocaleString('ru-RU', { year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false, fractionalSecondDigits: 3 })

export function Logs({ accounts }: { accounts: Row[] }) {
  const [preferences, setPreferences] = useState<Preferences>(readPreferences)
  const [options, setOptions] = useState<Options>({ domains: {}, levels: {}, kinds: {} })
  const [page, setPage] = useState<Page | null>(null)
  const [search, setSearch] = useState(''); const [query, setQuery] = useState('')
  const [runId, setRunId] = useState(''); const [live, setLive] = useState(true)
  const [snapshot, setSnapshot] = useState(0); const [before, setBefore] = useState(0)
  const [history, setHistory] = useState<number[]>([])
  const [revision, setRevision] = useState(0); const [error, setError] = useState(''); const [loading, setLoading] = useState(false)
  const [exporting, setExporting] = useState(false)
  useEffect(() => { api<Options>('/logs/options').then(setOptions).catch(e => setError(e.message)) }, [])
  useEffect(() => { try { localStorage.setItem('murer-log-filters', JSON.stringify(preferences)) } catch { /* filters still work without local storage */ } }, [preferences])
  useEffect(() => { const timer = setTimeout(() => setQuery(search.trim()), 300); return () => clearTimeout(timer) }, [search])
  const names = useMemo(() => Object.fromEntries(accounts.map(a => [a.id, `@${a.username}${a.archived ? ' · архив' : ''}`])), [accounts])
  const filters = new URLSearchParams()
  if (preferences.tab !== 'all' && preferences.tab !== 'problems') filters.set('domains', preferences.tab)
  let levels = preferences.levels
  if (preferences.tab === 'problems') levels = (levels ?? ['warning', 'error']).filter(v => v === 'warning' || v === 'error')
  if (levels !== null) filters.set('levels', levels.join(','))
  if (preferences.kinds !== null) filters.set('kinds', preferences.kinds.join(','))
  if (preferences.accounts !== null) filters.set('accounts', preferences.accounts.join(','))
  if (query) filters.set('q', query)
  if (runId) filters.set('run_id', runId)
  const filterKey = filters.toString()
  useEffect(() => { setBefore(0); setHistory([]) }, [filterKey])
  if (snapshot) filters.set('until', String(snapshot))
  if (before) filters.set('before', String(before))
  const pageQuery = filters.toString()
  useEffect(() => {
    const controller = new AbortController(); let active = true; let pending = false
    const refresh = async () => {
      if (pending) return
      pending = true; setLoading(true)
      try {
        const response = await api<Page>(`/logs?${pageQuery}`, { signal: controller.signal })
        if (active) { setPage(response); setError('') }
      } catch (e) { if (active && (e as Error).name !== 'AbortError') setError((e as Error).message) }
      finally { pending = false; if (active) setLoading(false) }
    }
    refresh()
    const interval = live && !before ? setInterval(refresh, 2000) : null
    return () => { active = false; controller.abort(); if (interval) clearInterval(interval) }
  }, [pageQuery, live, before, revision])
  const select = (key: keyof Omit<Preferences, 'tab'>, value: Selection) => setPreferences(prev => ({ ...prev, [key]: value }))
  const latest = () => { setBefore(0); setHistory([]); setSnapshot(0); setLive(true); setRevision(v => v+1) }
  const pause = () => { if (live) setSnapshot(Math.max(page?.latest_id ?? 0, 1)); setLive(false) }
  const exportLogs = async () => {
    setExporting(true)
    try {
      const params = new URLSearchParams(filterKey); params.set('until', String(snapshot || page?.latest_id || 1))
      const response = await fetch(`/api/logs/export?${params}`)
      if (!response.ok) throw new Error('Не удалось выгрузить журнал')
      const url = URL.createObjectURL(await response.blob()); const anchor = document.createElement('a')
      anchor.href = url; anchor.download = 'murer-logs.jsonl'; anchor.click(); setTimeout(() => URL.revokeObjectURL(url), 1000)
    } catch (e) { setError((e as Error).message) }
    finally { setExporting(false) }
  }
  return <div className="space-y-4" data-testid="activity-logs">
    <Card><CardHeader className="gap-2"><div className="flex flex-wrap items-center justify-between gap-3"><CardTitle className="text-base">Журнал работы программы</CardTitle><div className="flex items-center gap-2"><Switch id="logs-live" checked={live} onCheckedChange={v => v ? latest() : pause()} /><Label htmlFor="logs-live" className="text-xs">Обновлять автоматически</Label></div></div>
      <CardDescription>Этапы операций, действия браузера, результаты, ожидания и ошибки. Новые записи появляются сверху, примерно раз в 2 секунды.</CardDescription>
    </CardHeader><CardContent className="space-y-4">
      <Tabs value={preferences.tab} onValueChange={tab => setPreferences(prev => ({ ...prev, tab }))}><div className="overflow-x-auto pb-1"><TabsList className="w-max"><TabsTrigger value="all">Все события</TabsTrigger>{Object.entries(options.domains).map(([key, name]) => <TabsTrigger key={key} value={key}>{name}</TabsTrigger>)}<TabsTrigger value="problems">Ошибки и предупреждения</TabsTrigger></TabsList></div></Tabs>
      <div className="flex flex-wrap gap-2"><MultiFilter label="Типы событий" options={options.kinds} selected={preferences.kinds} onChange={v => select('kinds', v)} /><MultiFilter label="Уровни" options={options.levels} selected={preferences.levels} onChange={v => select('levels', v)} /><MultiFilter label="Аккаунты" options={{ '@none': 'Без аккаунта (общие события)', ...names }} selected={preferences.accounts} onChange={v => select('accounts', v)} /><Button variant="ghost" size="sm" onClick={() => { setPreferences(defaults); setSearch(''); setRunId(''); latest() }}>Сбросить фильтры</Button></div>
      <div className="flex flex-wrap gap-2 items-center"><div className="relative flex-1 min-w-44"><Search className="absolute left-3 top-2.5 size-4 text-muted-foreground" /><Input aria-label="Поиск по журналу" value={search} onChange={e => setSearch(e.target.value)} placeholder="Поиск по сообщениям, контексту и ID задания" className="pl-9" /></div>{runId && <Button variant="secondary" size="sm" onClick={() => setRunId('')}>Задание {runId.slice(0, 8)} · ×</Button>}<Button variant="outline" size="sm" onClick={() => setRevision(v => v+1)} disabled={loading}><RefreshCw className="size-3.5" />Обновить</Button><Button variant="outline" size="sm" onClick={exportLogs} disabled={exporting || !page?.items.length}><Download className="size-3.5" />Выгрузить JSONL</Button></div>
      <p className="text-xs text-muted-foreground">Внутри каждого фильтра действует «или», между фильтрами — «и». Выбор сохраняется на этом компьютере. Фильтры и пауза просмотра не останавливают запись событий.</p>
    </CardContent></Card>
    {error && <Alert variant="destructive"><AlertDescription>{error}</AlertDescription></Alert>}
    {page?.warning && <Alert variant="destructive"><AlertDescription>{page.warning}</AlertDescription></Alert>}
    <Card className="gap-0 py-0 overflow-hidden"><div className="px-4 py-3 border-b flex flex-wrap justify-between items-center gap-2 text-xs text-muted-foreground" aria-live="polite"><span>{loading && !page ? 'Загрузка…' : `На странице: ${number(page?.items.length)} · осталось с учётом фильтров: ${number(page?.matching)}`}</span><span>{live ? '● Прямой эфир' : 'Просмотр зафиксирован'} · {number(page?.stored)} записей на диске</span></div>
      <div className="divide-y max-h-[65vh] min-h-36 overflow-y-auto" aria-label="События журнала">{page?.items.map(event => <div key={event.id} className="p-4 space-y-2" data-log-id={event.id}>
        <div className="flex flex-wrap items-center gap-2 text-[11px] text-muted-foreground"><time dateTime={event.at}>{time(event.at)}</time><Badge variant={event.level === 'error' ? 'destructive' : event.level === 'warning' ? 'outline' : 'secondary'}>{options.levels[event.level] ?? event.level}</Badge><span>{options.domains[event.domain] ?? event.domain} / {options.kinds[event.kind] ?? event.kind}</span><span>#{event.id}</span>{event.account_id && <Badge variant="outline">{names[event.account_id] ?? event.account_id}</Badge>}{event.run_id && <button className="text-primary underline underline-offset-2" title="Показать только это задание" onClick={() => setRunId(event.run_id)}>Задание {event.run_id.slice(0, 8)}</button>}</div>
        <p className="text-sm whitespace-pre-wrap break-words leading-relaxed">{event.message}</p>
        {Object.keys(event.details).length > 0 && <details className="text-xs"><summary className="cursor-pointer text-muted-foreground w-fit">Подробности события</summary><pre className="mt-2 rounded-md bg-secondary/60 p-3 whitespace-pre-wrap break-all max-h-80 overflow-y-auto font-mono">{JSON.stringify(event.details, null, 2)}</pre></details>}
      </div>)}{!page?.items.length && <p className="px-5 py-12 text-sm text-muted-foreground text-center">{loading ? 'Загрузка событий…' : 'Событий по этим фильтрам нет. Выберите другие типы, вкладку или сбросьте фильтры.'}</p>}</div>
      <div className="border-t p-3 flex flex-wrap gap-2 items-center justify-between"><Button variant="ghost" size="sm" onClick={latest}>К новым событиям</Button><div className="flex gap-2"><Button variant="outline" size="sm" disabled={!history.length || loading} onClick={() => { setBefore(history[history.length-1]); setHistory(prev => prev.slice(0,-1)) }}><ChevronLeft className="size-4" />Новее</Button><Button variant="outline" size="sm" disabled={!page?.has_more || loading} onClick={() => { pause(); setHistory(prev => [...prev, before]); setBefore(page!.next_before!) }}>Старее<ChevronRight className="size-4" /></Button></div></div>
    </Card>
    <p className="text-xs text-muted-foreground leading-relaxed">Журнал хранится локально и переживает перезапуск: до {number(page?.max_rows ?? 20000)} последних событий за {page?.retention_days ?? 14} дней. Старые записи удаляются автоматически. Пароли, PIN, токены, cookies, тексты сообщений и содержимое страниц в журнал не записываются. Выгрузка содержит все сохранённые события по выбранным фильтрам на момент просмотра.</p>
  </div>
}
