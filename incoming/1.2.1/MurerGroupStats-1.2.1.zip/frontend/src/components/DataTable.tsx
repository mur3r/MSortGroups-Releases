import { useEffect, useMemo, useState, type MouseEvent, type ReactNode } from 'react'
import { Search, ArrowUpDown, Download, SlidersHorizontal, ChevronLeft, ChevronRight, LoaderCircle } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Checkbox } from '@/components/ui/checkbox'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { DropdownMenu, DropdownMenuContent, DropdownMenuCheckboxItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { metricValue, type Row } from '@/lib/api'
export type Column = { key: string; label: string; render?: (row: Row) => ReactNode; hint?: string; hidden?: boolean; exportable?: boolean }
type Props = { rows: Row[]; columns: Column[]; onRow?: (row: Row) => void; selected?: string[]; onSelect?: (ids: string[]) => void; exportUrl?: string; empty?: ReactNode; rowKey?: string | ((row: Row) => string); extra?: ReactNode }
export function DataTable({ rows, columns, onRow, selected, onSelect, exportUrl, empty, rowKey = 'id', extra }: Props) {
  const [search, setSearch] = useState(''); const [sort, setSort] = useState(''); const [descending, setDescending] = useState(false)
  const [hidden, setHidden] = useState(() => columns.filter(c => c.hidden).map(c => c.key)); const [page, setPage] = useState(0); const [size, setSize] = useState(25)
  const [exporting, setExporting] = useState(false); const [exportError, setExportError] = useState('')
  const searchKeys = [...new Set([...columns.map(column => column.key), 'name', 'username', 'group', 'category', 'status', 'reason', 'account_ids', 'group_ids', 'author', 'kind'])]
    .filter(key => !['posts', 'observations', 'access_attempts', 'components'].includes(key)).join('\u0000')
  const searchIndex = useMemo(() => {
    const keys = searchKeys.split('\u0000')
    // Build compact strings only when data/columns change. Publication bodies,
    // observation history and component evidence never enter the table index.
    return rows.map(row => ({ row, text: JSON.stringify(Object.fromEntries(keys.map(key => [key, row[key]]))).toLocaleLowerCase('ru-RU') }))
  }, [rows, searchKeys])
  const filtered = useMemo(() => {
    const query = search.toLocaleLowerCase('ru-RU')
    let result = query ? searchIndex.filter(entry => entry.text.includes(query)).map(entry => entry.row) : rows
    if (sort) result = [...result].sort((a, b) => { const av = metricValue(a[sort]), bv = metricValue(b[sort]); if (av == null && bv == null) return 0; if (av == null) return 1; if (bv == null) return -1; return (typeof av === 'number' && typeof bv === 'number' ? av - bv : String(av).localeCompare(String(bv), 'ru', { numeric: true })) * (descending ? -1 : 1) })
    return result
  }, [rows, searchIndex, search, sort, descending])
  useEffect(() => setPage(0), [search, size])
  const maxPage = Math.max(0, Math.ceil(filtered.length / size) - 1); const activePage = Math.min(page, maxPage)
  const visible = columns.filter(c => !hidden.includes(c.key)); const items = filtered.slice(activePage * size, (activePage + 1) * size)
  const rowId = (row: Row) => String(typeof rowKey === 'function' ? rowKey(row) : row[rowKey])
  const download = exportUrl ? new URL(exportUrl, window.location.origin) : null
  if (download) {
    download.searchParams.set('search', search); download.searchParams.set('sort', sort); download.searchParams.set('descending', String(descending))
    download.searchParams.set('columns', visible.filter(c => c.exportable !== false).map(c => c.key).join(','))
    // Preserve all visible filters and their order before pagination, while the
    // analysis scope remains the explicit account/group selection above.
    download.searchParams.set('row_ids', JSON.stringify(filtered.map(rowId)))
  }
  const downloadCsv = async (event: MouseEvent<HTMLAnchorElement>) => {
    event.preventDefault()
    if (!download || exporting) return
    setExporting(true); setExportError('')
    try {
      const response = await fetch(download.pathname, { method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...Object.fromEntries(download.searchParams), descending, row_ids: filtered.map(rowId) }) })
      if (!response.ok) { const error = await response.json().catch(() => ({})); throw new Error(typeof error.detail === 'string' ? error.detail : `Не удалось выгрузить таблицу (${response.status})`) }
      const blobUrl = URL.createObjectURL(await response.blob()); const anchor = document.createElement('a')
      anchor.href = blobUrl; anchor.download = `murer-${download.searchParams.get('table') ?? 'table'}.csv`; anchor.click()
      setTimeout(() => URL.revokeObjectURL(blobUrl), 1000)
    } catch (error) { setExportError((error as Error).message) }
    finally { setExporting(false) }
  }
  const toggle = (id: string, checked: boolean) => onSelect?.(checked ? [...(selected ?? []), id] : (selected ?? []).filter(x => x !== id))
  const mobileFields = visible.filter(column => column.key !== 'actions')
  const actions = visible.find(column => column.key === 'actions')
  const cell = (column: Column, row: Row) => column.render ? column.render(row) : row[column.key] ?? <span className="text-muted-foreground">—</span>
  return <div className="data-table rounded-xl border bg-card min-w-0 overflow-hidden">
    <div className="flex flex-wrap gap-2 p-3 border-b items-center">
      <div className="relative w-full sm:w-72"><Search className="absolute left-3 top-2.5 size-4 text-muted-foreground" /><Input value={search} onChange={e => setSearch(e.target.value)} placeholder="Поиск в таблице…" className="pl-9 bg-background" aria-label="Поиск в таблице" /></div>
      {extra}<div className="flex-1" /><DropdownMenu><DropdownMenuTrigger asChild><Button variant="outline" size="sm"><SlidersHorizontal className="size-4" />Колонки</Button></DropdownMenuTrigger><DropdownMenuContent align="end">{columns.map(c => <DropdownMenuCheckboxItem key={c.key} checked={!hidden.includes(c.key)} disabled={!hidden.includes(c.key) && visible.length === 1} onCheckedChange={checked => setHidden(checked ? hidden.filter(x => x !== c.key) : [...hidden, c.key])}>{c.label}</DropdownMenuCheckboxItem>)}</DropdownMenuContent></DropdownMenu>
      {download && <Button variant="outline" size="sm" disabled={exporting} asChild><a href={`${download.pathname}${download.search}`} onClick={downloadCsv} download>{exporting ? <LoaderCircle className="size-4 animate-spin" /> : <Download className="size-4" />}CSV</a></Button>}
    </div>
    {exportError && <Alert variant="destructive" className="rounded-none border-x-0 border-t-0"><AlertDescription>{exportError}</AlertDescription></Alert>}
    <div className="data-table-desktop overflow-auto max-h-[65vh] scrollbar-thin"><Table><TableHeader className="sticky top-0 z-10 bg-card shadow-[0_1px_0_var(--border)]"><TableRow>
      {onSelect && <TableHead className="w-10"><Checkbox aria-label="Выбрать строки страницы" checked={items.length > 0 && items.every(r => selected?.includes(rowId(r)))} onCheckedChange={checked => onSelect(checked ? [...new Set([...(selected ?? []), ...items.map(rowId)])] : (selected ?? []).filter(id => !items.some(r => rowId(r) === id)))} /></TableHead>}
      {visible.map(c => <TableHead key={c.key} className="whitespace-nowrap text-xs h-11" title={c.hint}><button className="inline-flex items-center gap-1.5 py-2" onClick={() => { setSort(c.key); setDescending(sort === c.key ? !descending : false) }}>{c.label}<ArrowUpDown className={`size-3 ${sort === c.key ? 'text-primary' : 'opacity-40'}`} /></button></TableHead>)}
    </TableRow></TableHeader><TableBody>{items.map(row => <TableRow key={rowId(row)} className={onRow ? 'cursor-pointer hover:bg-primary/5' : ''} onClick={() => onRow?.(row)}>
      {onSelect && <TableCell onClick={e => e.stopPropagation()}><Checkbox aria-label={`Выбрать ${row.username ?? row.name ?? rowId(row)}`} checked={selected?.includes(rowId(row))} onCheckedChange={checked => toggle(rowId(row), Boolean(checked))} /></TableCell>}
      {visible.map(c => <TableCell key={c.key} className="text-[13px] whitespace-nowrap h-14 numeric">{c.render ? c.render(row) : row[c.key] ?? <span className="text-muted-foreground">—</span>}</TableCell>)}
    </TableRow>)}</TableBody></Table></div>
    <div className="data-table-mobile">
      <div className="flex flex-wrap gap-2 border-b p-3"><Select value={sort || '__none'} onValueChange={value => setSort(value === '__none' ? '' : value)}><SelectTrigger className="min-w-0 flex-1" aria-label="Сортировка таблицы"><SelectValue placeholder="Сортировка" /></SelectTrigger><SelectContent><SelectItem value="__none">Без сортировки</SelectItem>{visible.map(column => <SelectItem key={column.key} value={column.key}>{column.label}</SelectItem>)}</SelectContent></Select><Button variant="outline" size="icon" disabled={!sort} aria-label={descending ? 'Сортировать по возрастанию' : 'Сортировать по убыванию'} onClick={() => setDescending(!descending)}><ArrowUpDown className="size-4" /></Button></div>
      {onSelect && <label className="flex items-center gap-3 p-3 border-b min-h-11 text-sm"><Checkbox checked={items.length > 0 && items.every(row => selected?.includes(rowId(row)))} onCheckedChange={checked => onSelect(checked ? [...new Set([...(selected ?? []), ...items.map(rowId)])] : (selected ?? []).filter(id => !items.some(row => rowId(row) === id)))} />Выбрать строки страницы</label>}
      {items.map(row => <article key={rowId(row)} className="mobile-record p-3 space-y-3 border-b last:border-b-0">
        <div className="flex min-w-0 items-start gap-3">{onSelect && <Checkbox className="mt-1 shrink-0" aria-label={`Выбрать ${row.username ?? row.name ?? rowId(row)}`} checked={selected?.includes(rowId(row))} onCheckedChange={checked => toggle(rowId(row), Boolean(checked))} />}<div className="min-w-0 flex-1"><p className="text-xs text-muted-foreground mb-1">{mobileFields[0]?.label}</p><div className="font-medium text-sm">{mobileFields[0] && cell(mobileFields[0], row)}</div></div>{onRow && <Button variant="outline" size="sm" onClick={() => onRow(row)} aria-label={`Подробнее: ${row.username ?? row.name ?? rowId(row)}`}>Открыть</Button>}</div>
        <dl className="space-y-2">{mobileFields.slice(1, 3).map(column => <div key={column.key} className="mobile-record-field"><dt>{column.label}</dt><dd>{cell(column, row)}</dd></div>)}</dl>
        {mobileFields.length > 3 && <details><summary className="min-h-11 cursor-pointer py-3 text-sm text-primary">Все показатели ({mobileFields.length})</summary><dl className="space-y-3 pt-2">{mobileFields.slice(3).map(column => <div key={column.key} className="mobile-record-field"><dt>{column.label}</dt><dd>{cell(column, row)}</dd></div>)}</dl></details>}
        {actions && <div className="mobile-record-actions flex flex-wrap gap-2 border-t pt-2">{cell(actions, row)}</div>}
      </article>)}
    </div>
    {!items.length && <div className="py-16 px-6 text-center text-sm text-muted-foreground">{search ? 'По этому запросу ничего не найдено.' : empty ?? 'Данных пока нет. Добавьте аккаунт и запустите сбор.'}</div>}
    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-t p-3 text-xs text-muted-foreground"><span>{filtered.length ? `${activePage * size + 1}–${Math.min((activePage + 1) * size, filtered.length)} из ${filtered.length}` : '0 строк'}{selected?.length ? ` · выбрано ${selected.length}` : ''}</span><div className="flex items-center justify-between sm:justify-end gap-2"><Select value={String(size)} onValueChange={v => setSize(Number(v))}><SelectTrigger className="w-20 h-8"><SelectValue /></SelectTrigger><SelectContent>{[25, 50, 100].map(n => <SelectItem key={n} value={String(n)}>{n}</SelectItem>)}</SelectContent></Select><Button variant="ghost" size="icon" className="size-8" aria-label="Предыдущая страница" disabled={!activePage} onClick={() => setPage(activePage - 1)}><ChevronLeft className="size-4" /></Button><span>{activePage + 1} / {maxPage + 1}</span><Button variant="ghost" size="icon" className="size-8" aria-label="Следующая страница" disabled={activePage >= maxPage} onClick={() => setPage(activePage + 1)}><ChevronRight className="size-4" /></Button></div></div>
  </div>
}
