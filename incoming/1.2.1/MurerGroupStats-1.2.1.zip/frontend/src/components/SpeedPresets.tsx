import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { number, type Row, type Settings } from '@/lib/api'

export function SpeedPresets({ presets, draft, labels, onApply }: {
  presets: Row[]; draft: Settings; labels: Record<string, [string, string, string]>; onApply: (preset: Row) => void
}) {
  const selected = presets.find(preset => Object.entries(preset.settings).every(([section, values]) =>
    Object.entries(values as Row).every(([key, value]) => draft[section as keyof Settings][key] !== '' && Number(draft[section as keyof Settings][key]) === value)))
  return <Card><CardHeader><CardTitle className="text-base">Скорость сбора</CardTitle>
    <CardDescription>Текущий режим: <strong>{selected?.name ?? 'Ручные настройки'}</strong>. Любое значение ниже можно изменить. Объём данных, таймауты и число аккаунтов задаются отдельно.</CardDescription>
  </CardHeader><CardContent className="space-y-4">
    <div className="flex flex-wrap gap-3">{presets.map(preset => <Button key={preset.id} type="button" variant={selected?.id === preset.id ? 'default' : 'outline'} onClick={() => onApply(preset)}>{preset.name}</Button>)}</div>
    <p className="text-xs text-muted-foreground">Профиль задаёт обычные задержки и диапазоны хьюманизации. Переключатель хьюманизации сохраняется: диапазоны применяются только при её включении. Изменения сохраняются автоматически и действуют со следующего запуска.</p>
    <details className="speed-presets-table"><summary className="text-sm cursor-pointer font-medium">Все значения встроенных режимов</summary>
      <Table className="mt-3"><TableHeader><TableRow><TableHead>Параметр</TableHead>{presets.map(preset => <TableHead key={preset.id}>{preset.name}</TableHead>)}</TableRow></TableHeader>
        <TableBody>{(['collection', 'humanization'] as const).flatMap(section => Object.keys(presets[0]?.settings[section] ?? {}).map(key =>
          <TableRow key={`${section}-${key}`}><TableCell className="text-xs">{section === 'humanization' ? 'Хьюманизация · ' : ''}{labels[key]?.[0] ?? key} <span className="text-muted-foreground">({labels[key]?.[1] ?? ''})</span></TableCell>
            {presets.map(preset => <TableCell key={preset.id} className="text-xs tabular-nums">{number(preset.settings[section][key], 2)}</TableCell>)}</TableRow>))}</TableBody>
      </Table>
    </details>
  </CardContent></Card>
}
