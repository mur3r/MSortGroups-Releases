import { useEffect, useRef, useState } from 'react'
import { ArrowLeftRight, LoaderCircle } from 'lucide-react'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip'
import { api, date, number, percent, type Row } from '@/lib/api'

/** An explicit pair request also reports disjoint audiences without a full matrix. */
export function PairComparison({ kind, options, query, scopeLabel, observations, revision }: { kind: 'group' | 'account'; options: Row[]; query: string; scopeLabel: string; observations: string; revision?: unknown }) {
  const [first, setFirst] = useState(''); const [second, setSecond] = useState('')
  const [result, setResult] = useState<Row | null>(null); const [busy, setBusy] = useState(false); const [error, setError] = useState('')
  const sequence = useRef(0)
  const optionIds = options.map(o => o.id).join(',')
  useEffect(() => {
    ++sequence.current; setResult(null); setBusy(false); setError('')
    const ids = optionIds.split(','); setFirst(value => ids.includes(value) ? value : ''); setSecond(value => ids.includes(value) ? value : '')
  }, [query, optionIds, revision])
  const label = (id: string) => { const option = options.find(o => o.id === id); return kind === 'account' ? `@${option?.username ?? id}` : option?.name ?? id }
  const select = (value: string, change: (id: string) => void, title: string) => <div className="flex-1 min-w-52"><Label className="text-xs">{title}</Label><Select value={value} onValueChange={id => { ++sequence.current; change(id); setResult(null); setBusy(false) }}><SelectTrigger className="w-full mt-2" aria-label={title}><SelectValue placeholder="Выберите…" /></SelectTrigger><SelectContent>{options.map(o => <SelectItem key={o.id} value={o.id}>{label(o.id)}</SelectItem>)}</SelectContent></Select></div>
  const compare = async () => {
    const seq = ++sequence.current; setBusy(true); setError('')
    const params = new URLSearchParams(query); params.set('kind', kind); params.set('a', first); params.set('b', second)
    try { const response = await api(`/compare?${params}`); if (seq === sequence.current) setResult(response) }
    catch (e) { if (seq === sequence.current) setError((e as Error).message) }
    finally { if (seq === sequence.current) setBusy(false) }
  }
  const period = result?.observed_from || result?.observed_to ? `${date(result.observed_from)} — ${date(result.observed_to)}` : observations
  const metric = (title: string, value: string, hint?: string) => <div className="rounded-lg bg-secondary/60 p-3"><div className="text-xs text-muted-foreground mb-2">{title}</div>{hint ? <Tooltip><TooltipTrigger asChild><span className="font-semibold numeric cursor-help border-b border-dotted">{value}</span></TooltipTrigger><TooltipContent className="max-w-xs text-xs">{hint}</TooltipContent></Tooltip> : <span className="font-semibold numeric">{value}</span>}</div>
  return <Card className="gap-4"><CardHeader><CardTitle className="text-base">Сравнить выбранную пару</CardTitle><CardDescription>Показывает и нулевое пересечение. Область сравнения остаётся заданной в верхней панели.</CardDescription></CardHeader><CardContent className="space-y-4"><div className="flex flex-wrap items-end gap-3">{select(first, setFirst, kind === 'group' ? 'Первая группа' : 'Первый аккаунт')}<ArrowLeftRight className="size-4 text-muted-foreground mb-3 hidden sm:block" />{select(second, setSecond, kind === 'group' ? 'Вторая группа' : 'Второй аккаунт')}<Button disabled={busy || !first || !second || first === second} onClick={compare}>{busy && <LoaderCircle className="size-4 animate-spin" />}Сравнить</Button></div>{error && <Alert variant="destructive"><AlertDescription>{error}</AlertDescription></Alert>}{result && <><div className="grid grid-cols-2 md:grid-cols-4 gap-3">{metric('Общих участников', number(result.common_count))}{metric('% от первой', percent(result.percent_a), `${number(result.common_count)} общих / ${number(result.a_count)} участников первой. ${scopeLabel}; ${period}`)}{metric('% от второй', percent(result.percent_b), `${number(result.common_count)} общих / ${number(result.b_count)} участников второй. ${scopeLabel}; ${period}`)}{metric('Коэффициент Жаккара', number(result.jaccard, 3), `${number(result.common_count)} общих / ${number(result.a_count + result.b_count - result.common_count)} в объединении. ${scopeLabel}; ${period}`)}{metric('Новых для первой из второй', number(result.new_for_a))}{metric('Новых для второй из первой', number(result.new_for_b))}{kind === 'account' && metric('Общих групп', number(result.common_group_count ?? result.shared_group_count))}</div><p className="text-xs text-muted-foreground">{result.preliminary ? 'Наблюдаемое пересечение предварительное: состав групп неполон.' : 'Расчёт по сохранённым составам групп.'} {scopeLabel} · {period}. Наши аккаунты учитываются согласно действующим правилам оценки.</p></>}</CardContent></Card>
}
