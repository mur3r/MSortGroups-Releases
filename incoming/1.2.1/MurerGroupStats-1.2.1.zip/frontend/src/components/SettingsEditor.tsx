import { useEffect, useRef, useState } from 'react'
import { Check, RotateCcw, Save, LoaderCircle, Info } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { SpeedPresets } from '@/components/SpeedPresets'
import { api, send, number, type Row, type Settings, type Analysis } from '@/lib/api'
const fields: Record<string, [string, string, string]> = {
  posts_limit: ['Последних элементов', 'шт.', 'Максимальное число уникальных карточек на профиль; просмотренное число сохраняется отдельно.'],
  profiles_limit: ['Профилей на аккаунт за запуск', 'шт.', '0 — все найденные профили. Ограничение позволяет выполнить небольшой первый сбор и позже продолжить.'],
  period_days: ['Период сбора', 'дней', 'Просмотр карточек до заданного периода, с явным учётом неполного покрытия.'],
  cache_hours: ['Свежесть кеша', 'часов', 'Старые наблюдения потребуют обновления при следующем сборе.'],
  group_scroll_limit: ['Предел списка групп', 'прокруток', 'Достижение предела даёт частичный результат.'],
  member_scroll_limit: ['Предел списка участников', 'прокруток', 'Ранее известные связи сохраняются при частичном сборе.'],
  profile_scroll_limit: ['Предел ленты профиля', 'прокруток', 'Предел просмотра публикаций; не подтверждает конец периода.'],
  idle_scroll_limit: ['Ожидания без новых элементов', 'раз', 'Остановка загрузки отличается от подтверждённого конца списка.'],
  load_wait_seconds: ['Ожидание загрузки', 'сек.', 'Пауза после прокрутки для новых элементов.'],
  retries: ['Повторные попытки', 'раз', 'Количество повторов при временной ошибке доступа.'],
  action_delay_seconds: ['Между действиями', 'сек.', 'Базовая задержка между безопасными действиями.'],
  profile_delay_seconds: ['Между профилями', 'сек.', 'Пауза после завершённого профиля.'],
  group_delay_seconds: ['Между группами', 'сек.', 'Пауза после завершённой группы.'],
  account_delay_seconds: ['Пауза после сбора аккаунта', 'сек.', 'После сбора аккаунт сохраняет окно на эту паузу, затем закрывает его и освобождает место следующему.'],
  account_start_interval_seconds: ['Интервал запуска аккаунтов', 'сек.', 'Минимальная пауза между началами запуска разных аккаунтов. 0 — без дополнительной паузы.'],
  concurrent_accounts: ['Одновременно открытых аккаунтов', 'шт.', 'Верхний предел браузеров, включая окна с ручным подтверждением. Освободившееся место автоматически получает следующий выбранный аккаунт.'],
  element_timeout_seconds: ['Ожидание элемента', 'сек.', 'Таймаут поиска необходимого элемента страницы.'],
  save_interval_seconds: ['Сохранение прогресса', 'сек.', 'Дополнительный интервал контрольной записи; завершённые этапы сохраняются.'],
  page_load_timeout_seconds: ['Загрузка страницы', 'сек.', 'Таймаут перехода Chrome на страницу.'],
  script_timeout_seconds: ['Чтение страницы', 'сек.', 'Таймаут безопасного извлечения видимых данных.'],
  login_typing_delay_min: ['Ввод данных входа: минимум', 'сек.', 'Исходная посимвольная задержка при авторизации.'],
  login_typing_delay_max: ['Ввод данных входа: максимум', 'сек.', 'Верхняя граница исходной задержки при авторизации.'],
  login_element_timeout_seconds: ['Элемент формы входа', 'сек.', 'Ожидание поля или кнопки при входе.'],
  login_poll_rounds: ['Проверки формы входа', 'раз', 'Количество ожиданий перехода на следующий этап входа.'],
  login_poll_seconds: ['Интервал проверки входа', 'сек.', 'Пауза между проверками состояния авторизации.'],
  login_page_wait_seconds: ['После открытия входа', 'сек.', 'Ожидание первоначальной загрузки формы X.'],
  login_step_wait_seconds: ['Между этапами входа', 'сек.', 'Ожидание обновления формы авторизации.'],
  login_button_timeout_seconds: ['Кнопка этапа входа', 'сек.', 'Максимальное ожидание кнопки продолжения.'],
  scroll_step_pixels: ['Базовый шаг прокрутки', 'px', 'Шаг обычного просмотра при выключенной хьюманизации.'],
  scroll_pause_seconds: ['Базовая пауза прокрутки', 'сек.', 'Пауза между обычными шагами просмотра.'],
  action_delay_min: ['Задержка действий: минимум', 'сек.', 'Случайная пауза применяется только при включённой хьюманизации.'],
  action_delay_max: ['Задержка действий: максимум', 'сек.', 'Верхняя граница случайной паузы.'],
  typing_delay_min: ['Посимвольный ввод: минимум', 'сек.', 'Безопасный ввод в поиск не нажимает Enter и не отправляет сообщения.'],
  typing_delay_max: ['Посимвольный ввод: максимум', 'сек.', 'Верхняя граница задержки между символами.'],
  scroll_step_min: ['Шаг прокрутки: минимум', 'px', 'Минимальная высота безопасной прокрутки.'],
  scroll_step_max: ['Шаг прокрутки: максимум', 'px', 'Максимальная высота прокрутки.'],
  scroll_pause_min: ['Пауза прокрутки: минимум', 'сек.', 'Задержка после отдельного шага.'],
  scroll_pause_max: ['Пауза прокрутки: максимум', 'сек.', 'Верхняя граница задержки после шага.'],
  followers_low: ['Подписчики: нижний порог', 'чел.', 'Медиана ниже этого уровня даёт компонент F = 0.'],
  followers_high: ['Подписчики: целевой порог', 'чел.', 'Медиана на этом уровне даёт F = 100.'],
  posts_low: ['Публикации: нижний порог', 'шт.', 'Общее число публикаций из шапки профиля.'],
  posts_high: ['Публикации: целевой порог', 'шт.', 'Медиана на этом уровне даёт P = 100.'],
  reposts_min: ['Минимум подтверждённых репостов', 'шт.', 'Недостаток репостов при неполной выборке не доказывает низкую активность.'],
  reposts_days: ['Период репостной активности', 'дней', 'В расчёт входят репосты с пригодной датой репоста.'],
  active_days: ['Свежая подтверждённая активность', 'дней', 'Окно для компонента A; старый закреплённый пост исключается.'],
  min_coverage: ['Минимальное покрытие', '%', 'Ниже порога категория будет предварительной либо недоступной.'],
  good_score: ['«Хорошая» от', 'баллов', 'Верхняя категория качества группы.'],
  medium_score: ['«Средняя» от', 'баллов', 'Ниже этой границы группа получает категорию «Плохая» при достаточных данных.'],
  overlap_pair_limit: ['Предел расчёта таблицы пересечений', 'пар', 'Для больших наборов сравнивайте нужную пару отдельно; аудитория и оценки остаются рассчитанными.'],
  default_allowance: ['Допустимо наших аккаунтов', 'шт.', 'Исходное ограничение для группы; индивидуальные решения задаются во вкладке «Наши аккаунты».'],
}
const weightLabels: Record<string, string> = { U: 'U · Эксклюзивность', F: 'F · Подписчики', P: 'P · Публикации', R: 'R · Репосты', A: 'A · Активность' }
const clone = <T,>(x: T): T => structuredClone(x)
function validate(draft: Settings): { settings?: Settings; error?: string } {
  const value = clone(draft)
  for (const section of ['collection', 'humanization', 'evaluation', 'own_accounts'] as const) for (const key of Object.keys(value[section])) {
    if (fields[key]) { const raw = value[section][key]; if (raw === '' || !Number.isFinite(Number(raw)) || Number(raw) < 0) return { error: `«${fields[key][0]}»: укажите неотрицательное число.` }; value[section][key] = Number(raw) }
  }
  const e = value.evaluation
  for (const key of Object.keys(e.weights)) { if (String(e.weights[key]) === '' || !Number.isFinite(Number(e.weights[key])) || Number(e.weights[key]) < 0) return { error: 'Вес каждого компонента должен быть неотрицательным числом.' }; e.weights[key] = Number(e.weights[key]) }
  if (!Object.values(e.weights).some(n => n > 0)) return { error: 'Хотя бы один вес должен быть больше нуля.' }
  if (e.followers_high <= e.followers_low || e.posts_high <= e.posts_low) return { error: 'Целевой порог должен быть выше нижнего.' }
  if (e.medium_score >= e.good_score || e.good_score > 100 || e.min_coverage > 100) return { error: 'Проверьте границы категорий и покрытие: от 0 до 100, «Средняя» ниже «Хорошая».' }
  for (const [low, high] of [['action_delay_min', 'action_delay_max'], ['typing_delay_min', 'typing_delay_max'], ['scroll_step_min', 'scroll_step_max'], ['scroll_pause_min', 'scroll_pause_max']]) if (value.humanization[low] > value.humanization[high]) return { error: 'Минимальная задержка или шаг не могут превышать максимальные.' }
  for (const key of ['posts_limit', 'period_days', 'concurrent_accounts', 'idle_scroll_limit', 'group_scroll_limit', 'member_scroll_limit', 'profile_scroll_limit', 'login_poll_rounds']) if (value.collection[key] < 1 || !Number.isInteger(value.collection[key])) return { error: `«${fields[key][0]}» должно быть целым числом не меньше 1.` }
  for (const key of ['element_timeout_seconds', 'save_interval_seconds', 'page_load_timeout_seconds', 'script_timeout_seconds', 'login_element_timeout_seconds', 'login_button_timeout_seconds', 'scroll_step_pixels']) if (value.collection[key] <= 0) return { error: `«${fields[key][0]}» должно быть больше 0.` }
  if (value.collection.login_typing_delay_min > value.collection.login_typing_delay_max) return { error: 'Минимальная задержка ввода при входе не может превышать максимальную.' }
  for (const [group, key] of [['collection', 'retries'], ['collection', 'profiles_limit'], ['evaluation', 'reposts_min'], ['evaluation', 'reposts_days'], ['evaluation', 'active_days'], ['own_accounts', 'default_allowance']] as const) if (!Number.isInteger(value[group][key])) return { error: `«${fields[key][0]}» должно быть целым числом.` }
  if (e.reposts_days < 1 || e.active_days < 1) return { error: 'Периоды оценки должны быть не меньше одного дня.' }
  if (e.overlap_pair_limit < 1 || !Number.isInteger(e.overlap_pair_limit)) return { error: 'Предел пересечений должен быть целым числом не меньше 1.' }
  return { settings: value }
}
export function SettingsEditor({ settings, defaults, rules, speedPresets = [], section, analysis, onSaved, onError, onPendingChange }: { settings: Settings; defaults: Settings; rules: Row[]; speedPresets?: Row[]; section: 'rules' | 'settings'; analysis: Analysis; onSaved: (settings?: Settings) => void; onError: (s: string) => void; onPendingChange?: (pending: boolean) => void }) {
  const [draft, setDraft] = useState(() => clone(settings)); const [dirty, setDirty] = useState(false); const [state, setState] = useState('Сохранено'); const [error, setError] = useState(''); const [presetOpen, setPresetOpen] = useState(false); const [name, setName] = useState(''); const [before, setBefore] = useState<Row | null>(null)
  const sequence = useRef(0); const clientId = useRef(crypto.randomUUID())
  useEffect(() => { onPendingChange?.(dirty); return () => onPendingChange?.(false) }, [dirty, onPendingChange])
  useEffect(() => { if (!dirty) setDraft(clone(settings)) }, [settings])
  useEffect(() => {
    if (!dirty) return
    const valid = validate(draft); setError(valid.error ?? '')
    if (!valid.settings) { setState('Ожидается корректное значение'); return }
    setState('Пересчёт…'); const seq = sequence.current
    const timer = setTimeout(async () => {
      try { const result = await api('/settings', { method: 'PUT', body: JSON.stringify(valid.settings), headers: { 'X-Settings-Client': clientId.current, 'X-Settings-Revision': String(seq) } }); if (seq === sequence.current) { setState('Сохранено и пересчитано'); setDirty(false); onSaved(result.settings) } }
      catch (err) { if (seq === sequence.current) { setState('Не сохранено'); setError((err as Error).message) } }
    }, 650)
    return () => clearTimeout(timer)
  }, [draft, dirty])
  const change = (group: keyof Settings, key: string, value: unknown) => { ++sequence.current; if (!dirty) setBefore({ ...analysis.summary, scores: Object.fromEntries(analysis.groups.map(g => [g.id, g.score])) }); setDraft(current => ({ ...current, [group]: { ...current[group], [key]: value } })); setDirty(true) }
  const numericFields = (group: keyof Settings, keys?: string[], omit: string[] = []) => <div className="grid gap-x-6 gap-y-5 md:grid-cols-2 xl:grid-cols-3">{Object.keys(draft[group]).filter(key => fields[key] && (!keys || keys.includes(key)) && !omit.includes(key)).map(key => <div key={key}><div className="flex justify-between items-center mb-2"><Label htmlFor={`${group}-${key}`} className="text-xs">{fields[key][0]}</Label><Button size="icon" variant="ghost" className="size-6 text-muted-foreground" title="Сбросить поле" onClick={() => change(group, key, defaults[group][key])}><RotateCcw className="size-3" /></Button></div><div className="flex gap-2 items-center"><Input id={`${group}-${key}`} type="number" min={0} step={key.includes('delay') || key.includes('seconds') || key.includes('pause') ? 0.05 : 1} value={draft[group][key]} onChange={e => change(group, key, e.target.value)} /><span className="text-xs text-muted-foreground w-12">{fields[key][1]}</span></div><p className="text-xs leading-relaxed text-muted-foreground mt-2">{fields[key][2]}</p></div>)}</div>
  const launchFields = ['concurrent_accounts', 'account_start_interval_seconds', 'account_delay_seconds']
  const applySpeed = (preset: Row) => {
    ++sequence.current
    setDraft(current => ({ ...current, collection: { ...current.collection, ...preset.settings.collection }, humanization: { ...current.humanization, ...preset.settings.humanization } }))
    setDirty(true)
  }
  const toggle = (group: keyof Settings, key: string, title: string, description: string) => <div className="flex items-center justify-between gap-4 rounded-lg border p-4"><div><Label htmlFor={key}>{title}</Label><p className="text-xs text-muted-foreground mt-1">{description}</p></div><Switch id={key} checked={Boolean(draft[group][key])} onCheckedChange={v => change(group, key, v)} /></div>
  return <div className="space-y-5"><div className="flex flex-wrap items-center gap-3"><span className="text-xs flex gap-2 items-center text-muted-foreground">{state.includes('Пересчёт') ? <LoaderCircle className="size-4 animate-spin" /> : <Check className="size-4 text-emerald-500" />}{state}</span><span className="flex-1" /><Select disabled={dirty} onValueChange={async id => { try { await send(`/rule-sets/${id}/apply`); onSaved() } catch (e) { onError((e as Error).message) } }}><SelectTrigger className="w-52"><SelectValue placeholder="Набор правил" /></SelectTrigger><SelectContent>{rules.length ? rules.map(r => <SelectItem key={r.id} value={String(r.id)}>{r.name}</SelectItem>) : <SelectItem value="none" disabled>Нет сохранённых наборов</SelectItem>}</SelectContent></Select><Button variant="outline" onClick={() => setPresetOpen(true)}><Save className="size-4" />Сохранить набор</Button><Button variant="outline" onClick={() => { ++sequence.current; setDraft(clone(defaults)); setDirty(true) }}><RotateCcw className="size-4" />Исходные значения</Button></div>
    {error && <Alert variant="destructive"><AlertDescription>{error} Последние валидные настройки продолжают действовать.</AlertDescription></Alert>}
    {section === 'rules' ? <>
      <Card><CardHeader><CardTitle className="text-base">Прозрачная формула оценки</CardTitle><CardDescription>Стартовые пороги — редактируемые ориентиры. Оценка относится к наблюдаемой базе и выбранной области.</CardDescription></CardHeader><CardContent><div className="rounded-lg bg-secondary p-4 font-mono text-sm mb-5">F(x) = 100 × clamp((x − low) / (high − low), 0, 1)<br /><span className="text-muted-foreground">Итог = Σ(значение × вес) / Σ доступных весов</span></div><div className="grid grid-cols-2 lg:grid-cols-5 gap-4">{Object.keys(weightLabels).map(key => <div key={key}><Label className="text-xs">{weightLabels[key]}</Label><Input className="mt-2" type="number" min={0} value={draft.evaluation.weights[key]} onChange={e => { ++sequence.current; setDraft(d => ({ ...d, evaluation: { ...d.evaluation, weights: { ...d.evaluation.weights, [key]: e.target.value as unknown as number } } })); setDirty(true); if (!dirty) setBefore({ ...analysis.summary, scores: Object.fromEntries(analysis.groups.map(g => [g.id, g.score])) }) }} /></div>)}</div><p className="text-xs text-muted-foreground mt-4">U: эксклюзивные внешние участники / найденные внешние участники. R и A: только профили с данными, пригодными для подтверждения условия. Пропуски исключаются из знаменателя.</p></CardContent></Card>
      <Card><CardHeader><CardTitle className="text-base">Пороги и полнота данных</CardTitle></CardHeader><CardContent>{numericFields('evaluation')}<div className="grid gap-3 mt-6 md:grid-cols-2">{toggle('evaluation', 'include_quotes', 'Учитывать цитаты', 'Включать цитаты в активность и знаменатель доли репостов. Цитаты остаются отдельным типом и не увеличивают число репостов.')}{toggle('evaluation', 'include_replies', 'Учитывать ответы', 'Включать ответы в активность и знаменатель доли репостов.')}{toggle('evaluation', 'include_ours', 'Включать наши аккаунты в аудиторию', 'По умолчанию наши аккаунты исключены во всех областях сравнения.')}</div><div className="grid md:grid-cols-2 gap-5 mt-5"><div><Label>Правило недоступных компонентов</Label><Select value={draft.evaluation.missing_policy} onValueChange={v => change('evaluation', 'missing_policy', v)}><SelectTrigger className="mt-2"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="renormalize">Перенормировать доступные веса</SelectItem><SelectItem value="strict">Требовать все компоненты</SelectItem></SelectContent></Select></div><div className="rounded-lg bg-secondary p-3 text-xs text-muted-foreground">Знаменатель R/A: оценимые профили. При неполной выборке достижение порога подтверждается наблюдением; недостижение — только при достаточном покрытии. Неизвестная дата репоста остаётся неизвестной.</div></div></CardContent></Card>
      {before && <Card><CardHeader><CardTitle className="text-base">До / после изменения правил</CardTitle></CardHeader><CardContent><div className="grid md:grid-cols-3 gap-4 text-sm"><div>Уникальная аудитория<br /><strong>{number(before.unique_audience)} → {number(analysis.summary.unique_audience)}</strong></div><div>Оценённых профилей<br /><strong>{number(before.profiles_checked)} → {number(analysis.summary.profiles_checked)}</strong></div><div>Полнота профилей<br /><strong>{number(before.profile_coverage, 1)}% → {number(analysis.summary.profile_coverage, 1)}%</strong></div></div>{before.scores && <div className="mt-4 max-h-52 overflow-auto text-xs">{analysis.groups.filter(g => before.scores[g.id] !== g.score).map(g => <div className="flex justify-between border-t py-2" key={g.id}><span>{g.name}</span><span>{number(before.scores[g.id], 1)} → {number(g.score, 1)}</span></div>)}</div>}</CardContent></Card>}
    </> : <Tabs defaultValue="collection"><TabsList><TabsTrigger value="collection">Сбор</TabsTrigger><TabsTrigger value="humanization">Хьюманизация</TabsTrigger><TabsTrigger value="own_accounts">Наши аккаунты</TabsTrigger></TabsList><TabsContent value="collection" className="space-y-5"><SpeedPresets presets={speedPresets} draft={draft} labels={fields} onApply={applySpeed} /><Card><CardHeader><CardTitle className="text-base">Запуск аккаунтов</CardTitle><CardDescription>Выберите аккаунты и нажмите «Начать сбор». Программа запускает их по очереди с указанным интервалом, соблюдая лимит одновременно открытых окон. После завершения одного аккаунта автоматически запускается следующий. Ручное подтверждение занимает одно место до продолжения или остановки задания.</CardDescription></CardHeader><CardContent>{numericFields('collection', launchFields)}</CardContent></Card><Card><CardHeader><CardTitle className="text-base">Параметры сбора</CardTitle><CardDescription>Параметры фиксируются при запуске задания. Изменения применяются к следующему запуску; активные значения доступны в истории.</CardDescription></CardHeader><CardContent>{numericFields('collection', undefined, launchFields)}<div className="mt-5 max-w-sm"><Label>Режим обновления</Label><Select value={draft.collection.refresh_mode} onValueChange={v => change('collection', 'refresh_mode', v)}><SelectTrigger className="mt-2"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="stale">Устаревшие и недостающие</SelectItem><SelectItem value="all">Все профили</SelectItem><SelectItem value="missing">Только недостающие</SelectItem></SelectContent></Select></div></CardContent></Card></TabsContent><TabsContent value="humanization"><Card><CardHeader><CardTitle className="text-base">Безопасные действия просмотра</CardTitle><CardDescription>Chrome остаётся видимым. Хьюманизация регулирует темп действий и не гарантирует неотличимость от человека.</CardDescription></CardHeader><CardContent><div className="mb-6">{toggle('humanization', 'enabled', 'Включить хьюманизацию', 'Случайные паузы, посимвольный поиск и плавная прокрутка.')}</div>{numericFields('humanization')}</CardContent></Card></TabsContent><TabsContent value="own_accounts"><Card><CardHeader><CardTitle className="text-base">Присутствие наших аккаунтов</CardTitle><CardDescription>Рекомендации не выполняют вступления, выходы или изменения аккаунтов.</CardDescription></CardHeader><CardContent>{numericFields('own_accounts')}<div className="mt-5">{toggle('own_accounts', 'unlimited', 'Без общего ограничения', 'Индивидуальные правила и закреплённые аккаунты задаются для каждой группы.')}</div></CardContent></Card></TabsContent></Tabs>}
    {analysis.coverage.needs_collection && <Alert><Info className="size-4" /><AlertDescription>Для текущих требований данных недостаточно: {(analysis.coverage.reasons ?? []).join('; ') || 'увеличены период, объём или требования к актуальности.'} Можно дособрать данные кнопкой в верхней панели.</AlertDescription></Alert>}
    <Dialog open={presetOpen} onOpenChange={setPresetOpen}><DialogContent><DialogHeader><DialogTitle>Сохранить набор правил</DialogTitle><DialogDescription>Именованный набор включает текущие параметры сбора, оценки и распределения аккаунтов.</DialogDescription></DialogHeader><Label htmlFor="rule-name">Название</Label><Input id="rule-name" value={name} onChange={e => setName(e.target.value)} placeholder="Например, активная аудитория · 30 дней" /><Button disabled={!name.trim() || Boolean(validate(draft).error)} onClick={async () => { try { await send('/rule-sets', { name: name.trim(), settings: validate(draft).settings }); setPresetOpen(false); setName(''); onSaved() } catch (e) { onError((e as Error).message) } }}>Сохранить</Button></DialogContent></Dialog>
  </div>
}



