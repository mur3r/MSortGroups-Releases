import { useEffect, useState } from 'react'
import { Download, RefreshCw, RotateCcw, ShieldCheck } from 'lucide-react'
import { api, send, type Row } from '@/lib/api'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { Progress } from '@/components/ui/progress'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog'

const running = new Set(['checking', 'downloading', 'preparing', 'installing'])

export function Updates({ onInstall }: { onInstall: (version: string) => void }) {
  const [status, setStatus] = useState<Row>({ phase: 'idle' })
  const [token, setToken] = useState('')
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)
  const [confirm, setConfirm] = useState<'install' | 'rollback' | null>(null)
  useEffect(() => {
    let disposed = false
    const refresh = () => api('/updates').then(value => { if (!disposed) setStatus(value) }).catch(() => {})
    refresh()
    const timer = setInterval(refresh, 2000)
    return () => { disposed = true; clearInterval(timer) }
  }, [])
  const action = async (path: string, body?: unknown, method = 'POST') => {
    setBusy(true); setError('')
    try {
      const value = await send(`/updates/${path}`, body, method)
      if (path === 'install' || path === 'rollback') onInstall(value.version)
      else { setStatus(value); if (path === 'settings') setToken('') }
      setConfirm(null)
    } catch (e) { setError((e as Error).message) }
    finally { setBusy(false) }
  }
  const inProgress = busy || running.has(status.phase)
  const installDisabled = inProgress || !!status.busy_reason || status.developer_checkout || !status.managed_launch
  return <Card data-testid="updates-card">
    <CardHeader><CardTitle className="text-base flex items-center gap-2"><Download className="size-4" />Обновления программы</CardTitle><CardDescription>Установлена версия {status.current_version ?? '…'}. Источник: <a className="underline" href={`https://github.com/${status.repository ?? ''}/releases`} target="_blank" rel="noreferrer">{status.repository || 'не настроен'}</a></CardDescription></CardHeader>
    <CardContent className="space-y-4">
      <div aria-live="polite" className="space-y-2">{status.phase !== 'error' && <p className="text-sm">{status.message || 'Проверьте, доступна ли новая версия.'}</p>}{status.latest_version && <p className="text-xs text-muted-foreground">Версия на GitHub: {status.latest_version}</p>}{running.has(status.phase) && status.phase !== 'checking' && <Progress value={status.progress || 0} />}</div>
      {status.is_public && <p className="text-xs text-muted-foreground">Обновления доступны без входа в GitHub и без токенов.</p>}
      {(error || status.phase === 'error') && <Alert variant="destructive"><AlertDescription>{error || status.message}</AlertDescription></Alert>}
      {status.last_result?.success === false && <Alert><AlertDescription>{status.last_result.message}</AlertDescription></Alert>}
      <div className="flex flex-wrap gap-2"><Button variant="outline" disabled={inProgress} onClick={() => action('check')}><RefreshCw className="size-4" />Проверить обновления</Button>{status.phase === 'available' && <Button disabled={inProgress} onClick={() => action('download')}><Download className="size-4" />Скачать обновление</Button>}{status.phase === 'ready' && <Button disabled={installDisabled} onClick={() => setConfirm('install')}>Установить и перезапустить</Button>}{status.rollback_available && <Button variant="outline" disabled={installDisabled} onClick={() => setConfirm('rollback')}><RotateCcw className="size-4" />Вернуть предыдущую версию</Button>}</div>
      {status.busy_reason && <p className="text-xs text-muted-foreground">{status.busy_reason} Проверка и скачивание остаются доступны.</p>}
      {status.developer_checkout && <p className="text-xs text-muted-foreground">Открыта папка разработки. Установка обновлений доступна в отдельной копии из архива релиза.</p>}
      {!status.managed_launch && <p className="text-xs text-muted-foreground">Для установки с перезапуском откройте программу через start.cmd.</p>}
      <div className="flex items-center gap-3"><Switch id="auto-update-check" checked={status.auto_check ?? true} disabled={inProgress} onCheckedChange={value => action('settings', { auto_check: value }, 'PUT')} /><Label htmlFor="auto-update-check" className="text-xs">Проверять при запуске и каждые 6 часов. Устанавливать по моему запросу.</Label></div>
      {status.notes && <details className="rounded-lg border p-3"><summary className="cursor-pointer text-sm">Что изменилось в версии {status.latest_version}</summary><p className="mt-3 whitespace-pre-wrap break-words text-xs leading-relaxed">{status.notes}</p></details>}
      {!status.is_public && <>
      <details className="rounded-lg border p-3"><summary className="cursor-pointer text-sm">Доступ к приватному GitHub {status.has_token ? '· настроен' : '· не настроен'}</summary><div className="mt-3 space-y-3"><p className="text-xs text-muted-foreground">Нужен персональный токен только для репозитория обновлений с правом Contents: read. Он хранится в хранилище Windows. Для публичных релизов токен не нужен.</p><Label htmlFor="github-update-token">Токен GitHub</Label><Input id="github-update-token" type="password" autoComplete="new-password" value={token} onChange={event => setToken(event.target.value)} placeholder={status.has_token ? 'Сохранён. Введите новый для замены.' : 'Введите токен доступа'} /><div className="flex flex-wrap gap-2"><Button variant="outline" disabled={inProgress || !token.trim()} onClick={() => action('settings', { token: token.trim() }, 'PUT')}>Сохранить доступ</Button>{status.has_token && <Button variant="outline" disabled={inProgress} onClick={() => action('settings', { clear_token: true }, 'PUT')}>Удалить доступ</Button>}</div></div></details>
      </>}
      <p className="text-xs text-muted-foreground flex gap-2"><ShieldCheck className="size-4 shrink-0" />Обновления проходят проверку подписи. Перед установкой сохраняется резервная копия базы. Если новая версия не запустится, программа восстановит предыдущую.</p>
    </CardContent>
    <Dialog open={confirm !== null} onOpenChange={open => !open && setConfirm(null)}><DialogContent><DialogHeader><DialogTitle>{confirm === 'rollback' ? 'Вернуть предыдущую версию?' : 'Установить обновление?'}</DialogTitle><DialogDescription>{confirm === 'rollback' ? 'Программа проверит совместимость базы и перезапустится. Новые данные сохранятся; если для возврата нужна старая база, операция будет запрещена.' : 'Программа сохранит резервную копию, перезапустится и проверит новую версию. Дождитесь завершения, не закрывая окно запуска.'}</DialogDescription></DialogHeader><div className="flex flex-wrap justify-end gap-2"><Button variant="outline" onClick={() => setConfirm(null)}>Отмена</Button><Button disabled={busy} onClick={() => confirm && action(confirm)}>{confirm === 'rollback' ? 'Вернуть версию' : 'Установить'}</Button></div></DialogContent></Dialog>
  </Card>
}

export function UpdateRestart({ target }: { target: string }) {
  const [message, setMessage] = useState('Устанавливаем версию ' + target + '. Программа откроется после проверки запуска.')
  const [failed, setFailed] = useState(false)
  useEffect(() => {
    let disposed = false
    const started = Date.now()
    const timer = setInterval(async () => {
      if (Date.now() - started > 180000) {
        if (!disposed) { setFailed(true); setMessage('Ожидание перезапуска закончилось. Запустите start.cmd: он проверит незавершённую установку и выполнит восстановление.') }
        clearInterval(timer); return
      }
      try {
        const [health, status] = await Promise.all([api('/health', { signal: AbortSignal.timeout(4000) }), api('/updates', { signal: AbortSignal.timeout(4000) })])
        if (disposed || status.trial || status.phase === 'installing') return
        if (health.version === target) window.location.reload()
        else if (status.last_result?.success === false && status.last_result.at * 1000 >= started - 5000) {
          setMessage(status.last_result.message); setFailed(true); clearInterval(timer)
        }
      } catch { /* The server is briefly offline during activation. */ }
    }, 1500)
    return () => { disposed = true; clearInterval(timer) }
  }, [target])
  return <main className="min-h-screen flex items-center justify-center p-6"><Card className="max-w-xl"><CardHeader><CardTitle>{failed ? 'Результат обновления' : 'Обновление программы'}</CardTitle><CardDescription className="leading-relaxed">{message}</CardDescription></CardHeader><CardContent>{failed ? <Button onClick={() => window.location.reload()}>Открыть программу</Button> : <p className="text-xs text-muted-foreground">Не закрывайте окно запуска. База и профили браузеров сохраняются.</p>}</CardContent></Card></main>
}
