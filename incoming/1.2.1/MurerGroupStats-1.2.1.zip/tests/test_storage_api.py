"""Integration with SQLite, HTTP and durable workers using explicit fake pages.

No test below logs into X or treats its synthetic chat/profile data as live data.
"""
import asyncio
from collections import Counter
from copy import deepcopy
from datetime import datetime, timezone
from datetime import timedelta
import io
import json
import sqlite3
from pathlib import Path
import tempfile
import threading
import time
import unittest
from unittest.mock import patch

import keyring.errors
from keyring.backend import KeyringBackend
from fastapi.testclient import TestClient
from openpyxl import load_workbook

from murer.api import create_app
from murer.analytics import analyze
from murer.exporting import excel_report
from murer.jobs import JobManager
from murer.rules import default_settings
from murer.secrets import SecretStore
from murer.storage import Store, encode, utcnow


class MemoryVault(KeyringBackend):
    priority = 1

    def __init__(self):
        self.values = {}

    def set_password(self, service, username, password):
        self.values[service, username] = password

    def get_password(self, service, username):
        return self.values.get((service, username))

    def delete_password(self, service, username):
        if (service, username) not in self.values:
            raise keyring.errors.PasswordDeleteError()
        del self.values[service, username]


def observed_profile(status="full", **values):
    result = {"observed_at": utcnow(), "status": status,
              "followers": {"raw": "1.2K", "value": 1200, "approximate": True},
              "posts_total": {"raw": "56.1K posts", "value": 56100, "approximate": True},
              "requested_n": 100, "requested_days": 30, "viewed_count": 1,
              "period_complete": True, "chronology_confirmed": True,
              "posts": [{"id": "100", "url": "https://x.com/person/status/100", "type": "own",
                         "author": "person", "event_at": utcnow(), "original_at": utcnow(),
                         "pinned": False, "classification_method": "synthetic_fixture"}]}
    result.update(values)
    return result


class Scenario:
    """Factory state supports deterministic interruption, access retry and races."""
    def __init__(self):
        self.calls = []
        self.guard = threading.Lock()
        self.instances = []
        self.groups = [{"x_id": "9001", "name": "Fixture chat A", "url": "https://x.com/i/chat/9001", "declared_count": 2},
                       {"x_id": "9002", "name": "Fixture chat B", "url": "https://x.com/i/chat/9002", "declared_count": 2}]
        self.people = {"9001": [{"username": "person", "x_id": "42"}, {"username": "owner", "x_id": "1"}],
                       "9002": [{"username": "person", "x_id": "42"}, {"username": "other", "x_id": "43"}]}
        self.login_status = {}
        self.unavailable_for = set()
        self.profile_error_once = False
        self.manual_once = False
        self.member_gate = None
        self.member_started = threading.Event()
        self.command_delay = 0.005

    def factory(self, config, logger, settings, checkpoint, progress):
        session = FakeSession(self, checkpoint)
        with self.guard:
            self.instances.append(session)
        return session

    def count(self, operation):
        with self.guard:
            return sum(call[0] == operation for call in self.calls)


class FakeSession:
    def __init__(self, scenario, checkpoint):
        self.scenario, self.checkpoint = scenario, checkpoint
        self.username = None
        self.active = 0
        self.max_active = 0
        self.closed = False

    async def command(self, operation, target=None):
        with self.scenario.guard:
            self.active += 1
            self.max_active = max(self.max_active, self.active)
            self.scenario.calls.append((operation, self.username, target, threading.get_ident()))
        if self.active != 1:
            raise AssertionError("Two commands reached one WebDriver")
        try:
            await asyncio.sleep(self.scenario.command_delay)
            if operation == "members" and self.scenario.member_gate is not None:
                self.scenario.member_started.set()
                while not self.scenario.member_gate.is_set():
                    await asyncio.sleep(0.005)
        finally:
            with self.scenario.guard:
                self.active -= 1

    async def login(self, credentials):
        self.username = credentials.username
        await self.command("login")
        if self.scenario.manual_once:
            self.scenario.manual_once = False
            return {"status": "requires_manual", "reason": "Synthetic confirmation"}
        return {"status": self.scenario.login_status.get(self.username, "active")}

    async def continue_login(self, credentials):
        await self.command("continue_login")
        return {"status": "active"}

    async def discover_groups(self, credentials):
        await self.command("discover")
        return {"status": "full", "groups": deepcopy(self.scenario.groups)}

    async def members(self, group):
        await self.command("members", group["x_id"])
        people = deepcopy(self.scenario.people[group["x_id"]])
        return {"status": "full", "participants": people, "declared_count": len(people)}

    async def profile(self, participant):
        await self.command("profile", participant["username"])
        if self.username in self.scenario.unavailable_for:
            return observed_profile("unavailable", posts=[], reason="Synthetic restricted access")
        if self.scenario.profile_error_once:
            self.scenario.profile_error_once = False
            return observed_profile("error", posts=[], reason="Synthetic transient failure")
        return observed_profile()

    async def close(self):
        await self.command("close")
        self.closed = True


class StorageApiTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.vault = MemoryVault()
        self.secrets = SecretStore(self.vault)
        self.scenario = Scenario()
        self.app = create_app(Path(self.temp.name), self.secrets, self.scenario.factory)
        self.state = self.app.state.application
        self.client = TestClient(self.app)
        self.client.__enter__()
        self.addCleanup(self.client.__exit__, None, None, None)
        self.addCleanup(self.unblock)
        settings = default_settings()
        settings["collection"].update(profile_delay_seconds=0, group_delay_seconds=0,
            account_delay_seconds=0, account_start_interval_seconds=0, action_delay_seconds=0, load_wait_seconds=0, refresh_mode="all")
        self.settings = settings
        self.assertEqual(self.client.put('/api/settings', json=settings).status_code, 200)

    def unblock(self):
        if self.scenario.member_gate:
            self.scenario.member_gate.set()

    def test_current_analysis_cache_expires_without_a_database_write(self):
        self.state.analysis_cache.clear()
        with patch('murer.api.analyze', wraps=analyze) as calculate:
            with patch('murer.api.time.monotonic', return_value=100):
                first = self.state.calculate()
            with patch('murer.api.time.monotonic', return_value=129):
                self.assertIs(first, self.state.calculate())
            with patch('murer.api.time.monotonic', return_value=131):
                self.assertIsNot(first, self.state.calculate())
            self.assertEqual(calculate.call_count, 2)

    def test_historical_account_export_keeps_frozen_username_and_scope(self):
        first, second = self.account('firstowner'), self.account('secondowner')
        jid = self.seed_job()
        self.state.snapshot(jid)
        self.state.store.save_account({'username':'renamedowner'}, first['id'])
        response = self.client.get('/api/export',params={'table':'accounts','run_id':jid,'account_ids':first['id']})
        self.assertEqual(response.status_code, 200)
        import csv
        rows = list(csv.DictReader(io.StringIO(response.content.decode('utf-8-sig')),delimiter=';'))
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]['username'], 'firstowner')
        self.assertNotIn('renamedowner',response.content.decode('utf-8-sig'))

    def test_manual_continue_restores_running_status_during_actual_collection(self):
        self.scenario.manual_once = True
        self.scenario.member_gate = threading.Event()
        owner = self.account()
        jid = self.job([owner])
        self.wait_until(lambda: self.state.store.job(jid)['status']=='requires_manual')
        self.client.post(f'/api/jobs/{jid}/continue')
        self.wait_until(self.scenario.member_started.is_set)
        self.assertEqual(self.state.store.job(jid)['status'], 'running')
        self.scenario.member_gate.set()
        self.finished(jid)

    def test_final_checkpoint_failure_still_closes_the_browser(self):
        owner = self.account()
        persist = self.state.jobs._persist_checkpoints
        def fail_final(*args, **kwargs):
            if kwargs.get('force'):
                raise OSError('Synthetic checkpoint disk failure')
            return persist(*args, **kwargs)
        with patch.object(self.state.jobs, '_persist_checkpoints', side_effect=fail_final):
            jid = self.job([owner], mode='login')
            result = self.finished(jid)
        self.assertTrue(self.scenario.instances[0].closed)
        self.assertEqual(result['status'], 'error')

    def test_browser_close_failure_blocks_all_new_browser_work(self):
        owner = self.account()
        factory = self.state.jobs.session_factory
        def failing(*args):
            instance = factory(*args)
            close = instance.close
            async def uncertain_close():
                await close()
                raise OSError('Synthetic shutdown uncertainty')
            instance.close = uncertain_close
            return instance
        self.state.jobs.session_factory = failing
        jid = self.job([owner], mode='login')
        self.assertEqual(self.finished(jid)['status'], 'error')
        self.assertTrue(self.state.jobs.browser_cleanup_failed)
        self.assertEqual(self.client.post('/api/jobs', json={'account_ids':[owner['id']],'mode':'login'}).status_code, 422)
        with self.assertRaises(ValueError):
            self.state.jobs.reserve_priority('synthetic-trade')
        self.assertIsNone(self.state.jobs.priority_owner)

    def test_setup_existing_data_restores_interrupted_jobs_and_trade_priority(self):
        moved = Store(Path(self.temp.name)/'moved-data')
        settings, _ = self.state.store.settings()
        version = moved.save_settings(settings)
        aid = moved.save_account({'username':'movedowner'})
        now = utcnow()
        moved.execute('INSERT INTO jobs VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',
            ('moved-job','collect',encode([aid]),'[]','running',now,now,encode(settings),version,'{}',None,None))
        moved.execute('INSERT INTO trade_runs(id,created_at,updated_at,status,config,plan,settings,settings_version,priority_held) VALUES(?,?,?,?,?,?,?,?,?)',
            ('moved-trade',now,now,'running',encode({'receive_account_id':aid,'send_account_id':aid,
                'donors':['partner'],'recipients':['partner'],'count':1,'quality':'any'}),
                encode({'groups':[],'send_accounts':[{'id':aid,'username':'movedowner'}]}),encode(settings),version,1))
        result = self.client.post('/api/setup',json={'data_dir':str(moved.data_dir)})
        self.assertEqual(result.status_code, 200, result.text)
        self.assertEqual(self.state.store.job('moved-job')['status'], 'interrupted')
        self.assertEqual(self.state.trades.run('moved-trade')['status'], 'interrupted')
        self.assertEqual(self.state.jobs.priority_owner, 'moved-trade')
        self.assertEqual(self.client.post('/api/jobs',json={'account_ids':[aid],'mode':'login'}).status_code, 422)

    def account(self, username="owner", **values):
        response = self.client.post('/api/accounts', json={"username": username, "password": "synthetic-password-secret",
            "ichat_password": "synthetic-ichat-secret",
            "auth_token": "synthetic-auth-secret", "ct0_token": "synthetic-ct0-secret",
            "proxy": "http://synthetic-user:synthetic-pass@127.0.0.1:9999", **values})
        self.assertEqual(response.status_code, 200, response.text)
        return response.json()

    def job(self, accounts, mode="collect", **values):
        response = self.client.post('/api/jobs', json={"account_ids": [a['id'] for a in accounts], "mode": mode, **values})
        self.assertEqual(response.status_code, 200, response.text)
        return response.json()['id']

    def wait_until(self, condition, timeout=20):
        end = time.monotonic() + timeout
        while time.monotonic() < end:
            if condition():
                return
            time.sleep(0.01)
        self.fail("Timed out waiting for deterministic fake worker; jobs=" + str(self.state.store.jobs()))

    def finished(self, job_id):
        self.wait_until(lambda: not self.state.jobs.threads[job_id].is_alive())
        return self.state.store.job(job_id)

    def seed_job(self, job_id="seed", status="completed"):
        now = utcnow()
        self.state.store.execute('INSERT INTO jobs VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',
            (job_id, "collect", encode([]), encode([]), status, now, now, encode(self.settings),
             self.state.store.settings()[1], encode({}), None, now if status == "completed" else None))
        return job_id

    def seed_group(self, account, members, status="full", xid="9001", name="Fixture"):
        gid = self.state.store.upsert_group({"x_id": xid, "url": f"https://x.com/i/chat/{xid}", "name": name,
                                             "declared_count": len(members)}, account['id'])
        pids = self.state.store.save_members("seed", gid, account['id'], {"status": status,
            "participants": members, "declared_count": len(members)})
        return gid, pids

    def test_accounts_vault_flags_mask_secrets_and_archive_retains_history(self):
        account = self.account(x_id="1", user_agent="fixture-agent", headless=False)
        serialized = json.dumps(account)
        self.assertTrue(account['has_password'])
        self.assertNotIn("synthetic-password-secret", serialized)
        self.assertEqual(self.secrets.get(account['id'])['password'], "synthetic-password-secret")
        self.assertNotIn("synthetic-password-secret", self.state.store.path.read_bytes().decode('latin1'))
        self.seed_job()
        gid, pids = self.seed_group(account, [{"username": "owner", "x_id": "1"}])
        response = self.client.delete('/api/accounts/' + account['id'])
        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.json()['archived'])
        result = self.client.get('/api/analysis').json()
        self.assertEqual(result['groups'][0]['id'], gid)
        self.assertEqual(result['summary']['unique_audience'], 0)
        self.assertEqual(result['summary']['own_participant_count'], 1)
        self.client.patch('/api/accounts/' + account['id'], json={"is_ours": False})
        self.assertEqual(self.client.get('/api/analysis').json()['summary']['unique_audience'], 1)

    def test_legacy_json_import_is_lossless_and_preview_never_exposes_secrets(self):
        original = [{"username": "Legacy", "password": "preserved-password", "proxy": "host:8080:user:pass",
                     "user_agent": "custom-agent", "headless": True, "group": "custom-label",
                     "auth_token": "preserved-auth", "ct0_token": "preserved-ct0"}]
        preview = self.client.post('/api/import/preview', json={"text": json.dumps(original)}).json()
        self.assertEqual(preview['valid_count'], 1)
        self.assertNotIn('preserved-password', json.dumps(preview))
        response = self.client.post('/api/import', json={"text": json.dumps(original)})
        self.assertEqual(response.status_code, 200, response.text)
        account = response.json()['accounts'][0]
        saved = {**self.state.store.account(account['id']), **self.secrets.get(account['id'])}
        for key, value in original[0].items():
            self.assertEqual(saved[key], value.lower() if key == 'username' else value)
        imported = self.client.post('/api/import', json={"text": json.dumps(original)}).json()
        self.assertEqual(imported['accounts'][0]['id'], account['id'])
        self.assertEqual(len(self.state.store.accounts()), 1)

    def test_invalid_import_preview_and_settings_keep_last_valid_version(self):
        values = [{"username": "same", "password": "secret"}, {"username": "SAME"}, {"username": "invalid name"}]
        response = self.client.post('/api/import/preview', json={"text": json.dumps(values)})
        self.assertEqual(response.status_code, 200)
        self.assertEqual(len(response.json()['errors']), 2)
        self.assertEqual(self.client.post('/api/import', json={"text": json.dumps(values)}).status_code, 422)
        self.assertEqual(self.state.store.accounts(), [])
        before, version = self.state.store.settings()
        bad = deepcopy(before)
        bad['collection']['posts_limit'] = ''
        self.assertEqual(self.client.put('/api/settings', json=bad).status_code, 422)
        self.assertEqual(self.state.store.settings(), (before, version))

    def test_settings_requests_arriving_in_reverse_order_cannot_overwrite_newer(self):
        newest = deepcopy(self.settings)
        newest['evaluation']['followers_high'] = 20000
        older = deepcopy(self.settings)
        older['evaluation']['followers_high'] = 7000
        headers = {"X-Settings-Client": "fixture-client", "X-Settings-Revision": "12"}
        response = self.client.put('/api/settings', json=newest, headers=headers)
        self.assertEqual(response.status_code, 200, response.text)
        version = response.json()['version']
        headers['X-Settings-Revision'] = '11'
        response = self.client.put('/api/settings', json=older, headers=headers)
        self.assertEqual(response.status_code, 409, response.text)
        saved, current_version = self.state.store.settings()
        self.assertEqual(current_version, version)
        self.assertEqual(saved['evaluation']['followers_high'], 20000)
        headers['X-Settings-Revision'] = '13'
        self.assertEqual(self.client.put('/api/settings', json=older, headers=headers).status_code, 200)

    def test_membership_partial_retains_prior_members_and_confirmed_full_removes(self):
        account = self.account()
        self.seed_job()
        gid, pids = self.seed_group(account, [{"username": "first", "x_id": "100"}, {"username": "second", "x_id": "101"}])
        self.state.store.save_members('seed', gid, account['id'], {"status": "partial", "participants": [{"username": "first", "x_id": "100"}]})
        current = self.state.store.dataset()['groups'][0]
        self.assertEqual(set(current['participant_ids']), set(pids))
        self.assertEqual(current['membership_status'], 'partial')
        self.assertTrue(all(r['uncertain'] for r in self.state.store.rows('SELECT * FROM group_members')))
        self.state.store.save_members('seed', gid, account['id'], {"status": "full", "participants": [{"username": "first", "x_id": "100"}], "declared_count": 1})
        self.assertEqual(self.state.store.dataset()['groups'][0]['participant_ids'], [pids[0]])
        self.assertEqual(len(self.state.store.rows('SELECT * FROM membership_observations')), 3)

    def test_stable_id_rename_and_reused_handle_never_silently_merge(self):
        store = self.state.store
        old = store.identify({"username": "same", "x_id": "100"})
        renamed = store.identify({"username": "renamed", "x_id": "100"})
        other = store.identify({"username": "same", "x_id": "200"})
        self.assertEqual(old, renamed)
        self.assertNotEqual(old, other)
        with self.assertRaisesRegex(ValueError, 'Неоднозначный'):
            store.identify({"username": "same"})
        self.assertEqual(len(store.dataset()['participants']), 2)

    def test_historical_alias_does_not_revert_current_stable_username(self):
        store = self.state.store
        pid = store.identify({"username": "before", "x_id": "100"})
        store.identify({"username": "current", "x_id": "100"})
        alias_pid = store.identify({"username": "before", "url": "https://x.com/before"})
        self.assertEqual(alias_pid, pid)
        person = store.participant(pid)
        self.assertEqual(person['username'], 'current')
        self.assertEqual(person['url'], 'https://x.com/current')
        self.assertEqual(person['identity_origin'], 'historical_username_alias')

    def test_full_claim_with_declared_mismatch_preserves_prior_members(self):
        account = self.account()
        self.seed_job()
        gid, pids = self.seed_group(account, [{"username": "first"}, {"username": "second"}])
        self.state.store.save_members('seed', gid, account['id'], {"status": "full", "declared_count": 2,
            "participants": [{"username": "first"}]})
        saved = self.state.store.dataset()['groups'][0]
        self.assertEqual(saved['membership_status'], 'partial')
        self.assertEqual(set(saved['participant_ids']), set(pids))
        self.assertIn('полнота', saved['reason'])

    def test_discovery_partial_retains_access_full_preserves_history_of_missing(self):
        account = self.account()
        store = self.state.store
        groups = [{"x_id": str(i), "url": f'https://x.com/i/chat/{i}', "name": str(i)} for i in (11, 12)]
        first, second = store.save_discovery(account['id'], groups, 'full')
        store.save_discovery(account['id'], groups[:1], 'partial')
        current = {g['id']: g for g in store.dataset()['groups']}
        self.assertEqual(current[second]['account_ids'], [account['id']])
        self.assertEqual(current[second]['uncertain_account_ids'], [account['id']])
        store.save_discovery(account['id'], groups[:1], 'full')
        current = {g['id']: g for g in store.dataset()['groups']}
        self.assertEqual(current[second]['account_ids'], [])
        self.assertEqual(current[second]['historical_account_ids'], [account['id']])
        self.assertEqual(current[first]['account_ids'], [account['id']])
        store.upsert_group(groups[1], account['id'])
        current = {g['id']: g for g in store.dataset()['groups']}
        self.assertEqual(current[second]['account_ids'], [account['id']])
        self.assertEqual(len(store.rows('SELECT * FROM account_groups')), 2)

    def test_dataset_read_uses_bounded_queries_for_many_entities(self):
        account = self.account()
        self.seed_job()
        store = self.state.store
        for gid in range(3):
            self.seed_group(account, [{"username": f'person{i}', "x_id": str(100+i)} for i in range(12)], xid=str(1000+gid))
        statements = []
        connect = sqlite3.connect
        def traced_connect(*args, **kwargs):
            db = connect(*args, **kwargs)
            db.set_trace_callback(statements.append)
            return db
        with patch('murer.storage.sqlite3.connect', traced_connect):
            data = store.dataset()
        self.assertEqual(len(data['groups']), 3)
        self.assertEqual(len(data['participants']), 12)
        self.assertLessEqual(sum(sql.lstrip().upper().startswith('SELECT') for sql in statements), 8)

    def test_failed_migration_rolls_back_ddl_and_can_retry_cleanly(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            module_file = root / 'module' / 'storage.py'
            migrations = module_file.parent / 'migrations'
            migrations.mkdir(parents=True)
            first = migrations / '001_sample.sql'
            first.write_text('CREATE TABLE durable(id INTEGER);', encoding='utf-8')
            failed = migrations / '002_broken.sql'
            failed.write_text('CREATE TABLE rollback_me(id INTEGER); INVALID SQL;', encoding='utf-8')
            with patch('murer.storage.__file__', str(module_file)), self.assertRaises(sqlite3.OperationalError):
                Store(root / 'data')
            with sqlite3.connect(root / 'data' / 'murer.sqlite3') as db:
                self.assertIsNotNone(db.execute("SELECT name FROM sqlite_master WHERE name='durable'").fetchone())
                self.assertIsNone(db.execute("SELECT name FROM sqlite_master WHERE name='rollback_me'").fetchone())
                self.assertEqual([r[0] for r in db.execute('SELECT version FROM schema_migrations')], [1])
            db.close()
            failed.write_text('CREATE TABLE rollback_me(id INTEGER);', encoding='utf-8')
            with patch('murer.storage.__file__', str(module_file)):
                recovered = Store(root / 'data')
            self.assertEqual([r['version'] for r in recovered.rows('SELECT version FROM schema_migrations ORDER BY version')], [1, 2])

    def test_profile_retry_preserves_available_observation_and_post_fk(self):
        account = self.account()
        self.seed_job()
        _, pids = self.seed_group(account, [{"username": "person", "x_id": "42"}])
        store = self.state.store
        store.save_profile('seed', pids[0], account['id'], observed_profile())
        store.save_profile('seed', pids[0], account['id'], observed_profile(followers={"raw": "1300", "value": 1300, "approximate": False}))
        store.save_profile('seed', pids[0], account['id'], {"status": "unavailable", "reason": "Synthetic denied"})
        profile = store.participant(pids[0])
        self.assertEqual(len(profile['observations']), 2)
        self.assertEqual(len(store.rows('SELECT * FROM post_observations')), 1)
        result = self.client.get('/api/analysis').json()['participants'][0]
        self.assertEqual(result['followers']['value'], 1300)

    def test_partial_profile_retry_retains_metrics_and_bounded_attempt_rows(self):
        account = self.account()
        self.seed_job()
        _, pids = self.seed_group(account, [{"username": "person", "x_id": "42"}])
        store = self.state.store
        store.save_profile('seed', pids[0], account['id'], observed_profile())
        partial = observed_profile('partial', followers={"raw": None, "value": None, "approximate": False},
            posts=[], period_complete=False, chronology_confirmed=False)
        for _ in range(3):
            store.save_profile('seed', pids[0], account['id'], partial)
        self.assertEqual(len(store.participant(pids[0])['observations']), 2)
        self.assertEqual(len(store.rows('SELECT * FROM post_observations')), 1)
        profile = self.client.get('/api/analysis').json()['participants'][0]
        self.assertEqual(profile['followers']['value'], 1200)
        for _ in range(3):
            store.save_profile('seed', pids[0], account['id'], {"status": "unavailable"})
        self.assertEqual(len(store.participant(pids[0])['observations']), 3)

    def test_real_http_vertical_fixture_job_saves_history_and_deduplicates(self):
        accounts = [self.account('owner', x_id='1'), self.account('secondowner', x_id='2')]
        self.settings['collection']['concurrent_accounts'] = 2
        self.client.put('/api/settings', json=self.settings)
        job_id = self.job(accounts)
        job = self.finished(job_id)
        self.assertEqual(job['status'], 'completed', job)
        result = self.client.get('/api/analysis').json()
        self.assertEqual(result['summary']['group_count'], 2)
        self.assertEqual(result['summary']['participant_count'], 3)
        self.assertEqual(result['summary']['unique_audience'], 2)
        self.assertEqual(self.scenario.count('profile'), 3)
        self.assertEqual(len(self.state.store.rows('SELECT * FROM profile_observations')), 3)
        self.assertTrue(all(session.max_active == 1 and session.closed for session in self.scenario.instances))
        self.assertEqual(len(self.state.store.rows('SELECT * FROM account_groups')), 4)
        history = self.client.get('/api/history').json()[0]
        self.assertEqual(history['id'], job_id)
        self.assertIsNotNone(history['snapshot'])
        frozen = self.client.get('/api/analysis', params={"run_id": job_id, "mode": "collection"})
        self.assertEqual(frozen.status_code, 200, frozen.text)
        self.assertEqual(frozen.json()['settings_version'], job['settings_version'])

    def test_failed_our_login_still_excluded_and_other_access_can_succeed(self):
        first, second = self.account('owner', x_id='1'), self.account('secondowner', x_id='2')
        self.scenario.login_status['owner'] = 'error'
        job = self.finished(self.job([first, second]))
        self.assertEqual(job['status'], 'partial')
        result = self.client.get('/api/analysis').json()
        self.assertEqual(result['summary']['own_participant_count'], 1)
        self.assertEqual(result['summary']['unique_audience'], 2)
        self.assertEqual(self.state.store.account(first['id'])['status'], 'error')

    def test_unavailable_profile_retried_through_next_access_context(self):
        first, second = self.account('owner'), self.account('secondowner')
        self.scenario.unavailable_for.add('owner')
        self.finished(self.job([first, second]))
        observations = self.state.store.rows('SELECT * FROM profile_observations')
        self.assertTrue(any(o['status'] == 'unavailable' for o in observations))
        self.assertTrue(any(o['status'] == 'full' for o in observations))
        result = self.client.get('/api/analysis').json()
        self.assertTrue(all(p['followers']['value'] == 1200 for p in result['participants']))
        self.assertEqual(result['summary']['group_count'], 2)

    def test_all_unavailable_profiles_make_run_partial(self):
        account = self.account()
        self.scenario.unavailable_for.add('owner')
        job = self.finished(self.job([account]))
        self.assertEqual(job['status'], 'partial')
        result = self.client.get('/api/analysis').json()
        self.assertEqual(result['summary']['profiles_checked'], 0)
        self.assertTrue(result['coverage']['needs_collection'])

    def test_cached_short_period_does_not_satisfy_longer_evaluation_window(self):
        account = self.account()
        self.finished(self.job([account]))
        before = self.scenario.count('profile')
        settings = deepcopy(self.settings)
        settings['collection']['refresh_mode'] = 'stale'
        settings['evaluation']['reposts_days'] = 60
        self.client.put('/api/settings', json=settings)
        self.finished(self.job([account]))
        self.assertGreater(self.scenario.count('profile'), before)

    def test_individual_group_allowance_unlimited_and_exemptions_recalculate(self):
        first, second = self.account('owner'), self.account('secondowner')
        self.seed_job()
        gid, pids = self.seed_group(first, [{"username": "owner"}, {"username": "secondowner"}])
        self.state.store.upsert_group({"x_id": "9001", "url": "https://x.com/i/chat/9001"}, second['id'])
        initial = self.client.get('/api/analysis').json()['own_accounts'][0]
        self.assertEqual(initial['excess'], 1)
        response = self.client.patch('/api/groups/' + gid, json={"unlimited": True})
        self.assertEqual(response.status_code, 200, response.text)
        unlimited = self.client.get('/api/analysis').json()['own_accounts'][0]
        self.assertTrue(unlimited['unlimited'])
        self.assertEqual(unlimited['excess'], 0)
        response = self.client.patch('/api/groups/' + gid, json={"unlimited": False, "allowance": 0,
            "exempt_account_ids": [second['id']], "pinned_account_ids": [first['id']]})
        self.assertEqual(response.status_code, 200, response.text)
        rule = self.client.get('/api/analysis').json()['own_accounts'][0]
        self.assertEqual(rule['excess'], 1)
        self.assertEqual(rule['exempt_account_ids'], [second['id']])

    def test_group_unlimited_inherits_global_unless_explicit_false_override(self):
        account = self.account()
        self.seed_job()
        gid, _ = self.seed_group(account, [{'username': 'owner'}])
        self.assertIsNone(self.state.store.dataset()['groups'][0]['unlimited'])
        settings = deepcopy(self.settings)
        settings['own_accounts']['unlimited'] = True
        response = self.client.put('/api/settings', json=settings)
        self.assertEqual(response.status_code, 200, response.text)
        self.assertTrue(response.json()['analysis']['own_accounts'][0]['unlimited'])
        self.assertEqual(self.client.patch('/api/groups/' + gid, json={'unlimited': False}).status_code, 200)
        result = self.client.get('/api/analysis').json()['own_accounts'][0]
        self.assertFalse(result['unlimited'])
        self.assertEqual(result['allowance'], 1)
        self.assertIs(self.state.store.dataset()['groups'][0]['unlimited'], False)
        settings['own_accounts']['group_rules'] = {gid: {'unlimited': True}}
        response = self.client.put('/api/settings', json=settings)
        self.assertTrue(response.json()['analysis']['own_accounts'][0]['unlimited'])

    def test_settings_recalculate_without_new_session_and_show_more_data_needed(self):
        account = self.account()
        self.finished(self.job([account]))
        before = self.client.get('/api/analysis').json()
        session_count, profile_count = len(self.scenario.instances), self.scenario.count('profile')
        settings = deepcopy(self.settings)
        settings['evaluation']['followers_high'] = 15000
        changed = self.client.put('/api/settings', json=settings)
        self.assertEqual(changed.status_code, 200)
        after = changed.json()['analysis']
        self.assertNotEqual(before['groups'][0]['score'], after['groups'][0]['score'])
        self.assertEqual(len(self.scenario.instances), session_count)
        self.assertEqual(self.scenario.count('profile'), profile_count)
        settings['collection']['posts_limit'] = 200
        enlarged = self.client.put('/api/settings', json=settings).json()['analysis']
        self.assertTrue(enlarged['coverage']['needs_collection'])

    def test_http_direct_pair_returns_zero_intersection_and_validates_scope(self):
        first, second = self.account('firstowner'), self.account('secondowner')
        self.seed_job()
        left, _ = self.seed_group(first, [{"username": "firstperson"}], xid='81')
        right, _ = self.seed_group(second, [{"username": "secondperson"}], xid='82')
        response = self.client.get('/api/compare', params={'kind': 'group', 'a': left, 'b': right})
        self.assertEqual(response.status_code, 200, response.text)
        pair = response.json()
        self.assertEqual((pair['common_count'], pair['percent_a'], pair['percent_b']), (0, 0, 0))
        self.assertEqual(pair['jaccard'], 0)
        self.assertEqual(pair['new_for_a'], 1)
        self.assertEqual(self.client.get('/api/compare', params={'kind': 'group', 'a': left, 'b': right,
            'account_ids': first['id']}).status_code, 422)
        pair = self.client.get('/api/compare', params={'kind': 'account', 'a': first['id'], 'b': second['id']}).json()
        self.assertEqual(pair['common_group_count'], 0)
        self.assertEqual(pair['common_count'], 0)

    def test_collection_time_history_keeps_original_activity_reference_date(self):
        account = self.account()
        job_id = self.job([account])
        self.finished(job_id)
        original = self.client.get('/api/analysis', params={"run_id": job_id, "mode": "collection"}).json()
        self.assertEqual(original['groups'][0]['components']['A']['value'], 100)
        future = datetime.now(timezone.utc) + timedelta(days=100)
        class FutureDatetime(datetime):
            @classmethod
            def now(cls, tz=None):
                return future if tz else future.replace(tzinfo=None)
        self.state.analysis_cache.clear()
        with patch('murer.analytics.datetime', FutureDatetime):
            frozen = self.client.get('/api/analysis', params={"run_id": job_id, "mode": "collection"}).json()
        self.assertEqual(frozen['groups'][0]['components']['A']['value'], 100)
        self.assertEqual(frozen['groups'][0]['score'], original['groups'][0]['score'])

    def test_export_csv_and_xlsx_have_metadata_no_secrets_or_formulas(self):
        account = self.account()
        self.seed_job()
        gid, pids = self.seed_group(account, [{"username": "person", "x_id": "42"}], name='=HYPERLINK("http://bad", "bad")')
        self.state.store.save_profile('seed', pids[0], account['id'], observed_profile())
        csv_response = self.client.get('/api/export', params={"format": "csv", "table": "groups", "search": "HYPERLINK"})
        self.assertEqual(csv_response.status_code, 200)
        text = csv_response.content.decode('utf-8-sig')
        self.assertIn("'=HYPERLINK", text)
        self.assertIn('export_metadata', text)
        for secret in filter(None, self.secrets.get(account['id']).values()):
            self.assertNotIn(secret, text)
        response = self.client.get('/api/export', params={"format": "xlsx"})
        self.assertEqual(response.status_code, 200)
        workbook = load_workbook(io.BytesIO(response.content), read_only=True, data_only=False)
        try:
            self.assertGreaterEqual(len(workbook.sheetnames), 12)
            self.assertIn('Наши аккаунты', workbook.sheetnames)
            self.assertTrue({'Публикации', 'Наблюдения', 'Состав групп', 'Расчёт оценки'} <= set(workbook.sheetnames))
            cells = [cell for sheet in workbook for row in sheet for cell in row]
            self.assertFalse(any(cell.data_type == 'f' for cell in cells))
            text = json.dumps([str(cell.value) for cell in cells], ensure_ascii=False)
            for secret in filter(None, self.secrets.get(account['id']).values()):
                self.assertNotIn(secret, text)
        finally:
            workbook.close()

    def test_empty_filtered_csv_keeps_scope_and_rules_metadata_without_fake_metrics(self):
        account = self.account()
        response = self.client.get('/api/export', params={'format': 'csv', 'table': 'groups',
            'search': 'no-group-will-match', 'columns': 'name,score'})
        self.assertEqual(response.status_code, 200, response.text)
        import csv
        rows = list(csv.DictReader(io.StringIO(response.content.decode('utf-8-sig')), delimiter=';'))
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]['name'], '')
        self.assertEqual(rows[0]['score'], '')
        metadata = json.loads(rows[0]['export_metadata'])
        self.assertIn('Дата экспорта', metadata)
        self.assertIn('Правила', metadata)
        self.assertIn('Сводка', metadata)
        for secret in filter(None, self.secrets.get(account['id']).values()):
            self.assertNotIn(secret, response.content.decode('utf-8-sig'))

    def test_excel_full_observations_posts_are_row_based_typed_and_scope_limited(self):
        account = self.account()
        self.seed_job()
        gid, pids = self.seed_group(account, [{'username': 'included', 'x_id': '42'}])
        _, excluded_pids = self.seed_group(account, [{'username': 'excluded', 'x_id': '43'}], xid='9002')
        posts = [{'id': str(index), 'type': 'own', 'text': f'Post {index}: ' + 'я' * 1500,
                  'event_at': utcnow(), 'author': {'username': 'included', 'x_id': '42'}} for index in range(500)]
        saved = observed_profile(posts=posts, requested_n=500, viewed_count=500)
        saved['password'] = 'not-exported-observation-secret'
        self.state.store.save_profile('seed', pids[0], account['id'], saved)
        self.state.store.save_profile('seed', excluded_pids[0], account['id'], observed_profile(
            posts=[{'id': 'private-other-group', 'text': 'unselected-private-profile-text'}]))
        settings = deepcopy(self.settings)
        settings['collection']['posts_limit'] = 500
        dataset = self.state.store.dataset()
        result = analyze(dataset, settings, group_ids=[gid])
        body = excel_report(result, self.state.public_accounts(), {'scope': [gid]}, dataset)
        workbook = load_workbook(io.BytesIO(body), read_only=True, data_only=False)
        try:
            def rows(name):
                values = list(workbook[name].values)
                return [dict(zip(values[0], row)) for row in values[1:]]
            participants = rows('Участники')
            self.assertEqual(len(participants), 1)
            self.assertNotIn('posts', participants[0])
            self.assertNotIn('access_attempts', participants[0])
            self.assertEqual(participants[0]['followers_value'], 1200)
            self.assertEqual(participants[0]['followers_raw'], '1.2K')
            self.assertIs(participants[0]['followers_approximate'], True)
            exported_posts = rows('Публикации')
            self.assertEqual(len(exported_posts), 500)
            self.assertEqual({p['id'] for p in exported_posts}, {str(i) for i in range(500)})
            self.assertEqual(exported_posts[-1]['text'], posts[-1]['text'])
            self.assertTrue(all(p['source_account_id'] == account['id'] and p['observed_at'] for p in exported_posts))
            observations = rows('Наблюдения')
            self.assertEqual(len(observations), 1)
            self.assertEqual(observations[0]['followers_value'], 1200)
            self.assertNotIn('posts', observations[0])
            self.assertEqual(len(rows('Состав групп')), 1)
            self.assertEqual(len(rows('Расчёт оценки')), 5)
            values = [cell.value for sheet in workbook for row in sheet for cell in row]
            strings = [value for value in values if isinstance(value, str)]
            self.assertFalse(any('unselected-private-profile-text' in value for value in strings))
            self.assertFalse(any('not-exported-observation-secret' in value for value in strings))
            self.assertTrue(all(len(value) <= 32767 for value in strings))
        finally:
            workbook.close()

    def test_excel_oversized_scalar_is_preserved_in_bounded_chunks(self):
        text = 'Очень длинное значение ' * 4000
        body = excel_report({'groups': [{'id': 'g', 'name': text}]}, [], {})
        workbook = load_workbook(io.BytesIO(body), read_only=True, data_only=False)
        try:
            self.assertIn('Длинные значения', workbook.sheetnames)
            values = list(workbook['Длинные значения'].values)
            chunks = [dict(zip(values[0], row)) for row in values[1:]]
            self.assertEqual(''.join(row['text'] for row in chunks), text)
            self.assertTrue(all(len(row['text']) < 30000 for row in chunks))
        finally:
            workbook.close()

    def test_pause_resume_stop_continue_preserve_steps_no_races(self):
        account = self.account()
        self.scenario.member_gate = threading.Event()
        job_id = self.job([account])
        self.assertTrue(self.scenario.member_started.wait(3))
        self.assertEqual(self.client.post(f'/api/jobs/{job_id}/pause').status_code, 200)
        self.scenario.member_gate.set()
        time.sleep(0.05)
        self.assertEqual(self.scenario.count('profile'), 0)
        self.assertEqual(self.client.post(f'/api/jobs/{job_id}/resume').status_code, 200)
        self.assertEqual(self.finished(job_id)['status'], 'completed')
        count = self.scenario.count('profile')
        self.assertEqual(self.client.post(f'/api/jobs/{job_id}/resume').status_code, 200)
        self.finished(job_id)
        self.assertEqual(self.scenario.count('profile'), count)
        self.assertEqual(len(self.state.store.rows('SELECT * FROM profile_observations')), 3)
        self.assertTrue(all(s.max_active == 1 for s in self.scenario.instances))

    def test_stop_at_safe_boundary_then_resume_saved_member_step(self):
        account = self.account()
        self.scenario.member_gate = threading.Event()
        job_id = self.job([account])
        self.assertTrue(self.scenario.member_started.wait(3))
        self.assertEqual(self.client.post(f'/api/jobs/{job_id}/stop').status_code, 200)
        self.scenario.member_gate.set()
        self.assertEqual(self.finished(job_id)['status'], 'stopped')
        self.assertEqual(self.scenario.count('profile'), 0)
        self.assertEqual(self.client.post(f'/api/jobs/{job_id}/resume').status_code, 200)
        self.assertEqual(self.finished(job_id)['status'], 'completed')
        self.assertEqual(self.scenario.count('discover'), 1)
        self.assertEqual(self.scenario.count('members'), 2)
        self.assertEqual(len(self.state.store.rows('SELECT * FROM group_members')), 4)

    def test_manual_confirmation_keeps_session_and_explicit_continue(self):
        account = self.account()
        self.scenario.manual_once = True
        job_id = self.job([account])
        self.wait_until(lambda: self.state.store.job(job_id)['status'] == 'requires_manual')
        self.assertEqual(self.scenario.count('discover'), 0)
        self.assertFalse(self.scenario.instances[0].closed)
        self.assertEqual(self.client.post(f'/api/jobs/{job_id}/continue').status_code, 200)
        self.assertEqual(self.finished(job_id)['status'], 'completed')
        self.assertEqual(self.scenario.count('continue_login'), 1)

    def test_recovery_marks_inflight_job_interrupted_and_resumes_idempotently(self):
        account = self.account()
        self.seed_job('interrupted-job', 'running')
        self.state.store.execute('UPDATE jobs SET account_ids=? WHERE id=?', (encode([account['id']]), 'interrupted-job'))
        recovered = JobManager(self.state.store, self.secrets, self.state.configuration, lambda message: None, self.scenario.factory)
        recovered.snapshot_callback = self.state.snapshot
        self.addCleanup(recovered.close)
        self.assertEqual(self.state.store.job('interrupted-job')['status'], 'interrupted')
        recovered.command('interrupted-job', 'resume')
        self.wait_until(lambda: not recovered.threads['interrupted-job'].is_alive())
        self.assertEqual(self.state.store.job('interrupted-job')['status'], 'completed')
        self.assertEqual(len(self.state.store.rows('SELECT * FROM groups')), 2)

    def test_http_rejects_cross_origin_mutation_unknown_jobs_and_busy_edit(self):
        response = self.client.post('/api/accounts', headers={"Origin": "https://foreign.example"}, json={"username": "owner"})
        self.assertEqual(response.status_code, 403)
        self.assertEqual(self.client.post('/api/jobs/missing/resume').status_code, 422)
        account = self.account()
        self.scenario.member_gate = threading.Event()
        job_id = self.job([account])
        self.assertTrue(self.scenario.member_started.wait(3))
        self.assertEqual(self.client.patch('/api/accounts/' + account['id'], json={"proxy": "changed:999"}).status_code, 422)
        self.assertEqual(self.client.post('/api/jobs', json={"account_ids": [account['id']]}).status_code, 422)
        self.scenario.member_gate.set()
        self.finished(job_id)


if __name__ == '__main__':
    unittest.main()
