"""Opt-in full Windows update cycle. No X, real data, tokens, or GitHub writes.

Installs real dependencies in temporary release environments, then exercises
the actual supervisor, HTTP health checks, migrations and automatic rollback.
Run after building a signed release: python tests/update_cycle_smoke.py
"""
import base64
import hashlib
import io
import json
import os
from pathlib import Path
import socket
import sqlite3
import subprocess
import sys
import tempfile
import time
from unittest.mock import patch
from urllib.request import Request, ProxyHandler, build_opener
import zipfile

import httpx
import psutil
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives.serialization import Encoding, PublicFormat

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from murer.storage import Store
from murer.update_format import canonical_json, extract_package, verify_manifest
from murer.updates import UpdateManager, atomic_json, read_json


class Vault:
    def get_password(self, service, key):
        return None


def fixture(base, key, keys, version, broken=False):
    names = read_json(ROOT / 'artifacts' / 'release' / 'murer-update.json')['files']
    files = {name:(base / name).read_bytes() for name in names}
    files['VERSION'] = (version + '\n').encode()
    files['config/updates.json'] = canonical_json({'repository':'fixture/repo','public_keys':keys})
    files['murer/migrations/009_update_smoke.sql'] = b'CREATE TABLE update_smoke_preserved(value TEXT);'
    if broken:
        files['murer/migrations/010_failed_update_smoke.sql'] = b'CREATE TABLE failed_update_should_not_survive(value TEXT);'
        code = files['murer/api.py'].decode('utf-8')
        marker = '    state = Application(data_dir, secrets, session_factory, trade_session_factory)'
        assert marker in code
        files['murer/api.py'] = code.replace(marker, marker + '\n    raise RuntimeError("Synthetic failure after migrations")', 1).encode('utf-8')
    content = io.BytesIO()
    with zipfile.ZipFile(content, 'w', zipfile.ZIP_DEFLATED) as archive:
        for name, value in files.items():
            archive.writestr(name, value)
    archive = content.getvalue()
    manifest = {'schema':1,'application':'Murer Group Stats','updater_protocol':1,'version':version,
                'files':{name:hashlib.sha256(value).hexdigest() for name,value in files.items()},
                'package':{'name':f'MurerGroupStats-{version}.zip','size':len(archive),'sha256':hashlib.sha256(archive).hexdigest()}}
    raw = canonical_json(manifest)
    signature = canonical_json({'key_id':'fixture','signature':base64.b64encode(key.sign(raw)).decode()})
    release = {'id':int(version.split('.')[1])+100,'tag_name':'v'+version,'draft':False,'prerelease':False,'body':'Synthetic update cycle',
               'assets':[{'id':i,'name':name,'state':'uploaded'} for i,name in enumerate(('murer-update.json','murer-update.sig',manifest['package']['name']),1)]}
    def handler(request):
        if '/assets/' in request.url.path:
            return httpx.Response(200, content={1:raw,2:signature,3:archive}[int(request.url.path.split('/')[-1])])
        return httpx.Response(200, json=release)
    return httpx.MockTransport(handler)


def wait_for(predicate, seconds=90):
    deadline = time.monotonic() + seconds
    while time.monotonic() < deadline:
        try:
            if predicate():
                return
        except (OSError, ValueError, KeyError):
            pass
        time.sleep(.2)
    raise RuntimeError('Timed out waiting for the synthetic update cycle.')


def main():
    report = {'synthetic_data':True,'real_x_access':False,'github_writes':False,'checks':[],'passed':False}
    process = None
    log = None
    opener = build_opener(ProxyHandler({}))
    artifacts = ROOT / 'artifacts'
    try:
        with tempfile.TemporaryDirectory(prefix='murer_update_cycle_') as temporary:
            workspace = Path(temporary)
            raw = (artifacts / 'release' / 'murer-update.json').read_bytes()
            manifest = verify_manifest(raw, (artifacts / 'release' / 'murer-update.sig').read_bytes(), read_json(ROOT / 'config' / 'updates.json')['public_keys'])
            base = workspace / 'app'
            extract_package(artifacts / 'release' / manifest['package']['name'], base, manifest)
            (base / 'VERSION').write_text('9.0.0\n')
            key = Ed25519PrivateKey.generate()
            keys = {'fixture':base64.b64encode(key.public_key().public_bytes(Encoding.Raw,PublicFormat.Raw)).decode()}
            atomic_json(base / 'config' / 'updates.json', {'repository':'fixture/repo','public_keys':keys})
            atomic_json(base / '.murer-updates' / 'preferences.json', {'auto_check':False})
            global_data = workspace / 'localappdata' / 'MurerGroupStats'
            data = workspace / 'data'
            atomic_json(global_data / 'bootstrap.json', {'data_dir':str(data),'configured':True,'chrome_path':'','driver_path':''})
            store = Store(data)
            store.execute("INSERT INTO application_meta VALUES('update_fixture','preserve me')")
            with patch('murer.updates.CODE_ROOT', base):
                manager = UpdateManager(store,Vault(),lambda:'',lambda event:None,root=base,transport=fixture(base,key,keys,'9.1.0'))
            print('Preparing two isolated Python environments...', flush=True)
            manager._prepare_runtime(base, workspace / 'base-prepare.log')
            manager.check(); manager.worker.join(60)
            manager.download(); manager.worker.join(900)
            assert manager.state['phase']=='ready', manager.state.get('message')
            report['checks'].append('real_dependencies_and_signed_download_prepared')
            with socket.socket() as probe:
                probe.bind(('127.0.0.1',0)); port=probe.getsockname()[1]
            url=f'http://127.0.0.1:{port}'
            def get(path):
                with opener.open(url+path,timeout=2) as response:
                    return json.load(response)
            def shutdown():
                with opener.open(Request(url+'/api/shutdown',data=b'{}',headers={'Content-Type':'application/json'}),timeout=3) as response:
                    assert response.status==200
            log=(workspace/'supervisor.log').open('wb')
            runtime=base/'.venv'/'Scripts'/'python.exe'
            process=subprocess.Popen([str(runtime),'scripts/launcher.py','--no-open','--port',str(port)],cwd=base,
                        env=dict(os.environ,LOCALAPPDATA=str(workspace/'localappdata')),
                        stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW if os.name=='nt' else 0)
            wait_for(lambda:get('/api/health')['version']=='9.0.0')
            session=read_json(base/'.murer-updates'/'running.json')['session']
            with patch.dict(os.environ,MURER_LAUNCHER_SESSION=session):
                manager.request_install()
            shutdown()
            wait_for(lambda:get('/api/health')['version']=='9.1.0' and read_json(base/'.murer-updates'/'result.json').get('success'))
            assert store.rows("SELECT value FROM application_meta WHERE key='update_fixture'")[0]['value']=='preserve me'
            assert store.rows("SELECT name FROM sqlite_master WHERE name='update_smoke_preserved'")
            report['checks'].append('supervised_restart_migration_health_and_data_preservation')
            with patch('murer.updates.CODE_ROOT',base):
                broken=UpdateManager(store,Vault(),lambda:'',lambda event:None,root=base,transport=fixture(base,key,keys,'9.2.0',broken=True))
            broken.check(); broken.worker.join(60)
            broken.download(); broken.worker.join(900)
            assert broken.state['phase']=='ready', broken.state.get('message')
            with patch.dict(os.environ,MURER_LAUNCHER_SESSION=session):
                broken.request_install()
            shutdown()
            wait_for(lambda:get('/api/health')['version']=='9.1.0' and read_json(base/'.murer-updates'/'result.json').get('failed_version')=='9.2.0')
            assert not store.rows("SELECT name FROM sqlite_master WHERE name='failed_update_should_not_survive'")
            assert store.rows("SELECT name FROM sqlite_master WHERE name='update_smoke_preserved'")
            assert store.rows("SELECT value FROM application_meta WHERE key='update_fixture'")[0]['value']=='preserve me'
            report['checks'].append('failed_real_start_restores_previous_code_and_pre_migration_database')
            shutdown()
            assert process.wait(30)==0
            report['checks'].append('graceful_exit_after_recovery')
            report['passed']=True
            manager.close(); broken.close()
            log.close(); log=None
    except Exception as error:
        report['error']=str(error)
        if process and process.poll() is None:
            children=psutil.Process(process.pid).children(recursive=True)
            for child in children:
                try: child.terminate()
                except psutil.Error: pass
            process.terminate()
            process.wait(20)
        if log: log.close()
    (artifacts/'update-cycle-smoke.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(report,ensure_ascii=True,indent=2))
    return 0 if report['passed'] else 1


if __name__=='__main__':
    raise SystemExit(main())
