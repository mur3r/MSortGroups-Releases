"""Synthetic identity observations; no credentials or real X calls."""
import asyncio
import json
from pathlib import Path
import tempfile
import time
import unittest
from unittest.mock import AsyncMock,MagicMock,patch
from fastapi.testclient import TestClient
from murer.account_identity import public_user_id,read_signed_in_identity
from murer.api import create_app
from murer.collector import SeleniumSession
from murer.rules import default_settings
from murer.secrets import SecretStore
from murer.storage import Store,AccountIdentityConflict
from tests.test_storage_api import MemoryVault,Scenario
from xgenius.config import Config
from xgenius.cookies import get_cookies_file_path
from xgenius.models import AccountState,AccountCredentials


def observed(username='actualowner',xid='123'):
    return {'verified':True,'username':username,'x_id':xid,'origin':'x_self_profile','observed_at':'2026-10-16T12:00:00+00:00'}


class IdentityStorageTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.store=Store(self.temp.name)
        self.aid=self.store.save_account({'username':'oldlabel'})

    def test_confirmed_identity_updates_same_record_with_audit(self):
        updated,changed=self.store.sync_account_identity(self.aid,observed())
        self.assertTrue(changed)
        self.assertEqual(updated['id'],self.aid)
        self.assertEqual(updated['username'],'actualowner')
        self.assertEqual(updated['previous_username'],'oldlabel')
        self.assertEqual(updated['x_id'],'123')
        self.assertEqual(updated['profile_key'],'oldlabel')
        self.store.sync_account_identity(self.aid,observed())
        self.assertEqual(len(self.store.rows('SELECT * FROM account_identity_events')),1)

    def test_profile_and_cookies_stay_in_same_folders_during_rename(self):
        config=Config(Path(self.temp.name))
        config.profile_key=self.store.account(self.aid)['profile_key']
        profile=config.get_profile_dir('oldlabel')
        cookie=get_cookies_file_path(config,'oldlabel')
        (profile/'marker').write_text('fixture',encoding='utf-8')
        cookie.write_text('{}',encoding='utf-8')
        self.store.sync_account_identity(self.aid,observed())
        self.assertEqual(config.get_profile_dir('actualowner'),profile)
        self.assertEqual(get_cookies_file_path(config,'actualowner'),cookie)
        self.assertEqual((profile/'marker').read_text(),'fixture')

    def test_reusing_old_handle_allocates_another_profile(self):
        self.store.sync_account_identity(self.aid,observed())
        other=self.store.save_account({'username':'oldlabel'})
        self.assertNotEqual(self.store.account(other)['profile_key'],self.store.account(self.aid)['profile_key'])

    def test_duplicate_handle_or_stable_id_never_merges_records(self):
        other=self.store.save_account({'username':'taken','x_id':'456'})
        for value in (observed('taken','999'),observed('different','456')):
            with self.assertRaises(AccountIdentityConflict):self.store.sync_account_identity(self.aid,value)
        self.assertEqual(self.store.account(self.aid)['username'],'oldlabel')
        self.assertEqual(self.store.account(other)['username'],'taken')

    def test_conflicting_known_id_and_unverified_observation_do_not_overwrite(self):
        self.store.save_account({'x_id':'123'},self.aid)
        for value in (observed(xid='456'),{**observed(),'verified':False},{**observed(),'username':'bad/name'}):
            with self.assertRaises(AccountIdentityConflict):self.store.sync_account_identity(self.aid,value)
        self.assertEqual(self.store.account(self.aid)['username'],'oldlabel')

    def test_manual_label_edit_preserves_storage_key(self):
        self.store.save_account({'username':'anotherlabel'},self.aid)
        self.assertEqual(self.store.account(self.aid)['profile_key'],'oldlabel')


class IdentityBrowserTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.settings=default_settings()['collection']
        self.settings.update(load_wait_seconds=0,login_poll_rounds=1,login_poll_seconds=0)
        self.browser=MagicMock()
        self.browser.current_url='https://x.com/home'
        self.browser.get_cookie.return_value={'name':'twid','value':'u%3D123'}
        self.actions=MagicMock()
        self.actions.call=AsyncMock(side_effect=lambda callback:callback())
        self.actions.get=AsyncMock()
        self.actions.sleep=AsyncMock()
        self.actions.script=AsyncMock(return_value={'verified':True,'username':'actualowner'})
        self.gate=AsyncMock(return_value=None)

    async def test_reads_own_id_route_and_verified_handle_only(self):
        value=await read_signed_in_identity(self.actions,self.browser,self.settings,self.gate)
        self.assertTrue(value['verified'])
        self.assertEqual(value['username'],'actualowner')
        self.assertEqual(value['x_id'],'123')
        self.actions.get.assert_awaited_once_with('https://x.com/i/user/123')
        self.assertNotIn('twid',json.dumps(value))
        self.assertNotIn('%3D',json.dumps(value))

    async def test_missing_cookie_or_foreign_origin_is_not_identity(self):
        self.browser.current_url='https://evil.invalid/'
        self.assertEqual((await read_signed_in_identity(self.actions,self.browser,self.settings,self.gate))['status'],'requires_manual')
        self.browser.get_cookie.assert_not_called()
        self.browser.current_url='https://x.com/home'
        self.browser.get_cookie.return_value=None
        self.assertEqual((await read_signed_in_identity(self.actions,self.browser,self.settings,self.gate))['status'],'requires_manual')
        self.actions.get.assert_not_awaited()

    async def test_header_without_self_edit_control_and_changed_session_are_rejected(self):
        self.actions.script.return_value={'verified':False}
        self.assertEqual((await read_signed_in_identity(self.actions,self.browser,self.settings,self.gate))['status'],'requires_manual')
        self.actions.script.return_value={'verified':True,'username':'actualowner'}
        self.browser.get_cookie.side_effect=[{'value':'u=123'},{'value':'u=456'}]
        self.assertEqual((await read_signed_in_identity(self.actions,self.browser,self.settings,self.gate))['status'],'requires_manual')

    async def test_challenge_and_stop_preserve_control_flow(self):
        self.gate.return_value={'status':'requires_manual','reason':'Synthetic challenge'}
        self.assertEqual((await read_signed_in_identity(self.actions,self.browser,self.settings,self.gate))['reason'],'Synthetic challenge')
        self.actions.script.assert_not_awaited()
        self.actions.get.side_effect=asyncio.CancelledError()
        with self.assertRaises(asyncio.CancelledError):await read_signed_in_identity(self.actions,self.browser,self.settings,self.gate)

    async def test_binding_and_credentials_change_after_persisting_identity(self):
        with tempfile.TemporaryDirectory() as folder:
            config=Config(Path(folder));config.profile_key='oldlabel'
            events=[]
            config.account_identity_handler=lambda identity:events.append(identity)
            session=SeleniumSession(config,MagicMock(),default_settings())
            session.username='oldlabel'
            state=AccountState('oldlabel',browser=self.browser)
            session.manager.accounts['oldlabel']=state
            session.actions=self.actions
            credentials=AccountCredentials('oldlabel','synthetic-secret')
            with patch('murer.account_identity.read_signed_in_identity',new=AsyncMock(return_value=observed())):
                result=await session._identity_after_login(credentials,{'status':'active'})
            self.assertEqual(result['identity']['username'],'actualowner')
            self.assertEqual(session.username,credentials.username)
            self.assertIs(session.browser,self.browser)
            self.assertEqual(state.username,'actualowner')
            self.assertNotIn('oldlabel',session.manager.accounts)
            self.assertEqual(config.profile_key,'oldlabel')
            self.assertEqual(len(events),1)

    async def test_manual_continue_also_observes_actual_identity(self):
        with tempfile.TemporaryDirectory() as folder:
            config=Config(Path(folder))
            session=SeleniumSession(config,MagicMock(),default_settings())
            session.username='oldlabel'
            session.manager.accounts['oldlabel']=AccountState('oldlabel',browser=self.browser)
            credentials=AccountCredentials('oldlabel','fixture')
            session._continue_login=AsyncMock(return_value={'status':'active'})
            with patch('murer.account_identity.read_signed_in_identity',new=AsyncMock(return_value=observed())):
                result=await session.continue_login(credentials)
            self.assertEqual(result['identity']['username'],'actualowner')
            self.assertEqual(credentials.username,'actualowner')
            self.assertEqual(config.profile_key,'oldlabel')

    async def test_collision_does_not_rebind_browser_or_overwrite_credentials(self):
        with tempfile.TemporaryDirectory() as folder:
            config=Config(Path(folder))
            def conflict(identity):raise AccountIdentityConflict('Synthetic duplicate account')
            config.account_identity_handler=conflict
            session=SeleniumSession(config,MagicMock(),default_settings())
            session.username='oldlabel'
            session.manager.accounts['oldlabel']=AccountState('oldlabel',browser=self.browser)
            credentials=AccountCredentials('oldlabel','fixture')
            with patch('murer.account_identity.read_signed_in_identity',new=AsyncMock(return_value=observed())):
                result=await session._identity_after_login(credentials,{'status':'active'})
            self.assertEqual(result['status'],'error')
            self.assertEqual(session.username,'oldlabel')
            self.assertEqual(credentials.username,'oldlabel')
            self.assertIs(session.browser,self.browser)

    def test_public_cookie_parser_never_accepts_tokens_or_arbitrary_values(self):
        self.assertEqual(public_user_id({'value':'u%3D123'}),'123')
        for value in (None,{}, {'value':'secret'}, {'value':'u=123&other=secret'}):
            self.assertIsNone(public_user_id(value))


class IdentityWorkerTests(unittest.TestCase):
    def test_login_worker_updates_ui_record_and_reuses_profile_on_next_run(self):
        with tempfile.TemporaryDirectory() as folder:
            scenario=Scenario();vault=SecretStore(MemoryVault());keys=[]
            def factory(config,*args):
                browser=scenario.factory(config,*args)
                original=browser.login
                async def login(credentials):
                    keys.append(config.get_profile_dir(credentials.username))
                    result=await original(credentials)
                    if result['status']=='active':
                        config.account_identity_handler(observed())
                        credentials.username='actualowner';browser.username='actualowner'
                    return result
                browser.login=login
                return browser
            app=create_app(Path(folder),vault,factory)
            with TestClient(app) as client:
                account=client.post('/api/accounts',json={'username':'oldlabel','password':'synthetic-secret'}).json()
                state=app.state.application
                for _ in range(2):
                    rid=client.post('/api/jobs',json={'account_ids':[account['id']],'mode':'login'}).json()['id']
                    end=time.monotonic()+5
                    while state.jobs.threads[rid].is_alive() and time.monotonic()<end:time.sleep(.01)
                    self.assertFalse(state.jobs.threads[rid].is_alive())
                    self.assertEqual(state.store.job(rid)['status'],'completed')
                    if len(keys)==1:
                        self.assertEqual(state.store.job(rid)['progress']['account'],'actualowner')
                updated=client.get('/api/accounts').json()[0]
                self.assertEqual(updated['username'],'actualowner')
                self.assertEqual(updated['id'],account['id'])
                self.assertTrue(updated['has_password'])
                self.assertEqual(vault.get(account['id'])['password'],'synthetic-secret')
                self.assertEqual(keys[0],keys[1])
                self.assertEqual(len(client.get('/api/accounts/'+account['id']+'/username-history').json()),1)


if __name__=='__main__':unittest.main()
