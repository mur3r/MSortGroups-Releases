"""Headless Trade UI against an isolated SQLite backend and synthetic sessions.

No real X account, invitation or normal application data is used.
"""
import json
import os
from pathlib import Path
import sys
import tempfile
import threading
import time
import traceback
from urllib.request import urlopen

import uvicorn
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from murer.api import create_app
from murer.secrets import SecretStore
from murer.trade_browser import TradeSession
from tests.test_storage_api import MemoryVault
from tests.test_trade import ExchangeScenario


def run():
    report = {'synthetic_data':True, 'real_x_access':False, 'checks':[], 'passed':False}
    browser = None
    with tempfile.TemporaryDirectory(prefix='murer_trade_ui_') as folder:
        scenario = ExchangeScenario()
        scenario.incoming_extra=4
        app = create_app(Path(folder)/'data', SecretStore(MemoryVault()), scenario.stats_factory, scenario.trade_factory)
        state = app.state.application
        state.configuration['configured'] = True
        settings, _ = state.store.settings()
        settings['collection'].update(profile_delay_seconds=0, group_delay_seconds=0, account_start_interval_seconds=0)
        state.store.save_settings(settings)
        owner = state.save_account({'username':'fixtureowner', 'password':'synthetic-private-password'})
        for group in scenario.stats.groups:
            state.store.upsert_group(group,owner['id'])
        extra=state.save_account({'username':'fixtureextra'})
        state.store.upsert_group(scenario.stats.groups[0],extra['id'])
        state.store.upsert_group({'x_id':'g777','name':'Extra source group','url':'https://x.com/i/chat/g777'},extra['id'])
        server = uvicorn.Server(uvicorn.Config(app, host='127.0.0.1', port=8768, log_level='error', access_log=False))
        thread = threading.Thread(target=server.run, daemon=True)
        thread.start()
        try:
            deadline = time.monotonic()+15
            while not server.started and time.monotonic()<deadline:
                time.sleep(.05)
            assert server.started
            chrome = Path(os.environ['LOCALAPPDATA'])/'MurerGroupStats'/'browser-test'
            options = webdriver.ChromeOptions()
            options.add_argument('--headless=new')
            options.binary_location = str(chrome/'chrome-win64'/'chrome.exe')
            options.add_argument(f'--user-data-dir={Path(folder)/"browser"}')
            options.add_argument('--window-size=1500,1050')
            options.add_argument('--no-first-run')
            options.set_capability('goog:loggingPrefs',{'browser':'ALL'})
            browser = webdriver.Chrome(service=Service(str(chrome/'chromedriver-win64'/'chromedriver.exe')),options=options)
            wait = WebDriverWait(browser,15)
            browser.get('http://127.0.0.1:8768')

            def click(text):
                element = wait.until(lambda _:next((el for el in browser.find_elements(By.XPATH,f'//button[normalize-space(.)={json.dumps(text,ensure_ascii=False)}]') if el.is_displayed() and el.is_enabled()),False))
                browser.execute_script('arguments[0].scrollIntoView({block:"center"})',element)
                element.click()

            def check(name, condition=True):
                assert condition,name
                report['checks'].append(name)

            click('Trade')
            wait.until(lambda _:browser.find_element(By.ID,'trade-receive-login').is_enabled())
            for selector, value in [('trade-receive-login','@fixtureowner'),('trade-send-login','fixtureowner'),
                                    ('trade-donors','@partner'),('trade-recipients','@partner\n@secondpartner')]:
                element = wait.until(lambda _:browser.find_element(By.ID,selector))
                element.send_keys(value)
            check('separate_own_account_and_partner_fields')
            check('group_counts_in_account_selector','2 групп' in browser.find_element(By.CSS_SELECTOR,'button[aria-label="trade-send: выбор аккаунта"]').text)
            count=browser.find_element(By.ID,'trade-count');count.send_keys(Keys.CONTROL,'a');count.send_keys('2')
            click('Подготовить план обмена')
            wait.until(lambda _:state.trades.history())
            rid = state.trades.history()[0]['id']
            plan = state.trades.run(rid)
            check('quota_per_recipient_and_reviewable_pool',plan['plan']['total_requested']==4 and len(plan['plan']['groups'])==2)
            scenario.unavailable.add(plan['plan']['groups'][0]['id'])
            click('Проверить взаимные подписки')
            wait.until(lambda _:state.trades.run(rid)['status']=='checked' and not state.trades.threads[rid].is_alive())
            check('read_only_relationship_button_never_invites',not scenario.invites)
            click('Начать обмен')
            wait.until(lambda _:state.trades.run(rid)['status']=='awaiting_account' and not state.trades.threads[rid].is_alive())
            finished = state.trades.run(rid)
            check('one_confirmed_group_for_each_recipient',finished['remaining']=={'partner':1,'secondpartner':1})
            wait.until(lambda _:'Группы без доступного добавления' in browser.find_element(By.TAG_NAME,'body').text)
            check('cached_missing_button_shown')
            click('История обменов')
            row = wait.until(lambda _:next((el for el in browser.find_elements(By.CSS_SELECTOR,'.data-table-desktop tbody tr') if 'Нужен ещё один аккаунт' in el.text),False))
            check('history_shows_counterparty_handles','@partner' in row.text and '@secondpartner' in row.text)
            row.click()
            wait.until(lambda _:browser.find_element(By.ID,'trade-extra-sender-login'))
            for width in (360,390,768,1440):
                browser.execute_cdp_cmd('Emulation.setDeviceMetricsOverride',{'width':width,'height':1000,'deviceScaleFactor':1,'mobile':False})
                def fitted(_):
                    bounds=browser.execute_script("return {width:innerWidth,overflow:document.documentElement.scrollWidth>innerWidth+1,controls:Array.from(document.querySelectorAll('[role=dialog] button,[role=dialog] input')).filter(e=>{const r=e.getBoundingClientRect();return r.width>0&&(r.left<0||r.right>innerWidth+1)}).length}")
                    report['last_layout']=bounds
                    return bounds if bounds['width']==width and not bounds['overflow'] and bounds['controls']==0 else False
                wait.until(fitted)
                check('extra_sender_exact_viewport_'+str(width))
                browser.save_screenshot(str(ROOT/'artifacts'/('trade-shortage-'+str(width)+'.png')))
            browser.find_element(By.ID,'trade-extra-sender-login').send_keys('fixtureextra')
            click('Добавить аккаунт в этот Trade')
            wait.until(lambda _:len(state.trades.run(rid)['plan']['send_accounts'])==2)
            click('Продолжить обмен')
            wait.until(lambda _:state.trades.run(rid)['status']=='awaiting_completion' and not state.trades.threads[rid].is_alive())
            check('same_cycle_continues_from_extra_account',state.trades.run(rid)['confirmed_count']==4)
            wait.until(lambda _:'Ссылки на группы' in browser.find_element(By.CSS_SELECTOR,'[role=dialog]').text)
            dialog = browser.find_element(By.CSS_SELECTOR,'[role=dialog]')
            links = dialog.find_elements(By.CSS_SELECTOR,'a[href^="https://x.com/i/chat/"]')
            check('vertical_links_and_group_names',len(links)==4 and 'Названия групп' in dialog.text)
            click('Уже состоял (0)')
            check('separate_existing_tab','Эти группы уже были у получателя' in dialog.text)
            click('Получено нами')
            check('incoming_count_visible','Наблюдаемых новых: 4' in dialog.text)
            calls=len(scenario.invites)
            click('Перепроверить')
            wait.until(lambda _:len(state.trades.run(rid)['incoming_checks'])==3 and not state.trades.threads[rid].is_alive())
            check('incoming_recheck_does_not_invite',len(scenario.invites)==calls)
            click('Все попытки')
            check('quality_and_failed_attempt_reason_visible','Качество при обмене' in dialog.text and 'Synthetic no add button' in dialog.text)
            check('collection_still_blocked_until_finish',state.jobs.priority_owner==rid)
            click('Завершить Trade')
            wait.until(lambda _:state.trades.run(rid)['status']=='completed' and state.jobs.priority_owner is None)
            check('explicit_finish_releases_collection')
            export = dialog.find_element(By.CSS_SELECTOR,'a[download]').get_attribute('href')
            with urlopen(export) as response:
                csv = response.read().decode('utf-8-sig')
            check('csv_links_without_secrets','https://x.com/i/chat/g' in csv and 'synthetic-private-password' not in csv)
            errors = [entry for entry in browser.get_log('browser') if entry['level']=='SEVERE' and 'favicon' not in entry['message']]
            check('no_browser_errors',not errors)
            for width in (360,390,768,1440):
                browser.execute_cdp_cmd('Emulation.setDeviceMetricsOverride',{'width':width,'height':1000,'deviceScaleFactor':1,'mobile':False})
                check('exact_viewport_'+str(width),browser.execute_script('return innerWidth')==width)
                wait.until(lambda _:browser.execute_script('return document.documentElement.scrollWidth<=window.innerWidth+1'))
                overflow=browser.execute_script("return Array.from(document.querySelectorAll('[role=dialog] button,[role=dialog] input')).filter(e=>{const r=e.getBoundingClientRect();return r.width>0&&(r.left<0||r.right>innerWidth+1)}).length")
                check('trade_cycle_responsive_'+str(width),overflow==0)
                browser.save_screenshot(str(ROOT/'artifacts'/('trade-cycle-'+str(width)+'.png')))
                for label,slug in [('Добавлено (4)','added'),('Уже состоял (0)','existing'),('Получено нами','incoming')]:
                    click(label)
                    assert browser.execute_script('return document.documentElement.scrollWidth<=innerWidth+1')
                    check('trade_tab_'+slug+'_'+str(width))
                    browser.save_screenshot(str(ROOT/'artifacts'/('trade-'+slug+'-'+str(width)+'.png')))
            browser.save_screenshot(str(ROOT/'artifacts'/'trade-ui-history.png'))
            # Exercise the original blocker through the rendered UI: a sender
            # with no saved groups must still be able to start an Any trade.
            browser.find_element(By.TAG_NAME,'body').send_keys(Keys.ESCAPE)
            browser.execute_cdp_cmd('Emulation.clearDeviceMetricsOverride',{})
            state.store.execute('DELETE FROM account_groups WHERE account_id=?',(owner['id'],))
            scenario.unavailable.clear()
            scenario.require_follow = True
            click('Trade')
            wait.until(lambda _:browser.find_element(By.ID,'trade-receive-login').is_enabled())
            for selector, value in [('trade-receive-login','fixtureowner'),('trade-send-login','fixtureowner'),
                                    ('trade-donors','partner'),('trade-recipients','partner'),('trade-count','1')]:
                element=browser.find_element(By.ID,selector)
                element.send_keys(Keys.CONTROL,'a');element.send_keys(value)
            click('Подготовить план обмена')
            wait.until(lambda _:state.trades.history()[0]['id']!=rid)
            quick_id=state.trades.history()[0]['id']
            check('empty_pool_plan',not state.trades.run(quick_id)['plan']['groups'])
            click('Начать обмен')
            wait.until(lambda _:quick_id in state.trades.threads and not state.trades.threads[quick_id].is_alive())
            quick=state.trades.run(quick_id)
            check('empty_pool_starts_and_adds_without_analysis',quick['confirmed_count']==1 and bool(quick['confirmed'][0]['url']))
            check('quick_trade_creates_no_quality_snapshot',not state.store.rows('SELECT * FROM run_snapshots'))
            state.trades.finish(quick_id,accept_unverified=True)
            browser.refresh()
            click('Trade')
            wait.until(lambda _:browser.find_element(By.ID,'trade-source-mode').is_enabled())
            for selector,value in [('trade-recipients','autopartner'),('trade-count','1')]:
                element=browser.find_element(By.ID,selector)
                element.send_keys(Keys.CONTROL,'a');element.send_keys(value)
            mode=browser.find_element(By.ID,'trade-source-mode')
            browser.execute_script('arguments[0].scrollIntoView({block:"center"})',mode)
            mode.click()
            option=wait.until(lambda _:next((el for el in browser.find_elements(By.CSS_SELECTOR,'[role=option]') if 'Подобрать автоматически' in el.text),False))
            option.click()
            check('auto_mode_hides_manual_sender',not browser.find_elements(By.ID,'trade-send-login'))
            # Prefer the extra source using its proven capability, even when
            # the receiving account has more groups in its saved list.
            state.store.execute("UPDATE trade_capabilities SET state='unknown' WHERE account_id=?",(owner['id'],))
            click('Подготовить план обмена')
            wait.until(lambda _:state.trades.history()[0]['id']!=quick_id)
            auto_id=state.trades.history()[0]['id']
            auto_plan=state.trades.run(auto_id)
            check('auto_plan_ranks_known_source',auto_plan['config']['sender_mode']=='auto' and auto_plan['plan']['send_accounts'][0]['id']==extra['id'])
            for width in (360,1440):
                browser.execute_cdp_cmd('Emulation.setDeviceMetricsOverride',{'width':width,'height':1000,'deviceScaleFactor':1,'mobile':False})
                wait.until(lambda _:browser.execute_script('return document.documentElement.scrollWidth<=innerWidth+1'))
                check('auto_plan_fits_'+str(width))
            browser.save_screenshot(str(ROOT/'artifacts'/'trade-auto-plan.png'))
            click('Начать обмен')
            wait.until(lambda _:auto_id in state.trades.threads and not state.trades.threads[auto_id].is_alive())
            automatic=state.trades.run(auto_id)
            check('auto_mode_adds_from_ranked_source',automatic['confirmed_count']==1 and automatic['confirmed'][0]['source_account_id']==extra['id'])
            state.trades.finish(auto_id,accept_unverified=True)
            factory=state.trades.session_factory
            def manual_factory(*args):
                session=factory(*args)
                async def invite(group,target,before_send):
                    before_send()
                    scenario.invites.append((group['id'],target))
                    return TradeSession._invitation_manual('Synthetic: X has not confirmed this invitation; sender stays open')
                session.invite=invite
                session._invitation_manual=TradeSession._invitation_manual
                return session
            state.trades.session_factory=manual_factory
            scenario.verify_status='not_added'
            recovery=state.trades.preview({'receive_account_id':owner['id'],'send_account_id':owner['id'],
                'donors':['partner'],'recipients':['reviewpartner'],'count':1,'quality':'any'})
            state.trades.start(recovery['id'])
            wait.until(lambda _:state.trades.run(recovery['id'])['status']=='requires_manual')
            check('pending_invitation_keeps_sender_open',scenario.trade_open==1)
            calls=len(scenario.invites)
            click('Проверить результат добавления')
            wait.until(lambda _:state.trades.controls[recovery['id']].manual_generation==1 and
                       state.trades.run(recovery['id'])['progress'].get('manual_reason','').startswith('Добавление всё ещё'))
            check('negative_recheck_keeps_browser_and_never_resends',scenario.trade_open==1 and len(scenario.invites)==calls)
            for width in (390,1440):
                browser.execute_cdp_cmd('Emulation.setDeviceMetricsOverride',{'width':width,'height':1000,'deviceScaleFactor':1,'mobile':False})
                wait.until(lambda _:browser.execute_script('return document.documentElement.scrollWidth<=innerWidth+1'))
                browser.save_screenshot(str(ROOT/'artifacts'/('trade-recovery-'+str(width)+'.png')))
            scenario.verify_status='confirmed'
            click('Проверить результат добавления')
            wait.until(lambda _:not state.trades.threads[recovery['id']].is_alive())
            check('manual_recovery_verifies_success_without_relogin_or_resending',state.trades.run(recovery['id'])['confirmed_count']==1 and len(scenario.invites)==calls)
            state.trades.finish(recovery['id'],accept_unverified=True)
            report['passed'] = True
        except Exception as error:
            report.update(error=str(error),traceback=traceback.format_exc())
            if browser:
                browser.save_screenshot(str(ROOT/'artifacts'/'trade-ui-failure.png'))
        finally:
            if browser:
                browser.quit()
            state.trades.close()
            state.jobs.close()
            server.should_exit = True
            thread.join(15)
            (ROOT/'artifacts'/'trade-ui-smoke.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'passed':report['passed'],'checks':len(report['checks']),'error':report.get('error')},ensure_ascii=True))
    return 0 if report['passed'] else 1


if __name__=='__main__':
    sys.exit(run())
