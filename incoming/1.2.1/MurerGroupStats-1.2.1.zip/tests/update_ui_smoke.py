"""Headless UI checks with fake GitHub, temporary data and no X access."""
import json
import os
from pathlib import Path
import socket
import sys
import tempfile
import threading
import time
from unittest.mock import patch

import httpx
import uvicorn
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT)); sys.path.insert(0,str(ROOT/'tests'))
from murer.api import create_app
from murer.secrets import SecretStore
from test_storage_api import MemoryVault


def main():
    report={'synthetic_data':True,'real_x_access':False,'checks':[],'passed':False}
    browser=None; server=None; thread=None
    try:
        with tempfile.TemporaryDirectory(prefix='murer_update_ui_') as temporary:
            folder=Path(temporary)
            with patch.dict(os.environ,MURER_INSTALL_ROOT=str(folder)):
                app=create_app(folder/'data',SecretStore(MemoryVault()))
            app.state.application.configuration['configured']=True
            app.state.application.updates.transport=httpx.MockTransport(lambda request:httpx.Response(404))
            with socket.socket() as probe:
                probe.bind(('127.0.0.1',0)); port=probe.getsockname()[1]
            server=uvicorn.Server(uvicorn.Config(app,host='127.0.0.1',port=port,log_level='error',access_log=False))
            thread=threading.Thread(target=server.run,daemon=True); thread.start()
            deadline=time.monotonic()+15
            while not server.started and time.monotonic()<deadline: time.sleep(.05)
            assert server.started
            test_browser=Path(os.environ['LOCALAPPDATA'])/'MurerGroupStats'/'browser-test'
            options=webdriver.ChromeOptions()
            options.binary_location=str(test_browser/'chrome-win64'/'chrome.exe')
            options.add_argument('--headless=new'); options.add_argument('--no-first-run')
            options.add_argument('--no-default-browser-check'); options.add_argument('--window-size=1440,1100')
            options.add_argument('--user-data-dir='+str(folder/'browser'))
            options.set_capability('goog:loggingPrefs',{'browser':'ALL'})
            browser=webdriver.Chrome(service=Service(str(test_browser/'chromedriver-win64'/'chromedriver.exe')),options=options)
            wait=WebDriverWait(browser,20)
            browser.get(f'http://127.0.0.1:{port}')
            settings=wait.until(lambda d:d.find_element(By.XPATH,'//aside//button[normalize-space(.)="Настройки"]'))
            settings.click()
            card=wait.until(lambda d:d.find_element(By.CSS_SELECTOR,'[data-testid="updates-card"]'))
            wait.until(lambda d:(ROOT/'VERSION').read_text(encoding='utf-8').strip() in card.text)
            report['checks'].append('version_and_update_controls_visible')
            assert 'без входа в GitHub и без токенов' in card.text
            assert not browser.find_elements(By.ID,'github-update-token')
            report['checks'].append('public_updates_need_no_github_login')
            app.state.application.updates.config['public']=False
            wait.until(lambda d:bool(d.find_elements(By.ID,'github-update-token')))
            card.find_element(By.XPATH,'.//summary[contains(.,"Доступ к приватному GitHub")]').click()
            token=browser.find_element(By.ID,'github-update-token')
            assert token.get_attribute('type')=='password'
            token.send_keys('fixture-ui-private')
            card.find_element(By.XPATH,'.//button[normalize-space(.)="Сохранить доступ"]').click()
            wait.until(lambda d:'· настроен' in card.text)
            assert 'fixture-ui-private' not in card.text
            assert browser.execute_script('return JSON.stringify(localStorage)') .find('fixture-ui-private')==-1
            report['checks'].append('github_access_masked_and_saved_without_localstorage')
            card.find_element(By.XPATH,'.//button[normalize-space(.)="Проверить обновления"]').click()
            wait.until(lambda d:'Релиз не найден' in card.text)
            report['checks'].append('fake_github_failure_explained_without_breaking_app')
            app.state.application.updates.config['public']=True
            wait.until(lambda d:not d.find_elements(By.ID,'github-update-token'))
            browser.execute_script('arguments[0].scrollIntoView({block:"start"})',card)
            browser.save_screenshot(str(ROOT/'artifacts'/'updates-desktop.png'))
            browser.set_window_size(390,1000)
            browser.execute_script('arguments[0].scrollIntoView({block:"start"})',card)
            assert browser.execute_script('return document.documentElement.scrollWidth <= innerWidth+1')
            browser.save_screenshot(str(ROOT/'artifacts'/'updates-mobile.png'))
            report['checks'].append('desktop_and_mobile_update_card_fit_viewport')
            errors=[entry for entry in browser.get_log('browser') if entry['level']=='SEVERE' and '404' not in entry['message']]
            assert not errors, errors
            report['checks'].append('no_browser_runtime_errors')
            browser.quit(); browser=None
            server.should_exit=True; thread.join(15)
            report['passed']=True
    except Exception as error:
        report['error']=str(error)
    finally:
        if browser: browser.quit()
        if server: server.should_exit=True
        if thread: thread.join(15)
    (ROOT/'artifacts'/'update-ui-smoke.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(report,ensure_ascii=True,indent=2))
    return 0 if report['passed'] else 1


if __name__=='__main__':
    raise SystemExit(main())
