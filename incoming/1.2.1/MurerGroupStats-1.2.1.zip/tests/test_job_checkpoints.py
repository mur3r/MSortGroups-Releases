"""Safe-step persistence and ordered HTTP exports; only synthetic observations."""
from copy import deepcopy
import csv
import io
import json
from pathlib import Path
import tempfile
import unittest
from uuid import uuid4

from fastapi.testclient import TestClient
from murer.api import create_app
from murer.history import changes_between
from murer.jobs import JobControl, StopRequested
from murer.secrets import SecretStore
from murer.storage import encode, utcnow
from tests.test_storage_api import MemoryVault, observed_profile


class SafeCheckpointTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.app = create_app(Path(self.temporary.name), SecretStore(MemoryVault()))
        self.state = self.app.state.application
        self.client = TestClient(self.app)
        self.account = self.client.post('/api/accounts', json={'username': 'fixture_owner'}).json()
        self.job_id = str(uuid4())
        now = utcnow()
        settings, version = self.state.store.settings()
        self.state.store.execute('INSERT INTO jobs VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',
            (self.job_id, 'collect', encode([self.account['id']]), '[]', 'running', now, now,
             encode(settings), version, '{}', None, None))
        self.control = JobControl()

    def tearDown(self):
        self.state.jobs.close()
        self.client.close()
        self.temporary.cleanup()

    def progress(self, checkpoint_data):
        self.state.jobs._progress(self.job_id, self.control, self.account['id'],
            {'operation': 'Synthetic safe step', 'checkpoint_data': checkpoint_data})

    def group(self, x_id='g123'):
        self.progress({'kind': 'groups', 'groups': [{'x_id': x_id, 'name': 'Fixture',
            'url': f'https://x.com/i/chat/{x_id}'}]})
        self.state.jobs._persist_checkpoints(self.job_id, self.control, self.account['id'], force=True)
        return self.state.store.rows('SELECT id FROM groups WHERE x_id=?', (x_id,))[0]['id']

    def test_group_and_member_steps_survive_interruption_without_progress_payload_leak(self):
        group_id = self.group()
        self.progress({'kind': 'members', 'group_x_id': 'g123',
            'participants': [{'x_id': '10', 'username': 'fixture_person'}], 'declared_count': 2})
        self.progress({'kind': 'members', 'group_x_id': 'g123',
            'participants': [{'x_id': '10', 'username': 'fixture_person'}, {'x_id': '11', 'username': 'fixture_other'}], 'declared_count': 2})
        self.control.stopped = True
        with self.assertRaises(StopRequested):
            self.state.jobs._checkpoint(self.job_id, self.control, self.account['id'])
        dataset = self.state.store.dataset()
        self.assertEqual(len(dataset['participants']), 2)
        self.assertEqual(len(dataset['groups'][0]['participant_ids']), 2)
        self.assertEqual(dataset['groups'][0]['membership_status'], 'partial')
        self.assertNotIn('checkpoint_data', json.dumps(self.state.store.job(self.job_id)['progress']))
        self.assertEqual(self.state.store.rows('SELECT COUNT(*) AS n FROM account_groups')[0]['n'], 1)
        self.assertEqual(dataset['groups'][0]['id'], group_id)

    def test_manual_status_tracks_all_waiting_accounts_and_clears_after_continue(self):
        progress = self.state.jobs._progress
        progress(self.job_id,self.control,'first',{'manual_reason':'Synthetic gate A'})
        progress(self.job_id,self.control,'second',{'manual_reason':'Synthetic gate B'})
        progress(self.job_id,self.control,'first',{'manual_reason':None})
        self.assertEqual(self.state.store.job(self.job_id)['status'], 'requires_manual')
        progress(self.job_id,self.control,'second',{'manual_reason':None})
        self.assertEqual(self.state.store.job(self.job_id)['status'], 'running')

    def test_partial_profile_saved_at_stop_and_success_supersedes_it_idempotently(self):
        pid = self.state.store.identify({'x_id': '10', 'username': 'fixture_person'})
        partial = observed_profile('partial', period_complete=False)
        self.progress({'kind': 'profile', 'participant_id': pid, 'result': partial})
        self.progress({'kind': 'profile', 'participant_id': pid, 'result': {**partial, 'viewed_count': 2}})
        self.control.paused = True
        self.state.jobs._persist_checkpoints(self.job_id, self.control, self.account['id'], force=True)
        self.assertEqual(self.state.store.participant(pid)['observations'][0]['viewed_count'], 2)
        self.state.store.save_profile(self.job_id, pid, self.account['id'], observed_profile())
        self.state.store.save_profile(self.job_id, pid, self.account['id'], observed_profile())
        self.assertEqual(self.state.store.rows('SELECT COUNT(*) AS n FROM profile_observations')[0]['n'], 1)
        self.assertEqual(self.state.store.participant(pid)['observations'][0]['status'], 'full')

    def test_post_csv_respects_explicit_order_despite_unrelated_search_and_sort(self):
        first = self.group('g1')
        second = self.group('g2')
        response = self.client.post('/api/export', json={'table': 'groups', 'format': 'csv',
            'columns': ['id', 'name'], 'row_ids': [second, first], 'search': 'does-not-match', 'sort': 'id'})
        self.assertEqual(response.status_code, 200)
        rows = list(csv.DictReader(io.StringIO(response.content.decode('utf-8-sig')), delimiter=';'))
        self.assertEqual([row['id'] for row in rows], [second, first])
        self.assertIn('export_metadata', rows[0])

    def test_large_post_export_does_not_require_long_url(self):
        response = self.client.post('/api/export', json={'table': 'participants', 'row_ids': ['fixture-'+str(i) for i in range(10000)]})
        self.assertEqual(response.status_code, 200)
        self.assertIn('export_metadata', response.content.decode('utf-8-sig'))

    def test_browser_stage_progress_retains_worker_group_and_profile_indexes(self):
        self.state.jobs._progress(self.job_id, self.control, self.account['id'],
            {'account_index': 1, 'account_total': 2, 'group_index': 3, 'group_total': 5,
             'profile_index': 4, 'profile_total': 10})
        self.state.jobs._progress(self.job_id, self.control, self.account['id'],
            {'operation': 'Чтение карточек', 'posts_viewed': 10})
        progress = self.state.store.job(self.job_id)['progress']
        self.assertEqual((progress['account_index'], progress['group_index'], progress['profile_index']), (1, 3, 4))

    def test_new_group_resets_nullable_profile_progress_without_failing_worker(self):
        self.state.jobs._progress(self.job_id, self.control, self.account['id'],
            {'group_index': 1, 'group_total': 2, 'profile_index': 4, 'profile_total': 10})
        self.state.jobs._progress(self.job_id, self.control, self.account['id'],
            {'group_index': 2, 'group_total': 2, 'profile_index': None, 'profile_total': None,
             'operation': 'Synthetic next group'})
        progress = self.state.store.job(self.job_id)['progress']
        self.assertEqual(progress['group_index'], 2)
        self.assertIsNone(progress['profile_index'])
        self.assertIsNone(progress['profile_total'])
        self.assertNotIn('eta_seconds', progress)

    def test_summary_payload_defers_posts_to_scoped_participant_detail(self):
        group_id = self.group()
        ids = self.state.store.save_members(self.job_id, group_id, self.account['id'],
            {'participants': [{'x_id': '10', 'username': 'fixture_person'}], 'status': 'full', 'declared_count': 1})
        self.state.store.save_profile(self.job_id, ids[0], self.account['id'], observed_profile())
        summary = self.client.get('/api/analysis').json()
        self.assertNotIn('posts', summary['participants'][0])
        self.assertEqual(summary['participants'][0]['viewed_count'], 1)
        detail = self.client.get('/api/participants/'+ids[0]).json()
        self.assertEqual(len(detail['posts']), 1)
        self.assertEqual(self.client.get('/api/participants/'+ids[0]+'?group_ids=unknown').status_code, 404)


class HistoryChangesTests(unittest.TestCase):
    def test_missing_from_partial_snapshot_never_proves_departure_or_score_delta(self):
        before = {'groups': [{'id': 'g', 'name': 'Fixture', 'participant_ids': ['a', 'b'], 'membership_status': 'full'}]}
        after = deepcopy(before)
        after['groups'][0].update(participant_ids=['a'], membership_status='partial')
        result = changes_between(before, after)
        row = result['groups'][0]
        self.assertEqual(row['observed_missing_count'], 1)
        self.assertFalse(row['membership_comparable'])
        self.assertEqual(row['change_status'], 'uncertain')
        self.assertIsNone(row['score_difference'])

    def test_confirmed_full_composition_delta_can_be_compared(self):
        before = {'groups': [{'id': 'g', 'name': 'Fixture', 'participant_ids': ['a'], 'membership_status': 'full'}]}
        after = deepcopy(before)
        after['groups'][0]['participant_ids'] = ['a', 'b']
        a = {'settings': {'version': 1}, 'groups': [{'id': 'g', 'score': 40, 'available_components': ['U']}]}
        b = {'settings': {'version': 1}, 'groups': [{'id': 'g', 'score': 70, 'available_components': ['U']}]}
        row = changes_between(before, after, a, b)['groups'][0]
        self.assertTrue(row['membership_comparable'])
        self.assertEqual(row['score_difference'], 30)

    def test_score_delta_rejects_different_comparison_scope(self):
        data = {'groups':[{'id':'g','name':'Fixture','participant_ids':['p'],'membership_status':'full'}]}
        before = {'settings':{},'summary':{'scope':{'account_ids':['a'],'group_ids':['g']}},
                  'groups':[{'id':'g','score':80,'available_components':['U']}]}
        after = {**before,'summary':{'scope':{'account_ids':['b'],'group_ids':['g','other']}}}
        row = changes_between(data,data,before,after)['groups'][0]
        self.assertTrue(row['membership_comparable'])
        self.assertFalse(row['scores_comparable'])
        self.assertIsNone(row['score_difference'])

    def test_conflicting_declared_count_cannot_confirm_history_difference(self):
        data = {'groups':[{'id':'g','name':'Fixture','participant_ids':['p'],'declared_count':2,'membership_status':'full'}]}
        self.assertFalse(changes_between(data,data)['groups'][0]['membership_comparable'])

    def test_missing_scores_never_appear_comparable(self):
        data = {'groups':[{'id':'g','name':'Fixture','participant_ids':['p'],'membership_status':'full'}]}
        row = changes_between(data,data)['groups'][0]
        self.assertTrue(row['membership_comparable'])
        self.assertFalse(row['scores_comparable'])
        self.assertIsNone(row['score_difference'])


if __name__ == '__main__':
    unittest.main()
