"""Visible Chrome checks at exact viewport widths, with synthetic local data only."""
import argparse
import json
import os
from pathlib import Path
import sys
import tempfile
import threading
import time
import traceback

import uvicorn
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from murer.api import create_app
from murer.secrets import SecretStore
from tests.test_storage_api import MemoryVault, Scenario
from murer.storage import utcnow

PAGES = ['Обзор', 'Аккаунты', 'Группы', 'Участники', 'Пересечения', 'Наши аккаунты', 'Правила оценки', 'История сборов', 'Trade', 'История обменов', 'Настройки']
LAYOUT = r"""
const width=window.innerWidth;
const shown=el=>{const r=el.getBoundingClientRect();const style=getComputedStyle(el);return r.width>0&&r.height>0&&style.visibility!=='hidden'&&style.opacity!=='0'&&!el.closest('[aria-hidden="true"]')};
const descendants=Array.from(document.querySelectorAll('body *')).filter(shown);
const inDesktopTable=el=>width>=1024&&!!el.closest('.data-table-desktop');
const escaped=descendants.filter(el=>{
  if(inDesktopTable(el)||el.matches('[data-slot="progress-indicator"]'))return false;
  const r=el.getBoundingClientRect();return r.left < -1 || r.right > width+1;
}).slice(0,8).map(el=>({tag:el.tagName,slot:el.getAttribute('data-slot'),class:el.className,text:(el.innerText||'').slice(0,90),left:el.getBoundingClientRect().left,right:el.getBoundingClientRect().right}));
const horizontal=descendants.filter(el=>!inDesktopTable(el)&&!['INPUT','TEXTAREA'].includes(el.tagName)&&
  el.scrollWidth>el.clientWidth+2&&['auto','scroll'].includes(getComputedStyle(el).overflowX))
  .slice(0,8).map(el=>({tag:el.tagName,slot:el.getAttribute('data-slot'),class:el.className,client:el.clientWidth,scroll:el.scrollWidth}));
const controls=descendants.filter(el=>el.matches('[data-slot="button"],input:not([type="hidden"]),[data-slot="select-trigger"]'));
const small=width<1024?controls.filter(el=>el.getBoundingClientRect().height<43).map(el=>({tag:el.tagName,text:(el.innerText||el.getAttribute('aria-label')||'').slice(0,60),height:el.getBoundingClientRect().height})):[];
return {viewport:width,document:document.documentElement.scrollWidth,escaped,horizontal,small};
"""


def run(chrome, driver_path, port=8767):
    artifacts = ROOT / 'artifacts'
    artifacts.mkdir(exist_ok=True)
    report = {'synthetic_data': True, 'real_x_access': False, 'checks': [], 'widths': [360, 390, 768, 1440], 'passed': False}
    browser = server = thread = None
    with tempfile.TemporaryDirectory(prefix='murer_responsive_') as temporary:
        scenario = Scenario()
        app = create_app(Path(temporary) / 'data', SecretStore(MemoryVault()), scenario.factory)
        state = app.state.application
        state.configuration.update(configured=True, chrome_path=chrome, driver_path=driver_path)
        settings, _ = state.store.settings()
        settings['collection'].update(profile_delay_seconds=0, group_delay_seconds=0, account_delay_seconds=0,
            account_start_interval_seconds=0, action_delay_seconds=0, load_wait_seconds=0)
        state.store.save_settings(settings)
        accounts = [state.save_account({'username': name}) for name in ('owner', 'secondowner')]
        job = state.jobs.start([account['id'] for account in accounts], 'collect')
        state.jobs.threads[job['id']].join(15)
        assert not state.jobs.threads[job['id']].is_alive(), 'Synthetic seed job did not finish'
        groups = state.store.rows('SELECT id FROM groups ORDER BY x_id')
        for index, group in enumerate(groups):
            state.store.execute('UPDATE groups SET name=? WHERE id=?',
                ('Тестовая группа ' + str(index+1) + ' · Длинное название для проверки читаемости и переноса текста ' + 'LongNameWithoutSpaces'*4, group['id']))
        state.store.execute('UPDATE participants SET name=?', ('Длинное имя участника для проверки отображения на телефоне',))
        # Exercise pagination and long identities without using any real profiles.
        people = [{'username': f'fixture{i}', 'x_id': str(1000+i)} for i in range(28)]
        state.store.save_members(job['id'], groups[0]['id'], accounts[0]['id'], {'status': 'full', 'participants': people, 'declared_count': 28})
        state.analysis_cache.clear()
        # Synthetic history only: no invitation or foreign account is accessed.
        trade = state.trades.preview({'receive_account_id':accounts[0]['id'], 'send_account_id':accounts[1]['id'],
            'donors':['fixture_donor'], 'recipients':['fixture_partner','other_partner'], 'count':1, 'quality':'any'})
        for index, group in enumerate(trade['plan']['groups']):
            state.store.execute('INSERT INTO trade_items(id,run_id,group_id,recipient,status,reason,group_name,url,quality,score,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)',
                (f'fixture-trade-{index}', trade['id'], group['id'], trade['config']['recipients'][index],
                 'confirmed', 'Synthetic history fixture, no X action', group['name'], group['url'], group['quality'], group['score'], utcnow()))
        state.trades.update(trade['id'], status='completed', finished_at=utcnow())
        server = uvicorn.Server(uvicorn.Config(app, host='127.0.0.1', port=port, log_level='error', access_log=False))
        thread = threading.Thread(target=server.run, daemon=True)
        thread.start()
        try:
            options = webdriver.ChromeOptions()
            options.binary_location = chrome
            options.add_argument(f'--user-data-dir={Path(temporary) / "browser"}')
            options.add_argument('--no-first-run')
            options.add_argument('--no-default-browser-check')
            options.add_argument('--window-size=1500,1050')
            options.set_capability('goog:loggingPrefs', {'browser': 'ALL'})
            browser = webdriver.Chrome(service=Service(driver_path), options=options)
            wait = WebDriverWait(browser, 15)
            browser.get(f'http://127.0.0.1:{port}')
            wait.until(lambda _: browser.find_elements(By.TAG_NAME, 'h1'))

            def visible(selector):
                return [el for el in browser.find_elements(By.CSS_SELECTOR, selector) if el.is_displayed()]

            def click_text(text, tag='button'):
                xpath = f'//{tag}[normalize-space(.)={json.dumps(text,ensure_ascii=False)}]'
                def find(_):
                    return next((el for el in browser.find_elements(By.XPATH, xpath) if el.is_displayed() and el.is_enabled()), False)
                el = wait.until(find)
                browser.execute_script('arguments[0].scrollIntoView({block:"center"})', el)
                el.click()

            def nav(name, width):
                browser.execute_script('window.scrollTo(0,0)')
                if browser.find_element(By.TAG_NAME, 'h1').text == name:
                    return
                if width < 1024:
                    trigger = visible('button[aria-label="Раздел приложения"]')[0]
                    if width < 768:
                        rect = trigger.rect
                        point = {'x': rect['x']+rect['width']/2, 'y': rect['y']+rect['height']/2}
                        browser.execute_cdp_cmd('Input.dispatchTouchEvent', {'type': 'touchStart', 'touchPoints': [point]})
                        browser.execute_cdp_cmd('Input.dispatchTouchEvent', {'type': 'touchEnd', 'touchPoints': []})
                    else:
                        trigger.click()
                    click_text(name, '*[@role="option"]')
                else:
                    click_text(name)
                wait.until(lambda _: browser.find_element(By.TAG_NAME, 'h1').text == name)

            def audit(name, width):
                browser.execute_async_script('const done=arguments[0];Promise.all(document.getAnimations().filter(a=>a.effect&&Number.isFinite(a.effect.getComputedTiming().endTime)).map(a=>a.finished.catch(()=>{}))).then(()=>done())')
                browser.execute_async_script('requestAnimationFrame(()=>requestAnimationFrame(arguments[0]))')
                result = browser.execute_script(LAYOUT)
                report['checks'].append({'name': name, 'width': width, **result})
                assert result['viewport'] == width, result
                assert result['document'] <= width+1, (name, result)
                assert not result['escaped'], (name, result)
                if width < 1024:
                    assert not result['horizontal'], (name, result)
                    assert not result['small'], (name, result)

            def close():
                browser.find_element(By.TAG_NAME, 'body').send_keys(Keys.ESCAPE)
                wait.until(lambda _: not visible('[role="dialog"]'))

            for width in report['widths']:
                browser.execute_cdp_cmd('Emulation.setDeviceMetricsOverride', {'width': width, 'height': 900, 'deviceScaleFactor': 1, 'mobile': width < 768})
                for page in PAGES:
                    nav(page, width)
                    audit(page, width)
                    if page == 'Группы':
                        if width < 1024:
                            search = visible('input[aria-label="Поиск в таблице"]')[0]
                            search.send_keys('Тестовая группа 1')
                            wait.until(lambda _: len(visible('.mobile-record')) == 1)
                            audit('Мобильный поиск', width)
                            search.send_keys(Keys.CONTROL, 'a')
                            search.send_keys(Keys.BACKSPACE)
                            wait.until(lambda _: len(visible('.mobile-record')) == 2)
                            sort = visible('button[aria-label="Сортировка таблицы"]')[0]
                            sort.send_keys(Keys.SPACE)
                            click_text('Заявлено', '*[@role="option"]')
                            visible('button[aria-label="Сортировать по убыванию"]')[0].click()
                            selection = visible('.mobile-record button[role="checkbox"]')[0]
                            selection.click()
                            assert selection.get_attribute('aria-checked') == 'true'
                            selection.click()
                            summary = visible('.mobile-record details summary')[0]
                            summary.click()
                            audit('Мобильная сортировка, выбор и все показатели', width)
                        browser.save_screenshot(str(artifacts / f'responsive-groups-{width}.png'))
                        if width < 1024:
                            visible('.mobile-record button[aria-label^="Подробнее:"]')[0].click()
                        else:
                            visible('.data-table-desktop tbody tr')[0].click()
                        wait.until(lambda _: visible('[role="dialog"]'))
                        audit('Карточка группы', width)
                        click_text('Расчёт оценки')
                        audit('Расчёт оценки группы', width)
                        close()
                    elif page == 'Участники':
                        if width < 1024:
                            visible('.mobile-record button[aria-label^="Подробнее:"]')[0].click()
                        else:
                            visible('.data-table-desktop tbody tr')[0].click()
                        wait.until(lambda _: visible('[role="dialog"]'))
                        audit('Карточка участника', width)
                        close()
                        next_button = visible('button[aria-label="Следующая страница"]')[0]
                        next_button.click()
                        audit('Пагинация', width)
                    elif page == 'Аккаунты':
                        click_text('Добавить аккаунт')
                        wait.until(lambda _: visible('#account-username'))
                        audit('Форма аккаунта', width)
                        browser.save_screenshot(str(artifacts / f'responsive-account-{width}.png'))
                        close()
                        click_text('Импорт')
                        wait.until(lambda _: visible('[role="dialog"]'))
                        audit('Импорт', width)
                        close()
                        click_text('Пароль iChat')
                        wait.until(lambda _: visible('[role="dialog"]'))
                        audit('Массовый пароль', width)
                        close()
                    elif page == 'История сборов':
                        click_text('Параметры запуска и ошибки · версия ' + str(job['settings_version']), 'summary')
                        audit('Настройки в истории', width)
                    elif page == 'Trade':
                        wait.until(lambda _: visible('#trade-donors'))
                        picker = visible('button[aria-label="trade-receive: выбор аккаунта"]')[0]
                        picker.send_keys(Keys.SPACE)
                        wait.until(lambda _: visible('[role="option"]'))
                        audit('Список аккаунтов Trade с количеством групп', width)
                        browser.find_element(By.TAG_NAME, 'body').send_keys(Keys.ESCAPE)
                        click_text('Подготовить план обмена')
                        wait.until(lambda _: any(el.text == 'План обмена' for el in browser.find_elements(By.CSS_SELECTOR, '[data-slot="card-title"]')))
                        audit('План обмена', width)
                        browser.save_screenshot(str(artifacts / f'responsive-trade-{width}.png'))
                    elif page == 'История обменов':
                        if width < 1024:
                            wait.until(lambda _: visible(f'button[aria-label="Подробнее: {trade["id"]}"]'))[0].click()
                        else:
                            # The completed history was seeded before the UI draft.
                            next(row for row in visible('.data-table-desktop tbody tr') if 'Обмен завершён' in row.text).click()
                        wait.until(lambda _: visible('[role="dialog"]'))
                        wait.until(lambda _: 'Ссылки на группы' in visible('[role="dialog"]')[0].text)
                        audit('История обмена: названия и вертикальные ссылки', width)
                        browser.save_screenshot(str(artifacts / f'responsive-trade-history-{width}.png'))
                        click_text('Все попытки')
                        audit('История обмена: качество и результаты', width)
                        close()
                    elif page == 'Настройки':
                        click_text('Все значения встроенных режимов', 'summary')
                        audit('Таблица скоростей', width)
                        browser.save_screenshot(str(artifacts / f'responsive-settings-{width}.png'))
                        click_text('Пути и проверка')
                        wait.until(lambda _: visible('[role="dialog"]'))
                        audit('Форма путей', width)
                        close()
                browser.execute_script('window.scrollTo(0,0)')
                browser.find_element(By.CSS_SELECTOR, 'button[aria-label="Переключить тему"]').click()
                audit('Другая тема', width)
            errors = [entry for entry in browser.get_log('browser') if entry['level'] == 'SEVERE' and 'favicon' not in entry['message']]
            assert not errors, errors
            report['passed'] = True
        except Exception as error:
            report['error'] = str(error)
            report['traceback'] = traceback.format_exc()
            if browser:
                browser.save_screenshot(str(artifacts / 'responsive-failure.png'))
        finally:
            if browser:
                browser.quit()
            state.trades.close()
            state.jobs.close()
            server.should_exit = True
            thread.join(15)
            (artifacts / 'responsive-smoke.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps({'passed': report['passed'], 'checks': len(report['checks']), 'error': report.get('error')}, ensure_ascii=True))
    return 0 if report['passed'] else 1


if __name__ == '__main__':
    test_browser = Path(os.environ.get('LOCALAPPDATA', '')) / 'MurerGroupStats' / 'browser-test'
    parser = argparse.ArgumentParser()
    parser.add_argument('--chrome', default=str(test_browser / 'chrome-win64' / 'chrome.exe'))
    parser.add_argument('--driver', default=str(test_browser / 'chromedriver-win64' / 'chromedriver.exe'))
    args = parser.parse_args()
    sys.exit(run(args.chrome, args.driver))
