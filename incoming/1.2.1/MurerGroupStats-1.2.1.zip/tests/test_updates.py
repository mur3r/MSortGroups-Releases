"""Updater tests use signed synthetic packages, fake GitHub and isolated SQLite."""
import base64
import io
import json
import os
from pathlib import Path
import sqlite3
import stat
import sys
import tempfile
import unittest
from unittest.mock import Mock, patch
import zipfile

import httpx
from fastapi.testclient import TestClient
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives.serialization import Encoding, PublicFormat

from murer import __version__
from murer.api import create_app
from murer.secrets import SecretStore
from murer.storage import Store
from murer.update_format import APP, REQUIRED, UpdateError, canonical_json, extract_package, safe_member, sha256, verify_manifest, verify_tree, version_tuple
from murer.updates import GitHubDownloads, UpdateManager, atomic_json, read_json, VAULT_SERVICE
from test_storage_api import MemoryVault

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))
from launcher import Supervisor
from build_release import build


class SignedPackage:
    def __init__(self, extra=None, version='9.0.0'):
        self.key = Ed25519PrivateKey.generate()
        self.keys = {'test': base64.b64encode(self.key.public_key().public_bytes(Encoding.Raw, PublicFormat.Raw)).decode()}
        self.files = {name: b'fixture\n' for name in REQUIRED}
        self.files['VERSION'] = (version + '\n').encode()
        self.files.update(extra or {})
        stream = io.BytesIO()
        with zipfile.ZipFile(stream, 'w') as archive:
            for name, content in self.files.items():
                archive.writestr(name, content)
        self.archive = stream.getvalue()
        import hashlib
        self.manifest = {'schema': 1, 'application': APP, 'updater_protocol': 1, 'version': version,
                         'package': {'name': f'MurerGroupStats-{version}.zip', 'size': len(self.archive), 'sha256': hashlib.sha256(self.archive).hexdigest()},
                         'files': {name: hashlib.sha256(value).hexdigest() for name, value in self.files.items()}}
        self.sign()

    def sign(self):
        self.raw = canonical_json(self.manifest)
        self.signature = canonical_json({'key_id': 'test', 'signature': base64.b64encode(self.key.sign(self.raw)).decode()})

    def transport(self):
        release = {'id': 123, 'tag_name': 'v' + self.manifest['version'], 'body': 'Fixture notes', 'draft': False, 'prerelease': False,
                   'assets': [{'id': index, 'name': name, 'state': 'uploaded'} for index, name in enumerate(
                       ('murer-update.json', 'murer-update.sig', self.manifest['package']['name']), 1)]}
        def handler(request):
            if '/releases/assets/' in request.url.path:
                return httpx.Response(200, content={1: self.raw, 2: self.signature, 3: self.archive}[int(request.url.path.split('/')[-1])])
            return httpx.Response(200, json=release)
        return httpx.MockTransport(handler)


class FormatTests(unittest.TestCase):
    def test_real_signature_and_file_hashes_round_trip(self):
        package = SignedPackage()
        manifest = verify_manifest(package.raw, package.signature, package.keys)
        with tempfile.TemporaryDirectory() as directory:
            archive = Path(directory) / 'release.zip'
            archive.write_bytes(package.archive)
            target = Path(directory) / 'candidate'
            extract_package(archive, target, manifest)
            verify_tree(target, manifest)
            (target / 'VERSION').write_text('9.0.1')
            with self.assertRaises(UpdateError):
                verify_tree(target, manifest)

    def test_changed_manifest_wrong_signature_and_unknown_key_rejected(self):
        package = SignedPackage()
        for raw, signature, keys in ((package.raw + b' ', package.signature, package.keys),
                                     (package.raw, b'{}', package.keys), (package.raw, package.signature, {})):
            with self.subTest(raw=raw[-4:]), self.assertRaises(UpdateError):
                verify_manifest(raw, signature, keys)

    def test_signed_traversal_windows_names_and_case_collisions_rejected(self):
        for name in ('../escape.py', '/absolute.py', 'murer/../../escape', 'murer\\escape', 'murer/x:ads',
                     'murer/CON.txt', 'murer/file. ', 'murer/./file.py', '.env', '.git/config', 'accounts.json',
                     'frontend/node_modules/x', 'data/file', '.', '', 'config/settings.json'):
            with self.subTest(name=name), self.assertRaises(UpdateError):
                safe_member(name)
        package = SignedPackage({'murer/API.py': b'collision'})
        with self.assertRaises(UpdateError):
            verify_manifest(package.raw, package.signature, package.keys)

    def test_future_protocol_and_incomplete_manifest_rejected(self):
        for change in ({'updater_protocol': 999}, {'files': {}}, {'application': 'other'}):
            package = SignedPackage()
            package.manifest.update(change)
            package.sign()
            with self.assertRaises(UpdateError):
                verify_manifest(package.raw, package.signature, package.keys)

    def test_corrupt_archive_extra_files_symlink_and_file_hashes_rejected(self):
        import hashlib
        for mode in ('corrupt', 'extra', 'symlink', 'file_hash'):
            package = SignedPackage()
            archive = package.archive
            if mode == 'corrupt':
                archive += b'corrupt'
            elif mode in ('extra', 'symlink'):
                stream = io.BytesIO(archive)
                with zipfile.ZipFile(stream, 'a') as zipfile_out:
                    item = zipfile.ZipInfo('murer/link')
                    item.create_system = 3
                    item.external_attr = (stat.S_IFLNK | 0o777) << 16
                    zipfile_out.writestr(item if mode == 'symlink' else 'murer/extra.py', 'outside')
                archive = stream.getvalue()
                package.manifest['package'].update(size=len(archive), sha256=hashlib.sha256(archive).hexdigest())
                if mode == 'symlink':
                    package.manifest['files']['murer/link'] = hashlib.sha256(b'outside').hexdigest()
            else:
                package.manifest['files']['VERSION'] = '0' * 64
            with tempfile.TemporaryDirectory() as directory:
                path = Path(directory) / 'release.zip'
                path.write_bytes(archive)
                with self.subTest(mode=mode), self.assertRaises(UpdateError):
                    extract_package(path, Path(directory) / 'candidate', package.manifest)

    def test_versions_compare_numerically_and_no_unannounced_downgrade(self):
        self.assertGreater(version_tuple('1.10.0'), version_tuple('1.9.9'))
        for invalid in ('1.0', 'v1.0.0', '1.0.0-rc1', '01.0.0', '../../1', None):
            with self.assertRaises(UpdateError):
                version_tuple(invalid)


class DownloadTests(unittest.TestCase):
    def test_public_releases_use_direct_downloads_without_token_or_rest_quota(self):
        package = SignedPackage()
        seen = []
        def handler(request):
            seen.append((request.url.host, request.headers.get('Authorization')))
            name = request.url.path.split('/')[-1]
            return httpx.Response(200, content={'murer-update.json':package.raw,'murer-update.sig':package.signature}[name])
        client = GitHubDownloads('fixture/repo',transport=httpx.MockTransport(handler),public=True)
        release = client.release()
        raw = client.download(client.asset(release,'murer-update.json'),100000)
        signature = client.download(client.asset(release,'murer-update.sig'),4096)
        self.assertEqual(verify_manifest(raw,signature,package.keys)['version'],'9.0.0')
        self.assertEqual(set(seen),{('github.com',None)})
        with self.assertRaisesRegex(UpdateError,'отозван'):
            client.release(release['id']+1)

    def test_private_api_redirect_does_not_leak_token(self):
        seen = []
        def handler(request):
            seen.append((request.url.host, request.headers.get('Authorization')))
            if request.url.host == 'api.github.com':
                return httpx.Response(302, headers={'location': 'https://release-assets.githubusercontent.com/asset'})
            return httpx.Response(200, content=b'package')
        result = GitHubDownloads('fixture/repo', 'fixture-secret', httpx.MockTransport(handler)).download('https://api.github.com/asset', 20)
        self.assertEqual(result, b'package')
        self.assertEqual(seen, [('api.github.com', 'Bearer fixture-secret'), ('release-assets.githubusercontent.com', None)])

    def test_insecure_redirects_network_errors_and_large_responses_are_safe(self):
        for response in (httpx.Response(302, headers={'location':'http://api.github.com/no'}),
                         httpx.Response(302, headers={'location':'https://example.com/no'}),
                         httpx.Response(401, text='secret-body'), httpx.Response(429),
                         httpx.Response(200, content=b'x' * 21), httpx.Response(200, headers={'content-length':'100'}, content=b'x')):
            client = GitHubDownloads('fixture/repo', 'secret-body', httpx.MockTransport(lambda request: response))
            with self.assertRaises(UpdateError) as caught:
                client.download('https://api.github.com/asset', 20)
            self.assertNotIn('secret-body', str(caught.exception))


class ManagerTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name)
        self.package = SignedPackage()
        atomic_json(self.root / 'config' / 'updates.json', {'repository':'fixture/repo', 'public_keys':self.package.keys})
        self.vault = MemoryVault()
        self.store = Store(self.root / 'data')
        self.busy = Mock(return_value='')
        with patch('murer.updates.CODE_ROOT', self.root):
            self.manager = UpdateManager(self.store, self.vault, self.busy, lambda event: None, root=self.root, transport=self.package.transport())

    def tearDown(self):
        self.manager.close()
        self.temporary.cleanup()

    def finish(self):
        self.manager.worker.join(timeout=10)
        self.assertFalse(self.manager.worker.is_alive())

    def prepare(self):
        self.manager.check()
        self.finish()
        self.assertEqual(self.manager.state['phase'], 'available')
        with patch.object(self.manager, '_prepare_runtime'):
            self.manager.download()
            self.finish()
        self.assertEqual(self.manager.state['phase'], 'ready', self.manager.state.get('message'))

    def test_check_prepare_and_install_record_preserve_existing_source(self):
        original = self.root / 'keep.txt'
        original.write_text('original')
        self.prepare()
        with patch.dict(os.environ, MURER_LAUNCHER_SESSION='fixture'):
            result = self.manager.request_install()
        self.assertEqual(result['version'], '9.0.0')
        self.assertEqual(read_json(self.manager.directory / 'pending.json')['session'], 'fixture')
        self.assertEqual(original.read_text(), 'original')

    def test_busy_jobs_developer_checkouts_and_unmanaged_start_block_install(self):
        self.prepare()
        with patch.dict(os.environ, {}, clear=True), self.assertRaises(UpdateError):
            self.manager.request_install()
        with patch.dict(os.environ, MURER_LAUNCHER_SESSION='fixture'):
            self.busy.return_value = 'fixture-active-trade'
            with self.assertRaisesRegex(UpdateError, 'fixture-active-trade'):
                self.manager.request_install()
            self.busy.return_value = ''
            (self.root / '.git').mkdir()
            with self.assertRaises(UpdateError):
                self.manager.request_install()
        self.assertFalse((self.manager.directory / 'pending.json').exists())

    def test_dependency_failure_and_disk_full_leave_working_version(self):
        self.manager.check(); self.finish()
        with patch.object(self.manager, '_prepare_runtime', side_effect=UpdateError('fixture-pip-failure')):
            self.manager.download(); self.finish()
        self.assertEqual(self.manager.state['phase'], 'error')
        self.assertFalse((self.manager.directory / 'active.json').exists())
        with patch('murer.updates.atomic_json', side_effect=OSError('disk full')):
            self.manager._run(lambda: self.manager._set(phase='checking'))
        self.assertEqual(self.manager.status()['phase'], 'error')

    def test_token_only_in_vault_never_status_or_configuration(self):
        self.manager.configure({'token':'fixture-secret-token'})
        self.assertEqual(self.vault.get_password(VAULT_SERVICE,'github:fixture/repo'), 'fixture-secret-token')
        self.assertNotIn('fixture-secret-token', json.dumps(self.manager.status()))
        self.assertFalse((self.manager.directory / 'preferences.json').exists())
        self.manager.configure({'clear_token':True})
        self.assertFalse(self.manager.status()['has_token'])
        for body in ({'token':'line\nbreak'}, {'auto_check':'yes'}, {'unknown':True}):
            with self.assertRaises(UpdateError):
                self.manager.configure(body)

    def test_retracted_release_cannot_be_installed(self):
        self.prepare()
        self.manager.transport = httpx.MockTransport(lambda request: httpx.Response(404))
        with patch.dict(os.environ, MURER_LAUNCHER_SESSION='fixture'), self.assertRaises(UpdateError):
            self.manager.request_install()
        self.assertFalse((self.manager.directory / 'pending.json').exists())

    def test_rollback_refuses_database_schema_downgrade(self):
        old = self.manager.directory / 'releases' / 'old'
        (old / 'murer' / 'migrations').mkdir(parents=True)
        (old / 'murer' / 'migrations' / '001_initial.sql').write_text('')
        atomic_json(self.manager.directory / 'active.json', {'previous': {'slot':str(old.relative_to(self.root)), 'version':'1.0.0'}})
        with patch.dict(os.environ, MURER_LAUNCHER_SESSION='fixture'), self.assertRaisesRegex(UpdateError, 'схему базы'):
            self.manager.request_install(rollback=True)


class SupervisorTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name)
        (self.root / 'VERSION').write_text('1.0.0')
        self.supervisor = Supervisor(self.root, self.root / 'global-data')
        self.store = Store(self.root / 'data')
        self.store.execute("INSERT INTO application_meta VALUES('fixture','before')")
        atomic_json(self.supervisor.global_data / 'bootstrap.json', {'data_dir':str(self.store.data_dir)})
        slot = self.supervisor.state / 'releases' / 'new'
        slot.mkdir(parents=True)
        (slot / 'VERSION').write_text('9.0.0')
        self.request = {'id':'fixture', 'target':{'slot':str(slot.relative_to(self.root)), 'version':'9.0.0'}, 'database':str(self.store.path)}
        self.child = Mock()
        self.child.poll.return_value = None

    def tearDown(self):
        self.temporary.cleanup()

    def test_success_commits_pointer_only_after_health_check_and_keeps_backup(self):
        def ready(*args):
            self.assertFalse((self.supervisor.state / 'active.json').exists())
            self.assertTrue((self.supervisor.state / 'backups' / 'fixture' / 'murer.sqlite3').is_file())
            return True
        with patch.object(self.supervisor, 'launch', return_value=self.child), patch.object(self.supervisor, 'wait_ready', side_effect=ready):
            self.assertIs(self.supervisor.activate(self.request, ['--no-open']), self.child)
        active = self.supervisor.active()
        self.assertEqual(active['version'], '9.0.0')
        self.assertEqual(active['previous']['version'], '1.0.0')
        self.assertEqual(read_json(self.supervisor.state / 'transaction.json')['phase'], 'committed')

    def test_failed_start_rolls_back_database_migrations_and_code(self):
        def fail(*args):
            self.store.execute("UPDATE application_meta SET value='changed'")
            self.store.execute('CREATE TABLE fixture_new_schema(x)')
            return False
        old_process = Mock()
        with patch.object(self.supervisor, 'launch', side_effect=[self.child, old_process]), patch.object(self.supervisor, 'wait_ready', side_effect=fail):
            self.assertIs(self.supervisor.activate(self.request, []), old_process)
        self.child.terminate.assert_called_once()
        self.assertEqual(self.supervisor.active()['version'], '1.0.0')
        self.assertEqual(self.store.rows("SELECT value FROM application_meta WHERE key='fixture'")[0]['value'], 'before')
        self.assertFalse(self.store.rows("SELECT name FROM sqlite_master WHERE name='fixture_new_schema'"))
        self.assertFalse(read_json(self.supervisor.state / 'result.json')['success'])

    def test_power_loss_after_pointer_switch_restores_consistent_pair(self):
        transaction = {**self.request, 'before':self.supervisor.active(), 'phase':'snapshot', 'nonce':'fixture'}
        self.supervisor.write_transaction(transaction)
        self.supervisor.snapshot(transaction)
        atomic_json(self.supervisor.state / 'active.json', self.request['target'])
        self.supervisor.write_transaction(transaction, phase='trial')
        self.store.execute("UPDATE application_meta SET value='migrated'")
        self.supervisor.recover()
        self.assertEqual(self.supervisor.active()['version'], '1.0.0')
        self.assertEqual(self.store.rows("SELECT value FROM application_meta WHERE key='fixture'")[0]['value'], 'before')
        self.assertEqual(read_json(self.supervisor.state / 'transaction.json')['phase'], 'rolled_back')

    def test_missing_backup_never_replaces_current_database(self):
        transaction = {**self.request, 'before':self.supervisor.active(), 'backup':'.murer-updates/backups/missing'}
        with self.assertRaises(RuntimeError):
            self.supervisor.restore(transaction)
        self.assertEqual(self.store.rows("SELECT value FROM application_meta WHERE key='fixture'")[0]['value'], 'before')

    def test_target_outside_release_directory_is_rejected(self):
        for slot in ('../outside', 'data', '.murer-updates/backups'):
            with self.subTest(slot=slot), self.assertRaises(RuntimeError):
                self.supervisor.slot(slot)

    def test_changed_target_cancels_before_any_backup_or_database_change(self):
        self.request['target']['version']='9.0.1'
        with self.assertRaises(RuntimeError):
            self.supervisor.activate(self.request,[])
        self.assertEqual(read_json(self.supervisor.state/'transaction.json')['phase'],'cancelled')
        self.assertFalse((self.supervisor.state/'backups').exists())

    def test_port_preservation_in_supervisor_and_restart(self):
        self.assertEqual(self.supervisor.port(['--port','8767','--no-open']),8767)
        self.assertEqual(self.supervisor.port(['--port=8768']),8768)
        self.assertEqual(self.supervisor.port([]),8765)


class ReleaseBuildTests(unittest.TestCase):
    def test_rebuilding_same_git_snapshot_produces_identical_signed_package(self):
        import subprocess
        from cryptography.hazmat.primitives.serialization import PrivateFormat, NoEncryption
        package=SignedPackage()
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory)/'source'; root.mkdir()
            for name,content in package.files.items():
                path=root/name; path.parent.mkdir(parents=True,exist_ok=True); path.write_bytes(content)
            atomic_json(root/'config'/'updates.json',{'repository':'fixture/repo','public_keys':package.keys})
            subprocess.run(['git','init','-q'],cwd=root,check=True)
            subprocess.run(['git','add','--','.'],cwd=root,check=True,capture_output=True)
            key=base64.b64encode(package.key.private_bytes(Encoding.Raw,PrivateFormat.Raw,NoEncryption())).decode()
            first=build(root,Path(directory)/'first',key)
            for path in root.rglob('*.py'):
                os.utime(path,(1234567890,1234567890))
            second=build(root,Path(directory)/'second',key)
            self.assertEqual(first,second)
            self.assertEqual((Path(directory)/'first'/'murer-update.sig').read_bytes(),(Path(directory)/'second'/'murer-update.sig').read_bytes())


class UpdateApiTests(unittest.TestCase):
    def test_install_response_sets_write_gate_before_any_other_action(self):
        with tempfile.TemporaryDirectory() as directory, patch.dict(os.environ, {'MURER_INSTALL_ROOT':directory}):
            app=create_app(Path(directory)/'data',SecretStore(MemoryVault()))
            state=app.state.application
            state.shutdown_callback=Mock()
            with TestClient(app) as client, patch.object(state.updates,'request_install',return_value={'status':'installing','version':'9.0.0'}):
                self.assertEqual(client.post('/api/updates/install').status_code,200)
                self.assertTrue(state.installing)
                self.assertEqual(client.post('/api/accounts',json={'username':'fixture'}).status_code,503)

    def test_health_status_token_redaction_and_trial_write_gate(self):
        with tempfile.TemporaryDirectory() as directory, patch.dict(os.environ, {'MURER_INSTALL_ROOT':directory}):
            app = create_app(Path(directory) / 'data', SecretStore(MemoryVault()))
            with TestClient(app) as client:
                self.assertEqual(client.get('/api/health').json()['version'], __version__)
                self.assertEqual(client.get('/api/updates').status_code, 200)
                response = client.put('/api/updates/settings', json={'token':'fixture-very-private'})
                self.assertEqual(response.status_code, 200)
                self.assertNotIn('fixture-very-private', response.text)
                self.assertEqual(client.post('/api/updates/install').status_code, 409)
                with patch.dict(os.environ, MURER_UPDATE_NONCE='trial'):
                    atomic_json(Path(directory) / '.murer-updates' / 'transaction.json', {'nonce':'trial','phase':'trial'})
                    blocked = client.post('/api/accounts', json={'username':'fixture'})
                    self.assertEqual(blocked.status_code, 503)
                    self.assertEqual(client.get('/api/health').status_code, 200)
                    atomic_json(Path(directory) / '.murer-updates' / 'transaction.json', {'nonce':'trial','phase':'committed'})
                    self.assertEqual(client.post('/api/accounts', json={'username':'fixture'}).status_code, 200)


if __name__ == '__main__':
    unittest.main()
