"""Headless journal UX check with isolated synthetic data and no X access."""
import json
import os
from pathlib import Path
import socket
import sys
import tempfile
import threading
import time
import traceback

import uvicorn
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.keys import Keys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT)); sys.path.insert(0, str(ROOT / 'tests'))
from murer.api import create_app
from murer.secrets import SecretStore
from test_storage_api import MemoryVault


def main():
    report = {'synthetic_data': True, 'real_x_access': False, 'checks': [], 'passed': False}
    browser = None; server = None; thread = None
    try:
        with tempfile.TemporaryDirectory(prefix='murer_logs_ui_', ignore_cleanup_errors=True) as temporary:
            app = create_app(Path(temporary) / 'data', SecretStore(MemoryVault()))
            state = app.state.application
            state.configuration['configured'] = True
            state.updates.start_auto_check = lambda: None
            state.events.protect(['fixture-private-password'])
            for i in range(245):
                state.events.emit('collection', 'result' if i % 2 else 'status',
                    f'Fixture journal event {i}', level='error' if i % 5 == 0 else 'info',
                    details={'index': i, 'reason': 'fixture-private-password'})
            with socket.socket() as probe:
                probe.bind(('127.0.0.1', 0)); port = probe.getsockname()[1]
            server = uvicorn.Server(uvicorn.Config(app, host='127.0.0.1', port=port, log_level='error', access_log=False))
            thread = threading.Thread(target=server.run, daemon=True); thread.start()
            deadline = time.monotonic()+15
            while not server.started and time.monotonic() < deadline: time.sleep(.05)
            assert server.started
            runtime = Path(os.environ['LOCALAPPDATA']) / 'MurerGroupStats' / 'browser-test'
            options = webdriver.ChromeOptions()
            options.binary_location = str(runtime / 'chrome-win64' / 'chrome.exe')
            options.add_argument('--headless=new'); options.add_argument('--no-first-run')
            options.add_argument('--window-size=1440,1100'); options.add_argument('--user-data-dir='+str(Path(temporary)/'browser'))
            options.set_capability('goog:loggingPrefs', {'browser':'ALL'})
            browser = webdriver.Chrome(service=Service(str(runtime/'chromedriver-win64'/'chromedriver.exe')), options=options)
            wait = WebDriverWait(browser, 20)
            def button(title, starts=False):
                expression = f'//button[starts-with(normalize-space(.),"{title}")]' if starts else f'//button[normalize-space(.)="{title}"]'
                return browser.find_element(By.XPATH, expression)
            def events():
                return browser.find_elements(By.CSS_SELECTOR, '[data-log-id]')
            def click(title, starts=False):
                wait.until(lambda d: button(title, starts).is_enabled())
                button(title, starts).click()
            def switch_tab(title):
                target = browser.find_element(By.XPATH, f'//*[@role="tab" and normalize-space(.)="{title}"]')
                browser.execute_script('arguments[0].scrollIntoView({block:"center",inline:"center"})', target)
                target.click()
            browser.get(f'http://127.0.0.1:{port}')
            wait.until(lambda d: d.find_element(By.XPATH, '//aside//button[normalize-space(.)="Логи"]')).click()
            wait.until(lambda d: len(events()) == 100)
            assert len(browser.find_elements(By.CSS_SELECTOR, '[data-testid="activity-logs"] [role="tab"]')) == 9
            report['checks'].append('log_page_domain_tabs_and_bounded_page_visible')
            button('Типы событий:', starts=True).click()
            browser.find_element(By.XPATH, '//*[@role="menuitem" and normalize-space(.)="Снять все"]').click()
            for label in ('Состояния','Результаты'):
                browser.find_element(By.XPATH, f'//*[@role="menuitemcheckbox" and normalize-space(.)="{label}"]').click()
            browser.switch_to.active_element.send_keys(Keys.ESCAPE)
            wait.until(lambda d: len(events()) == 100 and '2/18' in button('Типы событий:', starts=True).text)
            assert 'fixture-private-password' not in browser.page_source
            report['checks'].append('multiple_types_selected_and_secrets_hidden')
            state.events.emit('collection','result','Fixture live event')
            wait.until(lambda d: 'Fixture live event' in d.find_element(By.CSS_SELECTOR,'[data-testid="activity-logs"]').text)
            report['checks'].append('new_events_arrive_automatically')
            search = browser.find_element(By.CSS_SELECTOR, 'input[aria-label="Поиск по журналу"]')
            search.send_keys('Fixture journal')
            wait.until(lambda d: len(events()) == 100 and all('Fixture journal' in el.text for el in events()))
            first_ids = [el.get_attribute('data-log-id') for el in events()]
            click('Старее', starts=True)
            wait.until(lambda d: len(events()) == 100 and events()[0].get_attribute('data-log-id') not in first_ids)
            assert browser.find_element(By.ID, 'logs-live').get_attribute('aria-checked') == 'false'
            second_ids = [el.get_attribute('data-log-id') for el in events()]
            assert not set(first_ids) & set(second_ids)
            state.events.emit('collection','result','Fixture journal future event')
            click('Обновить')
            wait.until(lambda d: events()[0].get_attribute('data-log-id') == second_ids[0])
            click('Новее', starts=True)
            wait.until(lambda d: events()[0].get_attribute('data-log-id') == first_ids[0])
            report['checks'].append('stable_pagination_and_paused_view_while_recording_continues')
            button('Сбросить фильтры').click()
            switch_tab('Ошибки и предупреждения')
            wait.until(lambda d: len(events()) == 49 and all('Ошибки' in el.text for el in events()))
            report['checks'].append('problems_tab_filters_errors_across_domains')
            switch_tab('Сбор')
            button('Уровни:', starts=True).click()
            browser.find_element(By.XPATH, '//*[@role="menuitem" and normalize-space(.)="Снять все"]').click()
            browser.find_element(By.XPATH, '//*[@role="menuitemcheckbox" and normalize-space(.)="Информация"]').click()
            browser.switch_to.active_element.send_keys(Keys.ESCAPE)
            wait.until(lambda d: len(events()) == 100 and all('Информация' in el.text for el in events()))
            browser.refresh()
            wait.until(lambda d: d.find_element(By.XPATH, '//aside//button[normalize-space(.)="Логи"]')).click()
            wait.until(lambda d: button('Уровни:', starts=True).text.find('1/4') >= 0)
            report['checks'].append('multiple_filters_combine_and_preferences_survive_reload')
            browser.find_element(By.CSS_SELECTOR, '[data-log-id] summary').click()
            assert '[скрыто]' in browser.find_element(By.CSS_SELECTOR, '[data-log-id] pre').text
            browser.save_screenshot(str(ROOT/'artifacts'/'logs-desktop.png'))
            browser.set_window_size(390,1000)
            browser.execute_cdp_cmd('Emulation.setDeviceMetricsOverride', {'width':390,'height':1000,'deviceScaleFactor':1,'mobile':True})
            assert browser.execute_script('return document.documentElement.scrollWidth <= innerWidth+1')
            browser.save_screenshot(str(ROOT/'artifacts'/'logs-mobile.png'))
            report['checks'].append('desktop_and_mobile_layout_fit_viewport')
            errors = [entry for entry in browser.get_log('browser') if entry['level']=='SEVERE' and '404' not in entry['message']]
            assert not errors, errors
            report['checks'].append('no_browser_runtime_errors')
            browser.quit(); browser=None
            server.should_exit=True; thread.join(15)
            report['passed']=True
    except Exception as error:
        report['error']=str(error)
        report['traceback']=traceback.format_exc()
        if browser: browser.save_screenshot(str(ROOT/'artifacts'/'logs-failure.png'))
    finally:
        if browser: browser.quit()
        if server: server.should_exit=True
        if thread: thread.join(15)
    (ROOT/'artifacts'/'logs-ui-smoke.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(report,ensure_ascii=True,indent=2))
    return 0 if report['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
