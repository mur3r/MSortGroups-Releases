"""Explicit synthetic fixtures: these tests do not assert access to a real X page."""
import unittest
from copy import deepcopy
from datetime import datetime, timedelta, timezone

from murer.analytics import analyze, compare_pair
from murer.parsing import classify_card, normalize_username, parse_count
from murer.rules import default_settings, validate_settings

NOW = datetime(2026, 10, 15, 12, tzinfo=timezone.utc)


def date(days=0):
    return (NOW - timedelta(days=days)).isoformat()


def post(pid, kind="own", days=1, pinned=False, **values):
    result = {"id": str(pid), "url": f"https://x.com/person/status/{pid}", "type": kind,
              "event_at": date(days) if days is not None else None, "original_at": date(10),
              "pinned": pinned, "classification_method": "fixture_explicit_event"}
    result.update(values)
    return result


def profile(pid, username=None, posts=None, followers=5000, total=10000, complete=True, **observation_values):
    observation = {"observed_at": date(), "source_account_id": "a", "status": "full" if complete else "partial",
                   "followers": {"raw": str(followers) if followers is not None else None, "value": followers, "approximate": False},
                   "posts_total": {"raw": str(total) if total is not None else None, "value": total, "approximate": False},
                   "requested_n": 100, "requested_days": 30, "viewed_count": len(posts or []),
                   "period_complete": complete, "chronology_confirmed": complete, "posts": posts or []}
    observation.update(observation_values)
    return {"id": pid, "username": username or f"user_{pid}", "name": "Display name is not identity",
            "url": f"https://x.com/user_{pid}", "observations": [observation]}


def group(gid, members, account_ids=None, complete=True, **values):
    result = {"id": gid, "x_id": gid, "name": gid, "url": f"https://x.com/i/chat/{gid}",
              "declared_count": len(members), "membership_status": "full" if complete else "partial",
              "observed_at": date(), "account_ids": account_ids or ["a"], "participant_ids": members}
    result.update(values)
    return result


def dataset(groups=None, participants=None, accounts=None):
    return {"accounts": accounts if accounts is not None else [{"id": "a", "username": "owner", "is_ours": True}],
            "groups": groups or [], "participants": participants or []}


class RulesTests(unittest.TestCase):
    def test_defaults_are_independent_and_partial_updates_merge(self):
        settings = default_settings()
        settings["evaluation"]["weights"]["U"] = 0
        self.assertEqual(default_settings()["evaluation"]["weights"]["U"], 30)
        result = validate_settings({"evaluation": {"followers_low": 200}})
        self.assertEqual(result["evaluation"]["followers_high"], 5000)
        self.assertEqual(result["evaluation"]["followers_low"], 200)

    def test_weights_allow_zero_but_not_all_zero(self):
        values = {"U": 100, "F": 0, "P": 0, "R": 0, "A": 0}
        self.assertEqual(validate_settings({"evaluation": {"weights": values}})["evaluation"]["weights"], values)
        with self.assertRaises(ValueError):
            validate_settings({"evaluation": {"weights": dict.fromkeys("UFPRA", 0)}})

    def test_invalid_ranges_and_intermediate_empty_input(self):
        bad = [
            {"evaluation": {"followers_low": 5000, "followers_high": 5000}},
            {"evaluation": {"medium_score": 70, "good_score": 40}},
            {"evaluation": {"min_coverage": 101}},
            {"collection": {"posts_limit": ""}},
            {"collection": {"posts_limit": 1.5}},
            {"collection": {"concurrent_accounts": 0}},
            {"humanization": {"typing_delay_min": 2, "typing_delay_max": 1}},
            {"humanization": {"enabled": "false"}},
            {"evaluation": {"reposts_min": float("nan")}},
            {"collection": {"login_typing_delay_min": 0.2, "login_typing_delay_max": 0.1}},
            {"collection": {"login_poll_rounds": 0}},
            {"collection": {"page_load_timeout_seconds": 0}},
            {"collection": {"scroll_step_pixels": 0}},
            {"collection": {"login_button_timeout_seconds": -1}},
            {"evaluation": {"overlap_pair_limit": 0}},
            {"collection": {"profiles_limit": -1}},
        ]
        for settings in bad:
            with self.subTest(settings=settings), self.assertRaises(ValueError):
                validate_settings(settings)

    def test_per_group_own_rules_validated(self):
        settings = {"own_accounts": {"group_rules": {"g": {"allowance": 0, "pinned_account_ids": ["a"], "exempt_account_ids": ["b"]}}}}
        self.assertEqual(validate_settings(settings)["own_accounts"]["group_rules"]["g"]["allowance"], 0)
        with self.assertRaises(ValueError):
            validate_settings({"own_accounts": {"group_rules": {"g": {"allowance": -1}}}})

    def test_profile_limit_zero_is_unlimited_and_finite_limits_are_integer(self):
        self.assertEqual(default_settings()['collection']['profiles_limit'], 0)
        self.assertEqual(validate_settings({'collection': {'profiles_limit': 5}})['collection']['profiles_limit'], 5)
        with self.assertRaises(ValueError):
            validate_settings({'collection': {'profiles_limit': 1.5}})


class ParsingTests(unittest.TestCase):
    def test_localized_and_shortened_counts_retain_approximation(self):
        cases = [("56.1K posts", 56100, True), ("1,2 тыс. подписчиков", 1200, True),
                 ("2,5 млн", 2500000, True), ("3 тис.", 3000, True),
                 ("1 234 followers", 1234, False), ("12,345", 12345, False),
                 ("12.345", 12345, False), ("1\u202f234", 1234, False),
                 ("≈ 100", 100, True), ("0 posts", 0, False), ("١٬٢٣٤", 1234, False)]
        cases.extend([("12 members", 12, False), ("34 bookmarks", 34, False), ("5 подписчиков", 5, False)])
        cases.extend([("2,5 К подписчиков", 2500, True), ("1.2 М", 1200000, True), ("12 материалов", 12, False)])
        for raw, expected, approximate in cases:
            with self.subTest(raw=raw):
                parsed = parse_count(raw)
                self.assertEqual(parsed, {"raw": raw, "value": expected, "approximate": approximate})

    def test_missing_or_unqualified_decimal_is_unknown(self):
        for value in (None, "—", "недоступно", "12.5", "-5", "−5", "–5"):
            with self.subTest(value=value):
                self.assertIsNone(parse_count(value)["value"])

    def test_handle_normalization(self):
        self.assertEqual(normalize_username(" @MuReR "), "murer")
        self.assertEqual(normalize_username("https://x.com/MuReR/status/1"), "murer")

    def test_card_types_and_unknown_repost_date(self):
        self.assertEqual(classify_card({"author": "Actor", "original_at": date(1)}, "@actor")["type"], "own")
        card = {"author": "SomeoneElse", "social_context": "Actor reposted", "original_at": date(1), "event_at": date(1), "quote": True}
        result = classify_card(card, "Actor")
        self.assertEqual(result["type"], "repost")
        self.assertIsNone(result["event_at"])
        self.assertEqual(result["original_at"], date(1))
        self.assertEqual(classify_card({"author": "actor", "quote": True}, "actor")["type"], "quote")
        self.assertEqual(classify_card({"author": "actor", "reply": True}, "actor")["type"], "reply")
        self.assertEqual(classify_card({"author": "other", "original_at": date()}, "actor")["type"], "unknown")
        self.assertEqual(classify_card({"author": "actor", "pinned": True}, "actor")["type"], "own")
        self.assertEqual(card["event_at"], date(1), "Parsing must not mutate raw observation")


class AnalyticsTests(unittest.TestCase):
    def setUp(self):
        self.settings = default_settings()

    def test_requested_volume_is_not_the_recorded_volume(self):
        p = profile('p', posts=[post('one')], complete=False, requested_n=100, viewed_count=1)
        row = analyze(dataset([group('g', ['p'])], [p]), self.settings, now=NOW)['participants'][0]
        self.assertTrue(row['needs_collection'])
        self.assertTrue(any('Сохранено 1 уникальных' in reason for reason in row['coverage_reasons']))

    def test_sufficient_saved_sample_survives_newer_short_partial_attempt(self):
        p = profile('p', posts=[post(str(i)) for i in range(100)], complete=False)
        p['observations'][0]['observed_at'] = (NOW-timedelta(minutes=5)).isoformat()
        p['observations'].insert(0, profile('p', posts=[post('new')], complete=False)['observations'][0])
        row = analyze(dataset([group('g', ['p'])], [p]), self.settings, now=NOW)['participants'][0]
        self.assertEqual(row['observed_post_count'], 100)
        self.assertEqual(row['checked_at'], p['observations'][1]['observed_at'])

    def run_analysis(self, data, settings=None, **scope):
        return analyze(data, settings or self.settings, now=NOW, **scope)

    def test_observed_uniqueness_overlap_and_redundant_memberships(self):
        data = dataset([group("A", ["p1", "p2"]), group("B", ["p2", "p3"]), group("C", ["p2"])],
                       [profile(pid) for pid in ("p1", "p2", "p3")])
        result = self.run_analysis(data)
        summary = result["summary"]
        self.assertEqual(summary["memberships"], 5)
        self.assertEqual(summary["unique_audience"], 3)
        self.assertEqual(summary["redundant_memberships"], 2)
        self.assertEqual(summary["repeated_people"], 1)
        a = result["groups"][0]
        self.assertEqual(a["exclusive_count"], 1)
        self.assertEqual(a["exclusivity"], 50)
        ab = next(p for p in result["overlaps"] if p["group_a_id"] == "A" and p["group_b_id"] == "B")
        self.assertEqual(ab["common_count"], 1)
        self.assertEqual(ab["percent_a"], 50)
        self.assertAlmostEqual(ab["jaccard"], 1/3)

    def test_same_group_across_accounts_deduplicates_and_links_survive(self):
        data = dataset([group("g1", ["p"], ["a"], x_id="stable"),
                        group("g2", ["p"], ["b"], x_id="stable")], [profile("p")],
                       [{"id": "a", "username": "owner"}, {"id": "b", "username": "other_owner"}])
        result = self.run_analysis(data)
        self.assertEqual(result["summary"]["group_count"], 1)
        self.assertEqual(result["summary"]["memberships"], 1)
        self.assertEqual(set(result["groups"][0]["account_ids"]), {"a", "b"})
        self.assertEqual(result["account_overlaps"][0]["shared_group_count"], 1)

    def test_same_stable_person_deduplicates_without_display_name_merges(self):
        p1, p2, p3 = profile("p1"), profile("p2"), profile("p3")
        p1["x_id"], p2["x_id"] = "123", "123"
        data = dataset([group("a", ["p1"]), group("b", ["p2", "p3"])], [p1, p2, p3])
        result = self.run_analysis(data)
        self.assertEqual(result["summary"]["unique_audience"], 2)
        p = next(p for p in result["participants"] if p["id"] == "p1")
        self.assertEqual(p["group_count"], 2)

    def test_ours_excluded_even_failed_login_and_archived_history(self):
        accounts = [{"id": "a", "username": "owner", "status": "error", "is_ours": True},
                    {"id": "b", "username": "archived", "archived": True, "is_ours": True}]
        data = dataset([group("g1", ["ours", "archived", "external"]), group("g2", ["ours", "external"], ["b"])],
                       [profile("ours", "OWNER"), profile("archived", "ARCHIVED"), profile("external")], accounts)
        result = self.run_analysis(data)
        self.assertEqual(result["summary"]["unique_audience"], 1)
        self.assertEqual(result["summary"]["own_participant_count"], 2)
        self.assertEqual(result["groups"][0]["own_count"], 2)
        scoped = self.run_analysis(data, account_ids=["a"])
        self.assertEqual(scoped["summary"]["unique_audience"], 1)
        self.assertEqual(scoped["groups"][0]["exclusivity"], 100)
        self.assertEqual(scoped["groups"][0]["exclusivity_global"], 0)

    def test_archived_account_can_be_unmarked_as_ours(self):
        data = dataset([group("g", ["p"])], [profile("p", "archived")],
                       [{"id": "a", "username": "archived", "archived": True, "is_ours": False}])
        self.assertEqual(self.run_analysis(data)["summary"]["unique_audience"], 1)

    def test_stable_id_outranks_username_and_renames_preserve_identity(self):
        p = profile("p", "renamed")
        p["x_id"] = "123"
        foreign = profile("foreign", "owner")
        foreign["x_id"] = "456"
        data = dataset([group("g", ["p", "foreign"])], [p, foreign],
                       [{"id": "a", "username": "owner", "x_id": "123"}])
        result = self.run_analysis(data)
        self.assertEqual(result["summary"]["unique_audience"], 1)
        person = next(p for p in result["participants"] if p["id"] == "p")
        self.assertTrue(person["is_ours"])
        self.assertEqual(person["identity_provenance"], "stable_id")

    def test_ambiguous_username_is_not_silently_ours(self):
        p1, p2 = profile("p1", "same"), profile("p2", "same")
        p1["x_id"], p2["x_id"] = "111", "222"
        data = dataset([group("g", ["p1", "p2"])], [p1, p2], [{"id": "a", "username": "same"}])
        result = self.run_analysis(data)
        self.assertEqual(result["summary"]["unique_audience"], 2)
        self.assertTrue(result["summary"]["identity_warnings"])

    def test_comparison_group_selection_is_explicit(self):
        data = dataset([group("a", ["p"]), group("b", ["p"])], [profile("p")])
        result = self.run_analysis(data, group_ids=["a"])
        self.assertEqual(result["groups"][0]["exclusivity"], 100)
        self.assertEqual(result["groups"][0]["exclusivity_global"], 0)
        self.assertEqual(result["summary"]["scope"]["group_ids"], ["a"])

    def test_empty_sets_are_safe_and_percentages_unknown(self):
        data = dataset([group("g", [])])
        result = self.run_analysis(data)
        row = result["groups"][0]
        self.assertIsNone(row["exclusivity"])
        self.assertIsNone(row["score"])
        self.assertEqual(row["category"], "Недостаточно данных")
        self.assertIsNone(result["summary"]["profile_coverage"])
        self.assertEqual(result["overlaps"], [])

    def test_absent_values_are_not_zero_and_weights_renormalize(self):
        data = dataset([group("g", ["p"])], [profile("p", followers=None, total=None)])
        result = self.run_analysis(data)
        p, g = result["participants"][0], result["groups"][0]
        self.assertIsNone(p["followers"]["value"])
        self.assertIsNone(g["followers_median"])
        self.assertTrue(g["weights_renormalized"])
        self.assertIsNone(g["components"]["F"]["value"])
        self.assertAlmostEqual(sum(c["normalized_weight"] for c in g["components"].values()), 1)
        self.assertEqual(g["category"], "Недостаточно данных")

    def test_full_good_score_uses_median_and_exact_contributions(self):
        posts = [post(str(i), "repost", 1) for i in range(5)]
        data = dataset([group("g", ["p1", "p2", "p3"])],
                       [profile("p1", posts=posts), profile("p2", posts=posts), profile("p3", posts=posts, followers=10**9)])
        result = self.run_analysis(data)
        g = result["groups"][0]
        self.assertEqual(g["followers_median"], 5000)
        self.assertGreater(g["followers_mean"], 5000)
        self.assertEqual(g["score"], 100)
        self.assertEqual(g["category"], "Хорошая")
        self.assertEqual(sum(c["contribution"] or 0 for c in g["components"].values()), 100)

    def test_aggregate_metric_approximation_survives_observed_rounded_inputs(self):
        person = profile('rounded')
        person['observations'][0]['followers']['approximate'] = True
        person['observations'][0]['posts_total']['approximate'] = True
        data = dataset([group('g', ['rounded', 'exact'])], [person, profile('exact')])
        row = self.run_analysis(data)['groups'][0]
        self.assertTrue(row['followers_median_approximate'])
        self.assertTrue(row['followers_mean_approximate'])
        self.assertTrue(row['posts_median_approximate'])
        missing = self.run_analysis(dataset([group('g', ['p'])], [profile('p', followers=None, total=None)]))['groups'][0]
        self.assertIsNone(missing['followers_median'])
        self.assertFalse(missing['followers_median_approximate'])
        self.assertFalse(missing['followers_mean_approximate'])
        self.assertFalse(missing['posts_median_approximate'])

    def test_partial_membership_never_gives_confident_category(self):
        data = dataset([group("g", ["p"], complete=False, declared_count=1)],
                       [profile("p", posts=[post(str(i), "repost") for i in range(5)])])
        result = self.run_analysis(data)
        g = result["groups"][0]
        self.assertEqual(g["category"], "Предварительная оценка")
        self.assertTrue(result["summary"]["preliminary"])
        self.assertTrue(g["components"]["U"]["reason"])

    def test_declared_count_discrepancy_downgrades_complete_flag(self):
        data = dataset([group("g", ["p"], declared_count=10)], [profile("p")])
        result = self.run_analysis(data)
        self.assertEqual(result["summary"]["complete_groups"], 0)
        self.assertEqual(result["groups"][0]["membership_coverage"], 10)
        self.assertNotEqual(result["groups"][0]["category"], "Хорошая")

    def test_unknown_member_denominator_remains_unknown_and_never_gives_confident_category(self):
        data = dataset([group('known', ['p']), group('unknown', ['p'], complete=False, declared_count=None)], [profile('p')])
        result = self.run_analysis(data)
        row = next(g for g in result['groups'] if g['id'] == 'unknown')
        self.assertIsNone(row['membership_coverage'])
        self.assertIsNone(row['components']['U']['coverage'])
        self.assertIsNone(result['summary']['membership_coverage'])
        self.assertNotIn(row['category'], ('Хорошая', 'Средняя', 'Плохая'))

    def test_incomplete_low_reposts_are_unknown_but_threshold_is_positive_evidence(self):
        profiles = [profile("low", posts=[post("1", "repost")], complete=False),
                    profile("high", posts=[post(str(i), "repost") for i in range(5)], complete=False)]
        result = self.run_analysis(dataset([group("g", ["low", "high"])], profiles))
        people = {p["id"]: p for p in result["participants"]}
        self.assertIsNone(people["low"]["reposts_condition"])
        self.assertTrue(people["high"]["reposts_condition"])
        self.assertEqual(result["groups"][0]["components"]["R"]["evaluated"], 1)
        self.assertEqual(result["groups"][0]["components"]["R"]["excluded"], 1)
        self.assertEqual(result["groups"][0]["components"]["R"]["value"], 100)

    def test_unknown_repost_date_not_source_date_or_confirmed_activity(self):
        result = self.run_analysis(dataset([group("g", ["p"])], [profile("p", posts=[post("1", "repost", None, original_at=date())])]))
        p = result["participants"][0]
        self.assertEqual(p["reposts_confirmed"], 0)
        self.assertEqual(p["unknown_date_reposts"], 1)
        self.assertIsNone(p["last_activity"])
        self.assertIsNone(p["activity_condition"])

    def test_pinned_old_post_and_duplicate_card(self):
        old, new = post("old", "own", 300, pinned=True), post("new", "own", 1)
        result = self.run_analysis(dataset([group("g", ["p"])], [profile("p", posts=[old, new, new])]))
        p = result["participants"][0]
        self.assertEqual(p["sample_counts"]["own"], 2)
        self.assertEqual(p["last_activity"], date(1))
        pinned_only = self.run_analysis(dataset([group("g", ["p"])], [profile("p", posts=[old])]))["participants"][0]
        self.assertIsNone(pinned_only["last_activity"])
        self.assertEqual(pinned_only["sample_counts"]["own"], 1, "Raw pinned observation stays available")

    def test_quotes_and_replies_are_separate_and_activity_configured(self):
        data = dataset([group("g", ["p"])], [profile("p", posts=[post("q", "quote"), post("r", "reply")])])
        initial = self.run_analysis(data)["participants"][0]
        self.assertEqual(initial["sample_counts"]["quote"], 1)
        self.assertEqual(initial["sample_counts"]["reply"], 1)
        self.assertIsNone(initial["last_activity"])
        settings = deepcopy(self.settings)
        settings["evaluation"].update(include_quotes=True, include_replies=True)
        changed = self.run_analysis(data, settings)["participants"][0]
        self.assertTrue(changed["activity_condition"])
        self.assertEqual(changed["reposts_confirmed"], 0)
        self.assertEqual(changed["repost_share_denominator"], 2)

    def test_failed_access_preserves_successful_observation_and_context(self):
        p = profile("p", followers=123)
        p["observations"].append({"observed_at": date(-1), "source_account_id": "b", "status": "unavailable", "reason": "Protected"})
        result = self.run_analysis(dataset([group("g", ["p"])], [p]))["participants"][0]
        self.assertEqual(result["followers"]["value"], 123)
        self.assertEqual(result["source_account_id"], "a")
        self.assertEqual(result["access_attempts"][0]["source_account_id"], "b")

    def test_changes_recalculate_without_mutating_observations(self):
        data = dataset([group("g", ["p"])], [profile("p", followers=5000)])
        original = deepcopy(data)
        before = self.run_analysis(data)
        settings = deepcopy(self.settings)
        settings["evaluation"]["followers_high"] = 10000
        after = self.run_analysis(data, settings)
        self.assertGreater(before["groups"][0]["score"], after["groups"][0]["score"])
        self.assertEqual(data, original)

    def test_recent_partial_activity_outranks_old_complete_observation(self):
        p = profile("p", posts=[post("old", "own", 10)])
        p["observations"][0]["observed_at"] = date(2)
        fresh = profile("fresh", posts=[post("new", "own", 0)], complete=False)['observations'][0]
        p['observations'].append(fresh)
        result = self.run_analysis(dataset([group('g', ['p'])], [p]))['participants'][0]
        self.assertEqual(result['last_activity'], date())
        self.assertTrue(result['activity_condition'])
        self.assertIsNone(result['reposts_condition'])

    def test_period_change_recounts_dated_events_locally_and_retains_raw_sample(self):
        data = dataset([group('g', ['p'])], [profile('p', posts=[post('recent', 'own', 1), post('old', 'own', 15), post('unknown', 'repost', None)])])
        before = self.run_analysis(data)['participants'][0]
        settings = deepcopy(self.settings)
        settings['collection']['period_days'] = 7
        after = self.run_analysis(data, settings)['participants'][0]
        self.assertEqual(before['period_counts']['own'], 2)
        self.assertEqual(after['period_counts']['own'], 1)
        self.assertEqual(after['outside_period_count'], 1)
        self.assertEqual(after['unknown_date_count'], 1)
        self.assertEqual(len(after['posts']), 3)

    def test_stale_fallback_metric_downgrades_fresh_timeline(self):
        p = profile('p')
        p['observations'][0]['observed_at'] = date(3)
        fresh = profile('fresh', posts=[post('new')], followers=None, total=None)['observations'][0]
        p['observations'].append(fresh)
        result = self.run_analysis(dataset([group('g', ['p'])], [p]))
        self.assertEqual(result['participants'][0]['status'], 'stale')
        self.assertTrue(result['coverage']['needs_collection'])
        self.assertEqual(result['summary']['observed_from'], date(3))

    def test_larger_n_period_and_staleness_require_collection(self):
        data = dataset([group("g", ["p"])], [profile("p")])
        self.assertFalse(self.run_analysis(data)["coverage"]["needs_collection"])
        for changes in ({"posts_limit": 200}, {"period_days": 60}, {"cache_hours": 0}):
            settings = deepcopy(self.settings)
            settings["collection"].update(changes)
            now = NOW + timedelta(seconds=1) if changes == {"cache_hours": 0} else NOW
            result = analyze(data, settings, now=now)
            self.assertTrue(result["coverage"]["needs_collection"])
            self.assertEqual(result["coverage"]["participant_ids"], ["p"])

    def test_lower_n_trims_locally_without_inventing_negative_period_evidence(self):
        data = dataset([group("g", ["p"])], [profile("p", posts=[post(str(i), "own", i+10) for i in range(10)])])
        settings = deepcopy(self.settings)
        settings["collection"]["posts_limit"] = 1
        result = self.run_analysis(data, settings)["participants"][0]
        self.assertEqual(len(result["posts"]), 1)
        self.assertIsNone(result["reposts_condition"])
        self.assertIsNone(result["activity_condition"])
        self.assertFalse(result["needs_collection"], "Stored data suffices; lower N causes local sample uncertainty")

    def test_strict_missing_policy_and_u_only_zero_weights(self):
        data = dataset([group("g", ["p"])], [profile("p", followers=None)])
        settings = deepcopy(self.settings)
        settings["evaluation"]["missing_policy"] = "strict"
        self.assertIsNone(self.run_analysis(data, settings)["groups"][0]["score"])
        settings["evaluation"]["weights"] = {"U": 100, "F": 0, "P": 0, "R": 0, "A": 0}
        result = self.run_analysis(data, settings)["groups"][0]
        self.assertEqual(result["score"], 100)
        self.assertEqual(result["available_components"], ["U"])

    def test_own_allowance_pinned_exemptions_and_redistribution(self):
        accounts = [{"id": aid, "username": aid, "is_ours": True} for aid in ("a", "b", "c", "d", "e")]
        profiles = [profile(aid, aid) for aid in ("a", "b", "c", "d")] + [profile("p")]
        data = dataset([group("g", ["a", "b", "c", "d", "p"], ["a", "b", "c", "d"], complete=False)], profiles, accounts)
        result = self.run_analysis(data)
        own = result["own_accounts"][0]
        self.assertEqual(own["count"], 4)
        self.assertEqual(own["excess"], 3)
        self.assertEqual(own["count_label"], "найдено не менее 4")
        self.assertEqual(own["redistribution"][0]["new_audience"], 1)
        settings = deepcopy(self.settings)
        settings["own_accounts"]["group_rules"] = {"g": {"allowance": 1, "pinned_account_ids": ["a"], "exempt_account_ids": ["b"]}}
        own = self.run_analysis(data, settings)["own_accounts"][0]
        self.assertEqual(own["excess"], 2)
        candidates = own["recommendations"][0]["details"]["candidates"]
        self.assertEqual(candidates, ["c", "d"])
        settings["own_accounts"]["unlimited"] = True
        self.assertEqual(self.run_analysis(data, settings)["own_accounts"][0]["excess"], 0)

    def test_account_overlap_uses_union_of_unique_groups(self):
        accounts = [{"id": "a", "username": "a"}, {"id": "b", "username": "b"}]
        data = dataset([group("g1", ["p1", "p2"], ["a", "b"]), group("g2", ["p2", "p3"], ["a"])],
                       [profile(pid) for pid in ("p1", "p2", "p3")], accounts)
        pair = self.run_analysis(data)["account_overlaps"][0]
        self.assertEqual(pair["a_count"], 3)
        self.assertEqual(pair["b_count"], 2)
        self.assertEqual(pair["common_count"], 2)
        self.assertEqual(pair["shared_group_count"], 1)
        self.assertAlmostEqual(pair["jaccard"], 2/3)

    def test_direct_pair_includes_disjoint_groups_and_empty_denominators(self):
        data = dataset([group("g1", ["p1"]), group("g2", ["p2"]), group("empty", [])], [profile("p1"), profile("p2")])
        pair = compare_pair(data, self.settings, "group", "g1", "g2", now=NOW)
        self.assertEqual(pair["common_count"], 0)
        self.assertEqual(pair["percent_a"], 0)
        self.assertEqual(pair["jaccard"], 0)
        self.assertEqual((pair["new_for_a"], pair["new_for_b"]), (1, 1))
        empty = compare_pair(data, self.settings, "group", "empty", "empty", now=NOW)
        self.assertIsNone(empty["percent_a"])
        self.assertIsNone(empty["percent_b"])
        self.assertIsNone(empty["jaccard"])
        with self.assertRaisesRegex(ValueError, "области"):
            compare_pair(data, self.settings, "group", "g1", "g2", group_ids=["g1"])

    def test_direct_account_pair_uses_union_our_registry_and_explicit_scope(self):
        accounts = [{"id": "a", "username": "owner"}, {"id": "b", "username": "b"}, {"id": "c", "username": "c"}]
        groups = [group("g1", ["p1", "own"], ["a", "b"]), group("g2", ["p2", "own"], ["a"])]
        data = dataset(groups, [profile("p1"), profile("p2"), profile("own", "owner")], accounts)
        pair = compare_pair(data, self.settings, "accounts", "a", "b", now=NOW)
        self.assertEqual((pair["a_count"], pair["b_count"], pair["common_count"]), (2, 1, 1))
        self.assertEqual(pair["common_group_ids"], ["g1"])
        self.assertEqual(pair["common_group_count"], 1)
        self.assertEqual(pair["percent_a"], 50)
        self.assertEqual(pair["percent_b"], 100)
        scoped = compare_pair(data, self.settings, "account", "a", "b", group_ids=["g1"])
        self.assertEqual(scoped["a_count"], 1)
        no_groups = compare_pair(data, self.settings, "account", "b", "c")
        self.assertEqual(no_groups["common_count"], 0)
        self.assertIsNone(no_groups["percent_b"])

    def test_historical_username_alias_matches_ours_only_without_identity_ambiguity(self):
        person = profile("p", "renamed")
        person.update(x_id="42", aliases=["oldhandle", "renamed"])
        accounts = [{"id": "a", "username": "oldhandle", "is_ours": True}]
        data = dataset([group("g", ["p"])], [person], accounts)
        result = self.run_analysis(data)
        self.assertEqual(result["summary"]["unique_audience"], 0)
        self.assertEqual(result["participants"][0]["identity_provenance"], "historical_username_alias")
        reused = profile("other", "oldhandle")
        reused["x_id"] = "99"
        data["participants"].append(reused)
        data["groups"][0]["participant_ids"].append("other")
        result = self.run_analysis(data)
        self.assertFalse(any(p["is_ours"] for p in result["participants"]))
        self.assertTrue(result["summary"]["identity_warnings"])
        accounts[0]["x_id"] = "42"
        result = self.run_analysis(data)
        self.assertEqual([p["id"] for p in result["participants"] if p["is_ours"]], ["p"])

    def test_global_time_range_and_retained_memberships_are_explicit(self):
        groups = [group("recent", ["p1"], ["a"], membership_observed_from=date(5)),
                  group("historical", ["p2"], ["b"], observed_at=date(20))]
        data = dataset(groups, [profile("p1"), profile("p2")], [{"id": "a", "username": "a"}, {"id": "b", "username": "b"}])
        unlinked = profile('removed', observed_at=date(300))
        data['participants'].append(unlinked)
        summary = self.run_analysis(data, account_ids=["a"])["summary"]
        self.assertEqual(summary["observed_from"], date(5))
        self.assertEqual(summary["global_observed_from"], date(20))

    def test_dense_group_overlap_defers_matrix_but_keeps_exact_main_metrics_and_pair(self):
        groups = [group(f"g{i}", ["p"]) for i in range(120)]
        data = dataset(groups, [profile("p")])
        result = self.run_analysis(data)
        self.assertEqual(result['summary']['unique_audience'], 1)
        self.assertEqual(result['summary']['memberships'], 120)
        self.assertEqual(result['summary']['redundant_memberships'], 119)
        self.assertTrue(result['summary']['group_overlap_matrix_deferred'])
        self.assertEqual(result['summary']['group_overlap_pair_work'], 7140)
        self.assertEqual(result['overlaps'], [])
        self.assertIn('две группы', result['summary']['overlap_matrix_reason'])
        self.assertTrue(all(g['exclusivity'] == 0 for g in result['groups']))
        self.assertFalse(any(r['kind'] == 'overlap' for r in result['recommendations']))
        pair = compare_pair(data, self.settings, 'group', 'g0', 'g119')
        self.assertEqual(pair['common_count'], 1)
        self.assertEqual(pair['percent_a'], 100)
        settings = deepcopy(self.settings)
        settings['evaluation']['overlap_pair_limit'] = 8000
        enabled = self.run_analysis(data, settings)
        self.assertFalse(enabled['summary']['group_overlap_matrix_deferred'])
        self.assertEqual(len(enabled['overlaps']), 7140)

    def test_dense_shared_account_groups_defer_even_with_empty_external_audience(self):
        accounts = [{"id": str(i), "username": f'owner{i}'} for i in range(6)]
        data = dataset([group('shared', [], [a['id'] for a in accounts])], [], accounts)
        settings = deepcopy(self.settings)
        settings['evaluation']['overlap_pair_limit'] = 10
        result = self.run_analysis(data, settings)
        self.assertEqual(result['account_overlaps'], [])
        self.assertTrue(result['summary']['account_overlap_matrix_deferred'])
        self.assertFalse(result['summary']['group_overlap_matrix_deferred'])
        self.assertEqual(result['summary']['shared_group_pair_work'], 15)
        pair = compare_pair(data, settings, 'account', '0', '5')
        self.assertEqual(pair['common_group_count'], 1)
        self.assertEqual(pair['common_count'], 0)
        self.assertIsNone(pair['percent_a'])


if __name__ == "__main__":
    unittest.main()
