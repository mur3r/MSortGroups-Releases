"""Opt-in visible Chrome verification against synthetic local HTML only.

The production probe refuses file://. For DOM-only fixture cases the exact URL
declaration is replaced with a fixed synthetic X URL; the original origin guard
is tested separately first. No request is sent to X and no user data is opened.
"""
import argparse
import asyncio
import json
from pathlib import Path
import sys
import tempfile

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from murer.ichat_unlock import IChatUnlock, ICHAT_UNLOCK_PROBE_JS
from murer.rules import default_settings
from murer.safe_actions import SafeActions
from xgenius.browser import BrowserManager
from xgenius.config import Config
from xgenius.models import AccountCredentials, BrowserConfig
from xgenius.process_utils import hard_close_browser


async def run(chrome, driver):
    cases = []
    with tempfile.TemporaryDirectory(prefix='murer_ichat_fixture_') as directory:
        config = Config(Path(directory))
        config.chrome_path, config.chromedriver_path = Path(chrome), Path(driver)
        manager = BrowserManager(config, BrowserConfig())
        browser = None
        try:
            browser = await manager.create_browser(AccountCredentials('ichat-fixture', '', headless=False))
            fixture = Path(__file__).parent / 'fixtures' / 'ichat-unlock.html'
            browser.get(fixture.resolve().as_uri())
            assert browser.execute_script(ICHAT_UNLOCK_PROBE_JS)['state'] == 'absent'
            cases.append('production_origin_guard')
            synthetic = ICHAT_UNLOCK_PROBE_JS.replace('const pageUrl = new URL(location.href);',
                "const pageUrl = new URL('https://x.com/i/chat');")
            settings = default_settings()
            settings['collection'].update(action_delay_seconds=0, login_poll_rounds=1, login_poll_seconds=0)
            actions = SafeActions(browser, settings)
            real_script = actions.script
            async def fixture_script(script, *args):
                return await real_script(synthetic if script == ICHAT_UNLOCK_PROBE_JS else script, *args)
            actions.script = fixture_script
            assert browser.execute_script(synthetic)['state'] == 'ready'
            assert await IChatUnlock().check(actions, '1234') is None
            assert browser.execute_script('return window.fixtureSent') == ['1234']
            cases.append('shadow_single_password_no_enter')

            async def markup(html):
                browser.execute_script("document.querySelector('[data-testid=\"xchatEmbedRoute\"]').shadowRoot.innerHTML=arguments[0]", html)
                return await actions.script(ICHAT_UNLOCK_PROBE_JS)

            segmented = '<form><h2>Enter your PIN</h2>' + ''.join(
                '<input type="password" inputmode="numeric" maxlength="1" aria-label="PIN digit">' for _ in range(4)) + '</form>'
            assert (await markup(segmented))['state'] == 'ready'
            browser.execute_script("""window.fixtureEntered=[];const root=document.querySelector('[data-testid="xchatEmbedRoute"]').shadowRoot;
root.querySelectorAll('input').forEach(input=>input.addEventListener('input',()=>{
 const fields=Array.from(root.querySelectorAll('input'));if(fields.every(field=>field.value)) {
 window.fixtureEntered=fields.map(field=>field.value);root.innerHTML='<h2>Chats</h2>';
 }}));""")
            assert await IChatUnlock().check(actions, '1234') is None
            assert browser.execute_script('return window.fixtureEntered') == list('1234')
            cases.append('shadow_segmented_pin_autoadvance')

            normal_synthetic = synthetic
            synthetic = ICHAT_UNLOCK_PROBE_JS.replace('const pageUrl = new URL(location.href);',
                "const pageUrl = new URL('https://x.com/i/chat/pin/recovery?from=%2Fi%2Fchat');")
            recovery_form = '<form><h2>Enter Passcode</h2><p>Your passcode is required to recover your encryption keys so we can decrypt your previous messages.</p>' + ''.join(
                '<input type="password" inputmode="numeric" maxlength="1" aria-label="PIN digit">' for _ in range(4)) + '<a>Forgot passcode</a></form>'
            assert (await markup(recovery_form))['state'] == 'ready'
            browser.execute_script("""window.fixtureRecovery=[];const root=document.querySelector('[data-testid="xchatEmbedRoute"]').shadowRoot;
root.querySelectorAll('input').forEach(input=>input.addEventListener('input',()=>{
 const fields=Array.from(root.querySelectorAll('input'));if(fields.every(field=>field.value)) {
 window.fixtureRecovery=fields.map(field=>field.value);root.innerHTML='<h2>Chats</h2>';
 }}));""")
            assert await IChatUnlock().check(actions, '1234') is None
            assert browser.execute_script('return window.fixtureRecovery') == list('1234')
            cases.append('existing_passcode_on_key_recovery_route')
            for title in ('Create your PIN', 'Reset passcode', 'Recover your PIN', 'Enter verification code'):
                assert (await markup('<form><h2>' + title + '</h2><input type="password"><button>Continue</button></form>'))['state'] == 'manual'
            cases.append('key_recovery_route_still_rejects_reset_and_verification')
            # Live X DOM observed 2026-10-16: no form or semantic heading;
            # pin-title is a DIV and all four inputs are text/numeric.
            live_shape = '<div data-testid="pin-title">Enter Passcode</div><p>Your passcode is required to recover your encryption keys so we can decrypt your previous messages.</p><div role="group" data-testid="pin-code-input-container">' + ''.join(
                '<div><input type="text" inputmode="numeric" maxlength="1" aria-label="Digit ' + str(i) + ' of 4"></div>' for i in range(1,5)) + '</div><button data-testid="pin-forgot-pin">Forgot passcode</button>'
            assert (await markup(live_shape))['state'] == 'ready'
            browser.execute_script("""window.liveShapeEntered=[];const root=document.querySelector('[data-testid="xchatEmbedRoute"]').shadowRoot;
root.querySelectorAll('input').forEach(input=>input.addEventListener('keydown',event=>{if(event.key==='Enter')throw Error('Unexpected Enter');}));
root.querySelectorAll('input').forEach(input=>input.addEventListener('input',()=>{
 const fields=Array.from(root.querySelectorAll('input'));if(fields.every(field=>field.value)) {
 window.liveShapeEntered=fields.map(field=>field.value);root.innerHTML='<div>Chat</div>';
 }}));""")
            assert await IChatUnlock().check(actions, '1234') is None
            assert browser.execute_script('return window.liveShapeEntered') == list('1234')
            cases.append('live_shape_div_title_four_text_digits_autoadvance')
            for title in ('Create passcode', 'Confirm passcode', 'Enter verification code'):
                assert (await markup(live_shape.replace('Enter Passcode',title)))['state'] == 'manual'
            assert (await markup(live_shape.replace('data-testid="pin-title"','')))['state'] == 'manual'
            cases.append('live_shape_rejects_creation_verification_and_missing_title')
            synthetic = normal_synthetic

            for title in ('Enter your passcode', 'Введите код-пароль'):
                probe = await markup('<form><h2>' + title + '</h2><input type="password"><button>Continue</button></form>')
                assert probe['state'] == 'ready', title
            cases.append('passcode_heading_recognized')

            for title in ('Create your PIN', 'Confirm your PIN', 'Set a new password', 'Recover your PIN', 'Enter verification code'):
                probe = await markup('<form><h2>' + title + '</h2><input type="password"><button>Continue</button></form>')
                assert probe['state'] == 'manual', title
            cases.append('creation_recovery_confirmation_verification_rejected')
            probe = await markup('<form><h2>Enter your PIN</h2><input type="password" autocomplete="one-time-code"><button>Continue</button></form>')
            assert probe['state'] == 'manual'
            cases.append('otp_rejected')
            probe = await markup('<form><h2>Enter your PIN</h2><input type="password"><button>Unlock</button><button>Continue</button></form>')
            assert probe['state'] == 'manual'
            cases.append('ambiguous_buttons_rejected')
            probe = await markup('<form><h2>Enter your PIN</h2><input type="password"><input type="text" aria-label="Message"><button>Unlock</button></form>')
            assert probe['state'] == 'manual'
            cases.append('additional_input_rejected')
            await markup('<form><h2>Enter your PIN</h2><input type="password"><button type="button">Unlock</button></form>')
            browser.execute_script("""window.fixtureClicks=0;document.querySelector('[data-testid="xchatEmbedRoute"]').shadowRoot.querySelector('button').onclick=()=>window.fixtureClicks++;""")
            unlock = IChatUnlock()
            assert (await unlock.check(actions, 'wrong-fixture'))['status'] == 'requires_manual'
            assert (await unlock.check(actions, 'wrong-fixture'))['status'] == 'requires_manual'
            assert browser.execute_script('return window.fixtureClicks') == 1
            cases.append('wrong_value_once')
            print(json.dumps({'synthetic_fixture': True, 'visible_browser': True, 'passed': cases}, ensure_ascii=False))
            return 0
        finally:
            if browser:
                await asyncio.get_running_loop().run_in_executor(None, hard_close_browser, browser)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--chrome', required=True)
    parser.add_argument('--driver', required=True)
    arguments = parser.parse_args()
    sys.exit(asyncio.run(run(arguments.chrome, arguments.driver)))
