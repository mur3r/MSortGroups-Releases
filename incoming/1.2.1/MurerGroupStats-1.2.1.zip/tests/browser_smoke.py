"""Opt-in real browser test of fixture selectors and authenticated local proxy.

No X accounts or credentials are used. Run from repository root:
python tests/browser_smoke.py --chrome C:/path/chrome.exe --driver C:/path/chromedriver.exe
"""
import argparse
import asyncio
import base64
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
import sys
import tempfile
import threading

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from murer.collector import PROFILE_PROBE_JS, MEMBERS_PROBE_JS, browser_versions
from murer.parsing import classify_card
from xgenius.browser import BrowserManager
from xgenius.collectors.groups import CHAT_LIST_PROBE_JS
from xgenius.config import Config
from xgenius.models import BrowserConfig, AccountCredentials
from xgenius.process_utils import hard_close_browser


class FixtureProxy(BaseHTTPRequestHandler):
    challenges = 0
    accepted = 0
    credential = "Basic " + base64.b64encode(b'fixture-user:fixture-password').decode()

    def log_message(self, *args):
        pass

    def do_CONNECT(self):
        self.send_response(502)
        self.end_headers()

    def do_GET(self):
        if self.headers.get("Proxy-Authorization") != self.credential:
            type(self).challenges += 1
            self.send_response(407)
            self.send_header("Proxy-Authenticate", 'Basic realm="Murer test proxy"')
            self.send_header("Content-Length", "0")
            self.end_headers()
            return
        type(self).accepted += 1
        body = b"<html><body>MURER_AUTH_PROXY_OK</body></html>"
        self.send_response(200)
        self.send_header("Content-Type", "text/html")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)


async def run(chrome, driver):
    result = {"versions": browser_versions(chrome, driver), "fixture_selectors": False,
              "visible_browser": False, "authenticated_proxy": False}
    with tempfile.TemporaryDirectory(prefix="murer_browser_smoke_") as folder:
        config = Config(Path(folder))
        config.chrome_path, config.chromedriver_path = Path(chrome), Path(driver)
        manager = BrowserManager(config, BrowserConfig())
        browser = None
        proxy_server = ThreadingHTTPServer(('127.0.0.1', 0), FixtureProxy)
        proxy_thread = threading.Thread(target=proxy_server.serve_forever, daemon=True)
        proxy_thread.start()
        try:
            browser = await manager.create_browser(AccountCredentials('fixture', '', headless=False))
            result["visible_browser"] = True
            fixtures = Path(__file__).parent / 'fixtures'
            browser.get((fixtures / 'profile.html').resolve().as_uri())
            profile = browser.execute_script(PROFILE_PROBE_JS)
            types = [classify_card(card, 'alice') for card in profile['cards']]
            result['fixture_profile_diagnostics'] = {"posts_raw": profile.get('posts_raw'),
                "x_id": profile.get('x_id'), "types": [p['type'] for p in types]}
            assert profile['posts_raw'] == '56.1K posts'
            assert profile['x_id'] == '101'
            assert [p['type'] for p in types] == ['own', 'own', 'repost', 'quote', 'reply', 'unknown', 'own']
            assert types[0]['pinned']
            assert types[2]['event_at'] is None and types[2]['original_at'].startswith('2020')
            browser.execute_script("""document.querySelectorAll('[data-user-id]').forEach(el=>el.removeAttribute('data-user-id'));
const toolbar=document.createElement('div');toolbar.innerHTML='<button data-testid="userActions"></button><button data-testid="555-follow"></button>';
(document.querySelector('[data-testid="primaryColumn"]')||document.querySelector('main')).prepend(toolbar);""")
            header_identity = browser.execute_script(PROFILE_PROBE_JS)
            assert header_identity['x_id'] == '555'
            assert header_identity['identity_origin'] == 'profile_header_action_id'
            result['fixture_header_stable_id'] = True
            browser.get((fixtures / 'members.html').resolve().as_uri())
            membership = browser.execute_script(MEMBERS_PROBE_JS)
            result['fixture_member_diagnostics'] = membership
            assert len(membership['participants']) == 3
            assert not any(p['username'] == 'sender_only' for p in membership['participants'])
            assert membership['declared_raw'] == '3'
            # Mirrors the verified live XChat embed without copying any private
            # account, group or participant payload into fixtures.
            wrap_shadow = """const host=document.createElement('div');
const nodes=Array.from(document.body.childNodes);document.body.replaceChildren(host);
const root=host.attachShadow({mode:'open'});nodes.forEach(node=>root.append(node));"""
            browser.execute_script(wrap_shadow)
            shadow_membership = browser.execute_script(MEMBERS_PROBE_JS)
            assert len(shadow_membership['participants']) == 3
            assert shadow_membership['declared_raw'] == '3'
            browser.get((fixtures / 'chat-list.html').resolve().as_uri())
            chat = browser.execute_script(CHAT_LIST_PROBE_JS)
            assert chat['confirmed_end'] and len(chat['groups']) == 4
            browser.execute_script(wrap_shadow)
            shadow_chat = browser.execute_script(CHAT_LIST_PROBE_JS)
            assert shadow_chat['confirmed_end'] and len(shadow_chat['groups']) == 4
            result['fixture_shadow_selectors'] = True
            result['fixture_selectors'] = True
            result['fixture_cards'] = len(types)
            await asyncio.get_running_loop().run_in_executor(None, hard_close_browser, browser)
            browser = None
            credentials = AccountCredentials('fixture-proxy', '', headless=False,
                proxy=f'127.0.0.1:{proxy_server.server_port}:fixture-user:fixture-password')
            browser = await manager.create_browser(credentials)
            browser.set_page_load_timeout(8)
            await asyncio.sleep(1)
            try:
                browser.get('http://murer-proxy-fixture.invalid/test')
            except Exception as exc:
                result['proxy_navigation_error'] = type(exc).__name__
            body = browser.execute_script("return (document.body && document.body.innerText) || ''")
            result['authenticated_proxy'] = 'MURER_AUTH_PROXY_OK' in body and FixtureProxy.accepted > 0
            result['proxy_challenges'] = FixtureProxy.challenges
            result['proxy_authenticated_requests'] = FixtureProxy.accepted
            if not result['authenticated_proxy']:
                result['proxy_reason'] = 'Extension not loaded or authentication rejected; use Chrome for Testing/Chromium and repeat'
        except Exception as exc:
            result['error_type'] = type(exc).__name__
            # Avoid webdriver startup options/credentials in output.
            result['reason'] = 'Browser or fixture/proxy verification failed'
        finally:
            if browser:
                await asyncio.get_running_loop().run_in_executor(None, hard_close_browser, browser)
            proxy_server.shutdown()
            proxy_server.server_close()
            import shutil
            for directory in getattr(manager, '_proxy_temp_dirs', []):
                shutil.rmtree(directory, ignore_errors=True)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result['fixture_selectors'] and result['authenticated_proxy'] else 1


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--chrome', required=True)
    parser.add_argument('--driver', required=True)
    args = parser.parse_args()
    sys.exit(asyncio.run(run(args.chrome, args.driver)))
