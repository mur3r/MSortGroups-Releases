"""Synthetic unlock fixtures/mocks; not a claim of live X PIN verification."""
import asyncio
from pathlib import Path
import tempfile
import unittest
from unittest.mock import AsyncMock, MagicMock, patch

from murer.collector import SeleniumSession, RedactedLogger
from murer.ichat_unlock import IChatUnlock, ICHAT_UNLOCK_PROBE_JS
from murer.rules import default_settings
from murer.safe_actions import SafeActions
from xgenius.collectors.groups import GroupCollector
from xgenius.config import Config
from xgenius.models import AccountCredentials, AccountState, AuthStatus


class StopRequested(Exception):
    pass


def field(*, segmented=False, autocomplete=''):
    element = MagicMock()
    values = {'type': 'password', 'maxlength': '1' if segmented else '',
              'inputmode': 'numeric' if segmented else '', 'autocomplete': autocomplete}
    element.get_attribute.side_effect = lambda key: values.get(key, '')
    return element


class IChatUnlockTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.settings = default_settings()
        self.settings['collection'].update(action_delay_seconds=0, login_poll_rounds=2, login_poll_seconds=0)
        self.actions = SafeActions(MagicMock(), self.settings)
        self.actions.script = AsyncMock()
        self.unlock = IChatUnlock()
        self.button = MagicMock()
        self.button.get_attribute.return_value = ''

    def ready(self, fields, segmented=False):
        return {'state': 'ready', 'fields': fields, 'segmented': segmented, 'button': self.button}

    async def test_single_password_is_typed_character_by_character_and_button_clicked_once(self):
        target = field()
        ready = self.ready([target])
        self.actions.script.side_effect = [ready, ready, {'state': 'absent'}]
        self.assertIsNone(await self.unlock.check(self.actions, 'fixture-chat-password'))
        self.assertEqual([call.args[0] for call in target.send_keys.call_args_list], list('fixture-chat-password'))
        self.button.click.assert_called_once()
        self.assertTrue(self.unlock.attempted)

    async def test_split_pin_autoadvances_without_enter_or_button(self):
        fields = [field(segmented=True) for _ in range(4)]
        ready = {**self.ready(fields, True), 'button': None}
        self.actions.script.side_effect = [ready, {'state': 'absent'}]
        self.assertIsNone(await self.unlock.check(self.actions, '1234'))
        self.assertEqual([entry.send_keys.call_args.args[0] for entry in fields], list('1234'))
        self.button.click.assert_not_called()

    async def test_wrong_value_is_never_retried_on_later_gate_checks(self):
        target = field()
        self.actions.script.return_value = self.ready([target])
        first = await self.unlock.check(self.actions, 'wrong-fixture')
        second = await self.unlock.check(self.actions, 'wrong-fixture')
        self.assertEqual(first['status'], 'requires_manual')
        self.assertEqual(second['status'], 'requires_manual')
        self.assertEqual(target.send_keys.call_count, len('wrong-fixture'))
        self.button.click.assert_called_once()
        self.assertNotIn('wrong-fixture', first['reason'])

    async def test_missing_secret_and_unsupported_gate_remain_manual(self):
        target = field()
        self.actions.script.return_value = self.ready([target])
        self.assertEqual((await self.unlock.check(self.actions, ''))['status'], 'requires_manual')
        self.assertFalse(self.unlock.attempted)
        self.actions.script.return_value = {'state': 'manual', 'reason': 'verification'}
        self.assertEqual((await self.unlock.check(self.actions, 'never-fill'))['status'], 'requires_manual')
        target.send_keys.assert_not_called()
        self.button.click.assert_not_called()

    async def test_pin_length_mismatch_does_not_type_or_consume_attempt(self):
        fields = [field(segmented=True) for _ in range(6)]
        self.actions.script.return_value = self.ready(fields, True)
        result = await self.unlock.check(self.actions, '1234')
        self.assertEqual(result['status'], 'requires_manual')
        self.assertIn('PIN из 6 цифр', result['reason'])
        self.assertFalse(self.unlock.attempted)
        for target in fields:
            target.send_keys.assert_not_called()

    async def test_alphanumeric_chat_password_is_not_sent_to_four_digit_gate(self):
        fields = [field(segmented=True) for _ in range(4)]
        self.actions.script.return_value = self.ready(fields, True)
        result = await self.unlock.check(self.actions, 'fixture-chat-password')
        self.assertEqual(result['status'], 'requires_manual')
        self.assertIn('PIN из 4 цифр', result['reason'])
        self.assertNotIn('fixture-chat-password', result['reason'])
        self.assertFalse(self.unlock.attempted)
        for target in fields:
            target.send_keys.assert_not_called()

    async def test_unlock_wait_honors_the_configured_poll_count(self):
        self.settings['collection']['login_poll_rounds'] = 25
        self.actions.sleep = AsyncMock()
        self.actions.delay = AsyncMock()
        self.actions.script.return_value = self.ready([field()])
        result = await self.unlock.check(self.actions, 'fixture-chat')
        self.assertEqual(result['status'], 'requires_manual')
        self.assertEqual(self.actions.sleep.await_count, 25)
        self.button.click.assert_called_once()

    async def test_delete_control_character_is_rejected_before_input(self):
        target = field()
        self.actions.script.return_value = self.ready([target])
        result = await self.unlock.check(self.actions, 'fixture\x7fchat')
        self.assertEqual(result['status'], 'requires_manual')
        target.send_keys.assert_not_called()
        self.assertFalse(self.unlock.attempted)

    async def test_safe_input_rejects_otp_newlines_and_selenium_enter(self):
        for target, value in [(field(autocomplete='one-time-code'), '1234'),
                              (field(), 'pass\nword'), (field(), 'pass\ue007'),
                              (field(), 'pass\x7fword')]:
            with self.assertRaises(ValueError):
                await self.actions.unlock_input(target, value)
            target.send_keys.assert_not_called()

    async def test_stop_survives_and_partial_password_is_not_replayed(self):
        target = field()
        self.actions.script.return_value = self.ready([target])
        self.actions.unlock_input = AsyncMock(side_effect=StopRequested())
        with self.assertRaises(StopRequested):
            await self.unlock.check(self.actions, 'private-fixture')
        self.assertTrue(self.unlock.attempted)
        self.assertEqual((await self.unlock.check(self.actions, 'private-fixture'))['status'], 'requires_manual')
        self.actions.unlock_input.assert_awaited_once()

    async def test_driver_error_never_echoes_secret(self):
        self.actions.script.return_value = self.ready([field()])
        self.actions.unlock_input = AsyncMock(side_effect=RuntimeError('driver echoed private-fixture'))
        result = await self.unlock.check(self.actions, 'private-fixture')
        self.assertEqual(result['status'], 'requires_manual')
        self.assertNotIn('private-fixture', result['reason'])

    async def test_safe_telemetry_contains_only_enum_and_timestamp_in_order(self):
        events = []
        async def on_event(event):
            events.append(event)
        unlock = IChatUnlock(on_event=on_event)
        target = field()
        ready = self.ready([target])
        self.actions.script.side_effect = [ready, ready, {'state': 'absent'}]
        await unlock.check(self.actions, 'private-fixture')
        self.assertEqual([item['event'] for item in events],
                         ['gate_ready', 'input_completed', 'submit_clicked', 'gate_absent'])
        for item in events:
            self.assertEqual(set(item), {'event', 'timestamp'})
            self.assertIn('+00:00', item['timestamp'])
            self.assertNotIn('private-fixture', str(item))

    async def test_initial_gate_absence_does_not_use_password_or_imply_success(self):
        events = []
        unlock = IChatUnlock(on_event=events.append)
        self.actions.script.return_value = {'state': 'absent'}
        await unlock.check(self.actions, 'private-fixture')
        await unlock.check(self.actions, 'private-fixture')
        self.assertFalse(unlock.attempted)
        self.assertEqual([item['event'] for item in events], ['gate_absent'])

    async def test_segmented_autoadvance_emits_explicit_observations(self):
        events = []
        unlock = IChatUnlock(on_event=events.append)
        fields = [field(segmented=True) for _ in range(4)]
        self.actions.script.side_effect = [{**self.ready(fields, True), 'button': None}, {'state': 'absent'}]
        await unlock.check(self.actions, '1234')
        self.assertEqual([item['event'] for item in events],
                         ['gate_ready', 'input_completed', 'auto_advanced', 'gate_absent'])

    async def test_chat_confirmation_requires_ordered_input_absence_and_groups(self):
        with tempfile.TemporaryDirectory() as folder:
            progress = []
            session = SeleniumSession(Config(Path(folder)), MagicMock(), self.settings, progress=progress.append)
            session.username = 'fixture'
            session.manager.accounts['fixture'] = AccountState('fixture', browser=MagicMock())
            session.actions = MagicMock()
            session._page_gate = AsyncMock(return_value=None)
            group_result = {'groups': [{'x_id': 'g1'}], 'status': 'partial'}
            with patch('murer.collector.GroupCollector') as collector:
                collector.return_value.discover_groups = AsyncMock(side_effect=lambda *a, **k: {'groups': [{'x_id': 'g1'}], 'status': 'partial'})
                credentials = AccountCredentials('fixture', '')
                # An initial absent form followed by available chats proves
                # access, but does not prove that the stored secret was used.
                await session._ichat_unlock_event({'event': 'gate_absent'})
                result = await session.discover_groups(credentials)
                self.assertFalse(result['ichat_password_used'])
                self.assertFalse(result['real_auto_unlock_confirmed'])
                # An earlier absence cannot satisfy a later input attempt.
                await session._ichat_unlock_event({'event': 'input_completed'})
                result = await session.discover_groups(credentials)
                self.assertTrue(result['ichat_password_used'])
                self.assertFalse(result['real_auto_unlock_confirmed'])
                await session._ichat_unlock_event({'event': 'gate_absent'})
                result = await session.discover_groups(credentials)
                self.assertTrue(result['real_auto_unlock_confirmed'])
                self.assertEqual(result['ichat_unlock_events'][-1]['event'], 'chat_ready')
                self.assertTrue(progress[-1]['real_auto_unlock_confirmed'])
                # Manual intervention prevents claiming automatic success.
                await session._ichat_unlock_event({'event': 'manual'})
                await session._ichat_unlock_event({'event': 'gate_absent'})
                result = await session.discover_groups(credentials)
                self.assertFalse(result['real_auto_unlock_confirmed'])
            for item in session._ichat_unlock_events:
                self.assertEqual(set(item), {'event', 'timestamp'})

    async def test_input_and_absence_without_chat_groups_are_not_confirmation(self):
        with tempfile.TemporaryDirectory() as folder:
            session = SeleniumSession(Config(Path(folder)), MagicMock(), self.settings)
            session.username = 'fixture'
            session.manager.accounts['fixture'] = AccountState('fixture', browser=MagicMock())
            session.actions = MagicMock()
            session._page_gate = AsyncMock(return_value=None)
            await session._ichat_unlock_event({'event': 'input_completed'})
            await session._ichat_unlock_event({'event': 'gate_absent'})
            with patch('murer.collector.GroupCollector') as collector:
                collector.return_value.discover_groups = AsyncMock(return_value={'groups': [], 'status': 'partial'})
                result = await session.discover_groups(AccountCredentials('fixture', ''))
            self.assertFalse(result['real_auto_unlock_confirmed'])

    async def test_group_discovery_checks_gate_before_reading_groups(self):
        browser = MagicMock()
        actions = MagicMock()
        actions.get = AsyncMock()
        actions.sleep = AsyncMock()
        gate = AsyncMock(return_value={'status': 'requires_manual', 'reason': 'fixture PIN'})
        result = await GroupCollector(MagicMock()).discover_groups(browser, 'fixture', self.settings,
            actions=actions, page_gate=gate)
        self.assertEqual(result['status'], 'requires_manual')
        self.assertEqual(result['groups'], [])
        browser.execute_script.assert_not_called()

    async def test_session_gate_and_continue_hold_the_existing_queue(self):
        with tempfile.TemporaryDirectory() as folder:
            session = SeleniumSession(Config(Path(folder)), MagicMock(), self.settings)
            session._identity_after_login=AsyncMock(side_effect=lambda credentials,result:result)
            browser = MagicMock()
            browser.current_url = 'https://x.com/i/chat'
            session.username = 'fixture'
            session.manager.accounts['fixture'] = AccountState('fixture', browser=browser)
            session._bind()
            session.manager._check_login_locks = AsyncMock(return_value=None)
            session.manager._check_auth_state = AsyncMock(return_value=AuthStatus.OK)
            session.manager._finalize_login = AsyncMock()
            running, peak = 0, 0
            async def check(actions, password):
                nonlocal running, peak
                self.assertTrue(session.queue.locked())
                self.assertEqual(password, 'fixture-chat')
                running += 1
                peak = max(peak, running)
                await asyncio.sleep(0.01)
                running -= 1
            session._ichat_unlock.check = AsyncMock(side_effect=check)
            credentials = AccountCredentials('fixture', '')
            credentials.ichat_password = 'fixture-chat'
            results = await asyncio.gather(*(session.continue_login(credentials) for _ in range(3)))
            self.assertTrue(all(result['status'] == 'active' for result in results))
            self.assertEqual(peak, 1)

    async def test_session_never_checks_chat_secret_on_x_login_or_other_domain(self):
        with tempfile.TemporaryDirectory() as folder:
            session = SeleniumSession(Config(Path(folder)), MagicMock(), self.settings)
            session.username = 'fixture'
            browser = MagicMock()
            session.manager.accounts['fixture'] = AccountState('fixture', browser=browser)
            session._bind()
            session.manager._check_login_locks = AsyncMock(return_value=None)
            session._ichat_unlock.check = AsyncMock()
            for url in ('https://x.com/i/flow/login', 'https://x.com.evil.invalid/i/chat', 'https://example.com/i/chat'):
                browser.current_url = url
                await session._page_gate()
            session._ichat_unlock.check.assert_not_awaited()

    async def test_initial_login_error_checks_ichat_unlock_before_manual_lock(self):
        with tempfile.TemporaryDirectory() as folder:
            session = SeleniumSession(Config(Path(folder)), MagicMock(), self.settings)
            session._identity_after_login=AsyncMock(side_effect=lambda credentials,result:result)
            session.profile_lock = MagicMock()
            browser = MagicMock()
            browser.current_url = 'https://x.com/i/chat/pin/enter'
            session.manager.accounts['fixture'] = AccountState('fixture',browser=browser)
            session.manager.login_account = AsyncMock(side_effect=RuntimeError('Synthetic early chat gate'))
            session.manager._check_auth_state = AsyncMock(return_value=AuthStatus.OK)
            session.manager._finalize_login = AsyncMock()
            session.manager._check_login_locks = AsyncMock(return_value='MANUAL CONFIRMATION')
            async def gate():
                self.assertTrue(session.queue.locked())
                self.assertEqual(session._ichat_password,'fixture-chat')
            session._page_gate = AsyncMock(side_effect=gate)
            result = await session.login(AccountCredentials('fixture','fixture-x',ichat_password='fixture-chat'))
            self.assertEqual(result['status'],'active')
            session._page_gate.assert_awaited_once()
            session.manager._finalize_login.assert_awaited_once()
            session.manager._check_login_locks.assert_not_awaited()

    async def test_initial_chat_gate_preserves_specific_missing_or_unsupported_reason(self):
        with tempfile.TemporaryDirectory() as folder:
            session = SeleniumSession(Config(Path(folder)), MagicMock(), self.settings)
            session.profile_lock = MagicMock()
            browser = MagicMock()
            browser.current_url = 'https://x.com/i/chat'
            session.manager.accounts['fixture'] = AccountState('fixture',browser=browser)
            session.manager.login_account = AsyncMock(side_effect=RuntimeError('Synthetic early gate'))
            expected = {'status':'requires_manual','reason':'Synthetic unsupported iChat form'}
            session._page_gate = AsyncMock(return_value=expected)
            self.assertEqual(await session.login(AccountCredentials('fixture','fixture-x')),expected)

    async def test_initial_login_error_on_x_login_does_not_try_chat_password(self):
        with tempfile.TemporaryDirectory() as folder:
            session = SeleniumSession(Config(Path(folder)), MagicMock(), self.settings)
            session.profile_lock = MagicMock()
            browser = MagicMock()
            browser.current_url = 'https://x.com/i/flow/login'
            session.manager.accounts['fixture'] = AccountState('fixture',browser=browser)
            session.manager.login_account = AsyncMock(side_effect=RuntimeError('Synthetic verification'))
            session.manager._check_login_locks = AsyncMock(return_value='MANUAL CONFIRMATION')
            session._page_gate = AsyncMock()
            result = await session.login(AccountCredentials('fixture','fixture-x',ichat_password='fixture-chat'))
            self.assertEqual(result['status'],'requires_manual')
            session._page_gate.assert_not_awaited()

    def test_redacted_logger_removes_chat_secret(self):
        underlying = MagicMock()
        logger = RedactedLogger(underlying)
        credentials = AccountCredentials('fixture', 'fixture-x-password')
        credentials.ichat_password = 'fixture-chat-password'
        logger.configure(credentials)
        logger.error('driver fixture-chat-password fixture-x-password')
        self.assertEqual(underlying.error.call_args.args[0], 'driver [скрыто] [скрыто]')


if __name__ == '__main__':
    unittest.main()
