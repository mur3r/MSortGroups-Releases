"""Opt-in read-only inspection of the real account's group-info/add picker.

Never searches for or selects a foreign person and never clicks Add/Invite.
Credentials are read from the OS vault; only structural evidence is reported.
"""
import argparse
import asyncio
from concurrent.futures import ThreadPoolExecutor
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from murer.jobs import JobControl, SafeLogger
from murer.runtime import read_configuration, FileLease
from murer.secrets import SecretStore
from murer.storage import Store, utcnow
from murer.trade_browser import TradeSession, INVITE_DETAILS_JS, INVITE_FORM_JS
from xgenius.config import Config
from xgenius.logger import Logger
from xgenius.models import AccountCredentials
from xgenius.core.dom import DEEP_QUERY_JS


async def inspect(account_id, limit, search_self=False, search_known=False):
    configuration = read_configuration()
    store = Store(configuration['data_dir'])
    account = store.account(account_id)
    if not account or account['archived']:
        raise ValueError('Choose an existing working account ID')
    private = SecretStore().get(account_id)
    config = Config(store.data_dir)
    config.profile_key = account.get('profile_key') or account['username']
    config.account_identity_handler = lambda identity: account.update(store.sync_account_identity(account_id,identity)[0])
    config.chrome_path, config.chromedriver_path = configuration['chrome_path'], configuration['driver_path']
    settings, _ = store.settings()
    logger = SafeLogger(Logger(config), private.values())
    lease = FileLease(config.get_profile_dir(account['username']) / '.murer-profile.lock')
    browser = TradeSession(config, logger, settings, JobControl().checkpoint, lambda _: None)
    report = {'observed_at':utcnow(), 'read_only':True, 'real_x_access':True,
              'invitations_sent':0, 'groups':[]}
    try:
        credentials = AccountCredentials(username=account['username'], password=private['password'],
            proxy=private['proxy'] or None, user_agent=account.get('user_agent'), headless=False,
            auth_token=private['auth_token'] or None, ct0_token=private['ct0_token'] or None,
            ichat_password=private['ichat_password'] or None)
        login = await browser.login(credentials)
        report['login_status'] = login.get('status')
        if login.get('status') != 'active':
            return report
        groups = store.rows('SELECT g.id,g.url FROM groups g JOIN account_groups ag ON ag.group_id=g.id WHERE ag.account_id=? AND ag.present=1 LIMIT ?', (account_id,limit))
        for group in groups:
            result = {'group_id':group['id']}
            async with browser.queue, browser._scanning():
                await browser.actions.get(group['url'])
                await browser.actions.sleep(settings['collection']['load_wait_seconds'])
                gate = await browser._page_gate()
                if gate:
                    result['status'] = gate.get('status')
                    report['groups'].append(result)
                    break
                try:
                    await browser.actions.wait('[data-testid="dm-conversation-header"] div.cursor-pointer,[data-testid="DMConversationInfoButton"],[data-testid="dmConversationInfo"]', settings['collection']['element_timeout_seconds'])
                    opened = await browser._click_first(['[data-testid="dm-conversation-header"] div.cursor-pointer', '[data-testid="DMConversationInfoButton"]','[data-testid="dmConversationInfo"]'])
                    for _ in range(settings['collection']['login_poll_rounds']):
                        if opened:
                            break
                        await browser.actions.sleep(settings['collection']['login_poll_seconds'])
                        opened = await browser._click_first(['[data-testid="dm-conversation-header"] div.cursor-pointer', '[data-testid="DMConversationInfoButton"]','[data-testid="dmConversationInfo"]'])
                    if opened:
                        await browser.actions.wait('[role="dialog"],[data-testid="DMConversationDetails"]', settings['collection']['element_timeout_seconds'])
                        await browser.actions.sleep(settings['collection']['load_wait_seconds'])
                        details = await browser.actions.script(INVITE_DETAILS_JS)
                        result.update(state=details.get('state'), reason=details.get('reason'))
                        if details.get('state') == 'ready':
                            await browser.actions.click(details['button'])  # Only opens search.
                            await browser.actions.sleep(settings['collection']['load_wait_seconds'])
                            form = await browser.actions.script(INVITE_FORM_JS)
                            result.update(picker_state=form.get('state'), search_found=bool(form.get('input')),
                                          confirm_button_found=bool(form.get('button')))
                            result['picker_structure'] = await browser.actions.script(DEEP_QUERY_JS + r"""
return deepQueryAll('[role=dialog]').map(panel=>({headings:deepQueryAll('h1,h2,h3,[role=heading]',panel).map(el=>(el.innerText||'').slice(0,80)),labels:(panel.innerText||'').split('\n').map(t=>t.trim()).filter(t=>/^(add|search|select|no |members|добав|поиск|выбер)/i.test(t)).slice(0,12),inputs:deepQueryAll('input',panel).map(el=>({type:el.type,placeholder:el.placeholder,label:el.getAttribute('aria-label'),testid:el.getAttribute('data-testid')})),checkboxes:deepQueryAll('[role=checkbox],input[type=checkbox]',panel).length,cells:deepQueryAll('[data-testid=UserCell],[role=option]',panel).length}));
""")
                            if search_self or search_known:
                                query = account['username']
                                if search_known:
                                    known = store.rows('SELECT username FROM participants WHERE username IS NOT NULL AND lower(username)!=? ORDER BY username LIMIT 1',(account['username'].lower(),))
                                    query = known[0]['username'] if known else query
                                inputs = await browser.actions.find_all('[role="dialog"] input[placeholder="Search name or username"]')
                                if len(inputs) == 1:
                                    await browser.actions.search_input(inputs[0], query)
                                    await browser.actions.sleep(3)
                                    matched = await browser.actions.script(INVITE_FORM_JS)
                                    result['search_parser'] = {'state':matched.get('state'), 'rows':len(matched.get('users',[])),
                                        'confirm_button_found':bool(matched.get('button')),
                                        'recognized_stable_ids':sum(bool(user.get('x_id')) for user in matched.get('users',[])),
                                        'disabled_rows':sum(bool(user.get('disabled')) for user in matched.get('users',[]))}
                                    result['self_search_structure'] = await browser.actions.script(DEEP_QUERY_JS + r"""
return deepQueryAll('[role=dialog]').map(panel=>({labels:(panel.innerText||'').split('\n').map(t=>t.trim()).filter(t=>/^(add|search|select|no |members)/i.test(t)).slice(0,12),roles:deepQueryAll('[role]',panel).map(el=>({tag:el.tagName,role:el.getAttribute('role'),testid:el.getAttribute('data-testid'),checked:el.getAttribute('aria-checked')})),checkboxes:deepQueryAll('[role=checkbox],input[type=checkbox]',panel).length,cells:deepQueryAll('[data-testid=UserCell],[role=option]',panel).length,result_nodes:deepQueryAll('*',panel).filter(el=>el.children.length===0&&/^@[a-z0-9_]+$/i.test((el.innerText||'').trim())).slice(0,2).map(el=>{let parent=el;return Array.from({length:5},()=>{parent=parent?.parentElement;return parent?{tag:parent.tagName,class:parent.className,role:parent.getAttribute('role'),html:parent.outerHTML.slice(0,18000)}:null})})}));
""")
                                    await browser.actions.call(lambda:browser.actions.browser.save_screenshot(str(ROOT/'artifacts'/'live-trade-picker.png')))
                        # Structural labels only; no participant names or messages.
                        result['dialog_labels'] = await browser.actions.script(
                            DEEP_QUERY_JS + "return deepQueryAll('[role=dialog]').flatMap(p=>deepQueryAll('button',p)).map(b=>({testid:b.getAttribute('data-testid'),label:b.getAttribute('aria-label'),text:(b.innerText||'').trim().slice(0,50)})).filter(b=>/^(add|view|close|cancel|back|save|done|добав|посмотр|закрыть|назад|готово|отмен)/i.test(b.text||b.label||'')).slice(0,15);")
                    else:
                        result['state'] = 'info_not_opened'
                except Exception as error:
                    result.update(state='error', error_type=type(error).__name__)
            report['groups'].append(result)
        return report
    finally:
        await browser.close()
        lease.close()
        logger.base.close()


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--account-id', required=True)
    parser.add_argument('--limit', type=int, choices=range(1,5), default=1)
    parser.add_argument('--search-self', action='store_true', help='Read-only search for the owning account, never selects a result')
    parser.add_argument('--search-known', action='store_true', help='Read-only search for a saved participant, never selects a result')
    args = parser.parse_args()
    loop = asyncio.new_event_loop()
    loop.set_default_executor(ThreadPoolExecutor(max_workers=1))
    try:
        result = loop.run_until_complete(inspect(args.account_id,args.limit,args.search_self,args.search_known))
        target = ROOT / 'artifacts' / 'live-trade-inspect.json'
        target.write_text(json.dumps(result, ensure_ascii=False, indent=2),encoding='utf-8')
        print(json.dumps(result,ensure_ascii=True))
    finally:
        loop.run_until_complete(loop.shutdown_default_executor())
        loop.close()
