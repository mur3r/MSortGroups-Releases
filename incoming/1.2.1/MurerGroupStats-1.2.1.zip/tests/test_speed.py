"""Synthetic pacing and bounded browser scheduling; no X access or real vault."""
import asyncio
from copy import deepcopy
from pathlib import Path
import tempfile
import threading
import time
import unittest

from fastapi.testclient import TestClient

from murer.api import create_app
from murer.rules import default_settings, speed_presets, validate_settings
from murer.secrets import SecretStore
from tests.test_storage_api import MemoryVault


class SpeedRuleTests(unittest.TestCase):
    def test_presets_are_valid_detached_pacing_only_and_preserve_user_choices(self):
        presets = speed_presets()
        self.assertEqual([p['id'] for p in presets], ['slow', 'medium', 'fast'])
        for preset in presets:
            source = default_settings()
            source['collection'].update(posts_limit=777, concurrent_accounts=4)
            source['humanization']['enabled'] = True
            for section, values in preset['settings'].items():
                self.assertNotIn('enabled', values)
                self.assertNotIn('posts_limit', values)
                self.assertNotIn('concurrent_accounts', values)
                source[section].update(values)
            validated = validate_settings(source)
            self.assertEqual(validated['collection']['posts_limit'], 777)
            self.assertEqual(validated['collection']['concurrent_accounts'], 4)
            self.assertTrue(validated['humanization']['enabled'])
        presets[0]['settings']['collection']['action_delay_seconds'] = 999
        self.assertEqual(speed_presets()[0]['settings']['collection']['action_delay_seconds'], 3)

    def test_interval_and_concurrency_validation(self):
        for value in (-1, '5', True, float('inf')):
            with self.subTest(value=value), self.assertRaises(ValueError):
                validate_settings({'collection': {'account_start_interval_seconds': value}})
        for value in (0, .25, 60):
            self.assertEqual(validate_settings({'collection': {'account_start_interval_seconds': value}})['collection']['account_start_interval_seconds'], value)
        for value in (0, 1.5, True):
            with self.subTest(value=value), self.assertRaises(ValueError):
                validate_settings({'collection': {'concurrent_accounts': value}})


class Sessions:
    def __init__(self, duration=.25):
        self.lock = threading.Lock()
        self.starts = []
        self.closed = []
        self.active = self.peak = 0
        self.duration = duration
        self.release = threading.Event()

    def factory(self, config, logger, settings, checkpoint, progress):
        owner = self
        class Session:
            username = None
            async def login(self, credentials):
                self.username = credentials.username
                with owner.lock:
                    owner.starts.append((self.username, time.monotonic()))
                    owner.active += 1
                    owner.peak = max(owner.peak, owner.active)
                until = time.monotonic() + owner.duration
                while not owner.release.is_set() and time.monotonic() < until:
                    checkpoint()
                    await asyncio.sleep(.01)
                return {'status': 'active'}
            async def close(self):
                if self.username is not None:
                    with owner.lock:
                        owner.active -= 1
                        owner.closed.append(self.username)
        return Session()


class AccountSchedulingTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.sessions = Sessions()
        self.app = create_app(Path(self.temporary.name), SecretStore(MemoryVault()), self.sessions.factory)
        self.state = self.app.state.application
        self.client = TestClient(self.app)
        self.client.__enter__()
        self.addCleanup(self.client.__exit__, None, None, None)
        self.ids = [self.client.post('/api/accounts', json={'username': f'fixture_{i}'}).json()['id'] for i in range(5)]
        self.settings = default_settings()
        self.settings['collection'].update(concurrent_accounts=2, account_start_interval_seconds=.08)

    def wait(self, predicate, timeout=5):
        end = time.monotonic() + timeout
        while time.monotonic() < end:
            if predicate():
                return
            time.sleep(.01)
        self.fail('Synthetic scheduling did not reach the expected safe step')

    def start(self):
        response = self.client.put('/api/settings', json=self.settings)
        self.assertEqual(response.status_code, 200, response.text)
        response = self.client.post('/api/jobs', json={'account_ids': self.ids, 'mode': 'login'})
        self.assertEqual(response.status_code, 200, response.text)
        return response.json()['id']

    def finish(self, job_id):
        self.wait(lambda: not self.state.jobs.threads[job_id].is_alive())
        return self.state.store.job(job_id)

    def test_bounded_windows_staggered_starts_and_automatic_queue(self):
        job_id = self.start()
        job = self.finish(job_id)
        self.assertEqual(job['status'], 'completed', job)
        self.assertEqual(len(self.sessions.starts), 5)
        self.assertEqual(self.sessions.peak, 2)
        self.assertEqual(self.sessions.active, 0)
        self.assertCountEqual(self.sessions.closed, [f'fixture_{i}' for i in range(5)])
        times = sorted(t for _, t in self.sessions.starts)
        self.assertTrue(all(b-a >= .06 for a, b in zip(times, times[1:])), times)
        self.assertTrue(all(a['launch_state'] == 'finished' for a in job['progress']['accounts'].values()))

    def test_pause_does_not_open_queued_accounts_and_resume_keeps_limit(self):
        self.sessions.duration = 3
        self.settings['collection']['account_start_interval_seconds'] = .4
        job_id = self.start()
        self.wait(lambda: len(self.sessions.starts) == 1)
        self.client.post(f'/api/jobs/{job_id}/pause')
        time.sleep(.55)
        self.assertEqual(len(self.sessions.starts), 1)
        self.client.post(f'/api/jobs/{job_id}/resume')
        self.wait(lambda: len(self.sessions.starts) == 2)
        self.assertLessEqual(self.sessions.peak, 2)
        self.client.post(f'/api/jobs/{job_id}/stop')
        self.assertEqual(self.finish(job_id)['status'], 'stopped')
        self.assertEqual(self.sessions.active, 0)

    def test_zero_interval_can_fill_three_slots_without_starting_a_fourth(self):
        self.sessions.duration = 3
        self.settings['collection'].update(concurrent_accounts=3, account_start_interval_seconds=0)
        job_id = self.start()
        self.wait(lambda: len(self.sessions.starts) == 3)
        time.sleep(.1)
        self.assertEqual(len(self.sessions.starts), 3)
        self.assertEqual(self.sessions.peak, 3)
        self.sessions.release.set()
        self.assertEqual(self.finish(job_id)['status'], 'completed')
        self.assertEqual(len(self.sessions.starts), 5)

    def test_stop_interrupts_long_start_interval_without_opening_remaining_accounts(self):
        self.settings['collection']['account_start_interval_seconds'] = 30
        job_id = self.start()
        self.wait(lambda: len(self.sessions.starts) == 1)
        started = time.monotonic()
        self.client.post(f'/api/jobs/{job_id}/stop')
        self.assertEqual(self.finish(job_id)['status'], 'stopped')
        self.assertLess(time.monotonic()-started, 2)
        self.assertEqual(len(self.sessions.starts), 1)

    def test_running_job_keeps_its_frozen_concurrency_and_interval(self):
        self.sessions.duration = 3
        job_id = self.start()
        self.wait(lambda: len(self.sessions.starts) == 2)
        changed = deepcopy(self.settings)
        changed['collection'].update(concurrent_accounts=1, account_start_interval_seconds=100)
        self.assertEqual(self.client.put('/api/settings', json=changed).status_code, 200)
        self.sessions.release.set()
        job = self.finish(job_id)
        self.assertEqual(len(self.sessions.starts), 5)
        self.assertEqual(job['settings']['collection']['concurrent_accounts'], 2)
        self.assertEqual(job['settings']['collection']['account_start_interval_seconds'], .08)

    def test_bootstrap_exposes_the_complete_preset_values(self):
        result = self.client.get('/api/bootstrap').json()
        self.assertEqual(result['speed_presets'], speed_presets())
        self.assertIn('account_start_interval_seconds', result['defaults']['collection'])
