"""Local journal tests; synthetic accounts/pages only, no external services."""
import asyncio
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta, timezone
import json
from pathlib import Path
import sqlite3
import tempfile
import unittest
from unittest.mock import MagicMock, patch

from fastapi.testclient import TestClient

from murer.api import create_app
from murer.eventlog import EventLog
from murer.jobs import SafeLogger
from murer.rules import default_settings
from murer.safe_actions import SafeActions
from murer.secrets import SecretStore
from test_storage_api import MemoryVault, Scenario


class EventLogTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.log = EventLog(self.temp.name, max_rows=30)

    def test_restart_threads_and_stable_pagination(self):
        def write(i):
            self.log.emit('collection', 'step', f'Step {i}', run_id='run-a')
        with ThreadPoolExecutor(max_workers=4) as pool:
            list(pool.map(write, range(25)))
        first = self.log.query(limit=10)
        snapshot = first['latest_id']
        self.log.emit('system', 'status', 'New event during pagination')
        second = self.log.query(limit=10, before=first['next_before'], until=snapshot)
        third = self.log.query(limit=10, before=second['next_before'], until=snapshot)
        ids = [row['id'] for page in (first,second,third) for row in page['items']]
        self.assertEqual(len(ids), 25)
        self.assertEqual(len(set(ids)), 25)
        restarted = EventLog(self.temp.name)
        restarted.emit('system', 'lifecycle', 'Restart')
        self.assertGreater(restarted.query()['latest_id'], snapshot+1)

    def test_multi_filters_use_or_within_and_between(self):
        for domain in ('collection','trade'):
            for level in ('debug','info','warning','error'):
                self.log.emit(domain, 'result', f'{domain}:{level}', level=level, account_id='account-a', run_id='run-a')
        self.log.emit('system', 'error', 'other', level='error')
        page = self.log.query(domains=['collection','trade'], levels=['warning','error'], kinds=['result'], accounts=['account-a'])
        self.assertEqual(page['matching'], 4)
        self.assertEqual(self.log.query(levels=[])['items'], [])
        self.assertEqual(self.log.query(run_id='run-a')['matching'], 8)
        self.assertEqual(self.log.query(accounts=[''])['matching'], 1)

    def test_cyrillic_search_and_literal_wildcards(self):
        self.log.emit('collection', 'status', 'Ошибка обработки 100%_результата')
        self.log.emit('collection', 'status', '100_anything')
        self.assertEqual(self.log.query(q='ОШИБКА')['matching'], 1)
        self.assertEqual(self.log.query(q='%_')['matching'], 1)
        self.assertEqual(self.log.query(q="' OR 1=1 --")['matching'], 0)

    def test_secrets_are_redacted_before_disk_or_export(self):
        values = ('fixture password with spaces', '123456', 'private-cookie-value')
        self.log.protect(values)
        self.log.emit('auth', 'diagnostic', 'failed fixture password with spaces / 123456 / private-cookie-value',
            details={'password': 'never-written', 'nested': {'ct0_token': 'never-written-too'},
                     'reason': 'password="unknown multi word secret"; token=unknown-token; Cookie: other-cookie',
                     'url': 'https://someone:pass@example.org/path?code=private-code#private-fragment',
                     'github': 'ghp_fixturelongsecret'})
        page = self.log.query()
        text = json.dumps(page, ensure_ascii=False)
        for secret in (*values, 'never-written', 'unknown multi word secret', 'unknown-token', 'other-cookie',
                       'someone:pass', 'private-code', 'private-fragment', 'ghp_fixturelongsecret'):
            self.assertNotIn(secret, text)
        raw = self.log.path.read_bytes()
        for secret in values:
            self.assertNotIn(secret.encode(), raw)

    def test_row_age_and_payload_limits(self):
        for i in range(50):
            self.log.emit('system', 'status', str(i))
        self.assertEqual(self.log.query()['stored'], 30)
        with self.log._db() as db:
            db.execute('UPDATE events SET at=?', ((datetime.now(timezone.utc)-timedelta(days=20)).isoformat(),))
            db.commit()
        self.log.emit('system', 'progress', 'new', details={str(i): 'x'*2000 for i in range(30)})
        page = self.log.query()
        self.assertEqual(page['stored'], 1)
        self.assertLess(len(json.dumps(page['items'][0]['details']).encode()), 4000)

    def test_disk_failure_does_not_break_work_and_recovers_memory_events(self):
        self.log.emit('system', 'status', 'before')
        with patch.object(self.log, '_db', side_effect=sqlite3.OperationalError('disk full')):
            for i in range(5):
                self.log.emit('system', 'status', f'memory-{i}')
            page = self.log.query(q='MEMORY')
            self.assertEqual(page['matching'], 5)
            self.assertTrue(page['warning'])
        self.log.retry_at = 0
        self.log.emit('system', 'status', 'recovered')
        page = self.log.query()
        self.assertEqual(page['stored'], 7)
        self.assertFalse(page['warning'])
        self.assertEqual(page['memory_events'], 0)

    def test_existing_module_logger_keeps_levels_and_context(self):
        logger = SafeLogger(MagicMock(), (), self.log.emit, 'trade', 'account-a', 'run-a')
        logger.info('started'); logger.warning('waiting'); logger.error('failed')
        rows = self.log.query()['items']
        self.assertEqual([r['level'] for r in rows], ['error','warning','info'])
        self.assertTrue(all(r['domain']=='trade' and r['run_id']=='run-a' and r['account_id']=='account-a' for r in rows))

    def test_browser_actions_log_boundaries_but_never_script_arguments(self):
        browser = MagicMock()
        browser.execute_script.return_value = [1,2]
        events = []
        actions = SafeActions(browser, {'action_delay_seconds':0}, audit=lambda message, **fields: events.append((message, fields)))
        asyncio.run(actions.get('https://x.com/example'))
        asyncio.run(actions.script('return secret page contents', 'fixture-private-argument'))
        browser.get.side_effect = RuntimeError('fixture-private-argument')
        with self.assertRaises(RuntimeError):
            asyncio.run(actions.get('https://x.com/failed'))
        text = json.dumps(events, ensure_ascii=False)
        self.assertNotIn('secret page contents', text)
        self.assertNotIn('fixture-private-argument', text)
        self.assertTrue(any(fields['kind']=='error' for _,fields in events))
        self.assertTrue(any(fields['kind']=='navigation' for _,fields in events))

    def test_persistent_server_connection_is_thread_safe_and_closed(self):
        self.log.start()
        with ThreadPoolExecutor(max_workers=4) as pool:
            list(pool.map(lambda i: self.log.emit('system','status',str(i)), range(20)))
        self.assertIsNotNone(self.log.connection)
        self.assertEqual(self.log.query()['stored'], 20)
        self.log.close()
        self.assertIsNone(self.log.connection)
        self.assertEqual(EventLog(self.temp.name).query()['stored'], 20)

    def test_unavailable_at_start_can_recover_and_initialize_schema(self):
        with tempfile.TemporaryDirectory() as folder:
            with patch.object(EventLog, '_db', side_effect=sqlite3.OperationalError('unavailable')):
                log = EventLog(folder)
                log.emit('system','status','memory')
            log.retry_at = 0
            log.emit('system','status','disk')
            self.assertEqual(log.query()['stored'], 2)
            self.assertFalse(log.failure)

    def test_quoted_unknown_secrets_and_invalid_unicode_do_not_escape_redaction(self):
        logger = SafeLogger(MagicMock(), (), self.log.emit)
        logger.info('password="some unexpected multi word password"')
        self.log.emit('system','status','unpaired surrogate: \ud800')
        text = json.dumps(self.log.query())
        self.assertNotIn('unexpected', text)
        self.assertEqual(self.log.query()['stored'], 2)

    def test_pin_substrings_do_not_corrupt_opaque_account_filters(self):
        self.log.protect(['1234'])
        account_id = 'ccc01234-1ff8-1234-8300-afbb31123455'
        self.log.emit('collection','status','PIN 1234',account_id=account_id)
        self.assertEqual(self.log.query(accounts=[account_id])['matching'], 1)
        self.assertNotIn('1234', self.log.query()['items'][0]['message'])


class EventLogApiTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.scenario = Scenario()
        self.app = create_app(Path(self.temp.name), SecretStore(MemoryVault()), self.scenario.factory)
        self.state = self.app.state.application
        self.state.updates.start_auto_check = lambda: None
        self.client = TestClient(self.app)
        self.client.__enter__()
        self.addCleanup(self.client.__exit__, None, None, None)

    def test_log_reads_and_export_do_not_generate_recursive_events(self):
        original = self.state.events.query()['latest_id']
        for path in ('/api/logs', '/api/logs/options', '/api/logs/export', '/api/health', '/api/logs'):
            self.assertEqual(self.client.get(path).status_code, 200)
        self.assertEqual(self.state.events.query()['latest_id'], original)

    def test_validation_empty_selection_and_system_account_filter(self):
        self.assertEqual(self.client.get('/api/logs?levels=').json()['items'], [])
        for params in ('domains=wrong', 'levels=wrong', 'before=-1', 'limit=0', 'limit=999999'):
            self.assertEqual(self.client.get('/api/logs?'+params).status_code, 422)
        page = self.client.get('/api/logs?accounts=@none').json()
        self.assertTrue(page['items'])
        self.assertTrue(all(row['account_id']=='' for row in page['items']))

    def test_http_actions_rejections_and_secrets(self):
        self.client.post('/api/accounts', json={'username':'fixture','password':'fixture super secret','ichat_password':'654321'})
        self.client.post('/api/jobs', json={'account_ids':[]})
        self.client.post('/api/accounts', json={}, headers={'origin':'https://elsewhere.invalid'})
        text = self.client.get('/api/logs/export').text
        self.assertNotIn('fixture super secret', text)
        self.assertNotIn('654321', text)
        rows = [json.loads(line) for line in text.splitlines()]
        self.assertTrue(any(row['level']=='warning' for row in rows))
        self.assertTrue(any(row['kind']=='request' for row in rows))
        self.state.events.emit('auth','error','Vault error: fixture super secret and 654321',level='error')
        self.assertNotIn('fixture super secret', self.client.get('/api/logs').text)

    def test_export_all_filtered_pages_at_a_stable_snapshot(self):
        for i in range(510):
            self.state.events.emit('collection','result',f'row-{i}',account_id='fixture')
        snapshot = self.state.events.query()['latest_id']
        self.state.events.emit('collection','result','too-new',account_id='fixture')
        response = self.client.get(f'/api/logs/export?domains=collection&accounts=fixture&until={snapshot}')
        rows = [json.loads(line) for line in response.text.splitlines()]
        self.assertEqual(len(rows), 510)
        self.assertEqual(len({r['id'] for r in rows}), 510)
        self.assertTrue(all(r['id'] <= snapshot for r in rows))

    def test_collection_cycle_records_status_progress_saves_cache_and_finish(self):
        settings = default_settings()
        settings['collection'].update(profile_delay_seconds=0, group_delay_seconds=0, account_delay_seconds=0,
            account_start_interval_seconds=0, action_delay_seconds=0, load_wait_seconds=0, refresh_mode='all')
        self.client.put('/api/settings', json=settings)
        account = self.client.post('/api/accounts', json={'username':'fixture'}).json()
        job = self.client.post('/api/jobs', json={'account_ids':[account['id']],'mode':'collect'}).json()
        self.state.jobs.threads[job['id']].join(15)
        self.assertFalse(self.state.jobs.threads[job['id']].is_alive())
        page = self.client.get('/api/logs?run_id='+job['id']+'&limit=500').json()
        kinds = {r['kind'] for r in page['items']}
        self.assertTrue({'lifecycle','status','progress','checkpoint','result','cache'} <= kinds, kinds)
        self.assertEqual(self.state.store.job(job['id'])['status'], 'completed')
        self.assertTrue(any(r['message']=='Снимок данных и анализа задания сохранён' for r in page['items']))

    def test_update_phase_changes_are_logged_without_chunk_flood(self):
        with tempfile.TemporaryDirectory() as folder:
            self.state.updates.directory = Path(folder)
            self.state.updates._set(phase='checking',message='checking')
            self.state.updates._set(progress=1)
            self.state.updates._set(progress=2)
            self.state.updates._set(phase='error',message='fixture failure')
        rows = self.state.events.query(domains=['updates'])['items']
        self.assertEqual(len(rows), 2)
        self.assertEqual(rows[0]['level'], 'error')


if __name__ == '__main__':
    unittest.main()
