"""Opt-in visible Selenium UI verification with an isolated, synthetic backend.

Does not access X, real accounts, the normal application port or its data folder.
Run: .venv/Scripts/python.exe tests/ui_smoke.py --chrome PATH --driver PATH
"""
import argparse
import csv
import io
import json
import os
import re
from pathlib import Path
import sys
import tempfile
import threading
import time
import traceback
from urllib.parse import parse_qs, urlsplit
from urllib.request import urlopen
from unittest.mock import patch

import uvicorn
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / 'tests'))
from murer.api import create_app
from murer.secrets import SecretStore
from test_storage_api import MemoryVault, Scenario


async def synthetic_launch_failure(*args, **kwargs):
    return {'launch_ok': False, 'launch_message': 'Synthetic Chrome startup failure for UI verification'}


def run(chrome, driver_path, port=8766):
    artifacts = ROOT / 'artifacts'
    artifacts.mkdir(exist_ok=True)
    report = {'synthetic_data': True, 'real_x_access': False, 'visible_browser': False, 'checks': [], 'passed': False}
    browser = None
    server = None
    thread = None
    base = f'http://127.0.0.1:{port}'
    with tempfile.TemporaryDirectory(prefix='murer_ui_smoke_') as folder:
        scenario = Scenario()
        scenario.groups.append({'x_id': '9003', 'name': 'Fixture chat C', 'url': 'https://x.com/i/chat/9003', 'declared_count': 1})
        scenario.people['9003'] = [{'username': 'third', 'x_id': '44'}]
        app = create_app(Path(folder) / 'data', SecretStore(MemoryVault()), scenario.factory)
        state = app.state.application
        state.configuration.update(configured=False, chrome_path=chrome, driver_path=driver_path)
        settings, _ = state.store.settings()
        settings['collection'].update(profile_delay_seconds=0, group_delay_seconds=0, account_delay_seconds=0,
            action_delay_seconds=0, account_start_interval_seconds=0, load_wait_seconds=0, refresh_mode='all')
        state.store.save_settings(settings)
        server = uvicorn.Server(uvicorn.Config(app, host='127.0.0.1', port=port, log_level='error', access_log=False))
        thread = threading.Thread(target=server.run, daemon=True)
        thread.start()
        try:
            deadline = time.monotonic() + 15
            while not server.started and time.monotonic() < deadline:
                if not thread.is_alive():
                    raise RuntimeError('Isolated UI server could not bind its port')
                time.sleep(.05)
            assert server.started, 'Isolated UI server did not start'
            options = webdriver.ChromeOptions()
            options.binary_location = chrome
            options.add_argument(f'--user-data-dir={Path(folder) / "ui-browser"}')
            options.add_argument('--no-first-run')
            options.add_argument('--no-default-browser-check')
            options.add_argument('--window-size=1500,1050')
            downloads = Path(folder) / 'downloads'
            downloads.mkdir()
            options.add_experimental_option('prefs', {'download.default_directory': str(downloads), 'download.prompt_for_download': False})
            options.set_capability('goog:loggingPrefs', {'browser': 'ALL'})
            browser = webdriver.Chrome(service=Service(driver_path), options=options)
            report['visible_browser'] = True
            wait = WebDriverWait(browser, 15)

            def check(name, condition=True):
                assert condition, name
                report['checks'].append(name)

            def text():
                return browser.find_element(By.TAG_NAME, 'body').text

            def click_text(label, tag='button', context=''):
                xpath = f"{context}//{tag}[normalize-space(.)={json.dumps(label, ensure_ascii=False)}]"
                element = wait.until(EC.element_to_be_clickable((By.XPATH, xpath)))
                browser.execute_script('arguments[0].scrollIntoView({block:"center"})', element)
                element.click()

            def nav(label):
                click_text(label, context='//aside')
                wait.until(lambda d: d.find_element(By.TAG_NAME, 'h1').text == label)

            def set_input(element_id, value):
                element = wait.until(EC.visibility_of_element_located((By.ID, element_id)))
                element.send_keys(Keys.CONTROL, 'a')
                element.send_keys(Keys.BACKSPACE)
                if value:
                    element.send_keys(value)

            def get_json(path):
                with urlopen(base + '/api' + path, timeout=10) as response:
                    return json.load(response)

            def choose(select_id, label):
                wait.until(EC.element_to_be_clickable((By.ID, select_id))).click()
                option = wait.until(EC.element_to_be_clickable((By.XPATH, f'//*[@role="option" and normalize-space(.)={json.dumps(label, ensure_ascii=False)}]')))
                option.click()

            def edit_account(username):
                row = next(row for row in browser.find_elements(By.CSS_SELECTOR, 'tbody tr') if '@' + username in row.text)
                row.find_element(By.CSS_SELECTOR, 'button[title="Редактировать"]').click()
                wait.until(EC.visibility_of_element_located((By.ID, 'account-ichat_password')))

            browser.get(base)
            wait.until(lambda _: 'Подготовим локальное приложение' in text())
            check('first_run_wizard')
            with patch('murer.diagnostics.launch_check', side_effect=synthetic_launch_failure):
                click_text('Проверить совместимость')
                wait.until(lambda _: 'Пробный запуск Chrome завершился ошибкой.' in text())
                check('compatible_versions_do_not_hide_launch_failure', 'Synthetic Chrome startup failure' in text())
            click_text('Сохранить')
            wait.until(EC.invisibility_of_element_located((By.CSS_SELECTOR, '[role="dialog"]')))
            check('setup_saved', get_json('/bootstrap')['setup']['configured'])

            for page in ['Обзор', 'Аккаунты', 'Группы', 'Участники', 'Пересечения', 'Наши аккаунты', 'Правила оценки', 'История сборов', 'Настройки']:
                nav(page)
                check('page_' + page)
            nav('Аккаунты')
            click_text('Добавить аккаунт')
            set_input('account-username', 'owner')
            set_input('account-password', 'synthetic-ui-secret')
            set_input('account-ichat_password', '1234')
            check('distinct_x_and_ichat_password_fields', browser.find_element(By.ID, 'account-ichat_password').get_attribute('type') == 'password' and 'Пароль X' in text() and 'Пароль / PIN iChat' in text())
            click_text('Сохранить аккаунт')
            wait.until(lambda _: '@owner' in text() and not browser.find_elements(By.CSS_SELECTOR, '[role="dialog"]'))
            check('account_added_secret_masked', 'synthetic-ui-secret' not in text())
            owner = get_json('/accounts')[0]
            check('ichat_secret_flag_only', owner['has_ichat_password'] and 'ichat_password' not in owner and state.secrets.get(owner['id'])['password'] == 'synthetic-ui-secret' and state.secrets.get(owner['id'])['ichat_password'] == '1234')

            edit = browser.find_element(By.CSS_SELECTOR, 'button[title="Редактировать"]')
            edit.click()
            wait.until(EC.visibility_of_element_located((By.ID, 'account-ichat_password')))
            check('saved_ichat_password_never_echoed', browser.find_element(By.ID, 'account-ichat_password').get_attribute('value') == '' and 'Сохранён' in browser.find_element(By.ID, 'account-ichat_password').get_attribute('placeholder'))
            set_input('account-group', 'UI fixture label')
            click_text('Сохранить аккаунт')
            wait.until(lambda _: not browser.find_elements(By.CSS_SELECTOR, '[role="dialog"]'))
            check('blank_credential_preserves_secret', get_json('/accounts')[0]['has_password'] and get_json('/accounts')[0]['has_ichat_password'])
            browser.find_element(By.CSS_SELECTOR, 'button[title="Редактировать"]').click()
            click_text('Удалить сохранённый пароль X')
            click_text('Сохранить аккаунт')
            wait.until(lambda _: not browser.find_elements(By.CSS_SELECTOR, '[role="dialog"]'))
            check('explicit_credential_removal', not get_json('/accounts')[0]['has_password'] and get_json('/accounts')[0]['has_ichat_password'])
            edit_account('owner')
            click_text('Удалить сохранённый пароль iChat')
            click_text('Сохранить аккаунт')
            wait.until(lambda _: not browser.find_elements(By.CSS_SELECTOR, '[role="dialog"]'))
            check('explicit_individual_ichat_removal', not get_json('/accounts')[0]['has_ichat_password'])
            edit_account('owner')
            set_input('account-ichat_password', '1234')
            click_text('Сохранить аккаунт')
            wait.until(lambda _: not browser.find_elements(By.CSS_SELECTOR, '[role="dialog"]'))

            click_text('Добавить аккаунт')
            set_input('account-username', 'secondowner')
            click_text('Сохранить аккаунт')
            wait.until(lambda _: '@secondowner' in text() and not browser.find_elements(By.CSS_SELECTOR, '[role="dialog"]'))
            second = next(account for account in get_json('/accounts') if account['username'] == 'secondowner')
            click_text('Пароль iChat')
            check('bulk_ichat_requires_explicit_scope', 'Выберите область изменения' in text() and not browser.find_element(By.XPATH, '//button[normalize-space(.)="Сохранить пароль iChat"]').is_enabled())
            click_text('Отмена')
            browser.find_element(By.CSS_SELECTOR, 'button[aria-label="Выбрать owner"]').click()
            click_text('Пароль iChat')
            check('bulk_ichat_selected_scope', browser.find_element(By.ID, 'ichat-password-scope').text == 'Выбранные (1)')
            set_input('ichat-bulk-password', '9999')
            click_text('Сохранить пароль iChat')
            wait.until(lambda _: 'Обновлено: 0; пропущено: 1; всего: 1.' in text())
            check('bulk_ichat_only_missing_skips_saved', state.secrets.get(owner['id'])['ichat_password'] == '1234' and not state.secrets.get(second['id'])['ichat_password'])
            click_text('Готово')
            click_text('Пароль iChat')
            choose('ichat-password-scope', 'Все рабочие (2)')
            set_input('ichat-bulk-password', '8888')
            click_text('Сохранить пароль iChat')
            wait.until(lambda _: 'Обновлено: 1; пропущено: 1; всего: 2.' in text())
            check('bulk_ichat_all_working_missing_only', state.secrets.get(owner['id'])['ichat_password'] == '1234' and state.secrets.get(second['id'])['ichat_password'] == '8888')
            click_text('Готово')
            click_text('Пароль iChat')
            choose('ichat-password-overwrite', 'Заменить у всех в выбранной области')
            set_input('ichat-bulk-password', '7777')
            check('bulk_ichat_input_masked', browser.find_element(By.ID, 'ichat-bulk-password').get_attribute('type') == 'password' and '7777' not in text())
            click_text('Сохранить пароль iChat')
            wait.until(lambda _: 'Обновлено: 1; пропущено: 0; всего: 1.' in text())
            check('bulk_ichat_replaces_selected_only', state.secrets.get(owner['id'])['ichat_password'] == '7777' and state.secrets.get(second['id'])['ichat_password'] == '8888')
            browser.save_screenshot(str(artifacts / 'ui-ichat-password-result.png'))
            click_text('Готово')
            click_text('Пароль iChat')
            choose('ichat-password-operation', 'Удалить сохранённые пароли iChat')
            check('bulk_ichat_delete_requires_confirmation', not browser.find_element(By.XPATH, '//button[normalize-space(.)="Удалить пароли iChat"]').is_enabled())
            browser.find_element(By.ID, 'ichat-password-clear-confirm').click()
            click_text('Удалить пароли iChat')
            wait.until(lambda _: 'Удаление завершено.' in text())
            check('bulk_ichat_explicit_delete_selected_only', not state.secrets.get(owner['id'])['ichat_password'] and state.secrets.get(second['id'])['ichat_password'] == '8888')
            click_text('Готово')
            click_text('Пароль iChat')
            set_input('ichat-bulk-password', '1111')
            browser.execute_script('''const original = window.fetch; window.fetch = (...args) => {
                if (String(args[0]) === '/api/accounts/ichat-password/bulk') {
                    window.fetch = original;
                    return Promise.reject(new Error('Synthetic bulk request failure'));
                }
                return original(...args);
            };''')
            click_text('Сохранить пароль iChat')
            wait.until(lambda _: 'Synthetic bulk request failure' in text())
            check('bulk_ichat_error_visible_no_false_success', 'Пароль iChat сохранён.' not in text() and not state.secrets.get(owner['id'])['ichat_password'])
            click_text('Отмена')
            browser.find_element(By.CSS_SELECTOR, 'button[aria-label="Выбрать owner"]').click()

            click_text('Импорт')
            area = browser.find_element(By.CSS_SELECTOR, 'textarea[aria-label="Данные импорта"]')
            area.send_keys('[{"username":"owner"},{"username":"invalid user"}]')
            click_text('Проверить формат')
            wait.until(lambda _: 'Строка 2:' in text())
            check('invalid_import_preview_blocks_submit', not browser.find_element(By.XPATH, '//button[normalize-space(.)="Импортировать"]').is_enabled())
            click_text('Отмена')

            state.store.execute("UPDATE accounts SET status='proxy_error',reason='Synthetic proxy error' WHERE id=?", (owner['id'],))
            state.publish({'type': 'accounts'})
            wait.until(lambda _: 'Ошибка прокси' in text())
            check('account_error_visible', 'Synthetic proxy error' in text())
            scenario.manual_once = True
            click_text('Начать сбор')
            wait.until(lambda _:'Synthetic confirmation' in text() and 'Продолжить после ручного подтверждения' in text())
            check('specific_manual_reason_visible',get_json('/history')[0]['status']=='requires_manual')
            click_text('Продолжить после ручного подтверждения')
            wait.until(lambda _: bool(get_json('/history')) and get_json('/history')[0]['status'] in ('completed', 'partial'))
            wait.until(lambda _: get_json('/analysis')['summary']['group_count'] == 3)
            check('synthetic_vertical_collection_saved', scenario.count('profile') == 4)

            nav('Группы')
            wait.until(lambda _: 'Fixture chat A' in text())
            browser.save_screenshot(str(artifacts / 'ui-groups-light.png'))
            rows = browser.find_elements(By.CSS_SELECTOR, 'tbody tr')
            check('group_rows_and_values', len(rows) == 3 and '1200' in re.sub(r'\s', '', text()))
            search = browser.find_element(By.CSS_SELECTOR, 'input[aria-label="Поиск в таблице"]')
            search.send_keys('Fixture chat A')
            wait.until(lambda _: len(browser.find_elements(By.CSS_SELECTOR, 'tbody tr')) == 1)
            csv_link = browser.find_element(By.XPATH, '//a[normalize-space(.)="CSV"]')
            query = parse_qs(urlsplit(csv_link.get_attribute('href')).query)
            check('filtered_export_has_exact_row_ids', len(json.loads(query['row_ids'][0])) == 1)
            with urlopen(csv_link.get_attribute('href'), timeout=10) as response:
                exported = list(csv.DictReader(io.StringIO(response.read().decode('utf-8-sig')), delimiter=';'))
            check('filtered_csv_download', len(exported) == 1 and exported[0]['name'] == 'Fixture chat A' and 'export_metadata' in exported[0])
            csv_link.click()
            wait.until(lambda _: (downloads / 'murer-groups.csv').is_file())
            downloaded = list(csv.DictReader(io.StringIO((downloads / 'murer-groups.csv').read_text(encoding='utf-8-sig')), delimiter=';'))
            check('csv_button_post_download', len(downloaded) == 1 and downloaded[0]['name'] == 'Fixture chat A')
            search.send_keys(Keys.CONTROL, 'a'); search.send_keys(Keys.BACKSPACE)
            click_text('Колонки')
            menu_item = wait.until(EC.element_to_be_clickable((By.XPATH, '//*[@role="menuitemcheckbox" and normalize-space(.)="Наши"]')))
            menu_item.click()
            browser.find_element(By.TAG_NAME, 'body').send_keys(Keys.ESCAPE)
            check('column_visibility_changes_export', 'own_count' not in parse_qs(urlsplit(browser.find_element(By.XPATH, '//a[normalize-space(.)="CSV"]').get_attribute('href')).query)['columns'][0])
            click_text('Подписчики · мед.')
            check('table_sort_changes_export', parse_qs(urlsplit(browser.find_element(By.XPATH, '//a[normalize-space(.)="CSV"]').get_attribute('href')).query)['sort'][0] == 'followers_median')
            browser.find_elements(By.CSS_SELECTOR, 'tbody tr')[0].click()
            wait.until(lambda _: bool(browser.find_elements(By.CSS_SELECTOR, '[role="dialog"]')))
            click_text('Расчёт оценки')
            check('group_score_details', 'Действующий вес' in text() and 'Покрытие' in text())
            browser.save_screenshot(str(artifacts / 'ui-group-score.png'))
            browser.find_element(By.TAG_NAME, 'body').send_keys(Keys.ESCAPE)

            nav('Участники')
            wait.until(lambda _: '@person' in text())
            check('profile_metric_objects_rendered', '56100' in re.sub(r'\s', '', text()) and '≈' in text())
            row = next(r for r in browser.find_elements(By.CSS_SELECTOR, 'tbody tr') if '@person' in r.text)
            row.click()
            wait.until(lambda _: '56.1K posts' in text())
            wait.until(EC.visibility_of_element_located((By.CSS_SELECTOR, '[role="dialog"] a[href*="/status/"]')))
            check('participant_card_raw_metrics_and_posts', 'Дата действия участника' in text() and all('posts' not in p for p in get_json('/analysis')['participants']))
            browser.find_element(By.TAG_NAME, 'body').send_keys(Keys.ESCAPE)

            nav('Пересечения')
            for title, value in [('Первая группа', 'Fixture chat A'), ('Вторая группа', 'Fixture chat C')]:
                browser.find_element(By.CSS_SELECTOR, f'button[aria-label="{title}"]').click()
                wait.until(EC.element_to_be_clickable((By.XPATH, f'//*[@role="option" and normalize-space(.)="{value}"]'))).click()
            click_text('Сравнить')
            wait.until(lambda _: 'Новых для первой из второй' in text())
            check('disjoint_pair_comparison_visible', 'Общих участников' in text())
            browser.save_screenshot(str(artifacts / 'ui-pair-comparison.png'))

            nav('Правила оценки')
            prior = len(scenario.instances)
            revision = get_json('/bootstrap')['settings_version']
            set_input('evaluation-followers_high', '2500')
            wait.until(lambda _: get_json('/bootstrap')['settings_version'] > revision)
            wait.until(lambda _: 'Сохранено и пересчитано' in text())
            check('rules_recalculate_without_collection', len(scenario.instances) == prior and get_json('/analysis')['settings']['evaluation']['followers_high'] == 2500)
            revision = get_json('/bootstrap')['settings_version']
            set_input('evaluation-followers_high', '')
            wait.until(lambda _: 'Последние валидные настройки' in text())
            time.sleep(.8)
            check('blank_numeric_input_keeps_valid_settings', get_json('/bootstrap')['settings_version'] == revision)
            set_input('evaluation-followers_high', '5000')
            wait.until(lambda _: get_json('/bootstrap')['settings']['evaluation']['followers_high'] == 5000)
            nav('Настройки')
            original_volume = get_json('/bootstrap')['settings']['collection']['posts_limit']
            click_text('Медленная')
            wait.until(lambda _: get_json('/bootstrap')['settings']['collection']['account_start_interval_seconds'] == 30)
            check('slow_speed_preset_applies_without_changing_volume', get_json('/bootstrap')['settings']['collection']['posts_limit'] == original_volume)
            click_text('Все значения встроенных режимов', 'summary')
            check('speed_preset_values_are_visible', 'Хьюманизация · Задержка действий' in text() and 'Интервал запуска аккаунтов' in text())
            click_text('Средняя')
            wait.until(lambda _: get_json('/bootstrap')['settings']['collection']['profile_delay_seconds'] == 3)
            click_text('Быстрая')
            wait.until(lambda _: get_json('/bootstrap')['settings']['collection']['action_delay_seconds'] == .25)
            set_input('collection-concurrent_accounts', '3')
            check('start_waits_until_settings_are_saved', not browser.find_element(By.XPATH, '//header//button[contains(.,"сбор") or contains(.,"Дособрать")]').is_enabled())
            set_input('collection-account_start_interval_seconds', '12')
            wait.until(lambda _: get_json('/bootstrap')['settings']['collection']['account_start_interval_seconds'] == 12)
            check('manual_speed_and_concurrency_persist', get_json('/bootstrap')['settings']['collection']['concurrent_accounts'] == 3 and 'Текущий режим: Ручные настройки' in text())
            browser.save_screenshot(str(artifacts / 'ui-speed-presets.png'))
            click_text('Средняя')
            wait.until(lambda _: get_json('/bootstrap')['settings']['collection']['account_start_interval_seconds'] == 5)
            check('speed_preset_preserves_parallel_account_limit', get_json('/bootstrap')['settings']['collection']['concurrent_accounts'] == 3 and len(scenario.instances) == prior)
            set_input('collection-posts_limit', '101')
            wait.until(lambda _: get_json('/bootstrap')['settings']['collection']['posts_limit'] == 101)
            wait.until(lambda _: 'Для текущих требований данных недостаточно' in text())
            check('increased_volume_requests_more_data', len(scenario.instances) == prior)
            nav('История сборов')
            check('history_has_frozen_snapshot', get_json('/history')[0]['snapshot'] is not None)
            browser.find_element(By.CSS_SELECTOR, 'button[aria-label="Переключить тему"]').click()
            check('dark_theme', 'dark' in browser.find_element(By.TAG_NAME, 'html').get_attribute('class'))
            browser.save_screenshot(str(artifacts / 'ui-history-dark.png'))
            severe = [entry for entry in browser.get_log('browser') if entry['level'] == 'SEVERE' and 'favicon' not in entry['message']]
            check('no_browser_runtime_errors', not severe)
            report['passed'] = True
        except Exception as exc:
            report['error'] = f'{type(exc).__name__}: {exc}'
            report['traceback'] = traceback.format_exc()
            if browser:
                browser.save_screenshot(str(artifacts / 'ui-failure.png'))
        finally:
            if browser:
                browser.quit()
            if server:
                server.should_exit = True
            if thread:
                thread.join(15)
            (artifacts / 'ui-smoke.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if report['passed'] else 1


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    test_browser = Path(os.environ.get('LOCALAPPDATA', '')) / 'MurerGroupStats' / 'browser-test'
    parser.add_argument('--chrome', default=str(test_browser / 'chrome-win64' / 'chrome.exe'))
    parser.add_argument('--driver', default=str(test_browser / 'chromedriver-win64' / 'chromedriver.exe'))
    parser.add_argument('--port', type=int, default=8766)
    args = parser.parse_args()
    sys.exit(run(args.chrome, args.driver, args.port))
