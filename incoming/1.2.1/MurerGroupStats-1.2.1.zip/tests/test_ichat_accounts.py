"""Separate iChat credentials through the real local API and a synthetic OS vault.

These tests never open Chrome, touch an existing user profile, or contact X.
"""
from copy import deepcopy
import io
import json
from pathlib import Path
import tempfile
import time
import unittest
from unittest.mock import MagicMock, patch

from fastapi.testclient import TestClient
from openpyxl import load_workbook

from murer.api import create_app
from murer.exporting import clean, csv_report, excel_report
from murer.secrets import SecretStore, redact
from tests.test_storage_api import FakeSession, MemoryVault, Scenario


class FailOnceVault(MemoryVault):
    """A vault failure after one successful write exercises actual rollback."""
    def __init__(self):
        super().__init__()
        self.fail_key = None

    def set_password(self, service, username, password):
        if username == self.fail_key:
            self.fail_key = None
            raise RuntimeError('Synthetic vault failure while saving ' + password)
        super().set_password(service, username, password)


class IChatAccountTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.vault = MemoryVault()
        self.secrets = SecretStore(self.vault)
        self.app = create_app(Path(self.temporary.name), self.secrets)
        self.state = self.app.state.application
        self.client = TestClient(self.app)
        self.client.__enter__()
        self.addCleanup(self.client.__exit__, None, None, None)

    def account(self, username='fixture_owner', **values):
        response = self.client.post('/api/accounts', json={'username': username, **values})
        self.assertEqual(response.status_code, 200, response.text)
        return response.json()

    def bulk(self, account_ids, password='fixture-shared-chat-secret', overwrite=False, **values):
        body = {'account_ids': account_ids, 'password': password, 'overwrite': overwrite, **values}
        return self.client.post('/api/accounts/ichat-password/bulk', json=body)

    def assert_rejected_without_changes(self, body):
        before = deepcopy(self.vault.values)
        response = self.client.post('/api/accounts/ichat-password/bulk', json=body)
        self.assertEqual(response.status_code, 422, response.text)
        self.assertEqual(self.vault.values, before, 'Validation must finish before any vault mutation')
        if isinstance(body, dict):
            supplied = body.get('password')
            if isinstance(supplied, str) and supplied:
                self.assertNotIn(supplied, response.text, 'Validation errors must not echo the password')
        return response

    def test_individual_ichat_secret_is_separate_from_x_password(self):
        account = self.account(password='fixture-x-password', ichat_password='fixture-chat-password')
        private = self.secrets.get(account['id'])
        self.assertEqual(private['password'], 'fixture-x-password')
        self.assertEqual(private['ichat_password'], 'fixture-chat-password')
        self.assertTrue(account['has_password'])
        self.assertTrue(account['has_ichat_password'])
        self.assertNotIn('password', account)
        self.assertNotIn('ichat_password', account)
        for path in ('/api/accounts', '/api/bootstrap'):
            response = self.client.get(path)
            self.assertEqual(response.status_code, 200)
            self.assertNotIn('fixture-x-password', response.text)
            self.assertNotIn('fixture-chat-password', response.text)
        self.assertNotIn(b'fixture-chat-password', self.state.store.path.read_bytes())
        columns = {row['name'] for row in self.state.store.rows('PRAGMA table_info(accounts)')}
        self.assertNotIn('ichat_password', columns)

    def test_individual_edit_preserves_other_secrets_and_explicit_clear(self):
        account = self.account(password='fixture-x-password', ichat_password='fixture-before-chat')
        path = '/api/accounts/' + account['id']
        self.assertEqual(self.client.patch(path, json={'group': 'Other'}).status_code, 200)
        self.assertEqual(self.secrets.get(account['id'])['ichat_password'], 'fixture-before-chat')
        response = self.client.patch(path, json={'ichat_password': 'fixture-after-chat'})
        self.assertEqual(response.status_code, 200, response.text)
        self.assertTrue(response.json()['has_ichat_password'])
        self.assertEqual(self.secrets.get(account['id'])['password'], 'fixture-x-password')
        self.assertEqual(self.secrets.get(account['id'])['ichat_password'], 'fixture-after-chat')
        response = self.client.patch(path, json={'ichat_password': ''})
        self.assertEqual(response.status_code, 200, response.text)
        self.assertFalse(response.json()['has_ichat_password'])
        self.assertEqual(self.secrets.get(account['id'])['password'], 'fixture-x-password')

    def test_missing_ichat_password_is_optional_for_existing_accounts(self):
        account = self.account(password='fixture-x-password')
        self.assertFalse(account['has_ichat_password'])
        self.assertEqual(self.secrets.get(account['id'])['ichat_password'], '')

    def test_legacy_and_extended_import_preserve_credentials_without_preview_exposure(self):
        rows = [
            {'username': 'Legacy', 'password': 'fixture-legacy-x', 'auth_token': 'fixture-legacy-token',
             'ct0_token': 'fixture-legacy-ct0', 'proxy': 'host:8080:user:pass', 'headless': False, 'group': 'Legacy'},
            {'username': 'Newchat', 'password': 'fixture-new-x', 'ichat_password': 'fixture-import-chat',
             'user_agent': 'fixture-agent', 'headless': True},
        ]
        payload = {'text': json.dumps({'accounts': rows})}
        preview = self.client.post('/api/import/preview', json=payload)
        self.assertEqual(preview.status_code, 200, preview.text)
        self.assertEqual(preview.json()['valid_count'], 2)
        for row in rows:
            for field in ('password', 'ichat_password', 'auth_token', 'ct0_token', 'proxy'):
                if row.get(field):
                    self.assertNotIn(row[field], preview.text)
        imported = self.client.post('/api/import', json=payload)
        self.assertEqual(imported.status_code, 200, imported.text)
        accounts = imported.json()['accounts']
        self.assertEqual(len(accounts), 2)
        self.assertFalse(accounts[0]['has_ichat_password'])
        self.assertTrue(accounts[1]['has_ichat_password'])
        self.assertEqual(self.secrets.get(accounts[1]['id'])['ichat_password'], 'fixture-import-chat')
        self.assertEqual(self.secrets.get(accounts[0]['id'])['password'], 'fixture-legacy-x')
        self.assertEqual(self.client.post('/api/import', json=payload).json()['accounts'][1]['id'], accounts[1]['id'])
        self.assertEqual(len(self.state.store.accounts()), 2)

    def test_extended_csv_import_handles_ichat_password(self):
        text = 'username,password,ichat_password,headless\nfixture_csv,fixture-csv-x,fixture-csv-chat,false\n'
        preview = self.client.post('/api/import/preview', json={'text': text})
        self.assertEqual(preview.status_code, 200, preview.text)
        self.assertEqual(preview.json()['valid_count'], 1)
        self.assertNotIn('fixture-csv-chat', preview.text)
        response = self.client.post('/api/import', json={'text': text})
        self.assertEqual(response.status_code, 200, response.text)
        account = response.json()['accounts'][0]
        self.assertEqual(self.secrets.get(account['id'])['ichat_password'], 'fixture-csv-chat')

    def test_bulk_updates_explicit_selection_only_and_preserves_x_password(self):
        first = self.account('fixture_first', password='fixture-first-x')
        second = self.account('fixture_second', password='fixture-second-x')
        omitted = self.account('fixture_omitted', ichat_password='fixture-omitted-chat')
        response = self.bulk([first['id'], second['id']])
        self.assertEqual(response.status_code, 200, response.text)
        self.assertEqual(response.json(), {'updated': 2, 'skipped': 0, 'total': 2})
        for account in (first, second):
            self.assertEqual(self.secrets.get(account['id'])['ichat_password'], 'fixture-shared-chat-secret')
        self.assertEqual(self.secrets.get(first['id'])['password'], 'fixture-first-x')
        self.assertEqual(self.secrets.get(second['id'])['password'], 'fixture-second-x')
        self.assertEqual(self.secrets.get(omitted['id'])['ichat_password'], 'fixture-omitted-chat')
        self.assertNotIn('fixture-shared-chat-secret', response.text)

    def test_bulk_all_means_explicit_ids_of_working_accounts(self):
        first, second = self.account('fixture_first'), self.account('fixture_second')
        archived = self.account('fixture_arch', ichat_password='fixture-archived-chat')
        self.assertEqual(self.client.delete('/api/accounts/' + archived['id']).status_code, 200)
        working_ids = [a['id'] for a in self.client.get('/api/accounts').json() if not a['archived']]
        self.assertEqual(set(working_ids), {first['id'], second['id']})
        response = self.bulk(working_ids)
        self.assertEqual(response.status_code, 200, response.text)
        self.assertEqual(response.json()['updated'], 2)
        self.assertEqual(self.secrets.get(archived['id'])['ichat_password'], 'fixture-archived-chat')

    def test_bulk_only_missing_preserves_individual_values_then_overwrite_is_explicit(self):
        existing = self.account('fixture_exists', ichat_password='fixture-individual-chat')
        missing = self.account('fixture_missing')
        selected = [existing['id'], missing['id']]
        response = self.client.post('/api/accounts/ichat-password/bulk', json={
            'account_ids': selected, 'password': 'fixture-shared-chat-secret'})
        self.assertEqual(response.status_code, 200, response.text)
        self.assertEqual(response.json(), {'updated': 1, 'skipped': 1, 'total': 2})
        self.assertEqual(self.secrets.get(existing['id'])['ichat_password'], 'fixture-individual-chat')
        self.assertEqual(self.secrets.get(missing['id'])['ichat_password'], 'fixture-shared-chat-secret')
        response = self.bulk(selected, password='fixture-replacement-chat', overwrite=True)
        self.assertEqual(response.status_code, 200, response.text)
        self.assertEqual(response.json(), {'updated': 2, 'skipped': 0, 'total': 2})
        for account in (existing, missing):
            self.assertEqual(self.secrets.get(account['id'])['ichat_password'], 'fixture-replacement-chat')

    def test_bulk_clear_requires_explicit_mode_and_does_not_clear_x_password(self):
        account = self.account(password='fixture-x-password', ichat_password='fixture-chat-secret')
        response = self.client.post('/api/accounts/ichat-password/bulk', json={
            'account_ids': [account['id']], 'clear': True, 'overwrite': True})
        self.assertEqual(response.status_code, 200, response.text)
        self.assertEqual(response.json(), {'updated': 1, 'skipped': 0, 'total': 1})
        self.assertEqual(self.secrets.get(account['id'])['ichat_password'], '')
        self.assertEqual(self.secrets.get(account['id'])['password'], 'fixture-x-password')
        self.assertFalse(self.client.get('/api/accounts').json()[0]['has_ichat_password'])

    def test_bulk_rejects_missing_implicit_unknown_archived_or_malformed_targets_atomically(self):
        account = self.account(ichat_password='fixture-original-chat')
        archived = self.account('fixture_arch', ichat_password='fixture-archived-chat')
        self.client.delete('/api/accounts/' + archived['id'])
        invalid_ids = (None, [], 'all', [None], [123], [account['id'], 'missing-id'],
                       [account['id'], archived['id']], [account['id'], account['id']])
        for targets in invalid_ids:
            with self.subTest(targets=targets):
                self.assert_rejected_without_changes({'account_ids': targets,
                    'password': 'fixture-must-not-be-written', 'overwrite': True})
        self.assert_rejected_without_changes({'password': 'fixture-must-not-be-written', 'overwrite': True})
        self.assert_rejected_without_changes({'account_ids': [account['id']],
            'password': 'fixture-must-not-be-written', 'overwrite': True, 'all': True})

    def test_bulk_rejects_invalid_passwords_and_clear_combinations_without_echo(self):
        account = self.account(ichat_password='fixture-original-chat')
        base = {'account_ids': [account['id']], 'overwrite': True}
        for password in (None, '', 123, False, [], {}, 'x' * 129, 'fixture\nsecret', 'fixture\rsecret',
                         'fixture\tsecret', 'fixture\x00secret', 'fixture\ue007secret'):
            with self.subTest(kind=type(password).__name__, length=len(password) if isinstance(password, str) else None):
                self.assert_rejected_without_changes({**base, 'password': password})
        self.assert_rejected_without_changes(base)
        self.assert_rejected_without_changes({**base, 'password': 'fixture-secret', 'clear': True})
        self.assert_rejected_without_changes({'account_ids': [account['id']], 'clear': True, 'overwrite': False})
        self.assert_rejected_without_changes({'account_ids': [account['id']], 'clear': True})
        self.assert_rejected_without_changes({**base, 'password': 'fixture-secret', 'overwrite': 'true'})
        self.assert_rejected_without_changes({**base, 'password': 'fixture-secret', 'clear': 'false'})

    def test_password_maximum_boundary_and_non_ascii_are_preserved(self):
        account = self.account()
        value = 'Я' * 128
        response = self.bulk([account['id']], password=value)
        self.assertEqual(response.status_code, 200, response.text)
        self.assertEqual(self.secrets.get(account['id'])['ichat_password'], value)

    def test_individual_invalid_ichat_password_is_rejected_before_other_secret_mutation(self):
        account = self.account(password='fixture-original-x', ichat_password='fixture-original-chat')
        before = deepcopy(self.vault.values)
        for value in (12, [], 'x' * 129, 'fixture\nchat'):
            with self.subTest(kind=type(value).__name__):
                response = self.client.patch('/api/accounts/' + account['id'], json={
                    'password': 'fixture-not-written-x', 'ichat_password': value})
                self.assertEqual(response.status_code, 422, response.text)
                self.assertEqual(self.vault.values, before)
                self.assertNotIn('fixture-not-written-x', response.text)
                if isinstance(value, str):
                    self.assertNotIn(value, response.text)

    def test_import_invalid_ichat_password_is_safe_and_never_applies_valid_rows(self):
        values = [{'username': 'fixture_valid', 'ichat_password': 'fixture-not-written-chat'},
                  {'username': 'fixture_invalid', 'ichat_password': 'fixture\ninvalid-chat'}]
        preview = self.client.post('/api/import/preview', json={'text': json.dumps(values)})
        self.assertEqual(preview.status_code, 200, preview.text)
        self.assertTrue(preview.json()['errors'])
        self.assertNotIn('fixture-not-written-chat', preview.text)
        self.assertNotIn('fixture\\ninvalid-chat', preview.text)
        response = self.client.post('/api/import', json={'text': json.dumps(values)})
        self.assertEqual(response.status_code, 422, response.text)
        self.assertEqual(self.state.store.accounts(), [])
        self.assertEqual(self.vault.values, {})

    def test_busy_worker_blocks_bulk_and_individual_credential_edits(self):
        account = self.account(password='fixture-original-x', ichat_password='fixture-original-chat')
        thread = MagicMock()
        thread.is_alive.return_value = True
        with patch.dict(self.state.jobs.threads, {'fixture-running': thread}):
            self.assert_rejected_without_changes({'account_ids': [account['id']],
                'password': 'fixture-not-written-chat', 'overwrite': True})
            response = self.client.patch('/api/accounts/' + account['id'], json={'ichat_password': 'fixture-not-written-chat'})
            self.assertEqual(response.status_code, 422, response.text)
        self.assertEqual(self.secrets.get(account['id'])['ichat_password'], 'fixture-original-chat')

    def continue_with_updated_ichat_password(self, operation):
        scenario = Scenario()
        scenario.manual_once = True
        seen_login, seen_continue = [], []

        class RecordingSession(FakeSession):
            async def login(self, credentials):
                seen_login.append((credentials.password, credentials.ichat_password))
                result = await super().login(credentials)
                if result['status'] == 'requires_manual':
                    result['reason'] = 'Synthetic manual gate: ' + credentials.ichat_password
                return result

            async def continue_login(self, credentials):
                # Save values rather than a reference to mutable credentials.
                seen_continue.append((credentials.password, credentials.ichat_password))
                return await super().continue_login(credentials)

        def factory(config, logger, settings, checkpoint, progress):
            session = RecordingSession(scenario, checkpoint)
            with scenario.guard:
                scenario.instances.append(session)
            return session

        app = create_app(Path(self.temporary.name) / ('manual-' + operation), self.secrets, factory)
        state = app.state.application
        with TestClient(app) as client:
            settings, _ = state.store.settings()
            settings['collection'].update(profile_delay_seconds=0, group_delay_seconds=0,
                account_delay_seconds=0, action_delay_seconds=0, load_wait_seconds=0)
            self.assertEqual(client.put('/api/settings', json=settings).status_code, 200)
            account_response = client.post('/api/accounts', json={'username': 'fixture_owner',
                'password': 'fixture-unchanged-x', 'ichat_password': 'fixture-before-manual',
                'proxy': 'http://fixture:secret@127.0.0.1:9999'})
            self.assertEqual(account_response.status_code, 200, account_response.text)
            account = account_response.json()
            response = client.post('/api/jobs', json={'account_ids': [account['id']], 'mode': 'collect'})
            self.assertEqual(response.status_code, 200, response.text)
            job_id = response.json()['id']
            deadline = time.monotonic() + 5
            while time.monotonic() < deadline:
                if state.store.job(job_id)['status'] == 'requires_manual' and state.store.account(account['id'])['status'] == 'requires_manual':
                    break
                time.sleep(.01)
            else:
                self.fail('Synthetic worker did not reach its manual confirmation boundary')
            self.assertFalse(scenario.instances[0].closed)
            self.assertEqual(scenario.count('discover'), 0)
            deadline = time.monotonic()+5
            while not state.store.job(job_id)['progress'].get('manual_reason') and time.monotonic()<deadline:
                time.sleep(.01)
            pending = state.store.job(job_id)
            self.assertIn('Synthetic manual gate:',pending['progress']['manual_reason'])
            self.assertNotIn('fixture-before-manual',json.dumps(pending))
            self.assertNotIn('fixture-before-manual',state.store.account(account['id'])['reason'])

            # Only the iChat secret may change while this browser waits. A
            # mixed request cannot smuggle new profile/connection credentials.
            before = deepcopy(self.vault.values)
            for blocked in ({'proxy': 'new-proxy:8888'}, {'username': 'fixture_renamed'},
                            {'password': 'fixture-rejected-x'},
                            {'ichat_password': 'fixture-rejected-chat', 'proxy': 'new-proxy:8888'},
                            {'ichat_password': 'fixture-rejected-chat', 'username': 'fixture_renamed'}):
                with self.subTest(operation=operation, blocked_fields=sorted(blocked)):
                    rejected = client.patch('/api/accounts/' + account['id'], json=blocked)
                    self.assertEqual(rejected.status_code, 422, rejected.text)
                    self.assertEqual(self.vault.values, before)

            if operation == 'individual':
                saved = client.patch('/api/accounts/' + account['id'], json={'ichat_password': 'fixture-after-manual'})
                self.assertEqual(saved.status_code, 200, saved.text)
                self.assertTrue(saved.json()['has_ichat_password'])
            else:
                saved = client.post('/api/accounts/ichat-password/bulk', json={
                    'account_ids': [account['id']], 'password': 'fixture-after-manual', 'overwrite': True})
                self.assertEqual(saved.status_code, 200, saved.text)
                self.assertEqual(saved.json(), {'updated': 1, 'skipped': 0, 'total': 1})
            self.assertNotIn('fixture-after-manual', saved.text)
            self.assertEqual(self.secrets.get(account['id'])['password'], 'fixture-unchanged-x')
            self.assertEqual(self.secrets.get(account['id'])['ichat_password'], 'fixture-after-manual')
            self.assertEqual(state.store.account(account['id'])['username'], 'fixture_owner')
            self.assertEqual(state.store.job(job_id)['status'], 'requires_manual')
            self.assertEqual(seen_continue, [], 'Saving a secret must wait for explicit Continue')
            resumed = client.post('/api/jobs/' + job_id + '/continue')
            self.assertEqual(resumed.status_code, 200, resumed.text)
            state.jobs.threads[job_id].join(timeout=5)
            self.assertFalse(state.jobs.threads[job_id].is_alive())
            self.assertEqual(state.store.job(job_id)['status'], 'completed', state.store.job(job_id))
            self.assertEqual(seen_login, [('fixture-unchanged-x', 'fixture-before-manual')])
            self.assertEqual(seen_continue, [('fixture-unchanged-x', 'fixture-after-manual')])
            self.assertEqual(scenario.count('continue_login'), 1)
            self.assertEqual(scenario.count('login'), 1)
            self.assertEqual(scenario.instances[0].max_active, 1)
            self.assertTrue(scenario.instances[0].closed)
            self.assertIsNone(state.store.job(job_id)['progress']['accounts'][account['id']]['manual_reason'])

    def test_manual_confirmation_uses_individually_updated_ichat_password(self):
        self.continue_with_updated_ichat_password('individual')

    def test_manual_confirmation_uses_bulk_updated_ichat_password(self):
        self.continue_with_updated_ichat_password('bulk')

    def test_cross_origin_bulk_is_blocked_before_vault_write(self):
        account = self.account(ichat_password='fixture-original-chat')
        before = deepcopy(self.vault.values)
        response = self.client.post('/api/accounts/ichat-password/bulk', headers={'Origin': 'https://foreign.example'},
            json={'account_ids': [account['id']], 'password': 'fixture-not-written-chat', 'overwrite': True})
        self.assertEqual(response.status_code, 403, response.text)
        self.assertEqual(self.vault.values, before)

    def test_bulk_vault_failure_rolls_back_prior_success_and_masks_exception(self):
        faulting = FailOnceVault()
        self.vault.values = faulting.values
        self.secrets.backend = faulting
        first = self.account('fixture_first', password='fixture-first-x', ichat_password='fixture-first-chat')
        second = self.account('fixture_second', password='fixture-second-x', ichat_password='fixture-second-chat')
        before = deepcopy(faulting.values)
        faulting.fail_key = second['id'] + ':ichat_password'
        response = self.bulk([first['id'], second['id']], password='fixture-failed-shared-chat', overwrite=True)
        self.assertEqual(response.status_code, 422, response.text)
        self.assertEqual(faulting.values, before)
        self.assertNotIn('fixture-failed-shared-chat', response.text)
        self.assertNotIn('Synthetic vault failure', response.text)

    def test_bulk_validation_of_nonobject_body_never_echoes_password(self):
        self.account(ichat_password='fixture-original-chat')
        before = deepcopy(self.vault.values)
        secret = 'fixture-body-must-not-echo'
        response = self.client.post('/api/accounts/ichat-password/bulk', json=[{'password': secret}])
        self.assertEqual(response.status_code, 422, response.text)
        self.assertEqual(self.vault.values, before)
        self.assertNotIn(secret, response.text)

    def test_individual_vault_failure_rolls_back_preceding_x_password_write(self):
        faulting = FailOnceVault()
        self.vault.values = faulting.values
        self.secrets.backend = faulting
        account = self.account(password='fixture-original-x', ichat_password='fixture-original-chat')
        before = deepcopy(faulting.values)
        faulting.fail_key = account['id'] + ':ichat_password'
        response = self.client.patch('/api/accounts/' + account['id'], json={
            'password': 'fixture-changed-x', 'ichat_password': 'fixture-changed-chat', 'group': 'Not saved'})
        self.assertEqual(response.status_code, 422, response.text)
        self.assertEqual(faulting.values, before)
        self.assertNotEqual(self.state.store.account(account['id'])['group'], 'Not saved')
        self.assertNotIn('fixture-changed-chat', response.text)
        self.assertNotIn('fixture-changed-x', response.text)

    def test_duplicate_username_rejection_never_leaves_orphan_secrets(self):
        self.account(password='fixture-original-x', ichat_password='fixture-original-chat')
        before = deepcopy(self.vault.values)
        response = self.client.post('/api/accounts', json={'username': 'FIXTURE_OWNER',
            'password': 'fixture-duplicate-x', 'ichat_password': 'fixture-duplicate-chat'})
        self.assertIn(response.status_code, (409, 422), response.text)
        self.assertEqual(self.vault.values, before)
        self.assertEqual(len(self.state.store.accounts()), 1)
        self.assertNotIn('fixture-duplicate-chat', response.text)

    def test_stats_exports_and_error_redaction_exclude_new_secret(self):
        secret = 'fixture-private-ichat-secret'
        self.account(password='fixture-private-x-secret', ichat_password=secret)
        for format in ('csv', 'xlsx'):
            response = self.client.post('/api/export', json={'format': format, 'table': 'accounts'})
            self.assertEqual(response.status_code, 200, response.text if format == 'csv' else '')
            if format == 'csv':
                text = response.content.decode('utf-8-sig')
            else:
                workbook = load_workbook(io.BytesIO(response.content), read_only=True)
                try:
                    text = '\n'.join(str(cell.value) for sheet in workbook for row in sheet for cell in row)
                finally:
                    workbook.close()
            self.assertNotIn(secret, text)
            self.assertNotIn('fixture-private-x-secret', text)
        contaminated = {'username': 'fixture', 'ichat_password': secret,
                        'nested': {'ichat_password': secret, 'visible': 'safe'}}
        self.assertNotIn(secret, json.dumps(clean(contaminated)))
        self.assertNotIn(secret.encode(), csv_report([contaminated]))
        body = excel_report({'groups': [contaminated]}, [], {})
        workbook = load_workbook(io.BytesIO(body), read_only=True)
        try:
            text = '\n'.join(str(cell.value) for sheet in workbook for row in sheet for cell in row)
            self.assertNotIn(secret, text)
        finally:
            workbook.close()
        self.assertNotIn(secret, redact('ichat_password=' + secret))
        self.assertNotIn(secret, redact('iChat failed: ' + secret, [secret]))


if __name__ == '__main__':
    unittest.main()
