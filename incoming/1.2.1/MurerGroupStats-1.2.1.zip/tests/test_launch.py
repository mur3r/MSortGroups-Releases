"""Launch validation without accessing user accounts or application data."""
import argparse
import socket
import unittest
from unittest.mock import patch

from murer.__main__ import check_port, main, port_number


class LaunchTests(unittest.TestCase):
    def test_port_number_has_explicit_valid_range(self):
        self.assertEqual(port_number('8766'), 8766)
        for value in ('0', '-1', '65536', 'abc', '1.5'):
            with self.subTest(value=value), self.assertRaises(argparse.ArgumentTypeError):
                port_number(value)

    def test_occupied_port_is_reported_before_application_creation(self):
        with socket.socket(socket.AF_INET,socket.SOCK_STREAM) as occupied:
            occupied.bind(('127.0.0.1',0))
            occupied.listen(1)
            port = occupied.getsockname()[1]
            with patch('sys.argv',['murer','--no-open','--port',str(port)]), patch('murer.__main__.create_app') as create:
                with self.assertRaisesRegex(RuntimeError, 'занят или недоступен'):
                    main()
                create.assert_not_called()

    def test_free_port_check_does_not_keep_a_listening_socket(self):
        check_port(0)


if __name__ == '__main__':
    unittest.main()
