"""
Создание Chrome: флаги против нагрузки, прокси-расширение, stealth, CDP-блокировка медиа.
"""

import asyncio
import json
import random
import tempfile
import zipfile
from urllib.parse import urlparse, unquote

from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from selenium_stealth import stealth

from xgenius.config import Config
from xgenius.models import AccountCredentials, BrowserConfig
from xgenius.settings import BLOCK_MEDIA_URLS


# Размер экрана нужен для позиционирования окон Chrome (без tkinter: WinAPI на Windows)
def _screen_size():
    try:
        import ctypes
        user32 = ctypes.windll.user32
        return int(user32.GetSystemMetrics(0)), int(user32.GetSystemMetrics(1))
    except Exception:
        return 1920, 1080


SCREEN_WIDTH, SCREEN_HEIGHT = _screen_size()

# --------------------- BrowserManager ---------------------
class BrowserManager:
    def __init__(self, config: Config, browser_config: BrowserConfig):
        self.config = config
        self.browser_config = browser_config

    async def create_browser(self, credentials: AccountCredentials) -> webdriver.Chrome:
        try:
            chrome_bin = self.config.chrome_path
            driver_path = self.config.chromedriver_path
            options = Options()
            options.binary_location = str(chrome_bin)

            # 1. Возвращаем стандартную стратегию, чтобы React успевал отрендерить элементы
            options.page_load_strategy = "normal"

            # 2. Флаги, снимающие фоновую нагрузку с CPU (сервер без видеокарты:
            #    всё, что анимируется/проигрывается, рендерится процессором).
            options.add_argument("--disable-gpu")
            options.add_argument("--mute-audio")
            options.add_argument("--no-default-browser-check")
            options.add_argument("--no-first-run")
            options.add_argument("--disable-dev-shm-usage") # Обязательно для экономии RAM
            options.add_argument("--disable-background-networking")
            options.add_argument("--disable-component-update")
            options.add_argument("--disable-sync")
            options.add_argument("--disable-default-apps")
            options.add_argument("--disable-client-side-phishing-detection")
            options.add_argument("--metrics-recording-only")
            options.add_argument("--log-level=3")
            # Видео в ленте/чатах не стартует само — самый большой пожиратель CPU без GPU
            options.add_argument("--autoplay-policy=user-gesture-required")
            options.add_argument("--disable-features=Translate,MediaRouter,OptimizationHints,InterestFeedContentSuggestions,BackForwardCache")

            prefs = {
                # Картинки оставляем (их отключение не ломает React, но операторы хотят видеть чаты)
                "profile.default_content_setting_values.notifications": 2,
                "profile.default_content_setting_values.geolocation": 2,
                "profile.default_content_settings.popups": 0,
                "credentials_enable_service": False,
                "profile.password_manager_enabled": False,
            }
            options.add_experimental_option("prefs", prefs)

            # 3. Увеличиваем ширину окна до десктопного брейкпоинта (минимум 1024px)
            user_profile = str(self.config.get_profile_dir(credentials.username))
            options.add_argument(f"--user-data-dir={user_profile}")

            if credentials.headless:
                options.add_argument("--headless=new")
                options.add_argument("--window-size=1280,800")
            else:
                win_w, win_h = 1024, 768  # Фиксирует верстку десктопного чата
                x = max(0, SCREEN_WIDTH - win_w - 10)
                y = 10
                options.add_argument(f"--window-position={x},{y}")
                options.add_argument(f"--window-size={win_w},{win_h}")

            if credentials.user_agent:
                options.add_argument(f"user-agent={credentials.user_agent}")
            else:
                chrome_128_uas = [
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.6613.137 Safari/537.36",
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.6613.119 Safari/537.36"
                ]
                options.add_argument(f"user-agent={random.choice(chrome_128_uas)}")
            
            if credentials.proxy:
                self._add_proxy_authentication(options, credentials.proxy)

            options.add_argument("--ignore-certificate-errors")
            
            loop = asyncio.get_event_loop()
            driver_service = Service(str(driver_path))
            
            browser = await loop.run_in_executor(None, lambda: webdriver.Chrome(service=driver_service, options=options))

            # PID chromedriver — по нему hard_close_browser добивает дерево процессов chrome
            try:
                browser._xg_pid = driver_service.process.pid
            except Exception:
                browser._xg_pid = None

            if credentials.proxy and parse_proxy(credentials.proxy)[2] is not None:
                # Branded Chrome 137+ no longer supports ChromeDriver's extension
                # load switch. Never continue directly when proxy auth was requested.
                extension_loaded = False
                for _ in range(6):
                    try:
                        targets = await loop.run_in_executor(None, lambda: browser.execute_cdp_cmd("Target.getTargets", {}))
                        extension_loaded = any(
                            target.get("url", "").startswith("chrome-extension://")
                            and target.get("url", "").endswith("/background.js")
                            for target in targets.get("targetInfos", []))
                    except Exception:
                        pass
                    if extension_loaded:
                        break
                    await asyncio.sleep(0.5)
                if not extension_loaded:
                    await loop.run_in_executor(None, browser.quit)
                    raise RuntimeError("PROXY: расширение авторизации не загрузилось. Выберите Chrome for Testing или Chromium совместимой версии")

            if BLOCK_MEDIA_URLS:
                # Режем тяжёлые запросы на уровне CDP: видео и аналитика. Картинки не трогаем.
                try:
                    await loop.run_in_executor(None, lambda: browser.execute_cdp_cmd("Network.enable", {}))
                    await loop.run_in_executor(None, lambda: browser.execute_cdp_cmd("Network.setBlockedURLs", {
                        "urls": [
                            "*://video.twimg.com/*", "*.mp4", "*.m3u8", "*.webm",
                            "*://ads-api.twitter.com/*", "*://ads-api.x.com/*",
                            "*://analytics.twitter.com/*", "*://*.doubleclick.net/*",
                            "*://*.google-analytics.com/*", "*://*.googletagmanager.com/*",
                        ]
                    }))
                except Exception as e:
                    print(f"CDP block URLs failed (non-fatal): {e}")

            webgl_options = [
                ("Intel Inc.", "Intel Iris OpenGL Engine"),
                ("NVIDIA Corporation", "NVIDIA GeForce GTX 1050 Ti/PCIe/SSE2"),
                ("AMD", "AMD Radeon(TM) Graphics")
            ]
            webgl_vendor, webgl_renderer = random.choice(webgl_options)
            
            stealth(
                browser, 
                languages=["en-US", "en"],
                vendor="Google Inc.",
                platform="Win32",
                webgl_vendor=webgl_vendor,
                renderer=webgl_renderer,
                fix_hairline=True,
                emulate_print_media=True,
                await_for_load=False
            )
            
            browser.set_page_load_timeout(float(getattr(self.config, "page_load_timeout_seconds", 45)))
            browser.set_script_timeout(float(getattr(self.config, "script_timeout_seconds", 30)))
            return browser
            
        except Exception as e:
            raise Exception(f"Failed to create browser: {str(e)}")

    def _add_proxy_authentication(self, options: Options, proxy: str) -> None:
        """Keep the original proxy mechanism, migrating only the retired MV2 API.

        Credentials are JSON encoded, never interpolated as JavaScript source. Each
        session has its own extension directory, so concurrent accounts cannot
        overwrite another account's proxy credentials. The app removes this
        secret-bearing temporary directory when the browser closes.
        """
        host, port, username, password, scheme = parse_proxy(proxy)
        if username is None:
            server_host = f"[{host}]" if ":" in host else host
            options.add_argument(f"--proxy-server={scheme}://{server_host}:{port}")
            return
        if scheme not in ("http", "https"):
            raise ValueError("Прокси с авторизацией поддерживает HTTP/HTTPS; SOCKS требует отдельной проверки")
        manifest = {
            "version": "1.0.0", "manifest_version": 3,
            "name": "Murer local proxy authentication",
            "permissions": ["proxy", "storage", "webRequest", "webRequestAuthProvider"],
            "host_permissions": ["<all_urls>"],
            "background": {"service_worker": "background.js"},
        }
        configuration = {"mode": "fixed_servers", "rules": {
            "singleProxy": {"scheme": scheme, "host": host, "port": port},
            "bypassList": ["localhost", "127.0.0.1", "[::1]"]}}
        auth = {"username": username, "password": password}
        background = (
            "const config = " + json.dumps(configuration) + ";\n"
            "const credentials = " + json.dumps(auth) + ";\n"
            "chrome.proxy.settings.set({value: config, scope: 'regular'}, () => {});\n"
            "chrome.webRequest.onAuthRequired.addListener((details, callback) => {\n"
            "  if (details.isProxy) callback({authCredentials: credentials});\n"
            "  else callback({});\n"
            "}, {urls: ['<all_urls>']}, ['asyncBlocking']);\n"
        )
        temp_root = self.config.base_dir / "temp_proxy_extension"
        temp_root.mkdir(parents=True, exist_ok=True)
        temp_dir = tempfile.mkdtemp(prefix="session_", dir=temp_root)
        from pathlib import Path
        plugin_file = Path(temp_dir) / "proxy_auth_plugin.zip"
        with zipfile.ZipFile(plugin_file, "w") as zp:
            zp.writestr("manifest.json", json.dumps(manifest))
            zp.writestr("background.js", background)
        options.add_extension(str(plugin_file))
        self._proxy_temp_dirs = getattr(self, "_proxy_temp_dirs", []) + [Path(temp_dir)]


def parse_proxy(proxy: str):
    """Accept legacy host:port:user:password and explicit URL notation."""
    value = str(proxy or "").strip()
    if "://" not in value and value.count(":") >= 3 and "@" not in value and not value.startswith("["):
        host, port, username, password = value.split(":", 3)
        scheme = "http"
    else:
        try:
            parsed = urlparse(value if "://" in value else "http://" + value)
            host, port, scheme = parsed.hostname, parsed.port, parsed.scheme
        except ValueError:
            raise ValueError("Неверный формат адреса и порта прокси") from None
        username = unquote(parsed.username) if parsed.username is not None else None
        password = unquote(parsed.password or "") if username is not None else None
    if not host or port is None or not str(port).isdigit() or not 1 <= int(port) <= 65535:
        raise ValueError("Неверный формат прокси: host:port[:user:password] или http://user:password@host:port")
    if scheme not in ("http", "https", "socks4", "socks5"):
        raise ValueError("Неподдерживаемая схема прокси")
    return host, int(port), username, password, scheme

