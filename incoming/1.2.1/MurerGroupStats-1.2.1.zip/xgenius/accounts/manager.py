import asyncio
import json
import re
from typing import Dict, List, Optional, Set
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from xgenius.accounts.auth import AuthMixin
from xgenius.accounts.health import HealthMixin
from xgenius.browser import BrowserManager
from xgenius.core import FOLLOWERS_PROBE_JS
from xgenius.models import AccountState, BrowserConfig


class AccountManager(HealthMixin, AuthMixin):
    def __init__(self, config, logger):
        self.config = config
        self.logger = logger
        self.accounts: Dict[str, AccountState] = {}
        self.browser_manager = BrowserManager(config, BrowserConfig())

    async def report_account_error(self, error_type, username="", error_details=""):
        self.logger.error(f"{error_type}: {error_details}", username)

    def save_groups(self):
        try:
            if self.config.account_groups_file.exists():
                with open(self.config.account_groups_file, 'r', encoding='utf-8') as f:
                    groups_data = json.load(f)
            else:
                groups_data = {}
            for username, state in self.accounts.items():
                if state.groups:
                    groups_data[username] = list(state.groups)
            with open(self.config.account_groups_file, 'w', encoding='utf-8') as f:
                json.dump(groups_data, f, indent=4)
        except Exception as e:
            self.logger.error(f"Failed to save groups: {e}")

    def load_saved_groups(self, username: str) -> Set[str]:
        try:
            if self.config.account_groups_file.exists():
                with open(self.config.account_groups_file, 'r', encoding='utf-8') as f:
                    groups_data = json.load(f)
                    return set(groups_data.get(username, []))
        except Exception as e:
            self.logger.error(f"Failed to load groups for {username}: {e}")
        return set()

    def load_accounts(self) -> List[dict]:
        try:
            if self.config.accounts_file.exists():
                with open(self.config.accounts_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    return data.get("accounts", [])
            return []
        except Exception as e:
            self.logger.error(f"Failed to load accounts: {e}")
            return []

    def save_accounts(self, accounts: List[dict]) -> None:
        try:
            with open(self.config.accounts_file, 'w', encoding='utf-8') as f:
                json.dump({"accounts": accounts}, f, indent=4)
        except Exception as e:
            self.logger.error(f"Failed to save accounts: {e}")

    async def get_auth_tokens(self, browser: webdriver.Chrome) -> tuple[Optional[str], Optional[str]]:
        """Получение токенов авторизации из браузера"""
        try:
            loop = asyncio.get_event_loop()
            # Получаем все cookies
            cookies = await loop.run_in_executor(None, lambda: browser.get_cookies())
            
            auth_token = None
            ct0_token = None
            
            # Ищем нужные куки
            for cookie in cookies:
                if cookie.get('name') == 'auth_token':
                    auth_token = cookie.get('value')
                elif cookie.get('name') == 'ct0':
                    ct0_token = cookie.get('value')
            
            # Если не нашли в куках, пробуем получить из localStorage через JavaScript
            if not auth_token or not ct0_token:
                try:
                    tokens = await loop.run_in_executor(None, lambda: browser.execute_script(
                        """
                        try {
                            return {
                                'auth_token': localStorage.getItem('auth_token'),
                                'ct0': localStorage.getItem('ct0')
                            };
                        } catch(e) {
                            return null;
                        }
                        """
                    ))
                    
                    if tokens and isinstance(tokens, dict):
                        if not auth_token and tokens.get('auth_token'):
                            auth_token = tokens['auth_token']
                        if not ct0_token and tokens.get('ct0'):
                            ct0_token = tokens['ct0']
                except Exception:
                    pass
            
            self.logger.info(f"Получены токены: auth_token={'SET' if auth_token else 'N/A'}, ct0={'SET' if ct0_token else 'N/A'}")
            return auth_token, ct0_token
            
        except Exception as e:
            self.logger.error(f"Ошибка получения токенов: {e}")
            return None, None

    async def get_followers_count(self, browser: webdriver.Chrome, username: str) -> int:
        """
        Количество подписчиков одним JS-вызовом.
        Старая версия: xpath-перебор, regex по page_source (мегабайты) и обход 300
        элементов с outerHTML на каждом — сотни HTTP-запросов к chromedriver при каждом
        логине/перелогине.
        """
        loop = asyncio.get_event_loop()
        try:
            await loop.run_in_executor(None, lambda: browser.get(f"https://x.com/{username}"))

            def _wait_anchor():
                WebDriverWait(browser, 12).until(
                    EC.presence_of_element_located(
                        (By.XPATH, "//a[contains(@href, '/verified_followers') or contains(@href, '/followers')]"))
                )
                return browser.execute_script(FOLLOWERS_PROBE_JS)

            text = await loop.run_in_executor(None, _wait_anchor)
            followers_count = self._parse_count(text or "")
            self.logger.info(f"Количество подписчиков @{username}: {followers_count}", username)
            return followers_count
        except Exception as e:
            self.logger.warning(f"Не удалось получить подписчиков: {type(e).__name__}", username)
            return 0

    def _parse_count(self, text: str) -> int:
        """'1,234 Followers' / '12.5K' / '1.2M' / '1 234 подписчиков' / '12,5 тыс.' -> int.
        Старый вариант ловил кириллическую 'к' внутри слова 'подписчиков' и умножал на 1000."""
        if not text:
            return 0
        m = re.search(r"(\d[\d\s .,]*)\s*(K|M|k|m|К|М|тыс|млн)?", text.strip())
        if not m:
            return 0
        num = m.group(1).replace(" ", "").replace(" ", "")
        suffix = (m.group(2) or "").lower()
        mult = 1
        if suffix in ("k", "к", "тыс"):
            mult = 1000
        elif suffix in ("m", "м", "млн"):
            mult = 1_000_000
        if mult == 1:
            num = num.replace(",", "").replace(".", "")
        else:
            num = num.replace(",", ".")
            if num.count(".") > 1:
                num = num.replace(".", "")
        try:
            return int(float(num) * mult)
        except ValueError:
            return 0

