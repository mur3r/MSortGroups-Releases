"""Local settings only. No credentials or external service integrations."""
import json
from pathlib import Path

SETTINGS_FILE = Path(__file__).resolve().parent.parent / "config" / "settings.json"
LOGIN_DELAY_SECONDS = 40
HEALTH_TIMEOUT_STRIKES = 3
IDLE_HEALTH_INTERVAL = 30
IDLE_PARK_SECONDS = 180
BLOCK_MEDIA_URLS = True

def _apply_overrides():
    if not SETTINGS_FILE.exists():
        return
    data = json.loads(SETTINGS_FILE.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError("settings.json must contain a JSON object")
    for key in ("LOGIN_DELAY_SECONDS", "HEALTH_TIMEOUT_STRIKES", "IDLE_HEALTH_INTERVAL", "IDLE_PARK_SECONDS", "BLOCK_MEDIA_URLS"):
        if key in data:
            globals()[key] = data[key]

_apply_overrides()
