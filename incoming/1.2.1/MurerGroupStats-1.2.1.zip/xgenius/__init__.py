"""Reusable foundation for group statistics."""
