"""DOM query helpers for XChat's verified open shadow-root embed.

The October 2026 XChat DOM uses an open shadowRoot on xchatEmbedRoute.
Ordinary profile pages and earlier flat iChat markup remain supported.
"""

DEEP_QUERY_JS = r"""
const deepQueryAll = (selector, scope=document) => {
  const roots=[scope], matches=[];
  for(let index=0;index<roots.length;index++) {
    const root=roots[index];
    matches.push(...Array.from(root.querySelectorAll(selector)));
    if(root.shadowRoot) roots.push(root.shadowRoot);
    for(const node of root.querySelectorAll('*')) {
      if(node.shadowRoot) roots.push(node.shadowRoot);
    }
  }
  return [...new Set(matches)];
};
const deepQuery = (selector, scope=document) => deepQueryAll(selector, scope)[0] || null;
"""
