"""Conservative parsing of observed UI values, independent of Selenium."""
import re
import unicodedata
from copy import deepcopy
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from urllib.parse import urlparse


def normalize_username(value):
    if value is None:
        return ""
    text = str(value).strip()
    if "://" in text:
        text = urlparse(text).path.strip("/").split("/")[0]
    return text.lstrip("@").casefold()


def parse_count(text) -> dict:
    """Retain the raw label; absent/unreadable counters are never zero.

    X abbreviations are rounded observations, including 1K. Thousands separators
    (ordinary/nonbreaking/narrow spaces, comma, dot) and decimal suffixes in
    English/Russian/Ukrainian are accepted.
    """
    raw = None if text is None else str(text)
    result = {"raw": raw, "value": None, "approximate": False}
    if raw is None:
        return result
    normalized = unicodedata.normalize("NFKC", raw).casefold().replace("\u066b", ".").replace("\u066c", ",")
    normalized = "".join(str(unicodedata.digit(ch)) if ch.isdecimal() else ch for ch in normalized)
    match = re.search(r"(?<![\w\-−–])([0-9]+(?:[.,'’\s\u00a0\u202f][0-9]+)*)(?:\s*(тыс\.?|тис\.?|млрд\.?|млн\.?|[kmbкм])(?!\w))?", normalized)
    if not match:
        return result
    token = re.sub(r"[\s'’]", "", match.group(1))
    suffix = (match.group(2) or "").rstrip(".")
    if suffix:
        if "," in token and "." in token:
            decimal_separator = "," if token.rfind(",") > token.rfind(".") else "."
            token = token.replace("." if decimal_separator == "," else ",", "").replace(decimal_separator, ".")
        else:
            token = token.replace(",", ".")
    else:
        groups = re.split(r"[.,]", token)
        if len(groups) > 1:
            if all(len(group) == 3 for group in groups[1:]):
                token = "".join(groups)
            else:
                # An unqualified fractional count cannot be an exact integer.
                return result
    multiplier = {"k": 1000, "к": 1000, "тыс": 1000, "тис": 1000,
                  "m": 1_000_000, "м": 1_000_000, "млн": 1_000_000,
                  "b": 1_000_000_000, "млрд": 1_000_000_000}.get(suffix, 1)
    try:
        number = Decimal(token) * multiplier
        result["value"] = int(number.to_integral_value(rounding=ROUND_HALF_UP))
    except (InvalidOperation, ValueError):
        return result
    result["approximate"] = bool(suffix or re.search(r"[≈~+<>]|about|approximately|около|приблиз", normalized))
    return result


def classify_card(card: dict, username: str) -> dict:
    """Classify one actual card; do not infer an actor's repost date from its source.

    `author` must be an observed handle, not a display name. `repost_at` is allowed
    only when the UI explicitly supplied the actor's action timestamp.
    """
    result = deepcopy(card)
    author = card.get("author")
    if isinstance(author, dict):
        author = author.get("username")
    same_author = bool(normalize_username(author) and normalize_username(author) == normalize_username(username))
    context = str(card.get("social_context") or "").casefold()
    repost = bool(re.search(r"\brepost(?:ed)?\b|\bretweet(?:ed)?\b|репост|ретвит|ретвіт|повторно опубл", context))
    if repost:
        kind, method = "repost", "social_context"
        event_at = card.get("repost_at")
    elif same_author and card.get("quote"):
        kind, method = "quote", "quote_card_and_author"
        event_at = card.get("event_at") or card.get("original_at")
    elif same_author and card.get("reply"):
        kind, method = "reply", "reply_context_and_author"
        event_at = card.get("event_at") or card.get("original_at")
    elif same_author:
        kind, method = "own", "observed_author"
        event_at = card.get("event_at") or card.get("original_at")
    else:
        kind, method, event_at = "unknown", "insufficient_evidence", None
    result.update(type=kind, event_at=event_at, classification_method=method,
                  pinned=bool(card.get("pinned")))
    return result
