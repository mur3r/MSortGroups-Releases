"""Local launch configuration and cross-process profile ownership."""
import json
import os
from pathlib import Path
import re
import subprocess


def default_data_dir():
    return Path(os.environ.get('LOCALAPPDATA', str(Path.home()))) / 'MurerGroupStats'


def configuration_path():
    return default_data_dir() / 'bootstrap.json'


def read_configuration():
    path = configuration_path()
    defaults = {'data_dir': str(default_data_dir()), 'chrome_path': '', 'driver_path': '', 'configured': False}
    chrome = Path('C:/Program Files (x86)/Google/Chrome/Application/chrome.exe')
    if chrome.exists():
        defaults['chrome_path'] = str(chrome)
    tested_chrome = default_data_dir() / 'browser-test' / 'chrome-win64' / 'chrome.exe'
    tested_driver = default_data_dir() / 'browser-test' / 'chromedriver-win64' / 'chromedriver.exe'
    if tested_chrome.is_file() and tested_driver.is_file():
        defaults['chrome_path'] = str(tested_chrome)
        defaults['driver_path'] = str(tested_driver)
    if path.exists():
        defaults.update(json.loads(path.read_text(encoding='utf-8')))
    return defaults


def save_configuration(values):
    path = configuration_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps(values, ensure_ascii=False, indent=2), encoding='utf-8')
    temporary.replace(path)


class FileLease:
    def __init__(self, path):
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        self.file = path.open('a+b')
        try:
            # On Windows even reading an owned byte fails: include initial IO in
            # the guarded region so a competing lease closes its handle.
            self.file.seek(0)
            if not self.file.read(1):
                self.file.write(b'0')
                self.file.flush()
            self.file.seek(0)
            if os.name == 'nt':
                import msvcrt
                msvcrt.locking(self.file.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(self.file.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            self.file.close()
            raise RuntimeError('Эта папка данных или профиль Chrome уже используется другим процессом Murer Group Stats')

    def close(self):
        if self.file.closed:
            return
        self.file.seek(0)
        if os.name == 'nt':
            import msvcrt
            msvcrt.locking(self.file.fileno(), msvcrt.LK_UNLCK, 1)
        else:
            import fcntl
            fcntl.flock(self.file.fileno(), fcntl.LOCK_UN)
        self.file.close()


def browser_check(chrome_path, driver_path):
    result = {'compatible': False, 'chrome_version': None, 'driver_version': None, 'errors': [], 'warnings': []}
    for field, path in [('chrome', chrome_path), ('driver', driver_path)]:
        if not path or not Path(path).is_file():
            result['errors'].append('Выберите существующий ' + ('chrome.exe' if field == 'chrome' else 'chromedriver.exe'))
            continue
        try:
            if field == 'chrome' and os.name == 'nt':
                # File version avoids launching a user's normal Chrome profile.
                import ctypes
                size = ctypes.windll.version.GetFileVersionInfoSizeW(str(path), None)
                data = ctypes.create_string_buffer(size)
                ctypes.windll.version.GetFileVersionInfoW(str(path), 0, size, data)
                pointer = ctypes.c_void_p()
                length = ctypes.c_uint()
                ctypes.windll.version.VerQueryValueW(data, '\\', ctypes.byref(pointer), ctypes.byref(length))
                numbers = ctypes.cast(pointer, ctypes.POINTER(ctypes.c_uint32))
                major_ms, minor_ls = numbers[2], numbers[3]
                version = f'{major_ms >> 16}.{major_ms & 65535}.{minor_ls >> 16}.{minor_ls & 65535}'
            else:
                flags = subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0
                output = subprocess.run([str(path), '--version'], capture_output=True, text=True, timeout=10, creationflags=flags).stdout
                version = re.search(r'\d+\.\d+\.\d+\.\d+', output).group(0)
            result[field + '_version'] = version
        except Exception:
            result['errors'].append('Не удалось определить версию ' + field)
    if result['chrome_version'] and result['driver_version']:
        result['compatible'] = result['chrome_version'].split('.')[0] == result['driver_version'].split('.')[0]
        if not result['compatible']:
            result['errors'].append('Основные версии Chrome и ChromeDriver различаются')
        if int(result['chrome_version'].split('.')[0]) >= 137:
            result['warnings'].append('Для прокси с авторизацией требуется Chrome for Testing/Chromium с поддержкой расширений. Проверяйте прокси фактическим входом.')
    return result
