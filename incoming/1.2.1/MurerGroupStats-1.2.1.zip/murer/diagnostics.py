"""An actual visible isolated browser launch, without navigating to X."""
import asyncio
from pathlib import Path
import tempfile

from xgenius.browser import BrowserManager
from xgenius.config import Config
from xgenius.models import AccountCredentials, BrowserConfig
from xgenius.process_utils import hard_close_browser


async def launch_check(chrome_path, driver_path):
    with tempfile.TemporaryDirectory(prefix='murer-browser-check-') as temporary:
        config = Config(Path(temporary))
        config.chrome_path, config.chromedriver_path = Path(chrome_path), Path(driver_path)
        manager = BrowserManager(config, BrowserConfig())
        browser = None
        try:
            browser = await manager.create_browser(AccountCredentials('murer_probe', ''))
            loop = asyncio.get_running_loop()
            await loop.run_in_executor(None, lambda: browser.get('data:text/html,<title>Murer browser check</title><h1>Murer browser check</h1>'))
            title = await loop.run_in_executor(None, lambda: browser.title)
            return {'launch_ok': title == 'Murer browser check', 'launch_message': 'Видимый Chrome запущен; команды Selenium работают'}
        except Exception:
            return {'launch_ok': False, 'launch_message': 'Chrome не запустился. Проверьте выбранные исполняемые файлы, версии и права доступа.'}
        finally:
            if browser:
                await asyncio.get_running_loop().run_in_executor(None, hard_close_browser, browser)
