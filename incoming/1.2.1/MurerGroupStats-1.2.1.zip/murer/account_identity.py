"""Read the signed-in user's own profile, never a supplied foreign handle."""
import re
from urllib.parse import unquote, urlsplit

from xgenius.core.dom import DEEP_QUERY_JS
from .storage import utcnow

SELF_PROFILE_JS = DEEP_QUERY_JS + r"""
const visible=el=>!!el&&(el.offsetWidth||el.offsetHeight||el.getClientRects().length);
const main=deepQuery('[data-testid="primaryColumn"]')||deepQuery('main');
const name=main?.querySelector('[data-testid="UserName"]');
const handles=[...(name?.innerText||'').matchAll(/@([A-Za-z0-9_]{1,15})\b/g)].map(m=>m[1].toLowerCase());
const edit=main?Array.from(main.querySelectorAll('[data-testid="editProfileButton"],a[href="/settings/profile"]')).filter(visible):[];
return handles.length===1&&edit.length?{verified:true,username:handles[0]}:{verified:false};
"""


def public_user_id(cookie):
    value=unquote(cookie.get('value','')) if isinstance(cookie,dict) else ''
    match=re.fullmatch(r'u=(\d+)',value)
    return match[1] if match else None


async def read_signed_in_identity(actions, browser, settings, page_gate):
    """twid supplies only a public numeric ID; its raw value is never returned."""
    location=await actions.call(lambda:browser.current_url)
    url=urlsplit(location)
    if url.scheme!='https' or url.hostname not in ('x.com','www.x.com'):
        return {'status':'requires_manual','reason':'Для сверки логина откройте авторизованный аккаунт на x.com'}
    xid=public_user_id(await actions.call(lambda:browser.get_cookie('twid')))
    if not xid:
        return {'status':'requires_manual','reason':'X не предоставил ID текущей сессии. Завершите вход и повторите проверку логина.'}
    await actions.get('https://x.com/i/user/'+xid)
    await actions.sleep(settings['load_wait_seconds'])
    for _ in range(settings['login_poll_rounds']):
        gate=await page_gate()
        if gate:
            return gate
        observed=await actions.script(SELF_PROFILE_JS)
        if observed.get('verified') is True and re.fullmatch(r'[a-z0-9_]{1,15}',observed.get('username','')):
            current=public_user_id(await actions.call(lambda:browser.get_cookie('twid')))
            if current!=xid:
                return {'status':'requires_manual','reason':'Аккаунт X сменился во время сверки логина. Повторите вход.'}
            return {'verified':True,'username':observed['username'],'x_id':xid,
                    'origin':'x_self_profile','observed_at':utcnow()}
        await actions.sleep(settings['login_poll_seconds'])
    return {'status':'requires_manual','reason':'Собственный профиль X не загрузился. Проверьте открытое окно и продолжите после загрузки.'}
