"""Bounded local activity journal. No request bodies, credentials or page contents.

The journal has its own database: a logging failure must never roll back a
collection transaction. Readers use stable, monotonic IDs instead of offsets.
"""
from collections import deque
from contextlib import closing, contextmanager
from datetime import datetime, timedelta, timezone
from functools import wraps
import json
import math
from pathlib import Path
import re
import sqlite3
import threading
import time

from .storage import utcnow

DOMAINS = {'system': 'Система', 'auth': 'Вход и аккаунты', 'browser': 'Браузер',
           'collection': 'Сбор', 'trade': 'Trade', 'data': 'Данные и анализ', 'updates': 'Обновления'}
LEVELS = {'debug': 'Подробности', 'info': 'Информация', 'warning': 'Предупреждения', 'error': 'Ошибки'}
KINDS = {'lifecycle': 'Запуск и завершение', 'request': 'Действия в интерфейсе',
         'status': 'Состояния', 'step': 'Этапы операций', 'progress': 'Прогресс',
         'checkpoint': 'Сохранение прогресса', 'cache': 'Кеш и пропуски', 'retry': 'Повторные попытки',
         'wait': 'Ожидания и задержки', 'navigation': 'Переходы по страницам', 'command': 'Команды браузеру',
         'input': 'Поиск и ввод', 'scroll': 'Прокрутка', 'result': 'Результаты',
         'diagnostic': 'Сообщения модулей', 'settings': 'Настройки', 'export': 'Выгрузки', 'error': 'Сбои'}
SECRET_KEY = re.compile(r'(?i)password|passwd|token|cookie|authorization|secret|proxy|\bpin\b|credential')


class EventLog:
    def __init__(self, data_dir, max_rows=20000, retention_days=14):
        self.path = Path(data_dir) / 'logs' / 'activity.sqlite3'
        self.max_rows, self.retention_days = max_rows, retention_days
        self.lock = threading.RLock()
        self.private = set()
        self.fallback = deque(maxlen=500)
        self.failure = ''
        self.retry_at = 0
        self.sequence = 0
        self.connection = None
        self.keep_open = False
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            with self._db() as db:
                db.execute('PRAGMA journal_mode=WAL')
                self._schema(db)
                self.sequence = (db.execute("SELECT seq FROM sqlite_sequence WHERE name='events'").fetchone() or [0])[0]
                self._prune(db)
                db.commit()
        except (OSError, sqlite3.Error):
            self._failed()

    @staticmethod
    def _schema(db):
        db.executescript('''CREATE TABLE IF NOT EXISTS events(
                    id INTEGER PRIMARY KEY AUTOINCREMENT, at TEXT NOT NULL,
                    domain TEXT NOT NULL, level TEXT NOT NULL, kind TEXT NOT NULL,
                    message TEXT NOT NULL, account_id TEXT NOT NULL, run_id TEXT NOT NULL,
                    details TEXT NOT NULL);
                    CREATE INDEX IF NOT EXISTS events_domain ON events(domain,id);
                    CREATE INDEX IF NOT EXISTS events_level ON events(level,id);
                    CREATE INDEX IF NOT EXISTS events_account ON events(account_id,id);''')
        db.execute('CREATE INDEX IF NOT EXISTS events_time ON events(at)')

    @contextmanager
    def _db(self):
        with self.lock:
            db = self.connection
            if db is None:
                db = sqlite3.connect(self.path, timeout=.25, check_same_thread=False)
                db.row_factory = sqlite3.Row
                db.execute('PRAGMA synchronous=NORMAL')
                db.create_function('casefold', 1, lambda value: str(value).casefold())
                if self.keep_open:
                    self.connection = db
            try:
                yield db
            except BaseException:
                db.rollback()
                raise
            finally:
                if db is not self.connection:
                    db.close()

    def start(self):
        # Keep one WAL connection while the server is running. All access is
        # serialized by lock; no per-event connection/checkpoint/fsync churn.
        with self.lock:
            self.keep_open = True

    def close(self):
        with self.lock:
            self.keep_open = False
            if self.connection:
                self.connection.close()
                self.connection = None

    def _failed(self):
        # Never include database exception text: it can contain inserted data.
        self.failure = 'Запись на диск недоступна. Последние 500 новых событий доступны в памяти; после перезапуска они будут потеряны.'
        self.retry_at = time.monotonic() + 10

    def protect(self, values):
        with self.lock:
            self.private.update(str(v) for v in values if v)

    def clean(self, value, depth=0):
        if depth > 4:
            return '[вложенные данные опущены]'
        if isinstance(value, dict):
            return {self.clean(str(k), depth+1)[:80]: '[скрыто]' if SECRET_KEY.search(str(k)) else self.clean(v, depth+1)
                    for k, v in list(value.items())[:40]}
        if isinstance(value, (list, tuple)):
            return [self.clean(v, depth+1) for v in value[:30]]
        if value is None or isinstance(value, (bool, int)):
            return value
        if isinstance(value, float):
            return value if math.isfinite(value) else None
        text = str(value).encode('utf-8', errors='replace').decode('utf-8')
        for secret in sorted(self.private, key=len, reverse=True):
            text = text.replace(secret, '[скрыто]')
        # Also redact common token formats, quoted key/value pairs, URL query
        # strings and userinfo. Do not record raw Selenium stacks/page source.
        text = re.sub(r'(?i)\b(?:gh[pousr]_[A-Za-z0-9_]+|github_pat_[A-Za-z0-9_]+|Bearer\s+[^\s,;]+)', '[скрыто]', text)
        text = re.sub(r'''(?i)(["']?(?:password|ichat_password|auth_token|ct0(?:_token)?|cookie|authorization|pin|token)["']?\s*[:=]\s*)(?:"[^"]*"|'[^']*'|[^\s,;}]+)''', r'\1[скрыто]', text)
        text = re.sub(r'(?i)(https?://)[^/\s@]+@', r'\1[скрыто]@', text)
        text = re.sub(r'(https?://[^\s?#]+)[?#][^\s]*', r'\1?[параметры скрыты]', text)
        text = text.split('Stacktrace:')[0]
        return re.sub(r'[\x00-\x08\x0b-\x1f\x7f]', '', text)[:2000]

    def emit(self, domain, kind, message, *, level='info', account_id='', run_id='', details=None):
        """Failure-isolated sink, called only with semantic, non-secret context."""
        with self.lock:
            self.sequence += 1
            event = {'id': self.sequence, 'at': utcnow(), 'domain': domain if domain in DOMAINS else 'system',
                     'level': level if level in LEVELS else 'info', 'kind': kind if kind in KINDS else 'diagnostic',
                     'message': self.clean(message), 'account_id': self._identity(account_id),
                     'run_id': self._identity(run_id), 'details': self.clean(details or {})}
            # Bound total payload as well as row count (large progress arrays).
            encoded = json.dumps(event['details'], ensure_ascii=False)
            if len(encoded.encode('utf-8')) > 4000:
                event['details'] = {'summary': 'Большой контекст опущен; основной результат указан в сообщении.'}
                encoded = json.dumps(event['details'], ensure_ascii=False)
            if self.failure and time.monotonic() < self.retry_at:
                self.fallback.append(event)
                return
            try:
                if self.failure:
                    self.path.parent.mkdir(parents=True, exist_ok=True)
                with self._db() as db:
                    if self.failure:
                        self._schema(db)
                    pending = [*self.fallback, event]
                    last = db.execute('SELECT coalesce(max(id),0) FROM events').fetchone()[0]
                    if pending[0]['id'] <= last:
                        for pending_event in pending:
                            last += 1
                            pending_event['id'] = last
                        self.sequence = last
                    db.executemany('INSERT INTO events VALUES(?,?,?,?,?,?,?,?,?)',
                        [(e['id'], e['at'], e['domain'], e['level'], e['kind'], e['message'], e['account_id'],
                          e['run_id'], json.dumps(e['details'], ensure_ascii=False)) for e in pending])
                    self._prune(db)
                    db.commit()
                self.fallback.clear()
                self.failure = ''
            except (OSError, sqlite3.Error):
                self.fallback.append(event)
                self._failed()

    def _identity(self, value):
        # An incidental PIN substring inside an opaque UUID must not break
        # account/job filters. These fields contain public IDs, never inputs.
        text = str(value or '')
        return text if re.fullmatch(r'[A-Za-z0-9_.:-]{0,100}', text) and text not in self.private else self.clean(text)

    def _prune(self, db):
        # IDs can have gaps after memory fallback; retention counts rows.
        db.execute('DELETE FROM events WHERE id <= coalesce((SELECT id FROM events ORDER BY id DESC LIMIT 1 OFFSET ?),0)', (self.max_rows,))
        cutoff = (datetime.now(timezone.utc) - timedelta(days=self.retention_days)).isoformat()
        db.execute('DELETE FROM events WHERE at < ?', (cutoff,))

    @staticmethod
    def _filters(domains=None, levels=None, kinds=None, accounts=None, run_id='', q='', before=0, until=0):
        clauses, args = [], []
        for column, values in [('domain', domains), ('level', levels), ('kind', kinds), ('account_id', accounts)]:
            if values is not None:
                if len(values) > 100:
                    raise ValueError('Слишком много значений фильтра')
                clauses.append(f'{column} IN ({",".join("?" for _ in values)})' if values else '0')
                args.extend(values)
        if run_id:
            clauses.append('run_id=?')
            args.append(run_id[:100])
        if q:
            clauses.append("(casefold(message) LIKE ? ESCAPE '\\' OR casefold(details) LIKE ? ESCAPE '\\' OR casefold(run_id) LIKE ? ESCAPE '\\')")
            escaped = q[:200].casefold().replace('\\', '\\\\').replace('%', '\\%').replace('_', '\\_')
            args.extend([f'%{escaped}%'] * 3)
        if before:
            clauses.append('id < ?')
            args.append(before)
        if until:
            clauses.append('id <= ?')
            args.append(until)
        return ' AND '.join(clauses) or '1', args

    def query(self, limit=100, **filters):
        limit = max(1, min(500, limit))
        where, args = self._filters(**filters)
        with self.lock:
            try:
                with self._db() as db:
                    rows = [dict(r) for r in db.execute(f'SELECT * FROM events WHERE {where} ORDER BY id DESC LIMIT ?', (*args, limit+1))]
                    total = db.execute(f'SELECT count(*) FROM events WHERE {where}', args).fetchone()[0]
                    stats = dict(db.execute('SELECT count(*) AS stored,coalesce(max(id),0) AS latest_id,min(at) AS oldest FROM events').fetchone())
                for row in rows:
                    row['details'] = json.loads(row['details'])
            except (OSError, sqlite3.Error):
                rows, total, stats = [], 0, {'stored': 0, 'latest_id': 0, 'oldest': None}
                self._failed()
            if self.fallback:
                # Apply the exact same SQL filters to memory events.
                with closing(sqlite3.connect(':memory:')) as memory:
                    memory.row_factory = sqlite3.Row
                    memory.create_function('casefold', 1, lambda value: str(value).casefold())
                    memory.execute('CREATE TABLE events(id,at,domain,level,kind,message,account_id,run_id,details)')
                    memory.executemany('INSERT INTO events VALUES(?,?,?,?,?,?,?,?,?)',
                        [(*[e[k] for k in ('id','at','domain','level','kind','message','account_id','run_id')],
                          json.dumps(e['details'], ensure_ascii=False)) for e in self.fallback])
                    found = [dict(r) for r in memory.execute(f'SELECT * FROM events WHERE {where} ORDER BY id DESC LIMIT ?', (*args, limit+1))]
                    for row in found:
                        row['details'] = json.loads(row['details'])
                    total += memory.execute(f'SELECT count(*) FROM events WHERE {where}', args).fetchone()[0]
                    rows = sorted(rows + found, key=lambda e: e['id'], reverse=True)[:limit+1]
                stats['latest_id'] = max(stats['latest_id'], self.fallback[-1]['id'])
            return {'items': rows[:limit], 'has_more': len(rows) > limit,
                    'next_before': rows[limit-1]['id'] if len(rows) > limit else None,
                    'matching': total, **stats, 'memory_events': len(self.fallback), 'warning': self.failure,
                    'max_rows': self.max_rows, 'retention_days': self.retention_days}


def session_step(domain, title):
    """Instrument an entire logical browser operation; never dump its arguments."""
    def decorate(function):
        @wraps(function)
        async def wrapped(self, *args, **kwargs):
            logger = getattr(self, 'logger', None)
            if args and function.__name__ in ('login', 'continue_login') and logger:
                logger.configure(args[0])
            event = getattr(logger, 'event', None)
            def write(message, **fields):
                if event:
                    event(message, domain=domain, kind='step', **fields)
            started = time.monotonic()
            target = args[0] if args else None
            context = {k: target[k] for k in ('id','x_id','username','name') if isinstance(target, dict) and k in target}
            if isinstance(target, str):
                context['target'] = target
            write(title + ': начало', details=context)
            try:
                result = await function(self, *args, **kwargs)
            except BaseException as error:
                # Stop/cancellation is expected control flow, not a browser bug.
                stopped = type(error).__name__ in ('StopRequested', 'CancelledError')
                write(title + (': прервано' if stopped else ': ошибка'), level='warning' if stopped else 'error',
                      details={**context, 'error_type': type(error).__name__, 'reason': str(error)})
                raise
            summary = {k: result[k] for k in ('status','reason','viewed_count','declared_count','period_complete','confirmed','already_member','following','follows_you') if isinstance(result, dict) and k in result}
            if isinstance(result, dict):
                for k in ('groups','participants','posts'):
                    if isinstance(result.get(k), list):
                        summary[k + '_count'] = len(result[k])
            write(title + ': завершено', details={**context, **summary, 'duration_ms': round((time.monotonic()-started)*1000)})
            return result
        return wrapped
    return decorate
