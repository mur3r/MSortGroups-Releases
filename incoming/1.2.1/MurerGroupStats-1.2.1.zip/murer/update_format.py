"""Signed, bounded release packages. Never execute files before verification."""
import base64
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import stat
import zipfile

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

APP = 'Murer Group Stats'
UPDATER_PROTOCOL = 1
MAX_PACKAGE = 128 * 1024 * 1024
MAX_UNPACKED = 512 * 1024 * 1024
MAX_METADATA = 2 * 1024 * 1024
REQUIRED = {'VERSION', 'start.cmd', 'install.cmd', 'requirements-lock.txt', 'murer/__main__.py',
            'murer/api.py', 'scripts/launcher.py', 'frontend/dist/index.html', 'config/updates.json'}
ALLOWED_ROOTS = {'murer', 'xgenius', 'frontend', 'config', 'scripts', 'docs', 'tests', '.github'}
ALLOWED_FILES = {'VERSION', 'start.cmd', 'start-8766.cmd', 'install.cmd', 'publish-release.cmd',
                 'requirements.txt', 'requirements-app.txt', 'requirements-lock.txt', 'check_setup.py',
                 'human1.py', '.gitignore', 'README.md', 'SOURCE.md', 'VALIDATION.md',
                 'IMPLEMENTATION_STATUS.md', 'COLLECTION_VALIDATION.md', 'RELEASE_NOTES.md'}


class UpdateError(ValueError):
    """Safe user-facing error; network responses and credentials are never echoed."""


def version_tuple(value):
    if not isinstance(value, str) or not re.fullmatch(r'(0|[1-9]\d{0,5})\.(0|[1-9]\d{0,5})\.(0|[1-9]\d{0,5})', value):
        raise UpdateError('Версия должна иметь вид 1.2.3 без beta/rc.')
    return tuple(map(int, value.split('.')))


def canonical_json(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False).encode('utf-8')


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def safe_member(name):
    if not isinstance(name, str) or not name or name == '.' or len(name) > 220 or '\\' in name or ':' in name or '\x00' in name:
        raise UpdateError('Недопустимый путь в пакете обновления.')
    path = PurePosixPath(name)
    if path.is_absolute() or str(path) != name or any(p in ('.', '..') or p.endswith((' ', '.')) for p in path.parts):
        raise UpdateError('Недопустимый путь в пакете обновления.')
    if any(re.match(r'^(con|prn|aux|nul|com[0-9]|lpt[0-9])(?:\.|$)', p, re.I) for p in path.parts):
        raise UpdateError('Зарезервированное имя Windows в пакете.')
    if any(p.lower() in {'.git', '.venv', 'node_modules', '__pycache__', '.murer-updates',
                         'browser_profiles', 'kook', 'logs', 'data', 'artifacts'} for p in path.parts):
        raise UpdateError('Пакет содержит локальные данные или зависимости.')
    if path.suffix.lower() in {'.lnk', '.sqlite3', '.db', '.pem', '.key', '.pyc', '.log'} or any(p.startswith('.env') for p in path.parts):
        raise UpdateError('Пакет содержит недопустимый локальный файл.')
    if len(path.parts) == 1 and name not in ALLOWED_FILES:
        raise UpdateError('Неизвестный корневой файл в пакете.')
    if len(path.parts) > 1 and path.parts[0] not in ALLOWED_ROOTS:
        raise UpdateError('Неизвестная папка в пакете.')
    if name in {'config/settings.json', 'config/accounts.json'}:
        raise UpdateError('Настройки пользователя не могут входить в обновление.')
    return name


def verify_manifest(raw, signature_raw, public_keys):
    if len(raw) > MAX_METADATA or len(signature_raw) > 4096:
        raise UpdateError('Метаданные обновления слишком велики.')
    try:
        signature = json.loads(signature_raw)
        key = Ed25519PublicKey.from_public_bytes(base64.b64decode(public_keys[signature['key_id']], validate=True))
        key.verify(base64.b64decode(signature['signature'], validate=True), raw)
    except (KeyError, ValueError, TypeError, InvalidSignature) as error:
        raise UpdateError('Подпись обновления недействительна. Установка отменена.') from error
    try:
        manifest = json.loads(raw)
        version_tuple(manifest['version'])
        package, files = manifest['package'], manifest['files']
        if (type(manifest['schema']) is not int or manifest['schema'] != 1 or manifest['application'] != APP
                or type(manifest['updater_protocol']) is not int or not 1 <= manifest['updater_protocol'] <= UPDATER_PROTOCOL):
            raise UpdateError('Этот пакет требует более нового установщика.')
        if package['name'] != f"MurerGroupStats-{manifest['version']}.zip":
            raise UpdateError('Имя архива не соответствует версии.')
        if type(package['size']) is not int or not 0 < package['size'] <= MAX_PACKAGE or not re.fullmatch('[0-9a-f]{64}', package['sha256']):
            raise UpdateError('Некорректный размер или контрольная сумма пакета.')
        if not isinstance(files, dict) or not REQUIRED.issubset(files) or len(files) > 5000:
            raise UpdateError('Пакет неполный.')
        lowered = set()
        for name, digest in files.items():
            safe_member(name)
            if name.lower() in lowered or not isinstance(digest, str) or not re.fullmatch('[0-9a-f]{64}', digest):
                raise UpdateError('Повтор пути или некорректная контрольная сумма.')
            lowered.add(name.lower())
        return manifest
    except (KeyError, TypeError, ValueError) as error:
        if isinstance(error, UpdateError):
            raise
        raise UpdateError('Некорректный формат подписанного обновления.') from error


def extract_package(archive, destination, manifest):
    archive, destination = Path(archive), Path(destination)
    if archive.stat().st_size != manifest['package']['size'] or sha256(archive) != manifest['package']['sha256']:
        raise UpdateError('Архив скачан не полностью или повреждён. Скачайте его заново.')
    try:
        with zipfile.ZipFile(archive) as source:
            members = source.infolist()
            names = [item.filename for item in members]
            if len(names) != len(set(names)) or set(names) != set(manifest['files']):
                raise UpdateError('Содержимое архива отличается от подписанного списка файлов.')
            if sum(item.file_size for item in members) > MAX_UNPACKED:
                raise UpdateError('Распакованный пакет слишком велик.')
            for item in members:
                safe_member(item.filename)
                mode = item.external_attr >> 16
                if stat.S_ISLNK(mode) or item.is_dir() or (mode and stat.S_IFMT(mode) not in (0, stat.S_IFREG)):
                    raise UpdateError('Ссылки и специальные файлы в обновлении запрещены.')
            destination.mkdir(parents=True, exist_ok=False)
            for item in members:
                target = destination.joinpath(*PurePosixPath(item.filename).parts)
                target.parent.mkdir(parents=True, exist_ok=True)
                digest = hashlib.sha256()
                with source.open(item) as src, target.open('xb') as out:
                    for chunk in iter(lambda: src.read(1024 * 1024), b''):
                        digest.update(chunk)
                        out.write(chunk)
                if digest.hexdigest() != manifest['files'][item.filename]:
                    raise UpdateError('Контрольная сумма файла не совпала. Установка отменена.')
    except (zipfile.BadZipFile, RuntimeError) as error:
        raise UpdateError('Архив обновления повреждён.') from error
    verify_tree(destination, manifest)


def verify_tree(directory, manifest):
    directory = Path(directory).resolve()
    for name, digest in manifest['files'].items():
        path = directory.joinpath(*PurePosixPath(safe_member(name)).parts)
        if path.is_symlink() or not path.is_file() or directory not in path.resolve().parents or sha256(path) != digest:
            raise UpdateError('Подготовленные файлы обновления изменены или повреждены.')
    if (directory / 'VERSION').read_text(encoding='utf-8').strip() != manifest['version']:
        raise UpdateError('Версия внутри пакета не совпадает с подписанной версией.')
