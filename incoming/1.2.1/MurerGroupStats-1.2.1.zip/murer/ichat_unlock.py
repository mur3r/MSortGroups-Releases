"""One conservative attempt to unlock an existing XChat password/PIN gate.

This is separate from X login and never handles verification, PIN creation,
PIN reset, or challenges. XChat's shadow-root pin-title and numeric inputs were
observed live; synthetic fixtures cover regression and unsupported forms.
"""
from __future__ import annotations

from datetime import datetime, timezone
import inspect

from xgenius.core.dom import DEEP_QUERY_JS


ICHAT_UNLOCK_PROBE_JS = DEEP_QUERY_JS + r"""
const pageUrl = new URL(location.href);
if (!['x.com','www.x.com'].includes(pageUrl.hostname) || pageUrl.protocol !== 'https:' ||
    !/^\/i\/chat(?:\/|$)/.test(pageUrl.pathname)) return {state:'absent'};
const visible = el => !!el && !!(el.offsetWidth || el.offsetHeight || el.getClientRects().length);
const sensitive = deepQueryAll('input[type="password"],input[inputmode="numeric"],input[inputmode="decimal"],input[autocomplete="one-time-code"]').filter(visible);
// X also uses /pin/recovery for entering an EXISTING passcode to decrypt keys.
// The route alone cannot distinguish that gate from PIN creation/reset.
const keyRecovery = /^\/i\/chat\/pin\/recovery\/?$/.test(pageUrl.pathname);
if (/\/pin\/(?:recover|create|setup|reset|change|confirm)(?:\/|$)/i.test(pageUrl.pathname))
  return {state:'manual',reason:'recovery_or_setup'};
const challenge = deepQueryAll('iframe[src*="captcha"],iframe[src*="arkose"],input[autocomplete="one-time-code"],input[name="verif_code"]').some(visible);
if (challenge) return {state:'manual',reason:'verification'};
if (!sensitive.length) return {state:'absent'};
// Password fields in a message composer or another part of X are never eligible.
const candidates = deepQueryAll('form,[role="dialog"],[data-testid="xchat-pin-unlock"],[data-testid="pin-unlock"],[data-testid="unlock-form"]')
  .filter(scope => visible(scope) && sensitive.some(input => deepQueryAll('input',scope).includes(input)));
// Some XChat embeds do not use a form. Accept its shadow root only when the
// root is an explicit xchatEmbedRoute, then still require the unlock heading.
for (const host of deepQueryAll('[data-testid="xchatEmbedRoute"],#xchatEmbedRoute')) {
  if (host.shadowRoot && sensitive.some(input => deepQueryAll('input',host.shadowRoot).includes(input))) candidates.push(host.shadowRoot);
}
const ready=[];
for (const scope of candidates) {
  const inputs = deepQueryAll('input',scope).filter(visible);
  const fields = sensitive.filter(input => inputs.includes(input));
  // Verified live: X renders "Enter Passcode" in a plain DIV, not h1/h2.
  const headings = deepQueryAll('h1,h2,h3,[role="heading"],legend,label,[data-testid="pin-title"]',scope).filter(visible)
    .map(el => (el.innerText || el.textContent || '').trim()).join(' ');
  const text = scope.innerText || Array.from(scope.children || []).map(el=>el.innerText || '').join(' ');
  const forbidden = /(?:create|set up|set a new|choose|confirm|change|reset|recover)\s+(?:your\s+|a\s+|new\s+)*(?:pin|password|passcode)|(?:verification|security|authentication)\s+code|two.factor|2fa|созда\S*\s+(?:нов\S*\s+)?(?:pin|пин|парол|код.парол)|подтверд\S*\s+(?:pin|пин|парол|код.парол)|(?:восстанов|смен|сброс)\S*\s+(?:pin|пин|парол|код.парол)|код\s+(?:проверки|подтверждения|безопасности)/i;
  if (forbidden.test(headings) || forbidden.test(text)) continue;
  const unlock = /(?:enter|type)\s+(?:your\s+)?(?:chat\s+)?(?:pin|password|passcode)|unlock\s+(?:your\s+)?(?:chat|messages)|введите\s+(?:свой\s+|ваш\s+)?(?:пин|pin|пароль|код.пароль)|разблокир\S*\s+(?:чат|сообщ)/i;
  if (!unlock.test(headings)) continue;
  if (keyRecovery && !/^(?:enter\s+(?:your\s+)?passcode|введите\s+(?:свой\s+|ваш\s+)?код.пароль)$/i.test(headings.trim())) continue;
  const markers = fields.map(input => ['name','id','aria-label','placeholder','autocomplete','data-testid']
    .map(key=>input.getAttribute(key) || '').join(' ')).join(' ');
  if (/one-time-code|verif|otp|2fa|captcha|composer|message-input|recovery|confirm|new.?pin|new.?password/i.test(markers)) continue;
  // Reject extra visible controls: a second password may be confirmation.
  if (inputs.some(input => !fields.includes(input) && !['hidden','submit','button'].includes(input.type))) continue;
  const segmented = fields.length >= 4 && fields.length <= 12 && fields.every(input =>
    input.maxLength === 1 && ['password','text','tel','number'].includes(input.type) &&
    (['numeric','decimal'].includes(input.inputMode) || /pin|пин|digit|цифр/i.test(input.getAttribute('aria-label') || '')));
  const single = fields.length === 1 && fields[0].type === 'password';
  if (!single && !segmented) continue;
  const buttons = deepQueryAll('button,input[type="submit"]',scope).filter(visible).filter(button =>
    /^(?:unlock|continue|submit|разблокировать|продолжить|далее|войти)$/i.test((button.innerText || button.value || button.getAttribute('aria-label') || '').trim()));
  // Split PIN widgets may auto-advance. Single-field forms require one
  // explicit button; Enter and inferred submission are never used.
  if (buttons.length > 1 || (!segmented && buttons.length !== 1)) continue;
  ready.push({state:'ready',fields,segmented,button:buttons[0] || null});
}
// A nested form and its enclosing dialog can describe the same single gate.
const unique=[];
for (const item of ready) if (!unique.some(other => other.fields.length===item.fields.length &&
    other.fields.every((field,index)=>field===item.fields[index]) && other.button===item.button)) unique.push(item);
return unique.length === 1 ? unique[0] : {state:'manual',reason:'ambiguous_or_unsupported'};
"""


class IChatUnlock:
    EVENTS = frozenset({'gate_ready', 'input_completed', 'submit_clicked',
                        'auto_advanced', 'gate_absent', 'manual'})

    def __init__(self, on_event=None):
        self.attempted = False
        self.on_event = on_event
        self._last_event = None

    async def _emit(self, event):
        if event not in self.EVENTS:
            raise ValueError('Неизвестное событие iChat')
        if event == self._last_event:
            return
        self._last_event = event
        if self.on_event:
            result = self.on_event({'event': event, 'timestamp': datetime.now(timezone.utc).isoformat()})
            if inspect.isawaitable(result):
                await result

    async def check(self, actions, password):
        """Caller holds the session queue; return a manual gate or None.

        Mark the attempt before the first character so pause/error/stop cannot
        replay a partly entered secret. Only an explicit new browser login
        creates a new instance and permits another automatic attempt.
        """
        probe = await actions.script(ICHAT_UNLOCK_PROBE_JS)
        if not isinstance(probe, dict):
            return None
        if probe.get('state') == 'absent':
            # Absence is an observation, never proof of successful unlocking.
            await self._emit('gate_absent')
            return None
        if probe.get('state') != 'ready':
            return await self.manual('Форма iChat требует ручного действия; автоматический ввод здесь недоступен')
        await self._emit('gate_ready')
        if self.attempted:
            return await self.manual('Автоматический ввод iChat уже выполнен один раз. Проверьте пароль/PIN в открытом Chrome')
        if not password:
            return await self.manual('Для iChat не задан отдельный пароль/PIN. Добавьте его в настройках аккаунта или введите в Chrome')
        if any(ord(char) < 32 or ord(char) == 127 or 0xE000 <= ord(char) <= 0xF8FF for char in password):
            return await self.manual('Пароль/PIN iChat содержит управляющие символы; проверьте значение в настройках аккаунта')
        fields = probe.get('fields') or []
        segmented = bool(probe.get('segmented'))
        if not fields:
            return await self.manual('В форме iChat не найдены поля PIN; продолжите вручную')
        if segmented and (len(password) != len(fields) or not password.isascii() or not password.isdigit()):
            return await self.manual(f'X запрашивает PIN из {len(fields)} цифр. Сохранённое значение не соответствует этому формату; исправьте «Пароль / PIN iChat» в аккаунте. Пароль X здесь не используется')
        self.attempted = True
        try:
            if segmented:
                for field, char in zip(fields, password):
                    await actions.unlock_input(field, char, segmented=True)
            else:
                await actions.unlock_input(fields[0], password)
            await self._emit('input_completed')
            # Re-probe after entry: the input can auto-submit or be replaced.
            current = await actions.script(ICHAT_UNLOCK_PROBE_JS)
            if current.get('state') == 'absent':
                await self._emit('auto_advanced')
                await self._emit('gate_absent')
                return None
            if current.get('state') != 'ready':
                return await self.manual('iChat требует ручного подтверждения после ввода пароля/PIN')
            if current.get('fields') != fields:
                return await self.manual('Форма iChat изменилась во время ввода; продолжите вручную')
            button = current.get('button')
            if button is not None:
                if not await actions.call(button.is_enabled):
                    return await self.manual('iChat не разрешил продолжение; проверьте пароль/PIN в открытом Chrome')
                await actions.click(button)
                await self._emit('submit_clicked')
            collection = actions.settings.get('collection', actions.settings)
            rounds = max(1, int(collection.get('login_poll_rounds', 12)))
            for _ in range(rounds):
                await actions.sleep(float(collection.get('login_poll_seconds', 2.5)))
                current = await actions.script(ICHAT_UNLOCK_PROBE_JS)
                if current.get('state') == 'absent':
                    if button is None:
                        await self._emit('auto_advanced')
                    await self._emit('gate_absent')
                    return None
                if current.get('state') != 'ready':
                    break
            return await self.manual('iChat не подтвердил разблокировку. Автоповтор отключён; проверьте пароль/PIN вручную')
        except Exception as exc:
            if type(exc).__name__ in ('StopRequested', 'PauseRequested', 'JobStopped'):
                raise
            # Do not include webdriver exceptions: some drivers echo input.
            return await self.manual('Автоматический ввод iChat остановлен. Проверьте открытое окно Chrome')

    async def manual(self, reason):
        await self._emit('manual')
        return {'status': 'requires_manual', 'reason': reason + '. Нажмите «Продолжить после ручного подтверждения» после завершения'}
