import csv
import io
import json
from openpyxl import Workbook
from openpyxl.cell.cell import ILLEGAL_CHARACTERS_RE

TABLES = ('accounts', 'groups', 'participants', 'overlaps', 'account_overlaps', 'own_accounts', 'recommendations')
LABELS = {'accounts': 'Аккаунты', 'groups': 'Группы', 'participants': 'Участники', 'overlaps': 'Пересечения групп',
          'account_overlaps': 'Пересечения аккаунтов', 'own_accounts': 'Наши аккаунты', 'recommendations': 'Рекомендации'}
SENSITIVE = {'password', 'ichat_password', 'ichat_pin', 'chat_password', 'proxy', 'auth_token', 'ct0_token', 'cookies', 'cookie', 'authorization', 'access_token'}


def clean(value):
    if isinstance(value, dict):
        return {k: clean(v) for k, v in value.items() if k.lower() not in SENSITIVE}
    if isinstance(value, list):
        return [clean(v) for v in value]
    return value


def cell(value):
    if value is None:
        return ''
    if isinstance(value, (dict, list)):
        value = json.dumps(clean(value), ensure_ascii=False)
    if isinstance(value, str) and value.lstrip(' \t\r\n')[:1] in ('=', '+', '-', '@'):
        # Protect CSV/Excel from formulas in untrusted names and text.
        return "'" + value
    return value


def filtered_rows(rows, search='', sort=None, descending=False):
    rows = [clean(r) for r in rows]
    if search:
        query = search.lower()
        rows = [r for r in rows if query in json.dumps(r, ensure_ascii=False).lower()]
    if sort:
        rows.sort(key=lambda r: (r.get(sort) is None, 0 if isinstance(r.get(sort), (int, float)) else 1,
            r[sort] if isinstance(r.get(sort), (int, float)) else str(r.get(sort, '')).lower()), reverse=descending)
    return rows


def csv_report(rows, columns=None, metadata=None):
    out = io.StringIO(newline='')
    fields = [k for k in (columns or list(dict.fromkeys(k for row in rows for k in row))) if k.lower() not in SENSITIVE]
    has_metadata = metadata is not None or bool(rows and 'export_metadata' in rows[0])
    if has_metadata and 'export_metadata' not in fields:
        fields.append('export_metadata')
    writer = csv.writer(out, delimiter=';')
    writer.writerow(fields)
    if not rows and metadata is not None:
        writer.writerow([cell(metadata) if key == 'export_metadata' else '' for key in fields])
    for row in rows:
        writer.writerow([cell(row.get(k, metadata if k == 'export_metadata' else None)) for k in fields])
    return b'\xef\xbb\xbf' + out.getvalue().encode('utf-8')


def _flatten(row, prefix=''):
    """Keep numeric metrics numeric instead of embedding them in JSON cells."""
    result = {}
    for key, value in clean(row).items():
        name = f'{prefix}_{key}' if prefix else key
        if isinstance(value, dict):
            result.update(_flatten(value, name))
        else:
            result[name] = value
    return result


def excel_report(analysis, accounts, metadata, dataset=None):
    """Export scoped records in rows; large observations never occupy one cell.

    The optional dataset supplies actual observations for the current/frozen
    snapshot. Without it, derived samples and access-attempt metadata are clearly
    identified as such. Cells exceeding Excel's limit are preserved in chunks.
    """
    workbook = Workbook(write_only=True)
    long_values = []
    def bounded(value, sheet, row, column):
        value = cell(value)
        if isinstance(value, str):
            value = ILLEGAL_CHARACTERS_RE.sub(lambda m: f'\\u{ord(m.group()):04x}', value)
            if len(value) > 30000:
                reference = f'L{len(long_values) + 1}'
                chunks = [value[index:index+29000] for index in range(0, len(value), 29000)]
                for index, chunk in enumerate(chunks, 1):
                    long_values.append({'reference': reference, 'sheet': sheet, 'row': row, 'column': column,
                                        'part': index, 'parts': len(chunks), 'text': chunk})
                return f'Длинное значение {reference}: {len(value)} символов, лист «Длинные значения»'
        return value

    def write_table(name, rows):
        rows = [_flatten(row) for row in rows]
        sheet = workbook.create_sheet(name)
        sheet.freeze_panes = 'A2'
        columns = list(dict.fromkeys(key for row in rows for key in row))
        sheet.append([bounded(key, name, 1, key) for key in columns] or ['Нет данных'])
        for index, row in enumerate(rows, 2):
            sheet.append([bounded(row.get(key), name, index, key) for key in columns])

    info = workbook.create_sheet('Область и правила')
    info.freeze_panes = 'A2'
    info.append(['Параметр', 'Значение'])
    for index, (key, value) in enumerate(clean(metadata).items(), 2):
        info.append([bounded(key, info.title, index, 'Параметр'), bounded(value, info.title, index, 'Значение')])
    for table in TABLES:
        rows = clean(accounts if table == 'accounts' else analysis.get(table, []))
        omitted = {'posts', 'observations', 'access_attempts'} if table == 'participants' else set()
        if table == 'groups':
            omitted = {'participant_ids', 'components', 'recommendations'}
        if table == 'own_accounts':
            omitted = {'recommendations'}
        write_table(LABELS[table], [{key: value for key, value in row.items() if key not in omitted} for row in rows])

    scoped_participants = {p['id']: p for p in analysis.get('participants', [])}
    raw_participants = {p['id']: p for p in (dataset or {}).get('participants', []) if p['id'] in scoped_participants}
    observation_rows, post_rows = [], []
    for pid, profile in scoped_participants.items():
        observations = raw_participants.get(pid, {}).get('observations', [])
        if observations:
            records = [('saved_observation', observation) for observation in observations]
        else:
            records = [('access_attempt', attempt) for attempt in profile.get('access_attempts', [])]
            records.append(('current_analysis_sample', {
                'observed_at': profile.get('checked_at'), 'source_account_id': profile.get('source_account_id'),
                'status': profile.get('status'), 'followers': profile.get('followers'), 'posts_total': profile.get('posts_total'),
                'metrics_observed_at': profile.get('metrics_observed_at'), 'posts': profile.get('posts', []),
                'period_complete': profile.get('period_complete'), 'chronology_confirmed': profile.get('chronology_confirmed'),
                'requested_n': profile.get('requested_n'), 'requested_days': profile.get('requested_days'),
                'viewed_count': profile.get('viewed_count'), 'classified_count': profile.get('classified_count')}))
        for index, (basis, observation) in enumerate(records, 1):
            key = f'{pid}:{index}'
            context = {'participant_id': pid, 'username': profile.get('username'), 'observation_key': key,
                       'export_basis': basis, 'observed_at': observation.get('observed_at'),
                       'source_account_id': observation.get('source_account_id')}
            observation_rows.append({**context, **{name: value for name, value in observation.items() if name != 'posts'}})
            seen = set()
            for sequence, post in enumerate(observation.get('posts', []), 1):
                identity = (post.get('id') or post.get('url'), post.get('type'), post.get('event_at'))
                if identity[0] is not None:
                    if identity in seen:
                        continue
                    seen.add(identity)
                post_rows.append({**post, **context, 'sequence': sequence})
    write_table('Публикации', post_rows)
    write_table('Наблюдения', observation_rows)

    membership_rows, component_rows = [], []
    for group in analysis.get('groups', []):
        for pid in group.get('participant_ids', []):
            if pid in scoped_participants:
                membership_rows.append({'group_id': group['id'], 'group_name': group.get('name'),
                    'participant_id': pid, 'username': scoped_participants[pid].get('username'),
                    'is_ours': scoped_participants[pid].get('is_ours'), 'membership_status': group.get('membership_status'),
                    'group_observed_at': group.get('observed_at'), 'source_account_ids': group.get('account_ids'),
                    'membership_observed_from': group.get('membership_observed_from'),
                    'membership_observed_to': group.get('membership_observed_to')})
        for component, values in group.get('components', {}).items():
            component_rows.append({'group_id': group['id'], 'group_name': group.get('name'), 'component': component,
                **values, 'score': group.get('score'), 'category': group.get('category'),
                'settings_version': analysis.get('settings_version'), 'calculated_at': analysis.get('calculated_at')})
    write_table('Состав групп', membership_rows)
    write_table('Расчёт оценки', component_rows)
    if long_values:
        write_table('Длинные значения', long_values)
    output = io.BytesIO()
    workbook.save(output)
    return output.getvalue()
