"""New credentials live in the OS credential vault, never SQLite or exports."""
import re
import keyring

SECRET_FIELDS = ("password", "auth_token", "ct0_token", "proxy", "ichat_password")


def validate_ichat_password(value, allow_empty=True):
    if not isinstance(value, str) or len(value) > 128:
        raise ValueError('Пароль/PIN iChat должен быть строкой до 128 символов')
    if not allow_empty and not value:
        raise ValueError('Введите пароль/PIN iChat')
    if any(ord(char) < 32 or ord(char) == 127 or 0xE000 <= ord(char) <= 0xF8FF for char in value):
        raise ValueError('Пароль/PIN iChat не должен содержать управляющие символы')
    return value


class SecretStore:
    service = "Murer Group Stats"

    def __init__(self, backend=None):
        self.protect = lambda values: None
        self.backend = backend or keyring.get_keyring()
        if backend is None and self.backend.priority <= 0:
            raise RuntimeError("Хранилище секретов Windows недоступно. Запустите приложение в своём профиле Windows.")

    def set(self, account_id, values):
        self.protect(values.get(field) for field in SECRET_FIELDS)
        for field in SECRET_FIELDS:
            if field in values and values[field] is not None:
                value = str(values[field])
                key = f"{account_id}:{field}"
                if value:
                    self.backend.set_password(self.service, key, value)
                else:
                    try:
                        self.backend.delete_password(self.service, key)
                    except keyring.errors.PasswordDeleteError:
                        pass

    def get(self, account_id):
        result = {field: self.backend.get_password(self.service, f"{account_id}:{field}") or "" for field in SECRET_FIELDS}
        self.protect(result.values())
        return result

    def flags(self, account_id):
        return {f"has_{field}": bool(value) for field, value in self.get(account_id).items()}


def redact(message, secrets=()):
    value = str(message)
    for secret in sorted((str(x) for x in secrets if x), key=len, reverse=True):
        value = value.replace(secret, "[скрыто]")
    value = re.sub(r"(?i)(auth_token|ct0|ichat_password|password|authorization)(\s*[=:]\s*)\S+", r"\1\2[скрыто]", value)
    value = re.sub(r"https?://[^\s/@]+:[^\s/@]+@", "https://[скрыто]@", value)
    return value[:2000]
