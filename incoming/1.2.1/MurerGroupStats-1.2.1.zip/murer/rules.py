"""Validated, versionable settings. All public values use seconds, days or percent."""
from copy import deepcopy
from math import isfinite


def default_settings() -> dict:
    return {
        "collection": {
            "posts_limit": 100, "period_days": 30, "cache_hours": 24,
            "profiles_limit": 0,
            "refresh_mode": "stale", "group_scroll_limit": 300,
            "member_scroll_limit": 300, "profile_scroll_limit": 300,
            "idle_scroll_limit": 6, "load_wait_seconds": 2, "retries": 2,
            "action_delay_seconds": 1, "profile_delay_seconds": 3,
            "group_delay_seconds": 3, "account_delay_seconds": 5,
            "concurrent_accounts": 1, "account_start_interval_seconds": 5, "element_timeout_seconds": 20,
            "save_interval_seconds": 5,
            "page_load_timeout_seconds": 45, "script_timeout_seconds": 30,
            "login_typing_delay_min": 0.05, "login_typing_delay_max": 0.15,
            "login_element_timeout_seconds": 15, "login_poll_rounds": 12,
            "login_poll_seconds": 2.5,
            "scroll_step_pixels": 600, "scroll_pause_seconds": 0.2,
            "login_page_wait_seconds": 2, "login_step_wait_seconds": 1,
            "login_button_timeout_seconds": 10,
        },
        "humanization": {
            "enabled": False, "action_delay_min": 1, "action_delay_max": 4,
            "typing_delay_min": 0.05, "typing_delay_max": 0.15,
            "scroll_step_min": 300, "scroll_step_max": 700,
            "scroll_pause_min": 0.5, "scroll_pause_max": 1.5,
        },
        "evaluation": {
            "weights": {"U": 30, "F": 20, "P": 10, "R": 25, "A": 15},
            "followers_low": 100, "followers_high": 5000,
            "posts_low": 100, "posts_high": 10000,
            "reposts_min": 5, "reposts_days": 30, "active_days": 7,
            "min_coverage": 80, "good_score": 70, "medium_score": 40,
            "include_quotes": False, "include_replies": False,
            "include_ours": False, "missing_policy": "renormalize",
            "denominator_policy": "evaluable",
            "overlap_pair_limit": 5000,
        },
        "own_accounts": {"default_allowance": 1, "unlimited": False, "group_rules": {}},
    }


def speed_presets():
    """Only pacing changes: volumes, timeouts, parallelism and humanization toggle stay intact."""
    baseline = default_settings()
    keys = ("action_delay_seconds", "profile_delay_seconds", "group_delay_seconds",
            "account_delay_seconds", "account_start_interval_seconds", "load_wait_seconds",
            "scroll_step_pixels", "scroll_pause_seconds", "login_typing_delay_min",
            "login_typing_delay_max", "login_page_wait_seconds", "login_step_wait_seconds",
            "login_poll_seconds")
    medium = {"collection": {key: baseline["collection"][key] for key in keys},
              "humanization": {key: value for key, value in baseline["humanization"].items() if key != "enabled"}}
    slow = {"collection": dict(zip(keys, (3, 8, 12, 15, 30, 4, 350, .8, .12, .25, 4, 2, 3))),
            "humanization": dict(action_delay_min=3, action_delay_max=6, typing_delay_min=.12,
                typing_delay_max=.25, scroll_step_min=200, scroll_step_max=450, scroll_pause_min=1, scroll_pause_max=2)}
    fast = {"collection": dict(zip(keys, (.25, 1, 1, 1, 2, 1, 800, .1, .03, .08, 1, .5, 1))),
            "humanization": dict(action_delay_min=.25, action_delay_max=.75, typing_delay_min=.03,
                typing_delay_max=.08, scroll_step_min=500, scroll_step_max=900, scroll_pause_min=.15, scroll_pause_max=.4)}
    return [{"id": key, "name": name, "settings": values} for key, name, values in
            (("slow", "Медленная", slow), ("medium", "Средняя", medium), ("fast", "Быстрая", fast))]


def _merge(base, supplied):
    result = deepcopy(base)
    for key, value in supplied.items():
        if isinstance(value, dict) and isinstance(result.get(key), dict):
            result[key] = _merge(result[key], value)
        else:
            result[key] = deepcopy(value)
    return result


def _number(section, key, minimum=0, maximum=None, integer=False):
    value = section.get(key)
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not isfinite(value):
        raise ValueError(f"{key}: требуется конечное число")
    if integer and int(value) != value:
        raise ValueError(f"{key}: требуется целое число")
    if value < minimum or (maximum is not None and value > maximum):
        raise ValueError(f"{key}: значение вне допустимого диапазона")
    if integer:
        section[key] = int(value)


def validate_settings(settings: dict) -> dict:
    """Merge omitted defaults, validate atomically, and return a detached value.

    Invalid intermediate input raises ValueError; the caller keeps its last valid
    persisted version. A version must be saved before starting a collection job.
    """
    if not isinstance(settings, dict):
        raise ValueError("Настройки должны быть объектом")
    result = _merge(default_settings(), settings)
    for name in ("collection", "humanization", "evaluation", "own_accounts"):
        if not isinstance(result[name], dict):
            raise ValueError(f"{name}: требуется объект")
    c, h, e, o = (result[name] for name in ("collection", "humanization", "evaluation", "own_accounts"))
    for key in ("posts_limit", "period_days", "group_scroll_limit", "member_scroll_limit",
                "profile_scroll_limit", "idle_scroll_limit", "concurrent_accounts", "login_poll_rounds"):
        _number(c, key, 1, integer=True)
    _number(c, "retries", 0, integer=True)
    _number(c, "profiles_limit", 0, integer=True)
    _number(c, "scroll_step_pixels", 1, integer=True)
    _number(c, "cache_hours", 0)
    for key in ("load_wait_seconds", "action_delay_seconds", "profile_delay_seconds",
                "group_delay_seconds", "account_delay_seconds", "account_start_interval_seconds", "login_typing_delay_min", "login_typing_delay_max", "login_poll_seconds",
                "scroll_pause_seconds", "login_page_wait_seconds", "login_step_wait_seconds"):
        _number(c, key, 0)
    if c["login_typing_delay_min"] > c["login_typing_delay_max"]:
        raise ValueError("login_typing_delay: минимум превышает максимум")
    for key in ("element_timeout_seconds", "save_interval_seconds", "page_load_timeout_seconds",
                "script_timeout_seconds", "login_element_timeout_seconds", "login_button_timeout_seconds"):
        _number(c, key, 0.01)
    if c["refresh_mode"] not in ("stale", "all", "missing"):
        raise ValueError("refresh_mode: допустимы stale, all, missing")
    if not isinstance(h["enabled"], bool):
        raise ValueError("enabled: требуется логическое значение")
    for prefix in ("action_delay", "typing_delay", "scroll_step", "scroll_pause"):
        _number(h, prefix + "_min", 1 if prefix == "scroll_step" else 0)
        _number(h, prefix + "_max", 1 if prefix == "scroll_step" else 0)
        if h[prefix + "_min"] > h[prefix + "_max"]:
            raise ValueError(f"{prefix}: минимум превышает максимум")
    if not isinstance(e["weights"], dict):
        raise ValueError("weights: требуется объект")
    for key in "UFPRA":
        _number(e["weights"], key, 0)
    if set(e["weights"]) != set("UFPRA"):
        raise ValueError("weights: допустимы только компоненты U, F, P, R, A")
    if not sum(e["weights"].values()):
        raise ValueError("Хотя бы один вес должен быть больше нуля")
    for prefix in ("followers", "posts"):
        _number(e, prefix + "_low", 0)
        _number(e, prefix + "_high", 0)
        if e[prefix + "_high"] <= e[prefix + "_low"]:
            raise ValueError(f"{prefix}: целевой порог должен быть выше нижнего")
    _number(e, "reposts_min", 0, integer=True)
    _number(e, "overlap_pair_limit", 1, integer=True)
    for key in ("reposts_days", "active_days"):
        _number(e, key, 1, integer=True)
    for key in ("min_coverage", "good_score", "medium_score"):
        _number(e, key, 0, 100)
    if e["medium_score"] >= e["good_score"]:
        raise ValueError("Граница «Хорошая» должна быть выше границы «Средняя»")
    for key in ("include_quotes", "include_replies", "include_ours"):
        if not isinstance(e[key], bool):
            raise ValueError(f"{key}: требуется логическое значение")
    if e["missing_policy"] not in ("renormalize", "strict") or e["denominator_policy"] != "evaluable":
        raise ValueError("Допустимы renormalize/strict; знаменатель — подтверждённые профили")
    _number(o, "default_allowance", 0, integer=True)
    if not isinstance(o["unlimited"], bool) or not isinstance(o["group_rules"], dict):
        raise ValueError("Правила наших аккаунтов имеют неверный формат")
    for gid, rule in o["group_rules"].items():
        if not isinstance(rule, dict):
            raise ValueError(f"Правило группы {gid} должно быть объектом")
        if rule.get("allowance") is not None:
            _number(rule, "allowance", 0, integer=True)
        if "unlimited" in rule and not isinstance(rule["unlimited"], bool):
            raise ValueError("unlimited: требуется логическое значение")
        for key in ("pinned_account_ids", "exempt_account_ids"):
            if key in rule and (not isinstance(rule[key], list) or any(isinstance(x, (dict, list)) for x in rule[key])):
                raise ValueError(f"{key}: требуется список идентификаторов аккаунтов")
    return result
