import argparse
import json
import os
from pathlib import Path
import socket
import sys
import threading
import time
import urllib.request
import webbrowser

import uvicorn
from .api import create_app
from .runtime import FileLease, default_data_dir


def port_number(value):
    try:
        port = int(value)
    except (ValueError, TypeError):
        raise argparse.ArgumentTypeError('Порт должен быть целым числом от 1 до 65535')
    if not 1 <= port <= 65535:
        raise argparse.ArgumentTypeError('Порт должен быть целым числом от 1 до 65535')
    return port


def check_port(port):
    # Check before creating Application: failed startup must not alter job state
    # or open a tab belonging to unrelated software using the requested port.
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as probe:
        if hasattr(socket, 'SO_EXCLUSIVEADDRUSE'):
            probe.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
        try:
            probe.bind(('127.0.0.1', port))
        except OSError as error:
            raise RuntimeError(f'Порт {port} занят или недоступен. Укажите другой: start.cmd --port 8766') from error


def main():
    parser = argparse.ArgumentParser(description='Murer Group Stats — локальный сервер')
    parser.add_argument('--port', type=port_number, default=8765)
    parser.add_argument('--no-open', action='store_true')
    arguments = parser.parse_args()
    check_port(arguments.port)
    lease = FileLease(default_data_dir() / '.application.lock')
    try:
        if os.environ.get('MURER_UPDATE_NONCE'):
            import psutil
            from .updates import atomic_json, read_json
            update_dir = Path(os.environ['MURER_INSTALL_ROOT']) / '.murer-updates'
            atomic_json(update_dir / 'trial-process.json', {'pid': os.getpid(), 'created': psutil.Process().create_time()})
            transaction = read_json(update_dir / 'transaction.json')
            if transaction.get('phase') != 'trial' or transaction.get('nonce') != os.environ['MURER_UPDATE_NONCE']:
                raise RuntimeError('Пробный запуск обновления отменён установщиком.')
        app = create_app()
        url = f'http://127.0.0.1:{arguments.port}'
        if not arguments.no_open:
            def open_when_ready():
                for _ in range(80):
                    try:
                        with urllib.request.urlopen(url + '/api/health', timeout=1) as response:
                            health = json.load(response)
                            if health.get('status') == 'ok' and health.get('application') == 'Murer Group Stats':
                                webbrowser.open(url)
                                return
                    except Exception:
                        time.sleep(0.25)
            threading.Thread(target=open_when_ready, daemon=True).start()
        print(f'Murer Group Stats: {url}\nДля завершения нажмите Ctrl+C в этом окне.')
        class LocalServer(uvicorn.Server):
            def handle_exit(self, sig, frame):
                app.state.application.shutting_down = True
                app.state.application.publish({'type': 'shutdown'})
                super().handle_exit(sig, frame)
        server = LocalServer(uvicorn.Config(app, host='127.0.0.1', port=arguments.port,
            log_level='warning', access_log=False, timeout_graceful_shutdown=5))
        app.state.application.shutdown_callback = lambda: setattr(server, 'should_exit', True)
        server.run()
    finally:
        lease.close()


if __name__ == '__main__':
    try:
        main()
    except (RuntimeError, OSError) as error:
        print(f'Не удалось запустить Murer Group Stats: {error}', file=sys.stderr)
        raise SystemExit(1)
