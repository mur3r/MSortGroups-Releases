ALTER TABLE groups ADD COLUMN exempt_account_ids TEXT NOT NULL DEFAULT '[]';
