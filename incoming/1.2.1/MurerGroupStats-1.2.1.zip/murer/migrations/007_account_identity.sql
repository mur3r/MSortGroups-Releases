ALTER TABLE accounts ADD COLUMN profile_key TEXT NOT NULL DEFAULT '';
UPDATE accounts SET profile_key=username WHERE profile_key='';
CREATE UNIQUE INDEX accounts_profile_key ON accounts(profile_key);
ALTER TABLE accounts ADD COLUMN previous_username TEXT;
ALTER TABLE accounts ADD COLUMN username_verified_at TEXT;
CREATE TABLE account_identity_events(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 account_id TEXT NOT NULL REFERENCES accounts(id),
 old_username TEXT NOT NULL,
 username TEXT NOT NULL,
 old_x_id TEXT,
 x_id TEXT NOT NULL,
 origin TEXT NOT NULL,
 observed_at TEXT NOT NULL
);
CREATE INDEX account_identity_events_account ON account_identity_events(account_id,id);
