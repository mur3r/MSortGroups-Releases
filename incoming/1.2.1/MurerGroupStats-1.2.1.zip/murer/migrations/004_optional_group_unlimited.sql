-- NULL inherits the global rule; 0 and 1 are explicit individual overrides.
ALTER TABLE groups RENAME COLUMN unlimited TO unlimited_legacy;
ALTER TABLE groups ADD COLUMN unlimited INTEGER;
UPDATE groups SET unlimited=CASE WHEN unlimited_legacy=1 THEN 1 ELSE NULL END;
ALTER TABLE groups DROP COLUMN unlimited_legacy;
