CREATE TABLE trade_runs(
 id TEXT PRIMARY KEY,created_at TEXT NOT NULL,updated_at TEXT NOT NULL,finished_at TEXT,
 status TEXT NOT NULL,config TEXT NOT NULL,plan TEXT NOT NULL,settings TEXT NOT NULL,
 settings_version INTEGER NOT NULL,progress TEXT NOT NULL DEFAULT '{}',
 resume_jobs TEXT NOT NULL DEFAULT '[]',error TEXT);
CREATE TABLE trade_items(
 id TEXT PRIMARY KEY,run_id TEXT NOT NULL REFERENCES trade_runs(id),group_id TEXT NOT NULL REFERENCES groups(id),
 recipient TEXT NOT NULL,status TEXT NOT NULL,reason TEXT NOT NULL DEFAULT '',
 group_name TEXT NOT NULL,url TEXT NOT NULL,quality TEXT NOT NULL,score REAL,updated_at TEXT NOT NULL,
 UNIQUE(run_id,group_id,recipient));
CREATE INDEX trade_items_recipient ON trade_items(recipient,group_id,status);
CREATE TABLE trade_capabilities(
 group_id TEXT NOT NULL REFERENCES groups(id),account_id TEXT NOT NULL REFERENCES accounts(id),
 state TEXT NOT NULL,reason TEXT NOT NULL,observed_at TEXT NOT NULL,PRIMARY KEY(group_id,account_id));
CREATE TABLE trade_relationships(
 account_id TEXT NOT NULL REFERENCES accounts(id),username TEXT NOT NULL,
 following INTEGER,follows_us INTEGER,observed_at TEXT NOT NULL,details TEXT NOT NULL,
 PRIMARY KEY(account_id,username));
