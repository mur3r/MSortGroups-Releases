-- Keep historical access while distinguishing confirmed absence from a partial discovery.
ALTER TABLE account_groups ADD COLUMN present INTEGER NOT NULL DEFAULT 1;
ALTER TABLE account_groups ADD COLUMN uncertain INTEGER NOT NULL DEFAULT 0;
CREATE INDEX IF NOT EXISTS account_groups_current ON account_groups(account_id,present);
