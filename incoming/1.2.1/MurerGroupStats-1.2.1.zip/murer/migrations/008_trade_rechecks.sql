CREATE TABLE trade_member_rechecks(
 group_id TEXT NOT NULL REFERENCES groups(id),username TEXT NOT NULL,
 requested_at TEXT NOT NULL,PRIMARY KEY(group_id,username));
CREATE INDEX group_members_person_present ON group_members(participant_id,present,group_id);
