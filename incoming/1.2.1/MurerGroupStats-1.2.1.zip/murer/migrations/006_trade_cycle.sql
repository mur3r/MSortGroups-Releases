ALTER TABLE trade_runs ADD COLUMN baseline TEXT NOT NULL DEFAULT '{}';
ALTER TABLE trade_runs ADD COLUMN incoming TEXT NOT NULL DEFAULT '{}';
ALTER TABLE trade_runs ADD COLUMN priority_held INTEGER NOT NULL DEFAULT 0;
ALTER TABLE trade_items ADD COLUMN source_account_id TEXT REFERENCES accounts(id);
ALTER TABLE trade_items ADD COLUMN evidence TEXT NOT NULL DEFAULT '{}';
CREATE TABLE trade_member_observations(
 group_id TEXT NOT NULL REFERENCES groups(id),username TEXT NOT NULL,x_id TEXT,
 account_id TEXT NOT NULL REFERENCES accounts(id),run_id TEXT NOT NULL REFERENCES trade_runs(id),
 observed_at TEXT NOT NULL,origin TEXT NOT NULL,PRIMARY KEY(group_id,username));
CREATE TABLE trade_follow_actions(
 run_id TEXT NOT NULL REFERENCES trade_runs(id),account_id TEXT NOT NULL REFERENCES accounts(id),
 username TEXT NOT NULL,status TEXT NOT NULL,observed_at TEXT NOT NULL,
 PRIMARY KEY(run_id,account_id,username));
CREATE TABLE trade_incoming_checks(
 id TEXT PRIMARY KEY,run_id TEXT NOT NULL REFERENCES trade_runs(id),
 observed_at TEXT NOT NULL,data TEXT NOT NULL);
