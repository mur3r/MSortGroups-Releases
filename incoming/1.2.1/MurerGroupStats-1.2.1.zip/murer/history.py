"""Changes between frozen observations; incomplete lists do not prove exits."""
from .analytics import _membership_complete


def changes_between(previous, current, previous_analysis=None, current_analysis=None):
    before = {g['id']: g for g in previous.get('groups', [])}
    after = {g['id']: g for g in current.get('groups', [])}
    previous_analysis, current_analysis = previous_analysis or {}, current_analysis or {}
    old_scores = {g['id']: g for g in previous_analysis.get('groups', [])}
    new_scores = {g['id']: g for g in current_analysis.get('groups', [])}
    def scope(analysis):
        selected = analysis.get('summary', {}).get('scope', {})
        return (frozenset(selected.get('account_ids', [])),
                frozenset(selected.get('group_ids', [g['id'] for g in analysis.get('groups', [])])),
                selected.get('include_ours'))
    same_scope = scope(previous_analysis) == scope(current_analysis)
    rows = []
    for gid in sorted(set(before) | set(after)):
        a, b = before.get(gid), after.get(gid)
        old_members = set(a.get('participant_ids', [])) if a else set()
        new_members = set(b.get('participant_ids', [])) if b else set()
        complete = bool(a and b and _membership_complete(a) and _membership_complete(b))
        old, new = old_scores.get(gid, {}), new_scores.get(gid, {})
        comparable = (complete and same_scope and old.get('score') is not None and new.get('score') is not None and
                      not old.get('preliminary') and not new.get('preliminary') and
                      previous_analysis.get('settings') == current_analysis.get('settings') and
                      old.get('available_components') == new.get('available_components'))
        rows.append({'group_id': gid, 'name': (b or a)['name'], 'before_count': len(old_members),
            'after_count': len(new_members), 'observed_added_count': len(new_members-old_members),
            'observed_missing_count': len(old_members-new_members), 'added_participant_ids': sorted(new_members-old_members),
            'missing_participant_ids': sorted(old_members-new_members), 'membership_comparable': complete,
            'change_status': 'confirmed_snapshot_difference' if complete else 'uncertain',
            'explanation': 'Разница двух подтверждённых полных составов' if complete else 'Новый или неполный список: отсутствие в снимке не доказывает выход',
            'score_before': old.get('score'), 'score_after': new.get('score'), 'scores_comparable': comparable,
            'score_comparison_reason': None if comparable else 'Нет сопоставимых оценок: отсутствуют баллы, либо различаются область сравнения, правила, компоненты или полнота данных',
            'score_difference': new['score']-old['score'] if comparable and new.get('score') is not None and old.get('score') is not None else None})
    return {'groups': rows, 'new_groups': len(set(after)-set(before)), 'missing_groups': len(set(before)-set(after)),
        'changed_groups': sum(bool(r['observed_added_count'] or r['observed_missing_count']) for r in rows),
        'uncertain_groups': sum(not r['membership_comparable'] for r in rows)}
