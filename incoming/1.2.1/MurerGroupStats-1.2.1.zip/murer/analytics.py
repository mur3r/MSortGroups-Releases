"""Pure analytics over immutable observed data, with explicit uncertainty.

No browser calls, writes, invented observations, display-name identity merging or
quadratic all-group matrix. Every denominator refers to the selected unique
groups; our identity registry always refers to the whole database.
"""
from collections import Counter, defaultdict
from copy import deepcopy
from datetime import datetime, timedelta, timezone
from hashlib import sha256
from itertools import combinations
from math import isfinite
from statistics import mean, median

from .parsing import normalize_username
from .rules import validate_settings

GOOD_STATUSES = {"full", "partial", "complete", "ok", "success"}
COMPLETE_STATUSES = {"full", "complete", "confirmed_end"}
KINDS = {"own", "repost", "quote", "reply", "unknown"}


def _date(value):
    if isinstance(value, datetime):
        result = value
    elif value:
        try:
            result = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        except (ValueError, TypeError):
            return None
    else:
        return None
    return result.replace(tzinfo=timezone.utc) if result.tzinfo is None else result.astimezone(timezone.utc)


def _iso(value):
    return value.isoformat() if value else None


def _percent(numerator, denominator):
    return 100 * numerator / denominator if isinstance(denominator, (int, float)) and denominator > 0 else None


def _metric(observation, key):
    item = observation.get(key)
    if isinstance(item, (int, float)) and not isinstance(item, bool):
        item = {"raw": str(item), "value": item, "approximate": False}
    if not isinstance(item, dict):
        return {"raw": None, "value": None, "approximate": False}
    value = item.get("value")
    if not isinstance(value, (int, float)) or isinstance(value, bool) or not isfinite(value) or value < 0:
        value = None
    return {"raw": item.get("raw"), "value": value, "approximate": bool(item.get("approximate"))}


def _identity_registry(accounts, participants):
    by_xid, by_username = defaultdict(list), defaultdict(list)
    participant_ids_by_name = defaultdict(set)
    participants_by_name = defaultdict(set)
    def names(participant):
        return {normalize_username(value) for value in [participant.get("username"),
            *participant.get("aliases", []), *participant.get("username_aliases", [])] if normalize_username(value)}
    for participant in participants:
        for name in names(participant):
            participants_by_name[name].add(participant["id"])
            if participant.get("x_id"):
                participant_ids_by_name[name].add(str(participant["x_id"]))
    for account in accounts:
        if not account.get("is_ours", True):
            continue
        if account.get("x_id"):
            by_xid[str(account["x_id"])].append(account)
        if normalize_username(account.get("username")):
            by_username[normalize_username(account["username"])].append(account)
    matched, provenance, warnings = {}, {}, []
    # Username aliases from historical observations can support an unchanged ID.
    for participant in participants:
        pid, xid = participant["id"], participant.get("x_id")
        xid = str(xid) if xid is not None else None
        if xid and xid in by_xid:
            matched[pid] = [a["id"] for a in by_xid[xid]]
            provenance[pid] = "stable_id"
            continue
        compatible, matched_names = {}, set()
        for name in names(participant):
            candidates = by_username.get(name, [])
            possible = [a for a in candidates if not xid or not a.get("x_id") or str(a["x_id"]) == xid]
            known_ids = {str(a["x_id"]) for a in possible if a.get("x_id")}
            participant_ids = participant_ids_by_name.get(name, set())
            if possible and len(known_ids | participant_ids) <= 1 and len(participants_by_name[name]) == 1:
                compatible.update({a["id"]: a for a in possible})
                matched_names.add(name)
            elif candidates:
                warnings.append(f"@{name}: неоднозначное сопоставление; стабильные ID имеют приоритет")
        matched[pid] = sorted(compatible, key=str)
        provenance[pid] = ("username_normalized" if normalize_username(participant.get("username")) in matched_names else
                           "historical_username_alias" if compatible else "unmatched")
    return matched, provenance, sorted(set(warnings))


def _canonicalize(dataset):
    """Defend against duplicated stable IDs; username alone never merges rows."""
    participants, p_alias = {}, {}
    for original in dataset.get("participants", []):
        item = deepcopy(original)
        key = ("x", str(item["x_id"])) if item.get("x_id") else ("id", str(item["id"]))
        if key not in participants:
            participants[key] = item
            item["observations"] = list(item.get("observations", []))
        else:
            saved = participants[key]
            saved["observations"].extend(item.get("observations", []))
            if item.get("username") != saved.get("username"):
                saved["username_aliases"] = sorted(set(saved.get("username_aliases", []) + [item.get("username") or ""]))
        p_alias[original["id"]] = participants[key]["id"]
    groups, g_alias = {}, {}
    for original in dataset.get("groups", []):
        item = deepcopy(original)
        key = ("x", str(item["x_id"])) if item.get("x_id") else ("id", str(item["id"]))
        item["participant_ids"] = list(dict.fromkeys(p_alias.get(pid, pid) for pid in item.get("participant_ids", [])))
        item["account_ids"] = list(dict.fromkeys(item.get("account_ids", [])))
        if key not in groups:
            groups[key] = item
        else:
            saved = groups[key]
            saved["participant_ids"] = list(dict.fromkeys(saved["participant_ids"] + item["participant_ids"]))
            saved["account_ids"] = list(dict.fromkeys(saved["account_ids"] + item["account_ids"]))
            if item.get("membership_status") in COMPLETE_STATUSES:
                saved["membership_status"] = item["membership_status"]
            if _date(item.get("observed_at")) and (_date(item.get("observed_at")) > (_date(saved.get("observed_at")) or datetime.min.replace(tzinfo=timezone.utc))):
                for name in ("declared_count", "observed_at", "name", "url"):
                    if item.get(name) is not None:
                        saved[name] = item[name]
        g_alias[original["id"]] = groups[key]["id"]
    return list(participants.values()), list(groups.values()), g_alias


def _deduplicate_posts(posts):
    saved, order = {}, []
    for index, original in enumerate(posts):
        item = deepcopy(original)
        kind = item.get("type", "unknown")
        if kind in ("post", "original"):
            kind = "own"
        item["type"] = kind if kind in KINDS else "unknown"
        # A source timestamp cannot identify when this participant reposted it.
        if item["type"] == "repost":
            item["event_at"] = item.get("event_at") if item.get("classification_method") not in ("original_date", "source_date") else None
        elif item["type"] in ("own", "quote", "reply"):
            item["event_at"] = item.get("event_at") or item.get("original_at")
        else:
            item["event_at"] = None
        key = str(item.get("id") or item.get("url") or sha256(str(item.get("text") or index).encode()).hexdigest())
        if key not in saved:
            order.append(key)
            saved[key] = item
        elif saved[key]["type"] == "unknown" and item["type"] != "unknown":
            saved[key] = item
    return [saved[key] for key in order]


def _profile(participant, settings, now):
    c, e = settings["collection"], settings["evaluation"]
    observations = sorted(participant.get("observations", []),
                          key=lambda o: _date(o.get("observed_at")) or datetime.min.replace(tzinfo=timezone.utc), reverse=True)
    good = [o for o in observations if o.get("status") in GOOD_STATUSES]
    timeline = [o for o in good if "posts" in o]
    required_days = max(c["period_days"], e["reposts_days"], e["active_days"])
    # Prefer fresh evidence, then sufficient recorded volume, then the newest
    # successful attempt. Error/unavailable attempts remain in access history.
    def quality(o):
        recorded = len(_deduplicate_posts(o.get("posts", [])))
        complete = bool(o.get("period_complete") and o.get("chronology_confirmed"))
        adequate = ((recorded >= c["posts_limit"] or o.get("timeline_complete") or
                     (complete and o.get("requested_n", 0) >= c["posts_limit"])) and
                    o.get("requested_days", 0) >= required_days)
        observed = _date(o.get("observed_at")) or datetime.min.replace(tzinfo=timezone.utc)
        fresh = now - observed <= timedelta(hours=c["cache_hours"])
        return (fresh, adequate, observed, bool(o.get("period_complete") and o.get("chronology_confirmed")))
    observation = max(timeline, key=quality) if timeline else (good[0] if good else None)
    followers = next((_metric(o, "followers") for o in good if _metric(o, "followers")["value"] is not None), _metric({}, "followers"))
    posts_total = next((_metric(o, "posts_total") for o in good if _metric(o, "posts_total")["value"] is not None), _metric({}, "posts_total"))
    result = deepcopy(participant)
    result.pop("observations", None)
    result.update(followers=followers, posts_total=posts_total, last_activity=None,
                  sample_counts={k: None for k in ("own", "repost", "quote", "reply", "unknown")},
                  classified_count=None, viewed_count=None, repost_share=None,
                  reposts_confirmed=None, unknown_date_reposts=None,
                  reposts_condition=None, activity_condition=None, period_complete=False,
                  checked_at=None, source_account_id=None, posts=[], needs_collection=False,
                  coverage_reasons=[], status="unavailable", access_attempts=[{
                      "observed_at": o.get("observed_at"), "source_account_id": o.get("source_account_id"),
                      "status": o.get("status"), "reason": o.get("reason") or o.get("error")
                  } for o in observations])
    if not observation:
        result["status"] = (observations[0].get("status") if observations else "unavailable") or "unavailable"
        result["needs_collection"] = True
        result["coverage_reasons"] = ["Нет доступного наблюдения профиля"]
        return result
    checked = _date(observation.get("observed_at"))
    result.update(checked_at=_iso(checked), source_account_id=observation.get("source_account_id"),
                  status="full" if observation.get("status") in COMPLETE_STATUSES else "partial")
    if not checked or now - checked > timedelta(hours=c["cache_hours"]):
        result["status"] = "stale"
        result["coverage_reasons"].append("Истёк срок свежести кеша")
    if followers["value"] is None:
        result["coverage_reasons"].append("Нет доступного числа подписчиков")
    if posts_total["value"] is None:
        result["coverage_reasons"].append("Нет доступного общего числа публикаций")
    all_posts = _deduplicate_posts(observation.get("posts", []))
    posts = all_posts[:c["posts_limit"]]
    result["posts"] = posts
    if "posts" not in observation:
        result["coverage_reasons"].append("Последние публикации не просмотрены")
        result["needs_collection"] = True
        return result
    counts = Counter(post["type"] for post in posts)
    result["sample_counts"] = {kind: counts[kind] for kind in KINDS}
    sample_cutoff = now - timedelta(days=c["period_days"])
    dated_sample = [post for post in posts if _date(post.get("event_at")) and sample_cutoff <= _date(post["event_at"]) <= now]
    period_counts = Counter(post["type"] for post in dated_sample)
    result["period_counts"] = {kind: period_counts[kind] for kind in KINDS}
    result["sample_period_days"] = c["period_days"]
    result["outside_period_count"] = sum(bool(_date(post.get("event_at")) and _date(post["event_at"]) < sample_cutoff) for post in posts)
    result["unknown_date_count"] = sum(_date(post.get("event_at")) is None for post in posts)
    result["classified_count"] = len(posts) - counts["unknown"]
    result["viewed_count"] = min(observation.get("viewed_count", len(all_posts)), c["posts_limit"])
    included = {"own", "repost"} | ({"quote"} if e["include_quotes"] else set()) | ({"reply"} if e["include_replies"] else set())
    ratio_denominator = sum(counts[kind] for kind in included)
    result["repost_share"] = _percent(counts["repost"], ratio_denominator)
    result["repost_share_denominator"] = ratio_denominator
    result["repost_share_definition"] = "Репосты среди классифицированных элементов с включёнными типами; наблюдаемая выборка"
    rp_cutoff = now - timedelta(days=e["reposts_days"])
    activity_cutoff = now - timedelta(days=e["active_days"])
    activity_dates = []
    confirmed, undated, uncertain_activity = 0, 0, 0
    for post in posts:
        kind, event = post["type"], _date(post.get("event_at"))
        usable = bool(event and event <= now)
        if kind == "repost":
            if not usable:
                undated += 1
            elif event >= rp_cutoff:
                confirmed += 1
        if kind in included:
            if usable:
                activity_dates.append(event)
            else:
                uncertain_activity += 1
        elif kind == "unknown":
            uncertain_activity += 1
    latest_dates = [_date(post.get("event_at")) for post in posts if post["type"] in included and
                    _date(post.get("event_at")) and _date(post["event_at"]) <= now and
                    (not post.get("pinned") or _date(post["event_at"]) >= sample_cutoff)]
    result["last_activity"] = _iso(max(latest_dates)) if latest_dates else None
    result["reposts_confirmed"], result["unknown_date_reposts"] = confirmed, undated
    chronology = bool(observation.get("chronology_confirmed"))
    original_complete = bool(observation.get("period_complete") and chronology)
    sample_untrimmed = len(posts) == len(all_posts)
    recorded_days = observation.get("requested_days", 0)
    def covers(days):
        # Shrinking N cannot create completeness by discovering one old pinned or
        # reposted source. Keep negative evidence only for the full recorded sample.
        return original_complete and sample_untrimmed and recorded_days >= days
    result["period_complete"] = covers(required_days)
    uncertain_reposts = undated + counts["unknown"]
    if confirmed >= e["reposts_min"]:
        result["reposts_condition"] = True
    elif covers(e["reposts_days"]) and confirmed + uncertain_reposts < e["reposts_min"]:
        result["reposts_condition"] = False
    if any(date >= activity_cutoff for date in activity_dates):
        result["activity_condition"] = True
    elif covers(e["active_days"]) and not uncertain_activity:
        result["activity_condition"] = False
    required_n_met = (len(all_posts) >= c["posts_limit"] or observation.get("timeline_complete", False) or
                      (original_complete and observation.get("requested_n", 0) >= c["posts_limit"]))
    if not required_n_met:
        result["coverage_reasons"].append(f"Сохранено {len(all_posts)} уникальных элементов; требуется до {c['posts_limit']} (запрошено при сборе: {observation.get('requested_n', 0)})")
    if recorded_days < required_days:
        result["coverage_reasons"].append(f"Исследовано до {recorded_days} дней; требуется {required_days}")
    if not original_complete:
        result["coverage_reasons"].append("Хронологическая полнота периода не подтверждена")
    if not sample_untrimmed:
        result["coverage_reasons"].append("Текущий лимит элементов сократил сохранённую выборку; отрицательные условия периода неизвестны")
    result["needs_collection"] = bool(result["status"] == "stale" or not required_n_met or recorded_days < required_days or
                                      followers["value"] is None or posts_total["value"] is None or not original_complete)
    result["observed_post_count"] = len(all_posts)
    result["requested_n"] = observation.get("requested_n")
    result["requested_days"] = observation.get("requested_days")
    result["chronology_confirmed"] = chronology
    result["metrics_observed_at"] = {
        key: next((o.get("observed_at") for o in good if _metric(o, key)["value"] is not None), None)
        for key in ("followers", "posts_total")
    }
    if any(value and now - _date(value) > timedelta(hours=c["cache_hours"]) for value in result["metrics_observed_at"].values()):
        result["status"] = "stale"
        result["needs_collection"] = True
        result["coverage_reasons"].append("Часть метрик восстановлена из устаревшего наблюдения")
    return result


def _membership_complete(group, known=None):
    if group.get("membership_status") not in COMPLETE_STATUSES:
        return False
    known = len(set(group.get("participant_ids", []))) if known is None else known
    declared = group.get("declared_count")
    return not isinstance(declared, (int, float)) or declared == known


def _membership_coverage(group, known):
    if _membership_complete(group, known):
        return 100.0
    declared = group.get("declared_count")
    return min(100.0, 100 * known / declared) if isinstance(declared, (int, float)) and declared > 0 else None


def _uniqueness(sets):
    occurrence = Counter(pid for members in sets.values() for pid in members)
    return occurrence, {gid: {pid for pid in members if occurrence[pid] == 1} for gid, members in sets.items()}


def _sparse_overlaps(sets, preliminary, prefix="group", work_limit=None):
    inverted, common = defaultdict(list), Counter()
    for gid, members in sets.items():
        for pid in members:
            inverted[pid].append(gid)
    pair_work = sum(len(entries) * (len(entries)-1) // 2 for entries in inverted.values())
    if work_limit is not None and pair_work > work_limit:
        return [], True, pair_work
    for entries in inverted.values():
        for a, b in combinations(sorted(entries, key=str), 2):
            common[a, b] += 1
    rows = []
    for (a, b), count in common.items():
        ac, bc = len(sets[a]), len(sets[b])
        rows.append({f"{prefix}_a_id": a, f"{prefix}_b_id": b,
                     "common_count": count, "a_count": ac, "b_count": bc,
                     "percent_a": _percent(count, ac), "percent_b": _percent(count, bc),
                     "jaccard": count / (ac + bc - count) if ac + bc - count else None,
                     "new_for_a": bc - count, "new_for_b": ac - count,
                     "preliminary": preliminary})
    return sorted(rows, key=lambda row: -row["common_count"]), False, pair_work


def compare_pair(dataset, settings, kind, a, b, account_ids=None, group_ids=None, now=None):
    """Compare any two scoped audiences, including disjoint and empty ones.

    This calculates one set intersection directly; it deliberately avoids the
    sparse all-pair index, whose size depends on the rest of the database.
    """
    settings = validate_settings(settings)
    if kind not in ("group", "account", "groups", "accounts"):
        raise ValueError("Тип сравнения должен быть group или account")
    kind = kind.rstrip("s")
    participants, all_groups, aliases = _canonicalize(dataset)
    accounts = dataset.get("accounts", [])
    account_map = {account["id"]: account for account in accounts}
    matched, _, _ = _identity_registry(accounts, participants)
    participant_map = {p["id"]: p for p in participants}
    selected_accounts = set(account_ids) if account_ids is not None else set(account_map)
    selected_groups = {aliases.get(gid, gid) for gid in group_ids} if group_ids is not None else None
    groups = [g for g in all_groups if (account_ids is None or selected_accounts.intersection(g.get("account_ids", []))) and
              (selected_groups is None or g["id"] in selected_groups)]
    include_ours = settings["evaluation"]["include_ours"]
    audience = {g["id"]: {pid for pid in g.get("participant_ids", []) if pid in participant_map and
                           (include_ours or not matched.get(pid))} for g in groups}
    if kind == "group":
        a, b = aliases.get(a, a), aliases.get(b, b)
        group_map = {g["id"]: g for g in groups}
        if a not in group_map or b not in group_map:
            raise ValueError("Группа не найдена в выбранной области сравнения")
        involved = list({gid: group_map[gid] for gid in (a, b)}.values())
        a_set, b_set = audience[a], audience[b]
        a_name, b_name = group_map[a].get("name"), group_map[b].get("name")
        shared_groups = []
    else:
        if a not in selected_accounts or b not in selected_accounts or a not in account_map or b not in account_map:
            raise ValueError("Аккаунт не найден в выбранной области сравнения")
        a_groups = {g["id"] for g in groups if a in g.get("account_ids", [])}
        b_groups = {g["id"] for g in groups if b in g.get("account_ids", [])}
        involved = [g for g in groups if g["id"] in a_groups | b_groups]
        a_set = set().union(*(audience[gid] for gid in a_groups)) if a_groups else set()
        b_set = set().union(*(audience[gid] for gid in b_groups)) if b_groups else set()
        shared_groups = sorted(a_groups & b_groups, key=str)
        a_name, b_name = account_map[a].get("username"), account_map[b].get("username")
    common, ac, bc = len(a_set & b_set), len(a_set), len(b_set)
    times = []
    observed_pids = {pid for g in involved for pid in g.get("participant_ids", [])}
    for group in involved:
        times.extend(group.get(key) for key in ("observed_at", "membership_observed_from", "membership_observed_to"))
    for pid in observed_pids:
        if pid in participant_map:
            times.extend(o.get("observed_at") for o in participant_map[pid].get("observations", []) if o.get("status") in GOOD_STATUSES)
    dates = [_date(value) for value in times if _date(value)]
    return {"a_id": a, "b_id": b, "a_name": a_name, "b_name": b_name,
            f"{kind}_a_id": a, f"{kind}_b_id": b,
            f"{kind}_a_name": a_name, f"{kind}_b_name": b_name,
            "common_count": common, "a_count": ac, "b_count": bc,
            "percent_a": _percent(common, ac), "percent_b": _percent(common, bc),
            "jaccard": common / (ac + bc - common) if ac + bc - common else None,
            "new_for_a": bc - common, "new_for_b": ac - common,
            "common_group_count": len(shared_groups), "common_group_ids": shared_groups,
            "shared_group_count": len(shared_groups), "shared_group_ids": shared_groups,
            "preliminary": not all(_membership_complete(g) for g in involved),
            "observed_from": _iso(min(dates)) if dates else None,
            "observed_to": _iso(max(dates)) if dates else None,
            "include_ours": include_ours, "calculated_at": _iso(_date(now) or datetime.now(timezone.utc))}


def _score(group, members, exclusive, settings, lists_coverage, lists_complete):
    e = settings["evaluation"]
    n = len(members)
    followers = [p["followers"]["value"] for p in members if p["followers"]["value"] is not None]
    totals = [p["posts_total"]["value"] for p in members if p["posts_total"]["value"] is not None]
    r_eval = [p["reposts_condition"] for p in members if p["reposts_condition"] is not None]
    a_eval = [p["activity_condition"] for p in members if p["activity_condition"] is not None]
    follower_median, post_median = (median(followers) if followers else None), (median(totals) if totals else None)
    def scale(value, low, high):
        return 100 * max(0, min(1, (value - low) / (high - low))) if value is not None else None
    values = {"U": _percent(exclusive, n),
              "F": scale(follower_median, e["followers_low"], e["followers_high"]),
              "P": scale(post_median, e["posts_low"], e["posts_high"]),
              "R": _percent(sum(r_eval), len(r_eval)), "A": _percent(sum(a_eval), len(a_eval))}
    evaluated = {"U": n, "F": len(followers), "P": len(totals), "R": len(r_eval), "A": len(a_eval)}
    reasons = {"U": "Состав хотя бы одной группы сравнения неполон" if not lists_complete else None,
               "F": "Нет доступных данных подписчиков" if not followers else None,
               "P": "Нет доступного общего числа публикаций" if not totals else None,
               "R": "Даты репостов или полнота периода не позволяют проверить условие" if len(r_eval) < n else None,
               "A": "Даты активности или полнота периода не позволяют проверить условие" if len(a_eval) < n else None}
    available = [key for key in "UFPRA" if e["weights"][key] > 0 and values[key] is not None]
    enabled = [key for key in "UFPRA" if e["weights"][key] > 0]
    available_weight, total_weight = sum(e["weights"][k] for k in available), sum(e["weights"].values())
    components = {}
    for key in "UFPRA":
        coverage = lists_coverage if key == "U" and n else (_percent(evaluated[key], n) or 0)
        divisor = available_weight if e["missing_policy"] == "renormalize" else total_weight
        normalized = e["weights"][key] / divisor if key in available else 0
        components[key] = {"value": values[key], "weight": e["weights"][key],
                           "normalized_weight": normalized, "contribution": values[key] * normalized if key in available else None,
                           "coverage": coverage, "evaluated": evaluated[key], "excluded": n - evaluated[key],
                           "reason": reasons[key] if n else "Нет идентифицированных участников в области оценки"}
    score = sum(components[k]["contribution"] for k in available) if available_weight else None
    if e["missing_policy"] == "strict" and len(available) != len(enabled):
        score = None
    weighted_coverage = sum((components[k]["coverage"] or 0) * e["weights"][k] for k in available) / total_weight
    preliminary = (not lists_complete or any(p["status"] == "stale" for p in members) or
                   len(available) < len(enabled) or any(components[k]["coverage"] is None or components[k]["coverage"] < e["min_coverage"] for k in enabled))
    if score is None or not n or weighted_coverage < e["min_coverage"]:
        category = "Недостаточно данных"
    elif preliminary:
        category = "Предварительная оценка"
    elif score >= e["good_score"]:
        category = "Хорошая"
    elif score >= e["medium_score"]:
        category = "Средняя"
    else:
        category = "Плохая"
    return {"followers_median": follower_median, "followers_mean": mean(followers) if followers else None,
            "followers_median_approximate": bool(followers and any(p["followers"]["approximate"] for p in members if p["followers"]["value"] is not None)),
            "followers_mean_approximate": bool(followers and any(p["followers"]["approximate"] for p in members if p["followers"]["value"] is not None)),
            "posts_median": post_median, "below_followers_percent": _percent(sum(v < e["followers_low"] for v in followers), len(followers)),
            "posts_median_approximate": bool(totals and any(p["posts_total"]["approximate"] for p in members if p["posts_total"]["value"] is not None)),
            "below_posts_percent": _percent(sum(v < e["posts_low"] for v in totals), len(totals)),
            "followers_evaluated": len(followers), "posts_evaluated": len(totals),
            "reposts_confirmed": sum(p["reposts_confirmed"] for p in members if p["reposts_confirmed"] is not None) if any(p["reposts_confirmed"] is not None for p in members) else None,
            "unknown_date_reposts": sum(p["unknown_date_reposts"] for p in members if p["unknown_date_reposts"] is not None) if any(p["unknown_date_reposts"] is not None for p in members) else None,
            "activity_percent": values["A"], "score": score, "category": category,
            "score_coverage": weighted_coverage, "components": components,
            "enabled_components": enabled, "available_components": available,
            "available_weight_percent": _percent(available_weight, total_weight),
            "weights_renormalized": e["missing_policy"] == "renormalize" and available_weight != total_weight, "preliminary": preliminary,
            "score_definition": "Взвешенное среднее доступных U/F/P/R/A; R — подтверждённые репосты участника, цитаты отдельны"}


def analyze(dataset: dict, settings: dict, account_ids=None, group_ids=None, now=None) -> dict:
    settings = validate_settings(settings)
    now = _date(now) or datetime.now(timezone.utc)
    accounts = deepcopy(dataset.get("accounts", []))
    participants, all_groups, aliases = _canonicalize(dataset)
    account_map = {a["id"]: a for a in accounts}
    selected_account_ids = set(account_ids) if account_ids is not None else set(account_map)
    selected_group_ids = {aliases.get(gid, gid) for gid in group_ids} if group_ids is not None else None
    matched, provenance, identity_warnings = _identity_registry(accounts, participants)
    participant_map = {}
    for p in participants:
        result = _profile(p, settings, now)
        result.update(is_ours=bool(matched.get(p["id"])), our_account_ids=matched.get(p["id"], []),
                      identity_provenance=provenance.get(p["id"]), group_ids=[], group_count=0)
        participant_map[p["id"]] = result
    include_ours = settings["evaluation"]["include_ours"]
    def audience(group):
        return {pid for pid in group.get("participant_ids", []) if pid in participant_map and (include_ours or not participant_map[pid]["is_ours"])}
    global_sets = {g["id"]: audience(g) for g in all_groups}
    global_occurrence, global_exclusive = _uniqueness(global_sets)
    global_memberships = defaultdict(list)
    global_account_audiences = defaultdict(set)
    global_account_groups = defaultdict(dict)
    for group in all_groups:
        for pid in group.get("participant_ids", []):
            global_memberships[pid].append(group["id"])
        for aid in group.get("account_ids", []):
            global_account_audiences[aid].update(global_sets[group["id"]])
            global_account_groups[aid][group["id"]] = global_sets[group["id"]]
    chosen = [g for g in all_groups if (account_ids is None or selected_account_ids.intersection(g.get("account_ids", []))) and
              (selected_group_ids is None or g["id"] in selected_group_ids)]
    sets = {g["id"]: global_sets[g["id"]] for g in chosen}
    occurrence, exclusive = _uniqueness(sets)
    lists_complete = all(_membership_complete(g) for g in chosen)
    membership_coverages = [_membership_coverage(g, len(g.get("participant_ids", []))) for g in chosen]
    lists_coverage = min(membership_coverages) if membership_coverages and all(value is not None for value in membership_coverages) else None
    account_sets = {}
    account_group_sets = {}
    for aid in selected_account_ids:
        groups = [g for g in chosen if aid in g.get("account_ids", [])]
        account_sets[aid] = set().union(*(sets[g["id"]] for g in groups)) if groups else set()
        account_group_sets[aid] = {g["id"] for g in groups}
    single_account_exclusive = {}
    if account_ids is not None and len(selected_account_ids) == 1:
        _, single_account_exclusive = _uniqueness(global_account_groups[next(iter(selected_account_ids))])
    group_map = {g["id"]: g for g in chosen}
    recommendations, group_rows, own_rows = [], [], []
    all_found = set()
    timestamps = []
    for group in chosen:
        gid = group["id"]
        found = {pid for pid in group.get("participant_ids", []) if pid in participant_map}
        all_found.update(found)
        for pid in found:
            participant_map[pid]["group_ids"].append(gid)
        members = [participant_map[pid] for pid in sets[gid]]
        count, exclusive_count = len(members), len(exclusive[gid])
        checked = sum(p["checked_at"] is not None for p in (participant_map[pid] for pid in found))
        row = deepcopy(group)
        warnings = []
        complete = _membership_complete(group, len(found))
        if not complete:
            warnings.append("Состав неполон: эксклюзивность наблюдаемая, отсутствие человека в других группах не доказано")
        declared = group.get("declared_count")
        if declared is None:
            warnings.append("Заявленное число участников недоступно")
        elif declared != len(found):
            warnings.append(f"Заявлено {declared}; найдено {len(found)}. Ограничение, загрузка, недоступные профили или разное время наблюдений")
        if group.get("observed_at"):
            timestamps.append(group["observed_at"])
        timestamps.extend(group.get(key) for key in ("membership_observed_from", "membership_observed_to") if group.get(key))
        row.update(found_count=len(found), checked_count=checked, external_count=sum(not participant_map[pid]["is_ours"] for pid in found),
                   audience_count=count, exclusive_count=exclusive_count, additional_audience=exclusive_count,
                   exclusivity=_percent(exclusive_count, count), exclusivity_global=_percent(len(global_exclusive.get(gid, set())), count),
                   repeated_count=count-exclusive_count, repeated_percent=_percent(count-exclusive_count, count),
                   membership_coverage=_membership_coverage(group, len(found)), profile_coverage=_percent(checked, len(found)), warnings=warnings)
        if account_ids is not None and len(selected_account_ids) == 1:
            row["exclusivity_account"] = _percent(len(single_account_exclusive.get(gid, set())), count)
        else:
            row["exclusivity_account"] = None
        row.update(_score(group, members, exclusive_count, settings, lists_coverage, lists_complete))
        own_ids = {aid for pid in found for aid in matched.get(pid, [])}
        own_ids.update(aid for aid in group.get("account_ids", []) if aid in account_map and account_map[aid].get("is_ours", True))
        rule = settings["own_accounts"]["group_rules"].get(str(gid), settings["own_accounts"]["group_rules"].get(gid, {}))
        unlimited = rule.get("unlimited", group.get("unlimited") if group.get("unlimited") is not None else settings["own_accounts"]["unlimited"])
        allowance = rule.get("allowance", group.get("allowance"))
        if allowance is None:
            allowance = settings["own_accounts"]["default_allowance"]
        exemptions = set(rule.get("exempt_account_ids", group.get("exempt_account_ids", [])))
        pinned = set(rule.get("pinned_account_ids", group.get("pinned_account_ids", [])))
        own_count = len(own_ids)
        counted = len(own_ids - exemptions)
        excess = max(0, counted - allowance) if not unlimited else 0
        group_recommendations = []
        if excess:
            message = f"Найдено {own_count} наших аккаунта при разрешённом количестве {allowance}; рассмотреть сокращение присутствия на {excess} аккаунта"
            if exemptions:
                message += f"; исключений из ограничения: {len(own_ids & exemptions)}"
            group_recommendations.append({"group_id": gid, "kind": "own_excess", "text": message,
                                          "details": {"found": own_count, "allowance": allowance, "excess": excess,
                                                      "candidates": sorted(own_ids - pinned - exemptions, key=str), "pinned": sorted(pinned, key=str)}})
        if len(pinned - exemptions) > allowance and not unlimited:
            group_recommendations.append({"group_id": gid, "kind": "conflicting_rule", "text": f"Закреплено {len(pinned-exemptions)} аккаунта при ограничении {allowance}; решение требует изменения правила", "details": {}})
        if exclusive_count:
            group_recommendations.append({"group_id": gid, "kind": "additional_audience", "text": f"Группа добавляет {exclusive_count} наблюдаемых уникальных внешних участников — основание для приоритета сохранения" if not include_ours else f"Группа добавляет {exclusive_count} наблюдаемых уникальных участников (наши аккаунты включены)", "details": {"count": exclusive_count, "preliminary": not lists_complete}})
        profile_coverage = row["profile_coverage"]
        if not complete or profile_coverage is None or profile_coverage < settings["evaluation"]["min_coverage"]:
            group_recommendations.append({"group_id": gid, "kind": "finish_collection", "text": f"Проверено {profile_coverage or 0:.0f}% найденных участников ({checked}/{len(found)}); сначала завершите сбор", "details": {"checked": checked, "found": len(found), "declared": declared}})
        redistribution = []
        for account in accounts:
            if account.get("archived") or not account.get("is_ours", True) or account["id"] in group.get("account_ids", []):
                continue
            their_audience = global_account_audiences[account["id"]]
            added = len(sets[gid] - their_audience)
            redistribution.append({"account_id": account["id"], "username": account.get("username"), "new_audience": added,
                                   "basis": "Наблюдаемая аудитория группы минус объединение групп аккаунта; доступ/вступление не подтверждены"})
        own_row = {"group_id": gid, "group_name": group.get("name"), "account_ids": sorted(own_ids, key=str),
                   "accounts": [{"id": aid, "username": account_map.get(aid, {}).get("username"), "archived": account_map.get(aid, {}).get("archived", False)} for aid in sorted(own_ids, key=str)],
                   "count": own_count, "count_label": str(own_count) if complete else f"найдено не менее {own_count}",
                   "declared_share": _percent(own_count, declared) if isinstance(declared, (int, float)) else None,
                   "found_share": _percent(sum(participant_map[pid]["is_ours"] for pid in found), len(found)),
                   "allowance": None if unlimited else allowance, "unlimited": unlimited, "excess": excess,
                   "pinned_account_ids": sorted(pinned, key=str), "exempt_account_ids": sorted(exemptions, key=str),
                   "recommendations": group_recommendations, "redistribution": sorted(redistribution, key=lambda item: -item["new_audience"]),
                   "membership_complete": complete, "declared_share_definition": "Найденные наши аккаунты / заявленный состав",
                   "found_share_definition": "Сопоставленные наши профили в списке / найденные профили"}
        own_rows.append(own_row)
        row.update(own_count=own_count, recommendations=group_recommendations)
        recommendations.extend(group_recommendations)
        group_rows.append(row)
    participant_rows = []
    for pid in sorted(all_found, key=str):
        row = participant_map[pid]
        row["group_ids"] = list(dict.fromkeys(row["group_ids"]))
        row["group_count"] = len(row["group_ids"])
        row["global_group_ids"] = list(dict.fromkeys(global_memberships[pid]))
        participant_rows.append(row)
        if row.get("checked_at"):
            timestamps.append(row["checked_at"])
        timestamps.extend(value for value in row.get("metrics_observed_at", {}).values() if value)
    pair_limit = settings["evaluation"]["overlap_pair_limit"]
    overlaps, group_overlap_deferred, group_pair_work = _sparse_overlaps(sets, not lists_complete, work_limit=pair_limit)
    for pair in overlaps:
        a = group_map[pair["group_a_id"]]
        b = group_map[pair["group_b_id"]]
        pair["group_a_name"], pair["group_b_name"] = a.get("name"), b.get("name")
        recommendations.append({"group_id": a["id"], "kind": "overlap", "text": f"Группы {a.get('name') or a['id']} и {b.get('name') or b['id']} имеют {pair['percent_a']:.1f}% совпадения относительно первой ({pair['common_count']}/{pair['a_count']}); сравните активность и дополнительную аудиторию", "details": pair})
    shared_entries = [(group["id"], sorted(selected_account_ids.intersection(group.get("account_ids", [])), key=str)) for group in chosen]
    shared_pair_work = sum(len(aids) * (len(aids)-1) // 2 for _, aids in shared_entries)
    if shared_pair_work > pair_limit:
        account_overlap_rows, account_overlap_deferred, account_pair_work = [], True, None
    else:
        account_overlap_rows, account_overlap_deferred, account_pair_work = _sparse_overlaps(account_sets, not lists_complete, "account", work_limit=pair_limit)
    existing_pairs = {(r["account_a_id"], r["account_b_id"]): r for r in account_overlap_rows}
    shared_pairs = defaultdict(set)
    if not account_overlap_deferred:
        for gid, aids in shared_entries:
            for a, b in combinations(aids, 2):
                shared_pairs[a, b].add(gid)
    for pair, shared in shared_pairs.items():
        if pair not in existing_pairs:
            a, b = pair
            ac, bc = len(account_sets[a]), len(account_sets[b])
            row = {"account_a_id": a, "account_b_id": b, "common_count": 0, "a_count": ac, "b_count": bc,
                   "percent_a": _percent(0, ac), "percent_b": _percent(0, bc), "jaccard": 0 if ac+bc else None,
                   "new_for_a": bc, "new_for_b": ac, "preliminary": not lists_complete}
            existing_pairs[pair] = row
            account_overlap_rows.append(row)
    for pair, row in existing_pairs.items():
        row.update(shared_group_ids=sorted(shared_pairs.get(pair, set()), key=str), shared_group_count=len(shared_pairs.get(pair, set())),
                   account_a_name=account_map.get(pair[0], {}).get("username"), account_b_name=account_map.get(pair[1], {}).get("username"))
    dates = [_date(value) for value in timestamps if _date(value)]
    global_timestamps = [g.get(key) for g in all_groups for key in ("observed_at", "membership_observed_from", "membership_observed_to")]
    global_profiles = [participant_map[pid] for pid in global_memberships if pid in participant_map]
    global_timestamps.extend(p.get("checked_at") for p in global_profiles)
    global_timestamps.extend(value for p in global_profiles for value in p.get("metrics_observed_at", {}).values())
    global_dates = [_date(value) for value in global_timestamps if _date(value)]
    overlap_deferred = group_overlap_deferred or account_overlap_deferred
    overlap_reason = (f"Полная таблица пересечений отложена: объём парных операций превышает предел {pair_limit}. "
                      "Выберите две группы или два аккаунта для точного сравнения; аудитория и эксклюзивность рассчитаны по всей области.") if overlap_deferred else None
    needs_profiles = [p["id"] for p in participant_rows if p["needs_collection"]]
    external_found = {pid for pid in all_found if not participant_map[pid]["is_ours"]}
    checked = sum(p["checked_at"] is not None for p in participant_rows)
    scope = {"account_ids": sorted(selected_account_ids, key=str), "group_ids": [g["id"] for g in chosen],
             "type": "all" if account_ids is None else ("account" if len(selected_account_ids) == 1 else "selected_accounts"),
             "include_ours": include_ours, "label": "Все аккаунты" if account_ids is None else "Выбранные аккаунты"}
    summary = {"account_count": len(selected_account_ids & set(account_map)), "group_count": len(chosen),
               "participant_count": len(all_found), "external_participant_count": len(external_found),
               "memberships": sum(len(s) for s in sets.values()), "unique_audience": len(occurrence),
               "exclusive_people": sum(n == 1 for n in occurrence.values()), "repeated_people": sum(n > 1 for n in occurrence.values()),
               "redundant_memberships": sum(len(s) for s in sets.values()) - len(occurrence),
               "own_participant_count": len(all_found-external_found), "profiles_checked": checked, "profiles_total": len(all_found),
               "profile_coverage": _percent(checked, len(all_found)), "complete_groups": sum(_membership_complete(g) for g in chosen),
               "partial_groups": sum(not _membership_complete(g) for g in chosen),
               "observed_from": _iso(min(dates)) if dates else None, "observed_to": _iso(max(dates)) if dates else None,
               "global_observed_from": _iso(min(global_dates)) if global_dates else None,
               "global_observed_to": _iso(max(global_dates)) if global_dates else None,
               "overlap_matrix_deferred": overlap_deferred, "overlap_matrix_reason": overlap_reason,
               "group_overlap_matrix_deferred": group_overlap_deferred,
               "account_overlap_matrix_deferred": account_overlap_deferred,
               "overlap_pair_limit": pair_limit, "group_overlap_pair_work": group_pair_work,
               "account_overlap_pair_work": account_pair_work, "shared_group_pair_work": shared_pair_work,
               "scope": scope, "preliminary": not lists_complete, "identity_warnings": identity_warnings,
               "empty_audience": not bool(occurrence), "membership_coverage": lists_coverage if chosen else None}
    return {"summary": summary, "groups": group_rows, "participants": participant_rows, "overlaps": overlaps,
            "account_overlaps": account_overlap_rows, "own_accounts": own_rows, "recommendations": recommendations,
            "coverage": {"needs_collection": bool(needs_profiles or not lists_complete), "participant_ids": needs_profiles,
                         "overlap_matrix_deferred": overlap_deferred, "overlap_matrix_reason": overlap_reason,
                         "group_ids": [g["id"] for g in chosen if not _membership_complete(g)],
                         "reasons": ["Есть устаревшие, отсутствующие или недостаточные наблюдения профилей"] if needs_profiles else ([] if lists_complete else ["Не подтверждена полнота состава групп"]),
                         "requested_n": settings["collection"]["posts_limit"],
                         "requested_days": max(settings["collection"]["period_days"], settings["evaluation"]["reposts_days"], settings["evaluation"]["active_days"])},
            "settings": settings, "calculated_at": _iso(now)}
