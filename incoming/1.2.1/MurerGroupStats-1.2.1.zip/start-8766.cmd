@echo off
call "%~dp0start.cmd" --port 8766
