"""Explicit fixtures/mocks. These tests do not claim logged-in X verification."""
import asyncio
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import AsyncMock, MagicMock, patch
import zipfile
from selenium.common.exceptions import InvalidSessionIdException

from murer.collector import SeleniumSession, ProfileLock
from murer.rules import default_settings
from murer.safe_actions import SafeActions
from xgenius.browser import BrowserManager, parse_proxy
from xgenius.collectors.groups import GroupCollector, CHAT_LIST_PROBE_JS
from xgenius.config import Config
from xgenius.models import BrowserConfig, AccountCredentials, AccountState


class StopRequested(Exception):
    """Explicit control signal; must survive Selenium exception wrappers."""


class CollectorTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.config = Config(Path(self.temp.name))
        self.settings = default_settings()
        self.settings["collection"].update(action_delay_seconds=0, load_wait_seconds=0, idle_scroll_limit=2)
        self.session = SeleniumSession(self.config, MagicMock(), self.settings)
        self.session.username = "ours"
        self.browser = MagicMock()
        self.session.manager.accounts["ours"] = AccountState("ours", browser=self.browser)
        self.session.actions = MagicMock()
        self.session.actions.get = AsyncMock()
        self.session.actions.wait = AsyncMock()
        self.session.actions.script = AsyncMock()
        self.session.actions.scroll = AsyncMock()
        self.session.actions.sleep = AsyncMock()
        self.session._page_gate = AsyncMock(return_value=None)

    async def test_member_list_full_only_when_count_or_end_confirmed(self):
        self.session._open_members = AsyncMock(return_value=True)
        probe = {"panel_found": True, "declared_raw": "2", "participants": [
            {"x_id": "1", "username": "Alice", "name": "A", "url": "https://x.com/Alice", "identity_origin": "dom_stable_id"},
            {"x_id": None, "username": "BOB", "name": "B", "url": "https://x.com/BOB", "identity_origin": "profile_link_username"}], "loading": False}
        self.session.actions.script.return_value = probe
        result = await self.session.members({"url": "https://x.com/i/chat/g1"})
        self.assertEqual(result["status"], "full")
        self.assertEqual([row["username"] for row in result["participants"]], ["alice", "bob"])
        probe["declared_raw"] = "5"
        result = await self.session.members({"url": "https://x.com/i/chat/g1"})
        self.assertEqual(result["status"], "partial")
        self.assertEqual(len(result["participants"]), 2)

    async def test_delayed_profile_header_recovers_from_empty_loading_frame(self):
        self.session.actions.script.side_effect = [
            {'header_found':False,'cards':[],'loading':True},
            {'header_found':True,'username':'alice','followers_raw':'100','posts_raw':'0 posts','cards':[],'confirmed_end':True}]
        result = await self.session.profile({'username':'alice'})
        self.assertEqual(result['status'], 'full')
        self.assertEqual(result['followers']['value'], 100)

    async def test_card_classification_upgrade_does_not_consume_two_slots(self):
        card = {'id':'10','author':'someone','original_at':'2026-10-15T00:00:00Z','text':'same card'}
        self.settings['collection']['posts_limit'] = 2
        self.session.actions.script.side_effect = [
            {'header_found':True,'cards':[card]},
            {'header_found':True,'cards':[{**card,'social_context':'Alice reposted'}],'confirmed_end':True}]
        result = await self.session.profile({'username':'alice'})
        self.assertEqual(result['viewed_count'], 1)
        self.assertEqual(len(result['posts']), 1)
        self.assertEqual(result['posts'][0]['type'], 'repost')
        self.assertEqual(result['classified_count'], 1)
        self.assertIsNone(result['posts'][0]['event_at'])

    async def test_known_id_is_used_instead_of_possibly_reused_old_handle(self):
        self.session.actions.script.return_value = {'header_found':True,'username':'renamed','x_id':'123','cards':[],'confirmed_end':True}
        result = await self.session.profile({'username':'oldhandle','x_id':'123','url':'https://x.com/oldhandle'})
        self.session.actions.get.assert_awaited_once_with('https://x.com/i/user/123')
        self.assertEqual(result['username'], 'renamed')

    async def test_unavailable_members_never_use_message_senders(self):
        self.session._open_members = AsyncMock(return_value=False)
        result = await self.session.members({"url": "https://x.com/i/chat/g1"})
        self.assertEqual(result["status"], "unavailable")
        self.assertEqual(result["participants"], [])
        self.assertIsNone(result["declared_count"])

    async def test_xchat_view_all_carries_fresh_count_from_preview(self):
        self.session._click_first = AsyncMock(side_effect=[True, False])
        button = MagicMock()
        self.session.actions.call = AsyncMock(return_value=True)
        self.session.actions.click = AsyncMock()
        roster = {"panel_found": True, "participants": [
            {"username": f"fixture_{number}", "x_id": None} for number in range(59)]}
        self.session.actions.script.side_effect = [
            {"panel_found": False},
            {"panel_found": True, "declared_raw": "59", "participants": []},
            [button],
            roster,
            roster,
        ]
        result = await self.session.members({"x_id": "g1", "url": "https://x.com/i/chat/g1"})
        self.assertEqual(result["declared_count"], 59)
        self.assertEqual(len(result["participants"]), 59)
        self.assertEqual(result["status"], "full")
        self.session.actions.click.assert_awaited_once_with(button)

    async def test_profile_repost_unknown_date_dedup_and_pinned_do_not_stop(self):
        own = {"id": "10", "url": "https://x.com/alice/status/10", "author": "alice", "original_at": "2020-01-01T00:00:00Z", "pinned": True, "social_context": "Pinned"}
        repost = {"id": "11", "url": "https://x.com/bob/status/11", "author": "bob", "original_at": "2026-10-14T00:00:00Z", "social_context": "Alice reposted"}
        recent = {"id": "12", "url": "https://x.com/alice/status/12", "author": "alice", "original_at": "2026-10-14T00:00:00Z"}
        probe = {"header_found": True, "followers_raw": "1.2K", "posts_raw": "56.1K posts", "cards": [own, repost, repost, recent]}
        self.session.actions.script.return_value = probe
        result = await self.session.profile({"username": "alice", "url": "https://x.com/alice"})
        self.assertEqual(result["posts_total"]["value"], 56100)
        self.assertEqual(result["viewed_count"], 3)
        self.assertEqual(next(p for p in result["posts"] if p["type"] == "repost")["event_at"], None)
        self.assertFalse(result["period_complete"])
        self.assertEqual(result["status"], "partial")
        self.session.actions.scroll.assert_awaited()

    async def test_missing_profile_counters_are_not_zero(self):
        self.session.actions.script.return_value = {"header_found": True, "cards": [], "confirmed_end": True}
        result = await self.session.profile({"username": "alice", "url": "https://x.com/alice"})
        self.assertIsNone(result["followers"]["value"])
        self.assertIsNone(result["posts_total"]["value"])
        self.assertEqual(result["status"], "partial")

    async def test_header_removed_by_virtualization_retains_known_fields(self):
        first = {"header_found": True, "followers_raw": "1234", "posts_raw": "100 posts", "x_id": "10", "cards": []}
        last = {"header_found": True, "cards": [], "confirmed_end": True}
        self.session.actions.script.side_effect = [first, last]
        result = await self.session.profile({"username": "alice", "url": "https://x.com/alice"})
        self.assertEqual(result["followers"]["value"], 1234)
        self.assertEqual(result["posts_total"]["value"], 100)
        self.assertEqual(result["x_id"], "10")

    async def test_profile_reads_renamed_handle_without_display_name_identity(self):
        self.session.actions.script.return_value = {"header_found": True, "username": "NewHandle", "x_id": "10", "cards": [], "confirmed_end": True}
        result = await self.session.profile({"username": "oldhandle", "url": "https://x.com/oldhandle"})
        self.assertEqual(result["username"], "newhandle")
        self.assertEqual(result["x_id"], "10")

    async def test_suspended_participant_does_not_pause_our_account(self):
        self.session._page_gate = SeleniumSession._page_gate.__get__(self.session)
        self.session.actions.call = AsyncMock(return_value="https://x.com/participant")
        self.session.manager._check_login_locks = AsyncMock(return_value="SUSPENDED")
        self.assertIsNone(await self.session._page_gate())
        self.session.actions.call.return_value = "https://x.com/account/access"
        self.session.manager._check_login_locks.return_value = "LOCKED (CAPTCHA)"
        self.assertEqual((await self.session._page_gate())["status"], "requires_manual")

    async def test_closed_driver_requests_session_recovery(self):
        self.session._page_gate = SeleniumSession._page_gate.__get__(self.session)
        self.session.actions.call = AsyncMock(side_effect=InvalidSessionIdException("closed"))
        self.assertEqual((await self.session._page_gate())["status"], "session_expired")

    async def test_chat_pin_recovery_is_manual_without_automatic_bypass(self):
        self.session._page_gate = SeleniumSession._page_gate.__get__(self.session)
        self.session.actions.call = AsyncMock(return_value="https://x.com/i/chat/pin/recovery")
        self.session.manager._check_login_locks = AsyncMock(return_value=None)
        self.assertEqual((await self.session._page_gate())["status"], "requires_manual")

    async def test_pin_auto_advance_waits_for_key_decryption_navigation(self):
        self.session._page_gate = SeleniumSession._page_gate.__get__(self.session)
        pin_url = 'https://x.com/i/chat/pin/recovery'
        self.session.actions.call = AsyncMock(side_effect=[pin_url, pin_url, pin_url, 'https://x.com/i/chat'])
        self.session._ichat_unlock.check = AsyncMock(return_value=None)
        self.session._ichat_auto_unlock_candidate = True
        self.session.manager._check_login_locks = AsyncMock(return_value=None)
        self.assertIsNone(await self.session._page_gate())
        self.assertEqual(self.session.actions.sleep.await_count, 2)
        self.session._ichat_unlock.check.assert_awaited_once()

    async def test_pin_auto_advance_wait_has_a_limit(self):
        self.session._page_gate = SeleniumSession._page_gate.__get__(self.session)
        self.session.collection['login_poll_rounds'] = 2
        self.session.actions.call = AsyncMock(return_value='https://x.com/i/chat/pin/recovery')
        self.session._ichat_unlock.check = AsyncMock(return_value=None)
        self.session._ichat_auto_unlock_candidate = True
        self.session.manager._check_login_locks = AsyncMock(return_value=None)
        result = await self.session._page_gate()
        self.assertEqual(result['status'], 'requires_manual')
        self.assertEqual(self.session.actions.sleep.await_count, 2)
        self.session._ichat_unlock.check.assert_awaited_once()

    async def test_search_typing_never_sends_enter_and_rejects_composer(self):
        actions = SafeActions(self.browser, self.settings)
        field = MagicMock()
        field.get_attribute.side_effect = lambda key: "search" if key == "type" else ""
        await actions.search_input(field, "Alice")
        self.assertEqual([call.args[0] for call in field.send_keys.call_args_list], list("Alice"))
        field.get_attribute.side_effect = lambda key: "dmComposerTextInput" if key == "data-testid" else ""
        with self.assertRaises(ValueError):
            await actions.search_input(field, "Alice")

    async def test_same_session_public_commands_are_serialized(self):
        concurrent, peak = 0, 0
        async def member_open():
            nonlocal concurrent, peak
            concurrent += 1
            peak = max(peak, concurrent)
            await asyncio.sleep(0.01)
            concurrent -= 1
            return False
        self.session._open_members = member_open
        await asyncio.gather(*(self.session.members({"url": "https://x.com/i/chat/g1"}) for _ in range(3)))
        self.assertEqual(peak, 1)

    async def test_group_discovery_deduplicates_group_accesses_and_excludes_dm(self):
        probe = {"url": "https://x.com/i/chat", "confirmed_end": True, "groups": [
            {"url": "https://x.com/i/chat/g1", "name": "Group"},
            {"url": "https://x.com/i/chat/g1?other=1", "name": "Group"},
            {"url": "https://x.com/i/chat/1-2", "name": "Direct"}]}
        self.browser.execute_script.return_value = probe
        result = await GroupCollector(MagicMock()).discover_groups(self.browser, "ours", self.settings)
        self.assertEqual(result["status"], "full")
        self.assertEqual(len(result["groups"]), 1)

    async def test_stalled_group_list_is_not_complete(self):
        probe = {"url": "https://x.com/i/chat", "groups": [{"url": "https://x.com/i/chat/g1"}]}
        self.browser.execute_script.side_effect = lambda script: probe if script == CHAT_LIST_PROBE_JS else []
        result = await GroupCollector(MagicMock()).discover_groups(self.browser, "ours", self.settings)
        self.assertEqual(result["status"], "partial")
        self.assertIn("не подтверждён", result["reason"])

    async def test_stable_scroll_bottom_confirms_end_without_special_end_text(self):
        probe={'url':'https://x.com/i/chat','groups':[{'url':'https://x.com/i/chat/g1'}],
               'geometry':{'height':1000,'top':500,'viewport':500,'at_bottom':True},'loading':False}
        self.browser.execute_script.side_effect=lambda script:probe if script==CHAT_LIST_PROBE_JS else []
        result=await GroupCollector(MagicMock()).discover_groups(self.browser,'ours',self.settings)
        self.assertEqual(result['status'],'full')
        self.assertEqual(result['end_evidence']['kind'],'stable_scroll_bottom')

    async def test_stable_position_without_bottom_or_with_loading_is_not_complete(self):
        for geometry,loading in [({'height':1500,'top':500,'viewport':500,'at_bottom':False},False),
                                 ({'height':1000,'top':500,'viewport':500,'at_bottom':True},True)]:
            probe={'url':'https://x.com/i/chat','groups':[{'url':'https://x.com/i/chat/g1'}],'geometry':geometry,'loading':loading}
            self.browser.execute_script.side_effect=lambda script:probe if script==CHAT_LIST_PROBE_JS else []
            result=await GroupCollector(MagicMock()).discover_groups(self.browser,'ours',self.settings)
            self.assertEqual(result['status'],'partial')

    async def test_group_scroll_checkpoint_precedes_stop_and_is_detached(self):
        events, stop = [], False
        def checkpoint():
            if stop:
                raise StopRequested()
        def progress(value):
            nonlocal stop
            events.append(value)
            stop = True
        probe = {"url": "https://x.com/i/chat", "groups": [
            {"url": "https://x.com/i/chat/g1", "name": "Known group"}]}
        self.browser.execute_script.return_value = probe
        with self.assertRaises(StopRequested):
            await GroupCollector(MagicMock()).discover_groups(self.browser, "ours", self.settings,
                checkpoint=checkpoint, progress=progress)
        snapshot = events[0]["checkpoint_data"]
        self.assertEqual(snapshot["kind"], "groups")
        self.assertEqual(snapshot["groups"][0]["x_id"], "g1")
        self.assertEqual(snapshot["status"], "partial")
        self.assertFalse(self.session.manager.accounts["ours"].is_scanning)
        self.assertEqual(self.browser.execute_script.call_count, 1)

    async def test_member_scroll_saves_actual_partial_members_before_stop(self):
        events = []
        self.session.progress = events.append
        self.session._open_members = AsyncMock(return_value=True)
        self.session.actions.script.return_value = {"panel_found": True, "declared_raw": "12", "participants": [
            {"x_id": "101", "username": None, "name": "Stable ID only"},
            {"x_id": None, "username": "Alice"}, {"username": None}]}
        self.session._page_gate.side_effect = [None, StopRequested()]
        with self.assertRaises(StopRequested):
            await self.session.members({"x_id": "g1", "url": "https://x.com/i/chat/g1"})
        snapshot = events[-1]["checkpoint_data"]
        self.assertEqual(snapshot["group_x_id"], "g1")
        self.assertEqual(snapshot["declared_count"], 12)
        self.assertEqual(len(snapshot["participants"]), 2)
        self.assertEqual(snapshot["participants"][0]["x_id"], "101")
        self.assertIsNone(snapshot["participants"][0]["username"])
        self.assertEqual(snapshot["status"], "partial")

    async def test_profile_scroll_saves_observations_before_stop(self):
        events = []
        self.session.progress = events.append
        self.session.actions.script.return_value = {"header_found": True, "followers_raw": "1.2K", "cards": [
            {"id": "11", "author": "bob", "original_at": "2020-01-01T00:00:00Z", "social_context": "Alice reposted"}]}
        self.session._page_gate.side_effect = [None, StopRequested()]
        with self.assertRaises(StopRequested):
            await self.session.profile({"id": 7, "username": "alice", "url": "https://x.com/alice"})
        snapshot = events[-1]["checkpoint_data"]
        self.assertEqual(snapshot["kind"], "profile")
        self.assertEqual(snapshot["participant_id"], 7)
        result = snapshot["result"]
        self.assertEqual(result["followers"]["value"], 1200)
        self.assertIsNone(result["posts_total"]["value"])
        self.assertEqual(result["viewed_count"], 1)
        self.assertEqual(result["classified_count"], 1)
        self.assertIsNone(result["posts"][0]["event_at"])
        self.assertEqual(result["status"], "partial")
        self.assertFalse(result["period_complete"])

    async def test_stable_id_without_username_opens_identity_url(self):
        self.session.actions.script.return_value = {"header_found": True, "x_id": "101", "cards": [], "confirmed_end": True}
        result = await self.session.profile({"id": 7, "x_id": "101", "username": None})
        self.session.actions.get.assert_awaited_once_with("https://x.com/i/user/101")
        self.assertEqual(result["x_id"], "101")

    async def test_login_stop_is_not_transformed_into_error_status(self):
        self.session.manager.login_account = AsyncMock(side_effect=StopRequested())
        try:
            with self.assertRaises(StopRequested):
                await self.session.login(AccountCredentials("ours", "fixture"))
        finally:
            if self.session.profile_lock:
                self.session.profile_lock.release()

    async def test_foundation_auth_preserves_stop_before_browser_creation(self):
        self.session.config.login_checkpoint = lambda: (_ for _ in ()).throw(StopRequested())
        self.session.manager.accounts["ours"].browser = None
        self.session.manager.browser_manager.create_browser = AsyncMock()
        with self.assertRaises(StopRequested):
            await self.session.manager.login_account(AccountCredentials("ours", "fixture"), fetch_followers=False)
        self.session.manager.browser_manager.create_browser.assert_not_awaited()

    async def test_session_passes_configured_timeouts_and_login_delays(self):
        collection = self.settings["collection"]
        collection.update(page_load_timeout_seconds=60, script_timeout_seconds=20,
            login_typing_delay_min=0.02, login_typing_delay_max=0.03,
            login_element_timeout_seconds=21, login_poll_rounds=3, login_poll_seconds=0.5)
        session = SeleniumSession(self.config, MagicMock(), self.settings)
        for key in ("page_load_timeout_seconds", "script_timeout_seconds", "login_element_timeout_seconds", "login_poll_rounds", "login_poll_seconds"):
            self.assertEqual(getattr(session.config, key), collection[key])
        self.assertGreaterEqual(session.manager._credential_delay(), 0.02)
        self.assertLessEqual(session.manager._credential_delay(), 0.03)

    async def test_password_login_keeps_character_order_with_configured_waits(self):
        manager = self.session.manager
        manager._is_logged_in = AsyncMock(side_effect=[False, True])
        manager._accept_cookies = AsyncMock()
        manager._check_login_locks = AsyncMock(return_value=None)
        self.config.login_checkpoint = None
        self.config.login_element_timeout_seconds = 19
        self.config.login_button_timeout_seconds = 8
        self.config.login_typing_delay_min = 0.01
        self.config.login_typing_delay_max = 0.01
        username, next_button, password, login_button = [MagicMock() for _ in range(4)]
        waits = [MagicMock() for _ in range(4)]
        for wait, element in zip(waits, (username, next_button, password, login_button)):
            wait.until.return_value = element
        with patch("xgenius.accounts.auth.WebDriverWait", side_effect=waits) as waiting, \
             patch("xgenius.accounts.auth.asyncio.sleep", new_callable=AsyncMock):
            await manager._perform_login(self.browser, AccountCredentials("ours", "fixture-password"))
        self.assertEqual([call.args[0] for call in username.send_keys.call_args_list], list("ours"))
        self.assertEqual([call.args[0] for call in password.send_keys.call_args_list], list("fixture-password"))
        self.assertEqual([call.args[1] for call in waiting.call_args_list], [19, 8, 19, 8])
        next_button.click.assert_called_once()
        login_button.click.assert_called_once()

    async def test_browser_uses_configured_page_and_script_timeouts(self):
        self.config.page_load_timeout_seconds = 61
        self.config.script_timeout_seconds = 17
        browser = MagicMock()
        with patch("xgenius.browser.webdriver.Chrome", return_value=browser), \
             patch("xgenius.browser.stealth"), patch("xgenius.browser.Service"):
            manager = BrowserManager(self.config, BrowserConfig())
            await manager.create_browser(AccountCredentials("fixture", ""))
        browser.set_page_load_timeout.assert_called_once_with(61)
        browser.set_script_timeout.assert_called_once_with(17)

    async def test_non_humanized_scroll_uses_editable_step_and_pause(self):
        self.settings["collection"].update(scroll_step_pixels=321, scroll_pause_seconds=0.73)
        actions = SafeActions(self.browser, self.settings)
        actions.script = AsyncMock(return_value={"found": True})
        actions.sleep = AsyncMock()
        await actions.scroll()
        self.assertEqual(actions.script.await_args.args[2], 321)
        actions.sleep.assert_awaited_once_with(0.73)


class ProxyAndLockTests(unittest.TestCase):
    def test_legacy_and_url_proxy_credentials_are_preserved(self):
        self.assertEqual(parse_proxy('localhost:8080:user:pass:with:colons'), ('localhost', 8080, 'user', 'pass:with:colons', 'http'))
        self.assertEqual(parse_proxy('http://user:p%40ss@localhost:8080'), ('localhost', 8080, 'user', 'p@ss', 'http'))

    def test_mv3_proxy_extension_credentials_are_json_and_session_isolation(self):
        with tempfile.TemporaryDirectory() as folder:
            manager = BrowserManager(Config(Path(folder)), BrowserConfig())
            options = MagicMock()
            manager._add_proxy_authentication(options, 'host:8080:u\":p\\word')
            manager._add_proxy_authentication(options, 'host:8081:different:password')
            paths = [call.args[0] for call in options.add_extension.call_args_list]
            self.assertNotEqual(paths[0], paths[1])
            with zipfile.ZipFile(paths[0]) as extension:
                manifest = json.loads(extension.read('manifest.json'))
                script = extension.read('background.js').decode()
                self.assertEqual(manifest['manifest_version'], 3)
                self.assertIn('webRequestAuthProvider', manifest['permissions'])
                self.assertIn('asyncBlocking', script)
                self.assertIn('details.isProxy', script)
                self.assertIn(json.dumps({'username': 'u"', 'password': 'p\\word'}), script)

    def test_profile_lock_denies_second_owner_and_releases(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / 'profile' / '.lock'
            first, second = ProfileLock(path), ProfileLock(path)
            first.acquire()
            try:
                with self.assertRaises(RuntimeError):
                    second.acquire()
            finally:
                first.release()
            second.acquire()
            second.release()

if __name__ == '__main__':
    unittest.main()
