"""Independent Trade pacing, settings concurrency and real worker snapshots."""
import asyncio
from copy import deepcopy
from pathlib import Path
import tempfile
import unittest
from unittest.mock import AsyncMock, MagicMock, patch

from murer.rules import default_settings, trade_runtime_settings, trade_speed_presets, validate_settings
from murer.trade_browser import TradeSession
from xgenius.config import Config
from tests import test_trade as fixture


class TradeSpeedRulesTests(unittest.TestCase):
    def test_upgrade_adds_independent_defaults_and_leaves_collection_unchanged(self):
        old = default_settings()
        del old['trade']
        old['collection']['action_delay_seconds'] = 77
        new = validate_settings(old)
        self.assertEqual(new['collection'], old['collection'])
        self.assertEqual(new['trade']['action_delay_seconds'], 1)
        new['trade']['humanization']['enabled'] = True
        self.assertFalse(new['humanization']['enabled'])

    def test_presets_change_only_trade_pacing_and_preserve_verification_budget(self):
        for preset in trade_speed_presets():
            source = default_settings()
            before = deepcopy(source)
            source['trade']['humanization']['enabled'] = True
            pacing = deepcopy(preset['settings']['trade'])
            human = pacing.pop('humanization')
            source['trade'].update(pacing)
            source['trade']['humanization'].update(human)
            result = validate_settings(source)
            self.assertEqual(result['collection'], before['collection'])
            self.assertEqual(result['humanization'], before['humanization'])
            self.assertTrue(result['trade']['humanization']['enabled'])
            for key in ('login_poll_seconds', 'login_poll_rounds', 'retries', 'group_scroll_limit', 'element_timeout_seconds'):
                self.assertNotIn(key, pacing)
                self.assertEqual(result['trade'][key], before['trade'][key])
            self.assertNotIn('concurrent_accounts', result['trade'])
            self.assertNotIn('posts_limit', result['trade'])
        presets = trade_speed_presets()
        presets[0]['settings']['trade']['humanization']['typing_delay_min'] = 999
        self.assertEqual(trade_speed_presets()[0]['settings']['trade']['humanization']['typing_delay_min'], .12)

    def test_invalid_pacing_is_rejected_atomically(self):
        for supplied in ({'action_delay_seconds': -1}, {'group_delay_seconds': True},
                         {'load_wait_seconds': '1'}, {'login_poll_seconds': float('inf')},
                         {'retries': 1.5}, {'login_poll_rounds': 0}, {'scroll_step_pixels': 0},
                         {'element_timeout_seconds': 0}, {'humanization': {'enabled': 1}},
                         {'humanization': {'typing_delay_min': 2, 'typing_delay_max': 1}},
                         {'login_typing_delay_min': 2, 'login_typing_delay_max': 1},
                         {'posts_limit': 10}, {'humanization': {'unknown': 5}}):
            with self.subTest(supplied=supplied), self.assertRaises(ValueError):
                validate_settings({'trade': supplied})

    def test_browser_uses_trade_controls_for_auth_actions_and_group_discovery(self):
        settings = default_settings()
        settings['collection'].update(action_delay_seconds=99, login_poll_seconds=99, group_scroll_limit=999)
        settings['humanization']['enabled'] = True
        settings['trade'].update(action_delay_seconds=.7, group_scroll_limit=18, login_poll_seconds=.4,
                                 login_typing_delay_min=.01, login_typing_delay_max=.02)
        original = deepcopy(settings)
        with tempfile.TemporaryDirectory() as folder:
            session = TradeSession(Config(Path(folder)), MagicMock(), settings)
            self.assertEqual(session.collection['action_delay_seconds'], .7)
            self.assertEqual(session.collection['group_scroll_limit'], 18)
            self.assertEqual(session.collection['login_poll_seconds'], .4)
            self.assertEqual(session.manager.config.login_typing_delay_min, .01)
            self.assertFalse(session.settings['humanization']['enabled'])
        self.assertEqual(settings, original)
        legacy = deepcopy(settings); del legacy['trade']
        self.assertEqual(trade_runtime_settings(legacy), legacy)


class TradeSpeedAPITests(unittest.TestCase):
    setUp = fixture.TradeTests.setUp
    wait = fixture.TradeTests.wait
    preview = fixture.TradeTests.preview
    start = fixture.TradeTests.start
    finished = fixture.TradeTests.finished

    def save_speed(self, **changes):
        previous = self.client.get('/api/trade').json()['speed_settings']
        next_settings = {**previous, **changes}
        response = self.client.put('/api/trade/settings', json={'settings': next_settings, 'previous': previous})
        self.assertEqual(response.status_code, 200, response.text)
        return response.json()['settings']

    def test_api_exposes_presets_and_saves_only_trade_without_lost_updates(self):
        overview = self.client.get('/api/trade').json()
        self.assertEqual(overview['speed_presets'], trade_speed_presets())
        stale, _ = self.state.store.settings()
        self.save_speed(group_delay_seconds=7.25)
        stale['collection']['posts_limit'] = 333
        response = self.client.put('/api/settings', json=stale,
                                   headers={'X-Settings-Sections': 'collection,humanization,evaluation,own_accounts'})
        self.assertEqual(response.status_code, 200, response.text)
        current, version = self.state.store.settings()
        self.assertEqual(current['trade']['group_delay_seconds'], 7.25)
        self.assertEqual(current['collection']['posts_limit'], 333)
        response = self.client.put('/api/trade/settings', json={'previous': overview['speed_settings'], 'settings': overview['speed_settings']})
        self.assertEqual(response.status_code, 409)
        self.assertEqual(self.state.store.settings(), (current, version))
        invalid = {**current['trade'], 'group_delay_seconds': -1}
        self.assertEqual(self.client.put('/api/trade/settings', json={'previous': current['trade'], 'settings': invalid}).status_code, 422)
        self.assertEqual(self.state.store.settings(), (current, version))

    def test_worker_consumes_trade_delays_even_when_collection_is_different(self):
        settings, _ = self.state.store.settings()
        settings['collection'].update(action_delay_seconds=99, profile_delay_seconds=99, group_delay_seconds=99, account_start_interval_seconds=99)
        self.state.store.save_settings(settings)
        self.save_speed(action_delay_seconds=.75, counterparty_delay_seconds=4.25, group_delay_seconds=8.75, account_start_interval_seconds=12.5)
        received, pauses = [], []
        original = self.state.trades.session_factory
        def factory(config, logger, settings, checkpoint, progress):
            received.append(deepcopy(settings))
            browser = original(config, logger, settings, checkpoint, progress)
            async def sleep(seconds):
                pauses.append(seconds)
                checkpoint()
                await asyncio.sleep(0)
            browser.actions.sleep = sleep
            return browser
        self.state.trades.session_factory = factory
        for group in self.scenario.stats.groups:
            self.state.store.upsert_group(group, self.second['id'])
        plan = self.preview(send_account_id=self.second['id'])
        with patch.object(self.state.jobs, '_delay', new_callable=AsyncMock) as delay:
            run = self.finished(self.start(plan))
        self.assertIn(4.25, pauses)
        self.assertIn(8.75, pauses)
        self.assertTrue(delay.await_args_list)
        self.assertTrue(all(0 <= args.args[1] <= 12.5 for args in delay.await_args_list))
        self.assertTrue(received)
        for runtime in received:
            self.assertEqual(runtime['collection']['action_delay_seconds'], .75)
            self.assertEqual(runtime['collection']['profile_delay_seconds'], 4.25)
            self.assertEqual(runtime['collection']['account_start_interval_seconds'], 12.5)
        self.assertEqual(run['settings']['collection']['action_delay_seconds'], 99)
        self.assertEqual(run['settings']['trade']['group_delay_seconds'], 8.75)

    def test_preview_uses_speed_at_start_and_active_worker_stays_frozen_until_resume(self):
        plan = self.preview()
        self.save_speed(action_delay_seconds=.5)
        self.scenario.hold.clear()
        rid = self.start(plan)
        def cleanup():
            self.scenario.hold.set()
            self.state.trades.command(rid, 'stop')
            self.state.trades.threads[rid].join(10)
        self.addCleanup(cleanup)
        self.wait(lambda: self.scenario.started.is_set())
        run = self.state.trades.run(rid)
        self.assertEqual(run['settings']['trade']['action_delay_seconds'], .5)
        self.save_speed(action_delay_seconds=.1)
        self.assertEqual(self.state.trades.run(rid)['settings']['trade']['action_delay_seconds'], .5)
        self.state.trades.command(rid, 'stop')
        self.finished(rid)
        self.scenario.hold.set()
        resumed = self.finished(self.start(plan, verify_only=True))
        self.assertEqual(resumed['settings']['trade']['action_delay_seconds'], .1)
        self.assertEqual(resumed['settings']['evaluation'], plan['settings']['evaluation'])
        self.assertEqual(resumed['settings_version'], plan['settings_version'])
        self.assertGreater(resumed['progress']['speed_settings_version'], plan['settings_version'])
        self.assertEqual(len(self.scenario.invites), 1)


if __name__ == '__main__':
    unittest.main()
