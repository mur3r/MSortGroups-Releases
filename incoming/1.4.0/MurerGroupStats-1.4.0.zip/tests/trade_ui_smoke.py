"""Rendered two-phase Trade UI; synthetic sessions, no real X access."""
import json
import os
from pathlib import Path
import sys
import tempfile
import threading
import time
import traceback
import uvicorn
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from murer.api import create_app
from murer.secrets import SecretStore
from murer.storage import encode
from murer.runtime import read_configuration
from tests.test_storage_api import MemoryVault
from tests.test_trade import ExchangeScenario


def run():
    report={'synthetic_data':True,'real_x_access':False,'checks':[],'passed':False}
    browser=None
    (ROOT/'artifacts').mkdir(exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='murer_trade_workflow_ui_') as folder:
        scenario=ExchangeScenario()
        app=create_app(Path(folder)/'data',SecretStore(MemoryVault()),scenario.stats_factory,scenario.trade_factory)
        state=app.state.application;scenario.store=state.store
        state.configuration['configured']=True
        settings,_=state.store.settings()
        settings['trade'].update(counterparty_delay_seconds=0,group_delay_seconds=0,account_start_interval_seconds=0)
        state.store.save_settings(settings)
        owner=state.save_account({'username':'fixtureowner','password':'synthetic-private-password'})
        second=state.save_account({'username':'fixturesecond'})
        state.save_account({'username':'fixturereceiver'})
        scenario.receiver_username='fixturereceiver';scenario.group_lists['fixturereceiver']=[]
        for account,prefix in [(owner,'a'),(second,'b')]:
            groups=[{'x_id':'g'+prefix+str(i),'name':f'Fixture {prefix} group {i}','url':f'https://x.com/i/chat/g{prefix}{i}'} for i in range(10)]
            scenario.group_lists[account['username']]=groups
            for group in groups:state.store.upsert_group(group,account['id'])
        server=uvicorn.Server(uvicorn.Config(app,host='127.0.0.1',port=8768,log_level='error',access_log=False))
        thread=threading.Thread(target=server.run,daemon=True);thread.start()
        try:
            until=time.monotonic()+15
            while not server.started and time.monotonic()<until:time.sleep(.05)
            assert server.started
            runtime=read_configuration()
            options=webdriver.ChromeOptions();options.add_argument('--headless=new')
            options.binary_location=runtime['chrome_path']
            options.add_argument(f'--user-data-dir={Path(folder)/"browser"}')
            options.add_argument('--window-size=1500,1050');options.add_argument('--no-first-run')
            options.set_capability('goog:loggingPrefs',{'browser':'ALL'})
            browser=webdriver.Chrome(service=Service(runtime['driver_path']),options=options)
            wait=WebDriverWait(browser,40)
            browser.get('http://127.0.0.1:8768')

            def click(label,scope=None):
                def candidate(_):
                    return next((e for e in (scope or browser).find_elements(By.XPATH,f'.//button[normalize-space(.)={json.dumps(label,ensure_ascii=False)}]') if e.is_displayed() and e.is_enabled()),False)
                element=wait.until(candidate)
                browser.execute_script('arguments[0].scrollIntoView({block:"center"})',element);element.click()

            def check(name,condition=True):
                assert condition,name
                report['checks'].append(name)

            def field(identifier,value):
                element=wait.until(lambda _:browser.find_element(By.ID,identifier))
                element.send_keys(Keys.CONTROL,'a');element.send_keys(value)

            click('Trade')
            wait.until(lambda _:browser.find_element(By.ID,'trade-receive-login').is_enabled())
            for identifier,value in [('trade-receive-login','fixturereceiver'),('trade-donors','partner'),('trade-recipients','partner'),('trade-count','20')]:field(identifier,value)
            selector=browser.find_element(By.ID,'trade-source-mode')
            browser.execute_script('arguments[0].scrollIntoView({block:"center"})',selector);selector.click()
            wait.until(lambda _:browser.find_element(By.XPATH,'//*[@role="option" and contains(.,"Подобрать автоматически")]')).click()
            click('Подобрать группы и аккаунты')
            wait.until(lambda _:state.trades.history())
            rid=state.trades.history()[0]['id']
            wait.until(lambda _:state.trades.run(rid)['status']=='prepared' and not state.trades.run(rid)['worker_active'])
            wait.until(lambda _:browser.find_elements(By.CSS_SELECTOR,'textarea[aria-label="Сообщение со ссылками для получателя"]'))
            prepared=state.trades.run(rid)
            check('twenty_exact_groups_before_start',len(prepared['plan']['preparation']['assignments'])==20)
            check('no_follows_or_invitations_during_preparation',not scenario.invites and not scenario.follow_calls)
            check('preparation_releases_collection_priority',state.jobs.priority_owner is None)
            message=browser.find_element(By.CSS_SELECTOR,'textarea[aria-label="Сообщение со ссылками для получателя"]').get_attribute('value')
            check('copyable_links_only_for_used_sources','https://x.com/fixtureowner' in message and 'https://x.com/fixturesecond' in message and 'https://x.com/fixturereceiver' not in message)
            for width in (360,390,768,1440):
                browser.execute_cdp_cmd('Emulation.setDeviceMetricsOverride',{'width':width,'height':1050,'deviceScaleFactor':1,'mobile':False})
                wait.until(lambda _:browser.execute_script('return document.documentElement.scrollWidth<=innerWidth+1'))
                check('prepared_plan_responsive_'+str(width))
                browser.save_screenshot(str(ROOT/'artifacts'/f'trade-prepared-{width}.png'))
            browser.execute_cdp_cmd('Emulation.clearDeviceMetricsOverride',{})
            scenario.blocked_accounts.add(('fixturesecond','partner'))
            click('Начать Trade')
            wait.until(lambda _:state.trades.run(rid)['status']=='awaiting_subscriptions' and not state.trades.run(rid)['worker_active'])
            check('missing_one_follow_blocks_every_invitation',not scenario.invites and not scenario.follow_calls)
            wait.until(lambda _:'Обратная подписка не подтверждена' in browser.find_element(By.TAG_NAME,'body').text)
            check('exact_missing_account_visible','@fixturesecond' in browser.find_element(By.TAG_NAME,'body').text)
            scenario.blocked_accounts.clear();click('Начать Trade')
            wait.until(lambda _:state.trades.run(rid)['confirmed_count']==20 and not state.trades.run(rid)['worker_active'])
            check('only_prepared_twenty_groups_sent',{g for g,_ in scenario.invites}=={g['id'] for g in prepared['plan']['preparation']['assignments']})
            check('outgoing_complete_waits_for_incoming',state.trades.run(rid)['status']=='awaiting_incoming')
            click('Результаты и дополнительные аккаунты')
            dialog=wait.until(lambda _:browser.find_element(By.CSS_SELECTOR,'[role="dialog"]'))
            click('Получено нами',dialog)
            scenario.group_lists['fixturereceiver']=[{'x_id':'gIncoming'+str(i),'name':'Incoming '+str(i),'url':'https://x.com/i/chat/gIncoming'+str(i)} for i in range(20)]
            calls=len(scenario.invites);click('Перепроверить',dialog)
            wait.until(lambda _:state.trades.run(rid)['can_finish'] and not state.trades.run(rid)['worker_active'])
            check('incoming_recheck_never_reinvites',len(scenario.invites)==calls)
            click('Завершить Trade',dialog)
            wait.until(lambda _:state.trades.run(rid)['status']=='completed')
            check('explicit_finish_releases_queue',state.jobs.priority_owner is None)
            check('csv_report_available','/export' in dialog.find_element(By.CSS_SELECTOR,'a[download]').get_attribute('href'))
            current=state.trades.run(rid)
            state.store.execute('UPDATE trade_runs SET baseline=?,incoming=? WHERE id=?',
                                (encode({**current['baseline'],'complete':False}),encode({**current['incoming'],'sufficient_confirmed':False,'verdict':'preliminary'}),rid))
            browser.find_element(By.TAG_NAME,'body').send_keys(Keys.ESCAPE)
            browser.find_element(By.CSS_SELECTOR,'button[aria-label="Обновить данные"]').click()
            click('Результаты и дополнительные аккаунты')
            dialog=wait.until(lambda _:browser.find_element(By.CSS_SELECTOR,'[role="dialog"]'))
            click('Получено нами',dialog)
            wait.until(lambda _:dialog.find_element(By.XPATH,'.//summary[normalize-space(.)="Подтвердить входящие вручную"]')).click()
            checkbox=dialog.find_element(By.CSS_SELECTOR,'input[type="checkbox"]')
            check('manual_confirmation_requires_explicit_acknowledgement',not dialog.find_element(By.XPATH,'.//button[normalize-space(.)="Подтвердить проверенные входящие"]').is_enabled())
            browser.execute_script('arguments[0].scrollIntoView({block:"center"})',checkbox)
            checkbox.click();click('Подтвердить проверенные входящие',dialog)
            wait.until(lambda _:state.trades.run(rid)['incoming'].get('verdict')=='manual')
            check('manual_confirmation_preserves_old_incomplete_baseline',not state.trades.run(rid)['baseline']['complete'])
            check('no_browser_errors',not [e for e in browser.get_log('browser') if e['level']=='SEVERE' and 'favicon' not in e['message']])
            report['passed']=True
        except Exception as error:
            report.update(error=str(error),traceback=traceback.format_exc())
            if browser:browser.save_screenshot(str(ROOT/'artifacts'/'trade-ui-failure.png'))
        finally:
            if browser:browser.quit()
            state.trades.close();state.jobs.close();server.should_exit=True;thread.join(15)
            (ROOT/'artifacts'/'trade-ui-smoke.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'passed':report['passed'],'checks':len(report['checks']),'error':report.get('error')},ensure_ascii=True))
    return 0 if report['passed'] else 1


if __name__=='__main__':sys.exit(run())
