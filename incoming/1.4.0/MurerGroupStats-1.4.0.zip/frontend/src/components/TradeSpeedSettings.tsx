import { useEffect, useRef, useState } from 'react'
import { RotateCcw } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { SpeedPresets } from '@/components/SpeedPresets'
import { api, number, type Row } from '@/lib/api'

export const tradeSpeedLabels: Record<string, [string, string, string]> = {
  action_delay_seconds: ['Пауза между действиями', 'сек.', 'Клики, открытие профиля, переход к чату. При хьюманизации используется случайный диапазон ниже.'],
  counterparty_delay_seconds: ['Пауза между контрагентами', 'сек.', 'После проверки или подписки на очередного контрагента.'],
  group_delay_seconds: ['Пауза между добавлениями', 'сек.', 'После завершённой попытки добавления или проверки уже имеющегося участника.'],
  account_start_interval_seconds: ['Интервал запуска аккаунтов', 'сек.', 'Минимальное время между запусками браузеров. Trade работает с одним аккаунтом одновременно.'],
  load_wait_seconds: ['Пауза после загрузки страницы', 'сек.', 'Ожидание обновления профиля, чата и результатов поиска.'],
  scroll_step_pixels: ['Шаг прокрутки списка чатов', 'px', 'Используется при поиске исходящих и проверке входящих групп.'],
  scroll_pause_seconds: ['Пауза прокрутки', 'сек.', 'Обычная пауза между прокрутками списка чатов.'],
  login_typing_delay_min: ['Ввод при входе: минимум', 'сек./символ', 'Минимальная задержка ввода логина и пароля.'],
  login_typing_delay_max: ['Ввод при входе: максимум', 'сек./символ', 'Максимальная задержка ввода логина и пароля.'],
  login_page_wait_seconds: ['Открытие страницы входа', 'сек.', 'Пауза перед началом авторизации.'],
  login_step_wait_seconds: ['Пауза между шагами входа', 'сек.', 'Ожидание следующего экрана авторизации.'],
  login_poll_seconds: ['Интервал проверки состояния', 'сек.', 'Пауза ожидания авторизации, выбора получателя и подтверждения добавления. Режим скорости её не меняет.'],
  login_poll_rounds: ['Число проверок состояния', 'раз', 'Бюджет ожидания обновления интерфейса. Малые значения могут потребовать ручной проверки результата.'],
  retries: ['Повторы проверки после сбоя', 'раз', 'Повторяются чтение и подготовка до отправки. Неподтверждённое приглашение автоматически повторно не отправляется.'],
  element_timeout_seconds: ['Ожидание элемента', 'сек.', 'Сколько ждать появления нужной кнопки или формы.'],
  page_load_timeout_seconds: ['Таймаут загрузки страницы', 'сек.', 'Предельное ожидание навигации браузера.'],
  script_timeout_seconds: ['Таймаут скрипта браузера', 'сек.', 'Предельное ожидание выполнения скрипта.'],
  login_element_timeout_seconds: ['Ожидание поля входа', 'сек.', 'Предельное ожидание элемента авторизации.'],
  login_button_timeout_seconds: ['Ожидание кнопки входа', 'сек.', 'Предельное ожидание кнопки следующего шага входа.'],
  group_scroll_limit: ['Предел прокруток списка чатов', 'раз', 'Ограничение поиска исходящих и входящих групп. Не меняется режимами скорости.'],
  idle_scroll_limit: ['Прокруток без новых чатов', 'раз', 'После стольких пустых прокруток поиск завершается.'],
  action_delay_min: ['Случайная пауза: минимум', 'сек.', 'Нижняя граница паузы между действиями.'],
  action_delay_max: ['Случайная пауза: максимум', 'сек.', 'Верхняя граница паузы между действиями.'],
  typing_delay_min: ['Поиск и PIN: ввод минимум', 'сек./символ', 'Посимвольный ввод в поиске получателя и при разблокировке чатов.'],
  typing_delay_max: ['Поиск и PIN: ввод максимум', 'сек./символ', 'Верхняя граница задержки ввода.'],
  scroll_step_min: ['Случайный шаг: минимум', 'px', 'Минимальный шаг прокрутки списка чатов.'],
  scroll_step_max: ['Случайный шаг: максимум', 'px', 'Максимальный шаг прокрутки списка чатов.'],
  scroll_pause_min: ['Случайная пауза прокрутки: минимум', 'сек.', 'Нижняя граница паузы.'],
  scroll_pause_max: ['Случайная пауза прокрутки: максимум', 'сек.', 'Верхняя граница паузы.'],
}
export const tradeSpeedRows = (settings: Row) => [
  { prefix: '', values: settings }, { prefix: 'Хьюманизация · ', values: settings.humanization ?? {} },
].flatMap(({ prefix, values }) => Object.entries(values).filter(([key]) => key !== 'humanization' && key !== 'enabled').map(([key, value]) => ({
  id: prefix + key, name: prefix + (tradeSpeedLabels[key]?.[0] ?? key), value: number(value, 2), unit: tradeSpeedLabels[key]?.[1] ?? '',
})))
const integers = new Set(['scroll_step_pixels', 'login_poll_rounds', 'retries', 'group_scroll_limit', 'idle_scroll_limit'])
const positive = new Set(['scroll_step_pixels', 'login_poll_rounds', 'group_scroll_limit', 'idle_scroll_limit', 'scroll_step_min', 'scroll_step_max'])
function validate(draft: Row): { settings?: Row; error?: string } {
  const settings = structuredClone(draft)
  for (const section of [settings, settings.humanization]) {
    for (const key of Object.keys(section)) {
      if (!tradeSpeedLabels[key]) continue
      const raw = section[key], value = Number(raw)
      const min = positive.has(key) ? 1 : key.includes('timeout') ? .01 : 0
      if (raw === '' || !Number.isFinite(value) || value < min || (integers.has(key) && !Number.isInteger(value)))
        return { error: `«${tradeSpeedLabels[key][0]}»: укажите ${integers.has(key) ? 'целое ' : ''}число не меньше ${min}.` }
      section[key] = value
    }
  }
  if (settings.login_typing_delay_min > settings.login_typing_delay_max) return { error: 'Минимальная задержка ввода при входе превышает максимальную.' }
  for (const prefix of ['action_delay', 'typing_delay', 'scroll_step', 'scroll_pause'])
    if (settings.humanization[`${prefix}_min`] > settings.humanization[`${prefix}_max`]) return { error: 'Минимум хьюманизации не может превышать максимум.' }
  return { settings }
}

export function TradeSpeedSettings({ settings, defaults, presets, active, onSaved, onPending }: {
  settings: Row; defaults: Row; presets: Row[]; active: boolean; onSaved: (settings: Row) => void; onPending: (pending: boolean) => void
}) {
  const [draft, setDraft] = useState(() => structuredClone(settings))
  const [dirty, setDirty] = useState(false), [saving, setSaving] = useState(false), [error, setError] = useState('')
  const baseline = useRef(settings), revision = useRef(0), mounted = useRef(true)
  const savedCallback = useRef(onSaved); savedCallback.current = onSaved
  useEffect(() => { mounted.current = true; return () => { mounted.current = false } }, [])
  useEffect(() => { onPending(dirty || saving); return () => onPending(false) }, [dirty, saving, onPending])
  useEffect(() => {
    if (!dirty && !saving) { baseline.current = settings; setDraft(structuredClone(settings)) }
  }, [settings, dirty, saving])
  const valid = validate(draft)
  useEffect(() => {
    if (!dirty || saving || error || !valid.settings) return
    const snapshot = valid.settings, seq = revision.current
    const timer = window.setTimeout(async () => {
      setSaving(true)
      try {
        const result = await api('/trade/settings', { method: 'PUT', body: JSON.stringify({ settings: snapshot, previous: baseline.current }) })
        baseline.current = result.settings
        if (!mounted.current) return
        if (revision.current === seq) { setDraft(result.settings); setDirty(false) }
        savedCallback.current(result.settings)
      } catch (err) { if (mounted.current) setError((err as Error).message) }
      finally { if (mounted.current) setSaving(false) }
    }, 650)
    return () => window.clearTimeout(timer)
  }, [draft, dirty, saving, error])
  const edit = (next: Row) => { ++revision.current; setDraft(next); setDirty(true); setError('') }
  const fields = (keys: string[], human = false) => <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-3">{keys.map(key => {
    const values = human ? draft.humanization : draft, original = human ? defaults.humanization : defaults
    const id = `trade-speed-${human ? 'human-' : ''}${key}`
    return <div key={key}><div className="flex justify-between items-center gap-2 mb-2"><Label htmlFor={id} className="text-xs">{tradeSpeedLabels[key][0]}</Label><Button type="button" size="icon" variant="ghost" className="size-6 shrink-0" title={`Сбросить: ${tradeSpeedLabels[key][0]}`} onClick={() => edit(human ? { ...draft, humanization: { ...values, [key]: original[key] } } : { ...draft, [key]: original[key] })}><RotateCcw className="size-3" /></Button></div><div className="flex gap-2 items-center"><Input id={id} type="number" min={positive.has(key) ? 1 : key.includes('timeout') ? .01 : 0} step={integers.has(key) || key.startsWith('scroll_step') ? 1 : .05} value={values[key]} onChange={event => edit(human ? { ...draft, humanization: { ...values, [key]: event.target.value } } : { ...draft, [key]: event.target.value })} /><span className="text-xs text-muted-foreground shrink-0">{tradeSpeedLabels[key][1]}</span></div><p className="text-xs text-muted-foreground mt-2">{tradeSpeedLabels[key][2]}</p></div>
  })}</div>
  return <section aria-label="Настройки скорости Trade" className="space-y-3">
    <SpeedPresets title="Скорость Trade" presets={presets} draft={{ trade: draft }} labels={tradeSpeedLabels}
      description="Настройки независимы от автосбора. Таймауты, число проверок и полнота списка чатов задаются отдельно."
      footer="Режим меняет паузы и диапазоны хьюманизации, сохраняя её переключатель. Значения сохраняются автоматически и применяются при следующем запуске или продолжении Trade."
      onApply={preset => edit({ ...draft, ...preset.settings.trade, humanization: { ...draft.humanization, ...preset.settings.trade.humanization } })} />
    <Card><CardContent className="space-y-5 pt-5">
      <div className="flex flex-wrap gap-3 items-center"><p role="status" aria-label="Сохранение скорости Trade" className="text-sm flex-1">{saving ? 'Сохраняем скорость Trade…' : error ? 'Скорость Trade не сохранена' : dirty ? 'Ожидается сохранение скорости Trade…' : 'Скорость Trade сохранена'}</p><Button type="button" variant="outline" size="sm" onClick={() => edit(structuredClone(defaults))}>Исходная скорость Trade</Button></div>
      {active && <p className="text-xs text-muted-foreground">Текущий запуск использует зафиксированные значения. Чтобы применить новые, остановите Trade и продолжите его. Кнопка ручного подтверждения скорость не меняет.</p>}
      {(error || valid.error) && <Alert variant="destructive"><AlertDescription>{error || valid.error} Сохранённые настройки продолжают действовать.</AlertDescription></Alert>}
      {error && <div className="flex flex-wrap gap-2"><Button type="button" variant="outline" size="sm" disabled={saving} onClick={() => setError('')}>Повторить сохранение</Button><Button type="button" variant="outline" size="sm" disabled={saving} onClick={async () => { try { const latest = await api('/trade'); baseline.current = latest.speed_settings; setDraft(structuredClone(latest.speed_settings)); setDirty(false); setError(''); savedCallback.current(latest.speed_settings) } catch (err) { setError((err as Error).message) } }}>Загрузить сохранённые значения</Button></div>}
      {fields(['action_delay_seconds', 'counterparty_delay_seconds', 'group_delay_seconds', 'account_start_interval_seconds'])}
      <details><summary className="cursor-pointer py-3 text-sm font-medium">Загрузка и прокрутка чатов</summary>{fields(['load_wait_seconds', 'scroll_step_pixels', 'scroll_pause_seconds'])}</details>
      <details><summary className="cursor-pointer py-3 text-sm font-medium">Скорость входа в аккаунт</summary>{fields(['login_typing_delay_min', 'login_typing_delay_max', 'login_page_wait_seconds', 'login_step_wait_seconds'])}</details>
      <details><summary className="cursor-pointer py-3 text-sm font-medium">Хьюманизация Trade</summary><div className="flex items-center justify-between gap-4 border rounded-lg p-4 mb-5"><div><Label htmlFor="trade-speed-human-enabled">Включить хьюманизацию Trade</Label><p className="text-xs text-muted-foreground mt-1">Случайные паузы, посимвольный поиск и прокрутка в выбранных диапазонах.</p></div><Switch id="trade-speed-human-enabled" checked={draft.humanization.enabled} onCheckedChange={enabled => edit({ ...draft, humanization: { ...draft.humanization, enabled } })} /></div>{fields(Object.keys(defaults.humanization).filter(key => key !== 'enabled'), true)}</details>
      <details><summary className="cursor-pointer py-3 text-sm font-medium">Ожидание, повторные проверки и предел поиска чатов</summary><p className="text-xs text-muted-foreground mb-5">При любой скорости программа проверяет выбранный аккаунт и результат добавления. Слишком короткое ожидание может привести к ручной проверке. Приглашение с неизвестным результатом автоматически повторно не отправляется.</p>{fields(['login_poll_seconds', 'login_poll_rounds', 'retries', 'element_timeout_seconds', 'page_load_timeout_seconds', 'script_timeout_seconds', 'login_element_timeout_seconds', 'login_button_timeout_seconds', 'group_scroll_limit', 'idle_scroll_limit'])}</details>
    </CardContent></Card>
  </section>
}
