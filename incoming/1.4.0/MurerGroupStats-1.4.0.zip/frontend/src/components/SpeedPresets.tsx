import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { number, type Row } from '@/lib/api'

const leaves = (value: Row, path: string[] = []): { path: string[]; value: unknown }[] => Object.entries(value).flatMap(([key, item]) =>
  item && typeof item === 'object' ? leaves(item, [...path, key]) : [{ path: [...path, key], value: item }])
const at = (value: Row, path: string[]): any => path.reduce<any>((node, key) => node?.[key], value)

export function SpeedPresets({ presets, draft, labels, onApply, title = 'Скорость сбора', description = 'Объём данных, таймауты и число аккаунтов задаются отдельно.', footer = 'Профиль задаёт обычные задержки и диапазоны хьюманизации. Переключатель хьюманизации сохраняется: диапазоны применяются только при её включении. Изменения сохраняются автоматически и действуют со следующего запуска.' }: {
  presets: Row[]; draft: Row; labels: Record<string, [string, string, string]>; onApply: (preset: Row) => void; title?: string; description?: string; footer?: string
}) {
  const selected = presets.find(preset => leaves(preset.settings).every(({ path, value }) => at(draft, path) !== '' && Number(at(draft, path)) === value))
  return <Card><CardHeader><CardTitle className="text-base">{title}</CardTitle>
    <CardDescription>Текущий режим: <strong>{selected?.name ?? 'Ручные настройки'}</strong>. Любое значение ниже можно изменить. {description}</CardDescription>
  </CardHeader><CardContent className="space-y-4">
    <div className="flex flex-wrap gap-3">{presets.map(preset => <Button key={preset.id} type="button" variant={selected?.id === preset.id ? 'default' : 'outline'} onClick={() => onApply(preset)}>{preset.name}</Button>)}</div>
    <p className="text-xs text-muted-foreground">{footer}</p>
    <details className="speed-presets-table"><summary className="text-sm cursor-pointer font-medium">Все значения встроенных режимов</summary>
      <Table className="mt-3"><TableHeader><TableRow><TableHead>Параметр</TableHead>{presets.map(preset => <TableHead key={preset.id}>{preset.name}</TableHead>)}</TableRow></TableHeader>
        <TableBody>{leaves(presets[0]?.settings ?? {}).map(({ path }) => {
          const key = path[path.length - 1]
          return <TableRow key={path.join('-')}><TableCell className="text-xs">{path.includes('humanization') ? 'Хьюманизация · ' : ''}{labels[key]?.[0] ?? key} <span className="text-muted-foreground">({labels[key]?.[1] ?? ''})</span></TableCell>
            {presets.map(preset => <TableCell key={preset.id} className="text-xs tabular-nums">{number(at(preset.settings, path), 2)}</TableCell>)}</TableRow>
        })}</TableBody>
      </Table>
    </details>
  </CardContent></Card>
}
