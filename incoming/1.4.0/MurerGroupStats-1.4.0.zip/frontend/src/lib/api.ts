export type Row = Record<string, any>
export type Settings = {
  collection: Row
  humanization: Row
  trade: Row
  evaluation: Row & { weights: Record<string, number> }
  own_accounts: Row
}
export type Analysis = {
  summary: Row; groups: Row[]; participants: Row[]; overlaps: Row[]; account_overlaps: Row[];
  own_accounts: Row[]; recommendations: Row[]; coverage: Row; calculated_at?: string
}
export const emptyAnalysis: Analysis = { summary: {}, groups: [], participants: [], overlaps: [], account_overlaps: [], own_accounts: [], recommendations: [], coverage: {} }
export async function api<T = Row>(path: string, options?: RequestInit): Promise<T> {
  const response = await fetch(`/api${path}`, { ...options, headers: { 'Content-Type': 'application/json', ...options?.headers } })
  if (!response.ok) {
    const body = await response.json().catch(() => ({}))
    const detail = body.detail
    throw new Error(typeof detail === 'string' ? detail : Array.isArray(detail) ? detail.map((x: Row) => `${x.loc?.slice(1).join('.')}: ${x.msg}`).join('; ') : `Ошибка сервера (${response.status})`)
  }
  if (response.status === 204) return {} as T
  return response.json()
}
export function send<T = Row>(path: string, data?: unknown, method = 'POST') { return api<T>(path, { method, body: data === undefined ? undefined : JSON.stringify(data) }) }
export const metricValue = (value: unknown): unknown => value !== null && typeof value === 'object' && 'value' in value ? (value as Row).value : value
export const number = (value: unknown, digits = 0): string => {
  const numeric = metricValue(value)
  return numeric === null || numeric === undefined || numeric === '' || !Number.isFinite(Number(numeric)) ? '—' : new Intl.NumberFormat('ru-RU', { maximumFractionDigits: digits }).format(Number(numeric))
}
export const approximateNumber = (value: unknown, approximate = false): string => `${approximate || Boolean(value && typeof value === 'object' && (value as Row).approximate) ? '≈ ' : ''}${number(value)}`
export const percent = (value: unknown): string => value === null || value === undefined ? '—' : `${number(value, 1)}%`
export const date = (value: unknown): string => {
  const parsed = value ? new Date(String(value)) : null
  return parsed && Number.isFinite(parsed.getTime()) ? parsed.toLocaleString('ru-RU', { timeZone: 'Europe/Kiev', dateStyle: 'short', timeStyle: 'short' }) : '—'
}
export const statusText: Record<string, string> = { trade: 'Trade', yielding_trade: 'Уступает очередь Trade', suspended_trade: 'Пауза на время Trade', requires_manual: 'Требуется ручное действие', session_expired: 'Сессия истекла', full: 'Полный', stopping: 'Остановка', unauthenticated: 'Не авторизован', not_authorized: 'Не авторизован', idle: 'Не авторизован', logging_in: 'Вход', login: 'Вход', active: 'Активен', manual_required: 'Требуется ручное действие', manual: 'Требуется ручное действие', proxy_error: 'Ошибка прокси', expired: 'Сессия истекла', collecting: 'Сбор', running: 'Выполняется', queued: 'В очереди', paused: 'Пауза', error: 'Ошибка', failed: 'Ошибка', completed: 'Завершён', complete: 'Полный', partial: 'Частичный', unavailable: 'Недоступен', stale: 'Устарел', stopped: 'Остановлен', interrupted: 'Прерван', unknown: 'Неизвестно' }

