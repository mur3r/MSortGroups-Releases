"""Shared discovery/scroll geometry; a stopped network request is not an end."""
CHAT_SCROLLER_JS = r"""
function chatScroller() {
 const visible=e=>e&&e.clientHeight>0&&(e.offsetWidth||e.getClientRects().length);
 const root=deepQuery('[data-testid="dm-conversation-scroller"]');
 if(visible(root)) {
  if(root.scrollHeight>root.clientHeight+4)return root;
  const nested=deepQueryAll('*',root).filter(e=>visible(e)&&/(auto|scroll)/.test(getComputedStyle(e).overflowY)&&e.scrollHeight>e.clientHeight+4);
  return nested.sort((a,b)=>b.scrollHeight-a.scrollHeight)[0]||root;
 }
 const anchors=deepQueryAll("a[href*='/i/chat/']").filter(visible);
 const last=anchors[anchors.length-1];
 let node=last?.parentElement||last?.getRootNode()?.host;
 while(node&&node!==document.body) {
  if(visible(node)&&/(auto|scroll)/.test(getComputedStyle(node).overflowY))return node;
  node=node.parentElement||node.getRootNode()?.host;
 }
 return null;
}
"""
