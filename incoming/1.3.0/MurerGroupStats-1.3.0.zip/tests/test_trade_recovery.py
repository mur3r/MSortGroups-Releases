"""Regression coverage of interrupted invitations and account lifecycle."""
from datetime import datetime, timedelta, timezone
import unittest

from tests import test_trade as fixture
from murer.storage import utcnow
from murer.trade_browser import TradeSession


class TradeRecoveryTests(unittest.TestCase):
    setUp = fixture.TradeTests.setUp
    wait = fixture.TradeTests.wait
    preview = fixture.TradeTests.preview
    start = fixture.TradeTests.start
    finished = fixture.TradeTests.finished

    def cancel_if_running(self, rid):
        if self.state.trades.threads[rid].is_alive():
            self.state.trades.command(rid,'stop')
            self.state.trades.threads[rid].join(10)

    def interactive_factory(self, *, exception=False):
        original = self.state.trades.session_factory
        def factory(*args):
            browser = original(*args)
            async def invite(group, target, before_send):
                before_send()
                self.scenario.invites.append((group['id'], target))
                if exception:
                    raise RuntimeError('Synthetic lost response after click')
                return TradeSession._invitation_manual('Synthetic pending invitation')
            browser.invite = invite
            browser._invitation_manual = TradeSession._invitation_manual
            return browser
        self.state.trades.session_factory = factory

    def test_pending_invitation_keeps_sender_open_and_continue_only_verifies(self):
        self.interactive_factory()
        self.scenario.verify_status='uncertain'
        plan = self.preview()
        rid = self.start(plan)
        self.addCleanup(self.cancel_if_running,rid)
        self.wait(lambda:self.state.trades.run(rid)['status']=='requires_manual')
        self.assertEqual(self.state.trades.run(rid)['progress']['manual_kind'],'invitation')
        self.assertEqual(self.scenario.trade_open,1)
        self.assertEqual(len(self.scenario.invites),1)
        self.assertEqual(self.state.trades.run(rid)['items'][0]['status'],'sending')
        self.client.post(f'/api/trade/runs/{rid}/command/continue')
        self.wait(lambda:self.state.trades.controls[rid].manual_generation==1 and
                  self.state.trades.run(rid)['progress'].get('manual_reason','').startswith('Добавление всё ещё'))
        self.assertEqual(self.scenario.trade_open,1)
        self.assertEqual(len(self.scenario.invites),1)
        self.scenario.verify_status='confirmed'
        self.client.post(f'/api/trade/runs/{rid}/command/continue')
        result=self.finished(rid)
        self.assertEqual(result['confirmed_count'],1)
        self.assertEqual(self.scenario.continued_pin,None,'Invitation confirmation must not trigger login')
        self.assertEqual(len(self.scenario.invites),1)

    def test_stop_during_manual_invitation_preserves_uncertain_attempt(self):
        self.interactive_factory()
        rid=self.start(self.preview())
        self.addCleanup(self.cancel_if_running,rid)
        self.wait(lambda:self.state.trades.run(rid)['status']=='requires_manual')
        self.client.post(f'/api/trade/runs/{rid}/command/stop')
        result=self.finished(rid)
        self.assertEqual(result['status'],'stopped')
        self.assertEqual(result['items'][0]['status'],'uncertain')
        self.assertEqual(result['confirmed_count'],0)
        self.assertEqual(len(self.scenario.invites),1)

    def test_exception_after_intent_does_not_close_sender_or_resend(self):
        self.interactive_factory(exception=True)
        rid=self.start(self.preview())
        self.addCleanup(self.cancel_if_running,rid)
        self.wait(lambda:self.state.trades.run(rid)['status']=='requires_manual')
        self.assertEqual(self.scenario.trade_open,1)
        self.assertEqual(len(self.scenario.invites),1)
        self.client.post(f'/api/trade/runs/{rid}/command/continue')
        self.assertEqual(self.finished(rid)['confirmed_count'],1)
        self.assertEqual(len(self.scenario.invites),1)

    def test_transient_failure_before_intent_retries_same_sender(self):
        settings,_=self.state.store.settings()
        settings['trade'].update(retries=1,login_poll_seconds=0)
        self.state.store.save_settings(settings)
        original=self.state.trades.session_factory
        calls=[]
        def factory(*args):
            browser=original(*args)
            invite=browser.invite
            async def transient(group,target,before_send):
                calls.append(group['id'])
                if len(calls)==1:
                    return {'status':'error','retryable':True,'reason':'Synthetic delayed search'}
                return await invite(group,target,before_send)
            browser.invite=transient
            return browser
        self.state.trades.session_factory=factory
        result=self.finished(self.start(self.preview()))
        self.assertEqual(result['confirmed_count'],1)
        self.assertEqual(calls[0],calls[1])
        self.assertEqual(len(self.scenario.invites),1)
        self.assertEqual(self.state.store.rows('SELECT * FROM trade_capabilities WHERE state=?',('unavailable',)),[])

    def test_resume_reconciles_old_attempt_before_any_new_invitation(self):
        self.scenario.uncertain=True
        plan=self.preview(count=2)
        self.finished(self.start(plan))
        self.scenario.uncertain=False
        result=self.finished(self.start(plan))
        self.assertEqual(result['confirmed_count'],1)
        self.assertEqual(len(self.scenario.invites),1,'Resume must reconcile instead of blindly resending')
        self.assertEqual(result['status'],'awaiting_review')
        result=self.finished(self.start(plan))
        self.assertEqual(result['confirmed_count'],2)
        self.assertEqual(len(set(self.scenario.invites)),2)

    def test_stale_or_invalid_capability_does_not_permanently_block_group(self):
        gid=self.state.store.upsert_group(self.scenario.stats.groups[0],self.owner['id'])
        for observed_at in ((datetime.now(timezone.utc)-timedelta(minutes=16)).isoformat(),'invalid'):
            self.state.store.execute('INSERT OR REPLACE INTO trade_capabilities VALUES(?,?,?,?,?)',
                (gid,self.owner['id'],'unavailable','Synthetic transient missing button',observed_at))
            self.assertIn(gid,[g['id'] for g in self.preview()['plan']['groups']])
        self.state.store.execute('UPDATE trade_capabilities SET observed_at=?',(utcnow(),))
        self.assertNotIn(gid,[g['id'] for g in self.preview()['plan']['groups']])

    def test_known_sender_is_opened_once_and_never_preopened_to_scan(self):
        plan=self.preview(receive_account_id=self.second['id'])
        result=self.finished(self.start(plan))
        self.assertEqual(result['confirmed_count'],1)
        self.assertEqual(self.scenario.login_accounts,['secondowner','owner','secondowner'])
        self.assertNotIn('owner',self.scenario.discovery_accounts)


if __name__=='__main__':
    unittest.main()
