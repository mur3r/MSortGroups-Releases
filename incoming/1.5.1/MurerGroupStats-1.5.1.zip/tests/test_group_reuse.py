"""The same complete group roster is read once across a collection job."""
import unittest
from tests import test_storage_api as fixture


class GroupReuseTests(unittest.TestCase):
    setUp=fixture.StorageApiTests.setUp
    unblock=fixture.StorageApiTests.unblock
    account=fixture.StorageApiTests.account
    job=fixture.StorageApiTests.job
    wait_until=fixture.StorageApiTests.wait_until
    finished=fixture.StorageApiTests.finished

    def test_shared_groups_are_not_reopened_by_parallel_accounts(self):
        accounts=[self.account('owner'),self.account('secondowner')]
        settings,_=self.state.store.settings()
        settings['collection']['concurrent_accounts']=2
        self.state.store.save_settings(settings)
        self.finished(self.job(accounts))
        self.assertEqual(self.scenario.count('members'),2)
        for account in accounts:
            self.assertEqual(len(self.state.store.rows('SELECT * FROM account_groups WHERE account_id=? AND present=1',(account['id'],))),2)

    def test_partial_first_roster_does_not_block_another_account(self):
        factory=self.state.jobs.session_factory
        def partial(*args):
            session=factory(*args)
            original=session.members
            async def members(group):
                value=await original(group)
                if session.username=='owner':
                    value['status']='partial'
                return value
            session.members=members
            return session
        self.state.jobs.session_factory=partial
        self.finished(self.job([self.account('owner'),self.account('secondowner')]))
        self.assertEqual(self.scenario.count('members'),4)


if __name__=='__main__':
    unittest.main()
