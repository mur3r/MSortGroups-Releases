import asyncio
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

from xgenius.accounts import AccountManager
from xgenius.collectors.groups import GroupCollector
from xgenius.config import Config
from xgenius.models import AccountCredentials
from xgenius.cookies import save_cookies, load_cookies
from xgenius.core.network import ConnectionFailure
from selenium.common.exceptions import WebDriverException


class FoundationTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.config = Config(Path(self.temp.name))
        self.manager = AccountManager(self.config, MagicMock())
        self.browser = MagicMock()
        self.manager.browser_manager.create_browser = AsyncMock(return_value=self.browser)
        self.manager._finalize_login = AsyncMock()
        self.manager._login_with_tokens = AsyncMock()
        self.manager._perform_login = AsyncMock()
        self.credentials = AccountCredentials('example', 'placeholder', auth_token='placeholder')

    async def run_login(self, checks, **kwargs):
        self.manager._is_logged_in = AsyncMock(side_effect=checks)
        with patch('xgenius.accounts.auth.load_cookies'), patch('xgenius.accounts.auth.asyncio.sleep', new_callable=AsyncMock):
            await self.manager.login_account(self.credentials, **kwargs)

    async def test_saved_session_precedes_tokens_and_password(self):
        await self.run_login([True])
        self.manager._login_with_tokens.assert_not_awaited()
        self.manager._perform_login.assert_not_awaited()
        self.assertEqual(self.manager._finalize_login.await_args.args[3], 'cookies')

    async def test_expired_proxy_stops_before_token_or_password_fallback(self):
        self.credentials.proxy='http://127.0.0.1:9999'
        self.browser.get.side_effect=WebDriverException('net::ERR_PROXY_CONNECTION_FAILED')
        with self.assertRaises(ConnectionFailure) as failure:
            await self.run_login([False])
        self.assertEqual(failure.exception.result['status'],'proxy_error')
        self.manager._login_with_tokens.assert_not_awaited()
        self.manager._perform_login.assert_not_awaited()

    async def test_chrome_error_document_stops_before_auth_checks(self):
        self.credentials.proxy='http://127.0.0.1:9999'
        self.browser.execute_script.return_value='ERR_TUNNEL_CONNECTION_FAILED'
        with self.assertRaises(ConnectionFailure):
            await self.run_login([False])
        self.manager._is_logged_in.assert_not_awaited()

    async def test_tokens_precede_password(self):
        await self.run_login([False, True])
        self.manager._login_with_tokens.assert_awaited_once()
        self.manager._perform_login.assert_not_awaited()
        self.assertEqual(self.manager._finalize_login.await_args.args[3], 'tokens')

    async def test_password_fallback(self):
        await self.run_login([False, False, True])
        self.manager._perform_login.assert_awaited_once()
        self.assertEqual(self.manager._finalize_login.await_args.args[3], 'password')

    async def test_missing_password_reports_failure(self):
        self.credentials.password = ''
        with self.assertRaisesRegex(Exception, 'пароля нет'):
            await self.run_login([False, False])
        self.assertFalse(self.manager.accounts['example'].is_active)

    async def test_automatic_failure_closes_browser(self):
        self.credentials.password = ''
        with patch('xgenius.accounts.auth.hard_close_browser') as close:
            with self.assertRaises(Exception):
                await self.run_login([False, False], notify=False)
            close.assert_called_once_with(self.browser)
        self.assertIsNone(self.manager.accounts['example'].browser)

    async def test_fixed_methods_belong_to_class(self):
        for name in ('_accept_cookies', '_perform_login', '_check_login_locks', '_login_with_tokens', 'auto_relogin_if_needed'):
            self.assertTrue(asyncio.iscoroutinefunction(getattr(AccountManager, name)))
        self.assertTrue(asyncio.iscoroutinefunction(GroupCollector.find_groups))

    async def test_cookie_roundtrip_filters_unrelated_domains(self):
        self.browser.get_cookies.return_value = [
            {'name':'auth_token','value':'placeholder','domain':'.x.com','path':'/'},
            {'name':'other','value':'placeholder','domain':'.example.org','path':'/'},
        ]
        save_cookies(self.browser, self.config, 'example')
        load_cookies(self.browser, self.config, 'example')
        self.browser.get.assert_called_with('https://x.com')
        self.browser.add_cookie.assert_called_once()
        self.assertEqual(self.browser.add_cookie.call_args.args[0]['name'], 'auth_token')

    async def test_account_storage_roundtrip(self):
        data=[{'username':'example','password':'','auth_token':'placeholder'}]
        self.manager.save_accounts(data)
        self.assertEqual(self.manager.load_accounts(),data)

if __name__ == '__main__':
    unittest.main()
