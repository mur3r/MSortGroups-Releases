"""Two-phase contract, no writes before subscription preflight, recovery."""
import unittest

from tests import test_trade as fixture


class PreparationTests(unittest.TestCase):
    setUp = fixture.TradeTests.setUp
    preview = fixture.TradeTests.preview
    wait = fixture.TradeTests.wait
    finished = fixture.TradeTests.finished

    def prepare(self, plan):
        response=self.client.post('/api/trade/runs/'+plan['id']+'/prepare')
        self.assertEqual(response.status_code,200,response.text)
        return self.finished(plan['id'])

    def execute(self, plan):
        current=self.state.trades.run(plan['id'])
        response=self.client.post('/api/trade/runs/'+plan['id']+'/start',json={'preparation_id':current['plan']['preparation']['id']})
        self.assertEqual(response.status_code,200,response.text)
        return self.finished(plan['id'])

    def test_cannot_start_without_preparation(self):
        plan=self.preview()
        self.assertEqual(self.client.post('/api/trade/runs/'+plan['id']+'/start',json={}).status_code,422)
        self.assertFalse(self.scenario.invites)

    def test_prepare_freezes_exact_groups_ids_and_links_without_following_or_inviting(self):
        plan=self.prepare(self.preview(count=2))
        prep=plan['plan']['preparation']
        self.assertEqual(plan['status'],'prepared')
        self.assertEqual(len(prep['assignments']),2)
        self.assertEqual(prep['identities']['partner']['x_id'],'42')
        self.assertEqual(prep['required_accounts'][0]['url'],'https://x.com/owner')
        self.assertFalse(self.scenario.follow_calls)
        self.assertFalse(self.scenario.invites)
        self.assertIsNone(self.state.jobs.priority_owner)
        self.assertEqual(self.execute(plan)['confirmed_count'],2)

    def test_all_reverse_follows_are_checked_before_first_invitation(self):
        for group in self.scenario.stats.groups:
            self.state.store.upsert_group(group,self.second['id'])
        self.scenario.group_lists['owner']=[self.scenario.stats.groups[0]]
        self.scenario.group_lists['secondowner']=[self.scenario.stats.groups[1]]
        plan=self.prepare(self.preview(sender_mode='auto',count=2))
        self.assertEqual(len(plan['plan']['preparation']['required_accounts']),2)
        self.scenario.blocked_accounts.add(('secondowner','partner'))
        blocked=self.execute(plan)
        self.assertEqual(blocked['status'],'awaiting_subscriptions')
        self.assertFalse(self.scenario.invites)
        self.assertFalse(self.scenario.follow_calls)
        self.scenario.blocked_accounts.clear()
        self.assertEqual(self.execute(plan)['confirmed_count'],2)

    def test_known_but_outdated_account_list_is_refreshed(self):
        extra={'x_id':'g777','name':'Third group','url':'https://x.com/i/chat/g777'}
        self.scenario.group_lists['owner']=[*self.scenario.stats.groups,extra]
        plan=self.prepare(self.preview(sender_mode='auto',count=3))
        self.assertEqual(len(plan['plan']['preparation']['assignments']),3)
        self.assertIn('owner',self.scenario.discovery_accounts)

    def test_shared_groups_are_inspected_once_even_when_unavailable_or_already_member(self):
        for group in self.scenario.stats.groups:
            self.state.store.upsert_group(group,self.second['id'])
        rows=self.state.store.rows('SELECT id FROM groups ORDER BY x_id')
        self.scenario.unavailable.add(rows[0]['id'])
        self.scenario.already.add((rows[1]['id'],'partner'))
        plan=self.prepare(self.preview(sender_mode='auto',count=3))
        self.assertEqual(plan['status'],'preparation_shortage')
        self.assertEqual(len(self.scenario.inspections),2)
        self.assertEqual(len({(group,name) for _,group,name in self.scenario.inspections}),2)
        self.assertEqual(len(plan['plan']['preparation_checks']),2)

    def test_same_link_with_legacy_different_ids_is_never_reopened_on_next_source(self):
        from murer.trade_planning import group_key
        shared=self.scenario.stats.groups[0]
        duplicate={**shared,'x_id':'gLegacy','url':shared['url']+'/?source=legacy#top'}
        self.scenario.group_lists['owner']=[shared]
        self.scenario.group_lists['secondowner']=[duplicate]
        plan=self.prepare(self.preview(sender_mode='auto',count=3))
        self.assertEqual(len(self.scenario.inspections),1)
        self.assertEqual(len(plan['plan']['preparation']['assignments']),1)
        self.assertEqual(group_key(shared),group_key(duplicate))

    def test_known_exact_membership_is_remembered_in_later_preparations(self):
        row=self.state.store.rows('SELECT id FROM groups ORDER BY x_id')[0]
        self.scenario.already.add((row['id'],'partner'))
        plan=self.prepare(self.preview(count=3))
        self.scenario.inspections.clear()
        self.prepare(plan)
        self.assertNotIn(row['id'],[gid for _,gid,_ in self.scenario.inspections])

    def test_recent_exact_candidate_is_reused_after_preparation_retry_but_checked_before_sending(self):
        plan=self.prepare(self.preview(count=2))
        self.scenario.inspections.clear()
        plan=self.prepare(plan)
        self.assertFalse(self.scenario.inspections)
        self.assertEqual(self.execute(plan)['confirmed_count'],2)
        self.assertEqual(len(self.scenario.inspections),2)

    def test_expired_candidate_observation_is_refreshed(self):
        from datetime import datetime,timedelta,timezone
        plan=self.prepare(self.preview(count=2))
        for check in plan['plan']['preparation_checks']:
            check['checked_at']=(datetime.now(timezone.utc)-timedelta(minutes=16)).isoformat()
        self.state.trades.update(plan['id'],plan=plan['plan'])
        self.scenario.inspections.clear()
        self.prepare(plan)
        self.assertEqual(len(self.scenario.inspections),2)

    def test_shared_group_is_checked_separately_for_different_recipient_ids(self):
        for group in self.scenario.stats.groups:
            self.state.store.upsert_group(group,self.second['id'])
        self.prepare(self.preview(sender_mode='auto',count=3,recipients=['partner','another']))
        self.assertEqual(len(self.scenario.inspections),4)
        self.assertEqual({name for _,_,name in self.scenario.inspections},{'partner','another'})

    def test_proxy_failure_after_intent_never_retries_invitation_and_retains_uncertainty(self):
        from selenium.common.exceptions import WebDriverException
        plan=self.prepare(self.preview())
        factory=self.state.trades.session_factory
        def broken(*args):
            browser=factory(*args)
            async def invite(group,name,before_send):
                self.scenario.invites.append((group['id'],name))
                before_send()
                raise WebDriverException('net::ERR_PROXY_CONNECTION_FAILED')
            browser.invite=invite
            return browser
        self.state.trades.session_factory=broken
        result=self.execute(plan)
        self.assertEqual(len(self.scenario.invites),1)
        self.assertEqual(result['items'][0]['status'],'uncertain')
        self.assertEqual(self.state.store.account(self.owner['id'])['status'],'proxy_error')

    def test_proxy_break_during_discovery_marks_account_and_keeps_saved_groups(self):
        factory=self.state.trades.session_factory
        def broken(*args):
            browser=factory(*args)
            discover=browser.discover_groups
            async def discovery(credentials):
                if credentials.username=='secondowner':
                    return {'status':'proxy_error','reason':'Synthetic expired proxy'}
                return await discover(credentials)
            browser.discover_groups=discovery
            return browser
        self.state.trades.session_factory=broken
        for group in self.scenario.stats.groups:
            self.state.store.upsert_group(group,self.second['id'])
        plan=self.prepare(self.preview(sender_mode='auto',count=3))
        self.assertEqual(self.state.store.account(self.second['id'])['status'],'proxy_error')
        self.assertEqual(len(self.state.store.rows('SELECT * FROM account_groups WHERE account_id=? AND present=1',(self.second['id'],))),2)
        self.assertFalse(self.scenario.invites)

    def test_insufficient_groups_cannot_start_or_send_a_partial_contract(self):
        self.scenario.group_lists['secondowner']=[]
        plan=self.prepare(self.preview(count=3))
        self.assertEqual(plan['status'],'preparation_shortage')
        self.assertFalse(plan['can_start'])
        self.assertFalse(self.scenario.invites)
        self.assertFalse(self.scenario.follow_calls)

    def test_changed_membership_invalidates_plan_without_silent_replacement(self):
        plan=self.prepare(self.preview())
        group=plan['plan']['preparation']['assignments'][0]
        self.scenario.already.add((group['id'],'partner'))
        result=self.execute(plan)
        self.assertEqual(result['status'],'preparation_blocked')
        self.assertFalse(result['can_start'])
        self.assertFalse(self.scenario.invites)

    def test_stop_while_waiting_is_resumable(self):
        plan=self.prepare(self.preview())
        self.scenario.blocked.add('partner')
        self.execute(plan)
        response=self.client.post('/api/trade/runs/'+plan['id']+'/command/stop')
        self.assertEqual(response.json()['status'],'stopped')
        self.scenario.blocked.clear()
        self.assertEqual(self.execute(plan)['confirmed_count'],1)

    def test_new_trade_with_incomplete_baseline_sends_nothing_and_can_retry(self):
        self.scenario.incoming_complete=False
        plan=self.prepare(self.preview())
        self.assertEqual(plan['status'],'preparation_blocked')
        self.assertFalse(self.scenario.invites)
        self.scenario.incoming_complete=True
        plan=self.prepare(plan)
        self.assertEqual(plan['status'],'prepared')
        self.assertTrue(plan['baseline']['complete'])

    def test_stale_or_absent_preparation_id_is_rejected(self):
        plan=self.prepare(self.preview())
        for value in (None,'wrong'):
            result=self.client.post('/api/trade/runs/'+plan['id']+'/start',json={'preparation_id':value})
            self.assertEqual(result.status_code,422)
        self.assertFalse(self.scenario.invites)

    def test_twenty_groups_are_selected_before_links_and_no_extra_source_is_used(self):
        receiver=self.client.post('/api/accounts',json={'username':'receiver'}).json()
        self.scenario.group_lists['receiver']=[]
        self.scenario.group_lists['owner']=[{'x_id':'gA'+str(i),'name':'Group A '+str(i),'url':'https://x.com/i/chat/gA'+str(i)} for i in range(13)]
        self.scenario.group_lists['secondowner']=[{'x_id':'gB'+str(i),'name':'Group B '+str(i),'url':'https://x.com/i/chat/gB'+str(i)} for i in range(7)]
        plan=self.prepare(self.preview(receive_account_id=receiver['id'],sender_mode='auto',count=20))
        preparation=plan['plan']['preparation']
        self.assertEqual(len(preparation['assignments']),20)
        self.assertEqual({s['url'] for s in preparation['required_accounts']},{'https://x.com/owner','https://x.com/secondowner'})
        self.assertFalse(self.scenario.invites)
        self.assertFalse(self.scenario.follow_calls)
        result=self.execute(plan)
        self.assertEqual(result['confirmed_count'],20)
        self.assertEqual({i['group_id'] for i in result['confirmed']},{g['id'] for g in preparation['assignments']})

    def test_closed_unknown_can_be_verified_and_no_longer_blocks_a_future_trade(self):
        self.scenario.incoming_extra=0
        plan=self.prepare(self.preview())
        self.scenario.uncertain=True
        first=self.execute(plan)
        self.assertEqual(first['status'],'awaiting_review')
        self.state.trades.finish(plan['id'],accept_unverified=True)
        self.scenario.uncertain=False
        self.scenario.verify_status='not_added'
        response=self.client.post('/api/trade/runs/'+plan['id']+'/start',json={'verify_only':True})
        self.assertEqual(response.status_code,200,response.text)
        checked=self.finished(plan['id'])
        self.assertEqual(checked['status'],'closed_unverified')
        self.assertEqual(checked['items'][0]['status'],'not_added')
        new=self.prepare(self.preview(count=2))
        self.assertEqual(len(new['plan']['preparation']['assignments']),2)

    def test_preparation_can_reconcile_old_closed_intent_without_resending_it(self):
        self.scenario.incoming_extra=0
        old=self.prepare(self.preview())
        self.scenario.uncertain=True
        self.execute(old)
        self.state.trades.finish(old['id'],accept_unverified=True)
        self.scenario.uncertain=False
        calls=len(self.scenario.invites)
        new=self.prepare(self.preview(count=2))
        self.assertEqual(len(self.scenario.invites),calls)
        self.assertEqual(len(new['plan']['preparation']['assignments']),2)
        self.assertEqual(self.state.trades.run(old['id'])['items'][0]['status'],'not_added')

    def test_changed_id_aborts_before_first_invite(self):
        plan=self.prepare(self.preview())
        factory=self.state.trades.session_factory
        def changed(*args):
            browser=factory(*args)
            original=browser.relationship
            async def relationship(name):
                return {**await original(name),'x_id':'999'}
            browser.relationship=relationship
            return browser
        self.state.trades.session_factory=changed
        self.assertEqual(self.execute(plan)['status'],'preparation_blocked')
        self.assertFalse(self.scenario.invites)
        self.assertFalse(self.scenario.follow_calls)

    def test_picker_can_be_conditional_until_our_follow_after_reverse_preflight(self):
        self.scenario.require_follow=True
        factory=self.state.trades.session_factory
        def conditional(*args):
            browser=factory(*args)
            inspect=browser.inspect_candidate
            async def candidate(group,name):
                return {**await inspect(group,name),'invitation_ready':(browser.username,name) in self.scenario.following}
            browser.inspect_candidate=candidate
            return browser
        self.state.trades.session_factory=conditional
        plan=self.prepare(self.preview())
        self.assertEqual(plan['status'],'prepared')
        self.assertFalse(plan['plan']['preparation']['assignments'][0]['invitation_ready'])
        self.assertFalse(self.scenario.follow_calls)
        self.assertEqual(self.execute(plan)['confirmed_count'],1)

    def test_temporary_missing_profile_id_keeps_plan_for_retry_without_inviting(self):
        plan=self.prepare(self.preview())
        factory=self.state.trades.session_factory
        def missing(*args):
            browser=factory(*args)
            original=browser.relationship
            async def relationship(name):
                return {**await original(name),'x_id':None}
            browser.relationship=relationship
            return browser
        self.state.trades.session_factory=missing
        blocked=self.execute(plan)
        self.assertEqual(blocked['status'],'awaiting_review')
        self.assertTrue(blocked['can_start'])
        self.assertFalse(self.scenario.invites)
        self.state.trades.session_factory=factory
        self.assertEqual(self.execute(plan)['confirmed_count'],1)

    def test_legacy_partial_incoming_has_explicit_manual_confirmation_without_rebasing(self):
        from murer.storage import encode,utcnow
        plan=self.prepare(self.preview())
        result=self.execute(plan)
        baseline={**result['baseline'],'complete':False,'reason':'Legacy incomplete scan'}
        incoming={**result['incoming'],'sufficient_confirmed':False,'verdict':'preliminary'}
        self.state.store.execute('UPDATE trade_runs SET baseline=?,incoming=? WHERE id=?',(encode(baseline),encode(incoming),plan['id']))
        for value in (False,1):
            response=self.client.post('/api/trade/runs/'+plan['id']+'/confirm-incoming',json={'acknowledgement':value})
            self.assertEqual(response.status_code,422)
        response=self.client.post('/api/trade/runs/'+plan['id']+'/confirm-incoming',json={'acknowledgement':True})
        self.assertEqual(response.status_code,200,response.text)
        self.assertFalse(response.json()['baseline']['complete'])
        self.assertTrue(response.json()['can_finish'])
        self.assertEqual(self.state.trades.finish(plan['id'])['status'],'completed')


if __name__=='__main__':
    unittest.main()
