"""Real Chrome with local synthetic setup forms; no X network requests."""
import argparse
import asyncio
import json
from pathlib import Path
import sys
import tempfile
from selenium import webdriver
from selenium.webdriver.chrome.service import Service

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from murer.ichat_setup import IChatSetup,ICHAT_SETUP_PROBE_JS
from murer.safe_actions import SafeActions
from murer.rules import default_settings


async def run(chrome,driver):
    checks=[]
    with tempfile.TemporaryDirectory() as folder:
        options=webdriver.ChromeOptions();options.binary_location=chrome
        options.add_argument('--headless=new');options.add_argument('--user-data-dir='+folder)
        browser=webdriver.Chrome(service=Service(driver),options=options)
        try:
            browser.get((ROOT/'tests/fixtures/ichat-unlock.html').as_uri())
            assert browser.execute_script(ICHAT_SETUP_PROBE_JS)['state']=='absent'
            checks.append('production_origin_guard')
            synthetic=ICHAT_SETUP_PROBE_JS.replace('const pageUrl=new URL(location.href);',"const pageUrl=new URL('https://x.com/i/chat');")
            settings=default_settings();settings['collection'].update(action_delay_seconds=0,login_poll_rounds=2,login_poll_seconds=.01)
            actions=SafeActions(browser,settings)
            script=actions.script
            async def fixture_script(code,*args):
                return await script(synthetic if code==ICHAT_SETUP_PROBE_JS else code,*args)
            actions.script=fixture_script
            def markup(value):
                browser.execute_script("window.setupValues=[];window.setupClicks=0;document.querySelector('[data-testid=xchatEmbedRoute]').shadowRoot.innerHTML=arguments[0]",value)
            paired='<form><h2>Create your passcode</h2><input type=password autocomplete=new-password><input type=password name=confirm_password autocomplete=new-password><button type=button>Create</button></form>'
            markup(paired)
            assert (await IChatSetup().check(actions,'1234',False))['status']=='requires_manual'
            assert browser.execute_script("return Array.from(document.querySelector('[data-testid=xchatEmbedRoute]').shadowRoot.querySelectorAll('input')).every(e=>!e.value)")
            checks.append('disabled_toggle_never_types')
            browser.execute_script("const root=document.querySelector('[data-testid=xchatEmbedRoute]').shadowRoot;root.querySelector('button').onclick=()=>{window.setupClicks++;window.setupValues=Array.from(root.querySelectorAll('input')).map(e=>e.value);root.innerHTML='<h2>Chats</h2>'}")
            assert await IChatSetup().check(actions,'fixture-passcode',True) is None
            assert browser.execute_script('return window.setupValues')==['fixture-passcode']*2
            checks.append('paired_password_and_confirmation')
            markup('<form><div data-testid=pin-title>Create passcode</div><input type=password autocomplete=new-password><button type=button>Continue</button></form>')
            browser.execute_script("""const root=document.querySelector('[data-testid=xchatEmbedRoute]').shadowRoot;
root.querySelector('button').onclick=()=>{window.setupValues.push(root.querySelector('input').value);root.innerHTML='<form><h2>Confirm your passcode</h2><input type=password name=confirm_password autocomplete=new-password><button type=button>Confirm</button></form>';root.querySelector('button').onclick=()=>{window.setupValues.push(root.querySelector('input').value);root.innerHTML='<h2>Chats</h2>'}};""")
            assert await IChatSetup().check(actions,'1234',True) is None
            assert browser.execute_script('return window.setupValues')==['1234']*2
            checks.append('sequential_create_then_confirm')
            markup('<h2>Chats</h2>')
            browser.execute_script("""const root=document.querySelector('[data-testid=xchatEmbedRoute]').shadowRoot;
window.showSetupStep=confirm=>{root.innerHTML='<form><div data-testid=pin-title>'+(confirm?'Confirm your passcode':'Create your passcode')+'</div>'+Array.from({length:4},()=>'<input type=text inputmode=numeric maxlength=1 aria-label="PIN digit">').join('')+'</form>';root.querySelectorAll('input').forEach(e=>e.addEventListener('input',()=>{const fields=Array.from(root.querySelectorAll('input'));if(fields.every(e=>e.value)){window.setupValues.push(fields.map(e=>e.value).join(''));if(confirm)root.innerHTML='<h2>Chats</h2>';else window.showSetupStep(true)}}))};window.showSetupStep(false);""")
            assert await IChatSetup().check(actions,'1234',True) is None
            assert browser.execute_script('return window.setupValues')==['1234']*2
            checks.append('segmented_pin_autoadvance_twice')
            for title in ('Reset passcode','Recover your PIN','Enter verification code'):
                markup('<form><h2>'+title+'</h2><input type=password><button>Continue</button></form>')
                await IChatSetup().check(actions,'never-enter',True)
                assert browser.execute_script("return document.querySelector('[data-testid=xchatEmbedRoute]').shadowRoot.querySelector('input').value")==''
            checks.append('reset_recovery_verification_never_filled')
            markup('<form><h2>Create your passcode</h2><input type=password autocomplete=one-time-code><button>Continue</button></form>')
            assert (await IChatSetup().check(actions,'1234',True))['status']=='requires_manual'
            checks.append('otp_even_in_setup_heading_is_manual')
            markup('<form><h2>Confirm your passcode</h2><input type=password><button>Continue</button></form>')
            assert (await IChatSetup().check(actions,'1234',True))['status']=='requires_manual'
            checks.append('standalone_confirmation_not_guessed')
            markup('<form><h2>Create your passcode</h2><button>Unknown action</button></form>')
            assert (await IChatSetup().check(actions,'1234',True))['status']=='requires_manual'
            checks.append('setup_without_fields_is_not_absent')
            print(json.dumps({'passed':True,'synthetic_data':True,'real_x_access':False,'checks':checks}))
        finally:
            browser.quit()


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--chrome',required=True);parser.add_argument('--driver',required=True)
    args=parser.parse_args();asyncio.run(run(args.chrome,args.driver))
