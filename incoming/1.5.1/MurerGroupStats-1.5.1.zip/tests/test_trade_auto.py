"""Automatic source selection and reconciliation of durable Trade memory."""
import unittest
from unittest.mock import patch

from murer.storage import encode, utcnow
from tests import test_trade as trade_fixture


class AutoTradeTests(unittest.TestCase):
    setUp = trade_fixture.TradeTests.setUp
    wait = trade_fixture.TradeTests.wait
    preview = trade_fixture.TradeTests.preview
    start = trade_fixture.TradeTests.start
    finished = trade_fixture.TradeTests.finished

    def extra(self, xid='g777'):
        group = {'x_id':xid,'name':'Extra chat '+xid,'url':'https://x.com/i/chat/'+xid}
        gid = self.state.store.upsert_group(group,self.second['id'])
        self.scenario.group_lists['secondowner'] = [group]
        self.scenario.stats.people[xid] = []
        return gid

    def capability(self, gid, aid, state):
        self.state.store.execute('INSERT OR REPLACE INTO trade_capabilities VALUES(?,?,?,?,?)',(gid,aid,state,'Fixture access',utcnow()))

    def seed_members(self, gid, participants, status='full', declared=None):
        if not self.state.store.rows("SELECT id FROM jobs WHERE id='seed'"):
            now = utcnow()
            settings,version = self.state.store.settings()
            self.state.store.execute('INSERT INTO jobs VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',('seed','collect','[]','[]','completed',now,now,encode(settings),version,'{}',None,now))
        self.state.store.save_members('seed',gid,self.owner['id'],{'status':status,'participants':participants,'declared_count':len(participants) if declared is None else declared})
        if status=='full' and (declared is None or declared==len(participants)):
            xid=self.state.store.rows('SELECT x_id FROM groups WHERE id=?',(gid,))[0]['x_id']
            self.scenario.stats.people[xid]=list(participants)

    def test_auto_starts_with_empty_sender_and_uses_best_known_source_only(self):
        gid = self.extra()
        self.capability(gid,self.second['id'],'allowed')
        plan = self.preview(sender_mode='auto',send_account_id='')
        self.assertEqual(plan['plan']['send_accounts'][0]['id'],self.second['id'])
        result = self.finished(self.start(plan))
        self.assertEqual(result['confirmed'][0]['source_account_id'],self.second['id'])
        self.assertEqual(len(self.scenario.invites),1)
        self.assertIn('secondowner',self.scenario.discovery_accounts,'Preparation refreshes useful sources even with cached groups')
        self.assertGreaterEqual(self.scenario.login_accounts.count('secondowner'),2)
        self.assertGreaterEqual(self.scenario.login_accounts.count('owner'),2)

    def test_auto_falls_back_and_deduplicates_shared_groups_with_one_quota(self):
        gid = self.extra()
        self.state.store.upsert_group(self.scenario.stats.groups[0],self.second['id'])
        result = self.finished(self.start(self.preview(sender_mode='auto',count=3)))
        self.assertEqual(result['confirmed_count'],3)
        self.assertEqual({row['source_account_id'] for row in result['confirmed']},{self.owner['id'],self.second['id']})
        self.assertEqual(len({row['group_id'] for row in result['confirmed']}),3)
        self.assertEqual(result['remaining']['partner'],0)
        self.assertIn(gid,{row['group_id'] for row in result['confirmed']})

    def test_auto_rechecks_cached_unavailable_source_before_using_it(self):
        gid = self.extra()
        self.capability(gid,self.second['id'],'unavailable')
        result = self.finished(self.start(self.preview(sender_mode='auto',count=3)))
        self.assertEqual(result['confirmed_count'],3)
        self.assertIn('secondowner',self.scenario.login_accounts)
        self.assertIn(gid,{group_id for group_id,_ in self.scenario.invites})

    def test_auto_discovers_unknown_account_only_when_known_sources_are_insufficient(self):
        self.state.store.execute('DELETE FROM account_groups')
        group={'x_id':'g555','name':'Unknown source','url':'https://x.com/i/chat/g555'}
        self.scenario.group_lists['owner']=[]
        self.scenario.group_lists['secondowner']=[group]
        with patch('murer.analytics.analyze',side_effect=AssertionError('No analysis')):
            result = self.finished(self.start(self.preview(sender_mode='auto',send_account_id='')))
        self.assertEqual(result['confirmed_count'],1)
        self.assertEqual(result['confirmed'][0]['source_account_id'],self.second['id'])
        self.assertIn('secondowner',self.scenario.discovery_accounts)

    def test_auto_falls_back_when_preferred_account_cannot_log_in(self):
        gid = self.extra()
        self.capability(gid,self.second['id'],'allowed')
        self.scenario.login_failures['secondowner']='proxy_error'
        result=self.finished(self.start(self.preview(sender_mode='auto')))
        self.assertEqual(result['confirmed_count'],1)
        self.assertEqual(result['confirmed'][0]['source_account_id'],self.owner['id'])
        self.assertTrue(any(row.get('source_account_id')==self.second['id'] for row in result['plan']['excluded']))

    def test_auto_falls_back_when_reverse_follow_missing_and_reports_exact_account(self):
        gid=self.extra()
        self.capability(gid,self.second['id'],'allowed')
        self.scenario.blocked_accounts.add(('secondowner','partner'))
        result=self.finished(self.start(self.preview(sender_mode='auto',count=3)))
        self.assertEqual(result['confirmed_count'],0)
        self.assertEqual(result['status'],'awaiting_subscriptions')
        self.assertEqual([(row['account_id'],row['recipient']) for row in result['progress']['relationship_blocks']],[(self.second['id'],'partner')])
        self.assertIn('@secondowner',result['progress']['operation'])

    def test_auto_ignores_archived_candidates_and_recipient_accounts(self):
        recipient=self.client.post('/api/accounts',json={'username':'partner'}).json()
        self.state.store.execute('UPDATE accounts SET archived=1 WHERE id=?',(self.second['id'],))
        plan=self.preview(sender_mode='auto')
        self.assertEqual([a['id'] for a in plan['plan']['send_accounts']],[self.owner['id']])
        self.assertNotIn(recipient['id'],[a['id'] for a in plan['plan']['send_accounts']])

    def test_auto_uncertain_invitation_blocks_further_sources_and_is_not_resent(self):
        self.extra()
        self.scenario.uncertain=True
        plan=self.preview(sender_mode='auto',count=3)
        first=self.finished(self.start(plan))
        self.assertEqual(first['status'],'awaiting_review')
        self.assertEqual(len(self.scenario.invites),1)
        self.scenario.verify_status='uncertain'
        result=self.finished(self.start(plan))
        self.assertEqual(len(self.scenario.invites),1)
        self.assertEqual(result['confirmed_count'],0)

    def test_known_member_is_remembered_without_reopening_and_not_counted_in_contract(self):
        gid=self.extra()
        self.seed_members(gid,[{'username':'partner','x_id':'42'}])
        self.capability(gid,self.second['id'],'allowed')
        result=self.finished(self.start(self.preview(sender_mode='auto',count=3)))
        self.assertEqual(result['confirmed_count'],0)
        self.assertIn('secondowner',self.scenario.login_accounts)
        self.assertEqual(result['status'],'preparation_shortage')
        self.assertNotIn(gid,{group_id for group_id,_ in self.scenario.invites})
        self.assertIn(gid,{row['group_id'] for row in result['already_members']})
        self.assertNotIn(gid,{group_id for _,group_id,_ in self.scenario.inspections})

    def test_trade_member_is_reconciled_by_full_roster_but_not_partial_or_mismatch(self):
        plan=self.preview()
        result=self.finished(self.start(plan))
        gid=result['confirmed'][0]['group_id']
        self.state.trades.finish(plan['id'])
        store=self.state.store
        self.assertIn(gid,self.state.trades._known_members('partner'))
        self.seed_members(gid,[],status='partial')
        self.assertIn(gid,self.state.trades._known_members('partner'))
        self.seed_members(gid,[],status='full',declared=2)
        self.assertIn(gid,self.state.trades._known_members('partner'))
        self.seed_members(gid,[],status='full')
        self.assertNotIn(gid,self.state.trades._known_members('partner'))
        self.assertEqual(store.rows('SELECT * FROM trade_member_observations WHERE group_id=?',(gid,)),[])
        self.scenario.group_lists['owner']=[store.rows('SELECT * FROM groups WHERE id=?',(gid,))[0]]
        self.finished(self.start(self.preview(sender_mode='auto')))
        self.assertEqual(sum(group_id==gid for group_id,_ in self.scenario.invites),2)
        self.assertEqual(store.rows('SELECT status FROM trade_items WHERE run_id=?',(plan['id'],))[0]['status'],'confirmed')

    def test_ambiguous_or_reused_handle_does_not_skip_another_person(self):
        gid=self.extra()
        self.seed_members(gid,[{'username':'partner','x_id':'111'}])
        self.state.store.identify({'username':'partner','x_id':'222'})
        self.assertEqual(self.state.trades._known_members('partner'),{})
        self.assertNotIn(gid,self.state.trades._known_members('partner','222'))
        self.assertIn(gid,self.state.trades._known_members('partner','111'))

    def test_access_memory_survives_new_manager_and_is_ranked(self):
        from murer.trade import TradeManager
        gid=self.extra()
        self.capability(gid,self.second['id'],'allowed')
        manager=TradeManager(self.state.store,self.state.secrets,self.state.jobs,self.state.configuration,lambda _:None,self.scenario.trade_factory)
        sources,_,_=manager._sources({**self.config,'sender_mode':'auto'})
        self.assertEqual(sources[0]['id'],self.second['id'])
        self.assertEqual(sources[0]['allowed_count'],1)

    def test_same_group_uses_account_with_saved_access(self):
        group=self.scenario.stats.groups[0]
        gid=self.state.store.upsert_group(group,self.second['id'])
        self.capability(gid,self.owner['id'],'unavailable')
        self.capability(gid,self.second['id'],'allowed')
        result=self.finished(self.start(self.preview(sender_mode='auto')))
        self.assertEqual(result['confirmed'][0]['group_id'],gid)
        self.assertEqual(result['confirmed'][0]['source_account_id'],self.second['id'])

    def test_explicit_member_recheck_keeps_statistics_and_revalidates_memory(self):
        gid=self.extra()
        self.seed_members(gid,[{'username':'partner','x_id':'42'}])
        self.assertIn(gid,self.state.trades._known_members('partner'))
        response=self.client.post('/api/trade/members/recheck',json={'group_id':gid,'username':'partner'})
        self.assertEqual(response.status_code,200,response.text)
        self.assertNotIn(gid,self.state.trades._known_members('partner'))
        self.assertEqual(self.state.store.rows('SELECT present FROM group_members WHERE group_id=?',(gid,))[0]['present'],1)
        self.seed_members(gid,[{'username':'partner','x_id':'42'}],status='partial')
        self.assertIn(gid,self.state.trades._known_members('partner'))


if __name__=='__main__':
    unittest.main()
