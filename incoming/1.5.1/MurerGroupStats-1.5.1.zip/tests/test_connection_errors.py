"""Expired proxies fail at the account boundary, never as a missing group."""
import unittest
from unittest.mock import MagicMock

from selenium.common.exceptions import WebDriverException
from murer.safe_actions import SafeActions
from murer.rules import default_settings
from xgenius.core.network import ConnectionFailure, connection_failure, probe_connection
from tests import test_storage_api as fixture


class ConnectionClassificationTests(unittest.TestCase):
    def test_proxy_codes_are_recognized_without_credentials_in_reason(self):
        for code in ('ERR_PROXY_CONNECTION_FAILED','ERR_TUNNEL_CONNECTION_FAILED','ERR_SOCKS_CONNECTION_FAILED'):
            result=connection_failure(WebDriverException('net::'+code+' http://secret:password@host:8080'))
            self.assertEqual(result['status'],'proxy_error')
            self.assertNotIn('password',result['reason'])

    def test_network_failure_uses_proxy_only_when_configured(self):
        for configured,expected in ((False,'error'),(True,'proxy_error')):
            self.assertEqual(connection_failure('net::ERR_CONNECTION_RESET',configured)['status'],expected)
        self.assertIsNone(connection_failure('HTTPConnectionPool(host=localhost): connection refused',True))
        self.assertIsNone(connection_failure('NoSuchElementException: search input missing',True))
        self.assertEqual(connection_failure('ProxyError: Unable to connect to proxy')['status'],'proxy_error')

    def test_error_page_probe_and_rethrow_preserve_proxy_status(self):
        browser=MagicMock()
        browser.execute_script.return_value='ERR_TUNNEL_CONNECTION_FAILED'
        value=probe_connection(browser,True)
        self.assertEqual(connection_failure(ConnectionFailure(value)),value)


class ConnectionActionsTests(unittest.IsolatedAsyncioTestCase):
    async def test_navigation_detects_error_code_even_when_driver_does_not_raise(self):
        browser=MagicMock()
        browser.execute_script.return_value='ERR_CONNECTION_TIMED_OUT'
        actions=SafeActions(browser,default_settings(),proxy_configured=True)
        with self.assertRaises(ConnectionFailure) as failure:
            await actions.get('https://x.com/home')
        self.assertEqual(failure.exception.result['status'],'proxy_error')

    async def test_navigation_driver_failure_is_not_replaced_with_login_timeout(self):
        browser=MagicMock()
        browser.get.side_effect=WebDriverException('net::ERR_PROXY_CONNECTION_FAILED')
        with self.assertRaises(ConnectionFailure):
            await SafeActions(browser,default_settings()).get('https://x.com/home')


class ProxyCollectionTests(unittest.TestCase):
    setUp=fixture.StorageApiTests.setUp
    unblock=fixture.StorageApiTests.unblock
    account=fixture.StorageApiTests.account
    job=fixture.StorageApiTests.job
    wait_until=fixture.StorageApiTests.wait_until
    finished=fixture.StorageApiTests.finished

    def test_proxy_failing_after_login_marks_account_and_skips_remaining_groups(self):
        factory=self.state.jobs.session_factory
        def broken(*args):
            session=factory(*args)
            async def members(group):
                await session.command('members',group['x_id'])
                return {'status':'proxy_error','reason':'Synthetic expired proxy'}
            session.members=members
            return session
        self.state.jobs.session_factory=broken
        owner=self.account('owner')
        job=self.finished(self.job([owner]))
        self.assertEqual(self.state.store.account(owner['id'])['status'],'proxy_error')
        self.assertEqual(self.scenario.count('members'),1)
        self.assertEqual(self.scenario.count('profile'),0)
        self.assertNotEqual(job['status'],'completed')

    def test_proxy_exception_during_discovery_preserves_previous_groups(self):
        factory=self.state.jobs.session_factory
        def broken(*args):
            session=factory(*args)
            async def discover(credentials):
                await session.command('discover')
                raise WebDriverException('net::ERR_TUNNEL_CONNECTION_FAILED')
            session.discover_groups=discover
            return session
        self.state.jobs.session_factory=broken
        owner=self.account('owner')
        for group in self.scenario.groups:
            self.state.store.upsert_group(group,owner['id'])
        self.finished(self.job([owner]))
        self.assertEqual(self.state.store.account(owner['id'])['status'],'proxy_error')
        self.assertEqual(self.scenario.count('discover'),1)
        self.assertEqual(len(self.state.store.rows('SELECT * FROM account_groups WHERE account_id=? AND present=1',(owner['id'],))),2)

    def test_broken_source_is_marked_and_next_collection_account_can_finish(self):
        factory=self.state.jobs.session_factory
        def broken(*args):
            session=factory(*args)
            original=session.profile
            async def profile(person):
                if session.username=='owner':
                    await session.command('profile',person['username'])
                    raise WebDriverException('net::ERR_PROXY_CONNECTION_FAILED')
                return await original(person)
            session.profile=profile
            return session
        self.state.jobs.session_factory=broken
        first,second=self.account('owner'),self.account('secondowner')
        self.finished(self.job([first,second]))
        self.assertEqual(self.state.store.account(first['id'])['status'],'proxy_error')
        self.assertEqual(self.state.store.account(second['id'])['status'],'active')
        self.assertEqual(sum(call[0]=='profile' and call[1]=='owner' for call in self.scenario.calls),1)


if __name__=='__main__':
    unittest.main()
