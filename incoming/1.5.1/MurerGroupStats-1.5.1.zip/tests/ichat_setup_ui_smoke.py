"""Rendered settings and manual Trade notice with synthetic sessions."""
import json
import asyncio
from pathlib import Path
import socket
import sys
import tempfile
import threading
import time
import uvicorn
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from murer.api import create_app
from murer.runtime import read_configuration
from murer.secrets import SecretStore
from tests.test_storage_api import MemoryVault
from tests.test_trade import ExchangeScenario


def run():
    report={'passed':False,'synthetic_data':True,'real_x_access':False,'checks':[]}
    browser=None
    with tempfile.TemporaryDirectory() as folder:
        scenario=ExchangeScenario();continued=[]
        def factory(*args):
            session=scenario.trade_factory(*args)
            login=session.login
            async def gated(credentials):
                await login(credentials)
                return {'status':'requires_manual','manual_kind':'ichat_setup','reason':'На аккаунте не настроен пароль/PIN iChat. Автоматическое создание выключено'}
            async def resume(credentials):
                continued.append((credentials.ichat_password,credentials.ichat_auto_setup))
                return {'status':'active'}
            session.login=gated;session.continue_login=resume
            return session
        app=create_app(Path(folder)/'data',SecretStore(MemoryVault()),scenario.stats_factory,factory)
        analysis_started=threading.Event();analysis_done=threading.Event();release_analysis=threading.Event()
        @app.middleware('http')
        async def delayed_analysis(request,call_next):
            if request.url.path=='/api/analysis' and not release_analysis.is_set():
                analysis_started.set()
                await asyncio.to_thread(release_analysis.wait,25)
                analysis_done.set()
            return await call_next(request)
        state=app.state.application;scenario.store=state.store;state.configuration['configured']=True
        owner=state.save_account({'username':'owner'})
        for group in scenario.stats.groups:state.store.upsert_group(group,owner['id'])
        with socket.socket() as reserved:
            reserved.bind(('127.0.0.1',0));port=reserved.getsockname()[1]
        server=uvicorn.Server(uvicorn.Config(app,host='127.0.0.1',port=port,log_level='error',access_log=False))
        thread=threading.Thread(target=server.run,daemon=True);thread.start()
        try:
            deadline=time.monotonic()+20
            while not server.started and time.monotonic()<deadline:time.sleep(.05)
            assert server.started
            plan=state.trades.preview({'receive_account_id':owner['id'],'send_account_id':owner['id'],'donors':['partner'],'recipients':['partner'],'count':1,'quality':'any'})
            state.trades.start(plan['id'],prepare_only=True)
            runtime=read_configuration()
            options=webdriver.ChromeOptions();options.binary_location=runtime['chrome_path']
            options.add_argument('--headless=new');options.add_argument('--window-size=1440,1000')
            options.add_argument('--user-data-dir='+str(Path(folder)/'browser'))
            options.set_capability('goog:loggingPrefs',{'browser':'ALL'})
            browser=webdriver.Chrome(service=Service(runtime['driver_path']),options=options)
            # Prove recovery/refresh without an EventSource event being delivered.
            browser.execute_cdp_cmd('Page.addScriptToEvaluateOnNewDocument',{'source':'window.EventSource=class{close(){}}'})
            wait=WebDriverWait(browser,40)
            browser.get(f'http://127.0.0.1:{port}')
            def click(label):
                element=wait.until(lambda _:next((e for e in browser.find_elements(By.XPATH,'//button[normalize-space(.)='+json.dumps(label,ensure_ascii=False)+']') if e.is_displayed() and e.is_enabled()),False))
                browser.execute_script('arguments[0].scrollIntoView({block:"center"})',element);element.click()
            def fill(identifier,value):
                element=wait.until(lambda _:browser.find_element(By.ID,identifier))
                element.send_keys(Keys.CONTROL,'a');element.send_keys(value)
            def check(name,condition=True):
                assert condition,name
                report['checks'].append(name)
            wait.until(lambda _:'Trade ожидает ручного действия' in browser.find_element(By.TAG_NAME,'body').text)
            check('global_manual_notice_without_sse')
            check('manual_notice_does_not_wait_for_slow_analysis',analysis_started.is_set() and not analysis_done.is_set())
            release_analysis.set()
            click('Открыть Trade и продолжить')
            wait.until(lambda _:browser.find_element(By.CSS_SELECTOR,'[aria-label="Trade ожидает ручного действия"]'))
            check('manual_account_reason_and_continue_visible','@owner' in browser.find_element(By.TAG_NAME,'body').text)
            browser.refresh()
            # The default page also restores the global notice after a reload.
            wait.until(lambda _:'Trade ожидает ручного действия' in browser.find_element(By.TAG_NAME,'body').text)
            check('manual_notice_survives_reload')
            click('Аккаунты')
            edit=wait.until(lambda _:browser.find_element(By.CSS_SELECTOR,'button[title="Редактировать"]'))
            browser.execute_script('arguments[0].scrollIntoView({block:"center"})',edit);edit.click()
            switch=wait.until(lambda _:browser.find_element(By.ID,'account-ichat-auto-setup'))
            check('setup_toggle_default_off',switch.get_attribute('aria-checked')=='false')
            fill('account-ichat_password','1234');switch.click()
            fill('account-ichat-auto-setup-confirm','4321');click('Сохранить аккаунт')
            wait.until(lambda _:'Пароль/PIN iChat и подтверждение не совпадают' in browser.find_element(By.TAG_NAME,'body').text)
            check('mismatched_confirmation_is_rejected',not state.store.account(owner['id'])['ichat_auto_setup'])
            fill('account-ichat-auto-setup-confirm','1234');click('Сохранить аккаунт')
            wait.until(lambda _:not browser.find_elements(By.CSS_SELECTOR,'[role="dialog"]'))
            check('password_and_toggle_can_be_saved_while_trade_waits',state.store.account(owner['id'])['ichat_auto_setup'])
            click('Trade')
            wait.until(lambda _:browser.find_element(By.CSS_SELECTOR,'[aria-label="Trade ожидает ручного действия"]'))
            browser.execute_cdp_cmd('Emulation.setDeviceMetricsOverride',{'width':390,'height':950,'deviceScaleFactor':1,'mobile':False})
            wait.until(lambda _:browser.execute_script('return document.documentElement.scrollWidth<=innerWidth+1'))
            browser.save_screenshot(str(ROOT/'artifacts/ichat-manual-390.png'))
            check('manual_notice_responsive_390')
            browser.execute_cdp_cmd('Emulation.clearDeviceMetricsOverride',{})
            click('Продолжить после ручного подтверждения')
            wait.until(lambda _:state.trades.run(plan['id'])['status']=='prepared')
            wait.until(lambda _:not browser.find_elements(By.CSS_SELECTOR,'[aria-label="Trade ожидает ручного действия"]'))
            check('same_trade_resumes_with_updated_setup_credentials',continued==[('1234',True)])
            wait.until(lambda _:browser.find_elements(By.CSS_SELECTOR,'textarea[aria-label="Сообщение со ссылками для получателя"]'))
            check('prepared_plan_stays_visible_after_manual_recovery')
            browser.refresh();click('Trade')
            wait.until(lambda _:browser.find_elements(By.CSS_SELECTOR,'textarea[aria-label="Сообщение со ссылками для получателя"]'))
            check('prepared_plan_can_be_restored_after_reload')
            check('manual_recovery_does_not_send_invitations',not scenario.invites)
            check('no_browser_errors',not [e for e in browser.get_log('browser') if e['level']=='SEVERE'])
            report['passed']=True
        finally:
            release_analysis.set()
            (ROOT/'artifacts/ichat-setup-ui.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
            if browser:browser.quit()
            server.should_exit=True;thread.join(15)
        print(json.dumps(report))


if __name__=='__main__':run()
