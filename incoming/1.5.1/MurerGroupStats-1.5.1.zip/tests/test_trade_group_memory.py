"""Membership and intent memory must follow a chat link across all accounts."""
import unittest

from murer.group_identity import group_key
from murer.trade import TradeManager
from tests import test_trade as fixture, test_trade_auto as auto, test_trade_preparation as preparation


class SharedGroupMemoryTests(unittest.TestCase):
    setUp = fixture.TradeTests.setUp
    preview = fixture.TradeTests.preview
    wait = fixture.TradeTests.wait
    finished = fixture.TradeTests.finished
    prepare = preparation.PreparationTests.prepare
    execute = preparation.PreparationTests.execute
    seed_members = auto.AutoTradeTests.seed_members

    def shared(self):
        original = self.scenario.stats.groups[0]
        duplicate = {**original,'x_id':'gLegacy','url':original['url']+'/?source=second#top'}
        first = self.state.store.upsert_group(original,self.owner['id'])
        second = self.state.store.upsert_group(duplicate,self.second['id'])
        self.scenario.group_lists['owner'] = [original]
        self.scenario.group_lists['secondowner'] = [duplicate]
        return first,second

    def test_confirmed_membership_survives_new_trade_account_db_alias_and_restart(self):
        first,second = self.shared()
        old = self.execute(self.prepare(self.preview()))
        self.assertEqual(old['confirmed_count'],1)
        self.state.trades.finish(old['id'],accept_unverified=True)
        # Reopen the same SQLite database in a new manager; no in-memory cache.
        self.state.trades = TradeManager(self.state.store,self.state.secrets,self.state.jobs,
            self.state.configuration,lambda _:None,self.scenario.trade_factory)
        self.scenario.inspections.clear()
        new = self.prepare(self.preview(send_account_id=self.second['id']))
        self.assertEqual(new['status'],'preparation_shortage')
        self.assertEqual(new['confirmed_count'],0)
        self.assertEqual(len(self.scenario.invites),1)
        self.assertFalse(self.scenario.inspections)
        self.assertIn(second,{row['group_id'] for row in new['already_members']})
        self.assertEqual(set(self.state.trades._known_members('partner','42')),{first,second})

    def test_exact_stable_id_keeps_memory_after_recipient_rename(self):
        first,second = self.shared()
        self.seed_members(first,[{'username':'oldname','x_id':'42'}])
        self.state.store.identify({'username':'partner','x_id':'42'})
        plan = self.prepare(self.preview(send_account_id=self.second['id']))
        self.assertEqual(plan['status'],'preparation_shortage')
        self.assertFalse(self.scenario.inspections)
        self.assertIn(second,self.state.trades._known_members('partner','42'))
        self.assertNotIn(second,self.state.trades._known_members('partner','43'))

    def test_new_alias_discovered_after_cache_loaded_is_also_skipped(self):
        original = self.scenario.stats.groups[0]
        first = self.state.store.upsert_group(original,self.owner['id'])
        self.seed_members(first,[{'username':'partner','x_id':'42'}])
        self.scenario.group_lists['secondowner'] = [{**original,'x_id':'gNewLegacy'}]
        plan = self.prepare(self.preview(send_account_id=self.second['id']))
        self.assertEqual(plan['status'],'preparation_shortage')
        self.assertFalse(self.scenario.inspections)
        self.assertEqual(len(plan['already_members']),1)

    def test_complete_roster_of_alias_proves_departure_but_partial_does_not(self):
        first,second = self.shared()
        self.seed_members(first,[{'username':'partner','x_id':'42'}])
        self.seed_members(second,[],status='partial')
        self.assertIn(second,self.state.trades._known_members('partner','42'))
        self.seed_members(second,[],status='full')
        self.assertEqual(self.state.trades._known_members('partner','42'),{})
        self.seed_members(first,[{'username':'partner','x_id':'42'}],status='partial')
        self.assertIn(second,self.state.trades._known_members('partner','42'))

    def test_manual_recheck_applies_to_all_aliases(self):
        first,second = self.shared()
        self.seed_members(first,[{'username':'partner','x_id':'42'}])
        self.assertEqual(self.client.post('/api/trade/members/recheck',json={'group_id':second,'username':'partner'}).status_code,200)
        self.assertEqual(self.state.trades._known_members('partner','42'),{})
        self.seed_members(first,[{'username':'partner','x_id':'42'}],status='partial')
        self.assertIn(second,self.state.trades._known_members('partner','42'))

    def test_other_trade_confirms_membership_before_start_and_saved_plan_never_opens_group(self):
        first,second = self.shared()
        stale = self.prepare(self.preview(send_account_id=self.second['id']))
        old = self.execute(self.prepare(self.preview()))
        self.assertEqual(old['confirmed_count'],1)
        self.state.trades.finish(old['id'],accept_unverified=True)
        self.scenario.inspections.clear()
        blocked = self.execute(stale)
        self.assertEqual(blocked['status'],'preparation_blocked')
        self.assertFalse(self.scenario.inspections)
        self.assertEqual(len(self.scenario.invites),1)

    def test_legacy_duplicate_assignments_cannot_count_same_chat_twice(self):
        first,second = self.shared()
        plan = self.prepare(self.preview())
        assignment = plan['plan']['preparation']['assignments'][0]
        plan['plan']['preparation']['assignments'].append({**assignment,'id':second,'x_id':'gLegacy'})
        plan['config']['count'] = 2
        from murer.storage import encode
        self.state.store.execute('UPDATE trade_runs SET config=?,plan=? WHERE id=?',
            (encode(plan['config']),encode(plan['plan']),plan['id']))
        response = self.client.post('/api/trade/runs/'+plan['id']+'/start',json={'preparation_id':plan['plan']['preparation']['id']})
        self.assertEqual(response.status_code,422,response.text)
        self.assertFalse(self.scenario.invites)

    def test_historical_duplicate_confirmation_is_only_one_group_in_quota(self):
        from murer.storage import encode
        from uuid import uuid4
        first,second = self.shared()
        plan = self.execute(self.prepare(self.preview()))
        item = plan['confirmed'][0]
        self.state.store.execute('''INSERT INTO trade_items
            (id,run_id,group_id,recipient,status,reason,group_name,url,quality,score,updated_at,source_account_id,evidence)
            SELECT ?,run_id,?,recipient,status,reason,group_name,url,quality,score,updated_at,?,evidence
            FROM trade_items WHERE id=?''',(str(uuid4()),second,self.second['id'],item['id']))
        config = {**plan['config'],'count':2}
        self.state.store.execute('UPDATE trade_runs SET config=? WHERE id=?',(encode(config),plan['id']))
        current = self.state.trades.run(plan['id'])
        self.assertEqual(len(current['items']),2,'Immutable attempt history is retained')
        self.assertEqual(current['confirmed_count'],1)
        self.assertEqual(current['remaining']['partner'],1)

    def test_unknown_intent_on_alias_is_reconciled_before_another_account_can_send(self):
        first,second = self.shared()
        self.scenario.uncertain = True
        old = self.execute(self.prepare(self.preview()))
        self.state.trades.finish(old['id'],accept_unverified=True)
        self.scenario.uncertain = False
        self.scenario.already.add((second,'partner'))
        new = self.prepare(self.preview(send_account_id=self.second['id']))
        self.assertEqual(new['status'],'preparation_shortage')
        self.assertEqual(len(self.scenario.invites),1)
        self.assertEqual(self.state.trades.run(old['id'])['confirmed_count'],1)

    def test_canonical_links_keep_chat_id_case_and_ignore_tracking(self):
        base = {'id':'db','url':'https://x.com/i/chat/gAb123'}
        for url in ('https://www.x.com/i/chat/gAb123/?from=second#top',
                    'https://twitter.com/i/chat/gAb123', 'https://x.com/i/chat/%67Ab123'):
            self.assertEqual(group_key(base),group_key({**base,'url':url}))
        self.assertNotEqual(group_key(base),group_key({**base,'url':'https://x.com/i/chat/gab123'}))


if __name__ == '__main__':
    unittest.main()
