"""Initial PIN creation and manual Trade recovery, on synthetic accounts only."""
import json
import unittest
from unittest.mock import AsyncMock,MagicMock

from murer.ichat_setup import IChatSetup
from murer.rules import default_settings
from tests import test_storage_api as accounts
from tests import test_trade as trades


class IChatSetupTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.actions=MagicMock()
        self.actions.settings=default_settings()
        self.actions.settings['collection'].update(login_poll_rounds=1,login_poll_seconds=0)
        self.actions.script=AsyncMock()
        self.actions.setup_input=AsyncMock()
        self.actions.call=AsyncMock(return_value=True)
        self.actions.click=AsyncMock()
        self.actions.sleep=AsyncMock()
        self.setup=IChatSetup()

    def probe(self,state='create',segmented=False):
        return {'state':state,'fields':[MagicMock() for _ in range(4 if segmented else 2 if state=='paired' else 1)],
                'segmented':segmented,'numeric':segmented,'min_length':4 if segmented else 0,
                'max_length':4 if segmented else 128,'button':MagicMock()}

    async def test_default_off_returns_manual_without_any_secret_input(self):
        self.actions.script.return_value=self.probe()
        result=await self.setup.check(self.actions,'1234')
        self.assertEqual(result['status'],'requires_manual')
        self.assertEqual(result['manual_kind'],'ichat_setup')
        self.actions.setup_input.assert_not_awaited()

    async def test_creation_requires_confirmed_session_owner(self):
        self.actions.script.return_value=self.probe()
        self.assertEqual((await self.setup.check(self.actions,'1234',True,identity_verified=False))['status'],'requires_manual')
        self.actions.setup_input.assert_not_awaited()

    async def test_single_fields_create_and_confirm_same_secret_once_each(self):
        first,second=self.probe(),self.probe('confirm')
        self.actions.script.side_effect=[first,first,second,second,{'state':'absent'}]
        self.assertIsNone(await self.setup.check(self.actions,'fixture-new-password',True))
        self.assertEqual([c.args[1] for c in self.actions.setup_input.await_args_list],['fixture-new-password']*2)
        self.assertEqual(self.actions.click.await_count,2)

    async def test_paired_fields_receive_exactly_two_inputs(self):
        probe=self.probe('paired')
        self.actions.script.side_effect=[probe,probe,{'state':'absent'}]
        self.assertIsNone(await self.setup.check(self.actions,'1234',True))
        self.assertEqual(self.actions.setup_input.await_count,2)

    async def test_segmented_pin_auto_advances_and_is_entered_twice(self):
        first,second=self.probe(segmented=True),self.probe('confirm',True)
        self.actions.script.side_effect=[first,second,{'state':'absent'}]
        self.assertIsNone(await self.setup.check(self.actions,'1234',True))
        self.assertEqual([c.args[1] for c in self.actions.setup_input.await_args_list],list('12341234'))
        self.actions.click.assert_not_awaited()

    async def test_wrong_format_can_be_fixed_before_first_input(self):
        probe=self.probe(segmented=True)
        self.actions.script.return_value=probe
        self.assertEqual((await self.setup.check(self.actions,'letters',True))['status'],'requires_manual')
        self.assertFalse(self.setup.attempted)
        self.actions.setup_input.assert_not_awaited()
        second=self.probe('confirm',True)
        self.actions.script.side_effect=[probe,second,{'state':'absent'}]
        self.assertIsNone(await self.setup.check(self.actions,'1234',True))

    async def test_reset_or_verification_never_receives_saved_password(self):
        for reason in ('reset_or_recovery','verification','unsupported_setup'):
            self.actions.script.return_value={'state':'manual','reason':reason}
            self.assertEqual((await self.setup.check(self.actions,'secret',True))['status'],'requires_manual')
        self.actions.setup_input.assert_not_awaited()

    async def test_partial_secret_is_never_replayed_or_echoed_in_error(self):
        self.actions.script.return_value=self.probe()
        self.actions.setup_input.side_effect=RuntimeError('driver echoed fixture-secret')
        result=await self.setup.check(self.actions,'fixture-secret',True)
        self.assertNotIn('fixture-secret',result['reason'])
        self.assertEqual((await self.setup.check(self.actions,'fixture-secret',True))['status'],'requires_manual')
        self.actions.setup_input.assert_awaited_once()

    async def test_confirm_without_observed_first_entry_stays_manual(self):
        self.actions.script.return_value=self.probe('confirm')
        self.assertEqual((await self.setup.check(self.actions,'1234',True))['status'],'requires_manual')
        self.actions.setup_input.assert_not_awaited()

    async def test_stalled_setup_becomes_manual_within_one_stage_poll_budget(self):
        self.actions.script.return_value=self.probe()
        self.assertEqual((await self.setup.check(self.actions,'1234',True))['status'],'requires_manual')
        self.actions.setup_input.assert_awaited_once()
        self.assertLessEqual(self.actions.sleep.await_count,1)


class IChatSetupAccountTests(unittest.TestCase):
    setUp=accounts.StorageApiTests.setUp
    unblock=accounts.StorageApiTests.unblock
    account=accounts.StorageApiTests.account

    def test_default_is_off_and_enabled_password_needs_matching_confirmation(self):
        owner=self.account()
        self.assertFalse(owner['ichat_auto_setup'])
        url='/api/accounts/'+owner['id']
        for body in ({'ichat_auto_setup':True,'ichat_password':'1234'},
                     {'ichat_auto_setup':True,'ichat_password':'1234','ichat_password_confirmation':'4321'}):
            self.assertEqual(self.client.patch(url,json=body).status_code,422)
        result=self.client.patch(url,json={'ichat_auto_setup':True,'ichat_password':'1234','ichat_password_confirmation':'1234'})
        self.assertEqual(result.status_code,200,result.text)
        self.assertTrue(result.json()['ichat_auto_setup'])
        self.assertNotIn('1234',result.text)
        self.assertNotIn('1234',json.dumps(self.state.store.rows('SELECT * FROM application_meta')))
        self.assertEqual(self.state.secrets.get(owner['id'])['ichat_password'],'1234')

    def test_no_secret_cannot_enable_creation_and_bulk_clear_disables_it(self):
        owner=self.account(ichat_password='')
        self.assertEqual(self.client.patch('/api/accounts/'+owner['id'],json={'ichat_auto_setup':True}).status_code,422)
        body={'account_ids':[owner['id']],'password':'1234','confirmation':'1234','auto_setup':True}
        self.assertEqual(self.client.post('/api/accounts/ichat-password/bulk',json=body).status_code,200)
        self.assertTrue(self.state.store.account(owner['id'])['ichat_auto_setup'])
        self.assertEqual(self.client.post('/api/accounts/ichat-password/bulk',json={'account_ids':[owner['id']],'clear':True,'overwrite':True}).status_code,200)
        self.assertFalse(self.state.store.account(owner['id'])['ichat_auto_setup'])


class IChatSetupTradeTests(unittest.TestCase):
    setUp=trades.TradeTests.setUp
    preview=trades.TradeTests.preview
    wait=trades.TradeTests.wait
    finished=trades.TradeTests.finished

    def test_extra_candidate_manual_setup_is_visible_editable_and_resumes_same_trade(self):
        factory=self.state.trades.session_factory
        continued=[]
        def manual(*args):
            browser=factory(*args)
            login=browser.login
            async def login_gate(credentials):
                result=await login(credentials)
                if credentials.username=='secondowner':
                    return {'status':'requires_manual','manual_kind':'ichat_setup','reason':'Synthetic initial iChat setup required'}
                return result
            async def resume(credentials):
                continued.append((credentials.ichat_password,credentials.ichat_auto_setup))
                return {'status':'active'}
            browser.login=login_gate
            browser.continue_login=resume
            return browser
        self.state.trades.session_factory=manual
        self.scenario.group_lists['owner']=[self.scenario.stats.groups[0]]
        self.scenario.group_lists['secondowner']=[self.scenario.stats.groups[1]]
        plan=self.preview(sender_mode='auto',count=2)
        response=self.client.post('/api/trade/runs/'+plan['id']+'/prepare')
        self.assertEqual(response.status_code,200,response.text)
        self.wait(lambda:self.state.trades.run(plan['id'])['status']=='requires_manual')
        self.assertTrue(self.state.trades.run(plan['id'])['worker_active'])
        notice=self.client.get('/api/bootstrap').json()['trade_attention']
        self.assertEqual(notice['id'],plan['id'])
        self.assertEqual(notice['account'],'secondowner')
        self.assertEqual(self.client.get('/api/trade/status').json()['attention']['id'],plan['id'])
        self.assertFalse(self.scenario.invites)
        edited=self.client.patch('/api/accounts/'+self.second['id'],json={'ichat_auto_setup':True,'ichat_password':'1234','ichat_password_confirmation':'1234'})
        self.assertEqual(edited.status_code,200,edited.text)
        self.assertEqual(self.client.post('/api/trade/runs/'+plan['id']+'/command/continue').status_code,200)
        self.assertEqual(self.finished(plan['id'])['status'],'prepared')
        self.assertEqual(continued,[('1234',True)])
        self.assertFalse(self.scenario.invites)


if __name__=='__main__':
    unittest.main()
