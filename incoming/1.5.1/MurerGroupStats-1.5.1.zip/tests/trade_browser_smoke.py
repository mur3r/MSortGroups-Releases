"""Real visible Selenium interactions, only on local synthetic HTML."""
import argparse
import asyncio
import json
import os
from pathlib import Path
import sys
import tempfile
import threading
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from unittest.mock import AsyncMock, MagicMock

from selenium import webdriver
from selenium.webdriver.chrome.service import Service

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from murer.trade_browser import TradeSession, RELATIONSHIP_JS, OWNER_PROFILE_JS, INVITE_DETAILS_JS
from murer.rules import default_settings
from xgenius.collectors.groups import CHAT_LIST_PROBE_JS
from xgenius.config import Config
from xgenius.models import AccountState
from xgenius.core.network import ConnectionFailure
from murer.safe_actions import SafeActions


async def run(chrome, driver):
    checks=[]
    with tempfile.TemporaryDirectory(prefix='murer_trade_dom_') as folder:
        options=webdriver.ChromeOptions(); options.binary_location=chrome
        options.add_argument('--headless=new')
        options.add_argument('--user-data-dir='+str(Path(folder)/'browser'))
        class FixtureHandler(SimpleHTTPRequestHandler):
            def __init__(self,*args,**kwargs):
                super().__init__(*args,directory=str(ROOT/'tests/fixtures'),**kwargs)
            def log_message(self,*args):
                pass
        # file:// uses opaque storage origins: sessionStorage can disappear
        # across navigation. HTTP models server-persisted membership reliably.
        fixture_server=ThreadingHTTPServer(('127.0.0.1',0),FixtureHandler)
        fixture_thread=threading.Thread(target=fixture_server.serve_forever,daemon=True)
        fixture_thread.start()
        browser=webdriver.Chrome(service=Service(driver),options=options)
        try:
            fixture=f'http://127.0.0.1:{fixture_server.server_port}/trade.html'
            browser.get(fixture)
            browser.execute_script('sessionStorage.clear()')
            browser.refresh()
            relationship=browser.execute_script(RELATIONSHIP_JS,'partner')
            assert relationship['following'] is True and relationship['follows_us'] is True
            assert browser.execute_script('return window.fixtureFollowClicks')==0
            checks.append('mutual_follow_read_only')
            assert browser.execute_script(OWNER_PROFILE_JS,'partner')['state']=='mismatch'
            browser.execute_script("document.querySelector('[data-testid=primaryColumn]').insertAdjacentHTML('beforeend','<a data-testid=editProfileButton href=/settings/profile>Edit profile</a>')")
            assert browser.execute_script(OWNER_PROFILE_JS,'partner')['state']=='confirmed'
            assert browser.execute_script(OWNER_PROFILE_JS,'different')['state']=='loading'
            checks.append('owner_profile_guard_requires_exact_handle_and_edit_profile')
            browser.execute_script("const r=document.querySelector('[data-testid=xchatEmbedRoute]').shadowRoot;r.querySelector('#details').hidden=false;r.querySelector('#details').insertAdjacentHTML('beforeend','<div id=sync-status>Sync is in progress ...</div>')")
            assert browser.execute_script(INVITE_DETAILS_JS)['state']=='loading'
            browser.execute_script("document.querySelector('[data-testid=xchatEmbedRoute]').shadowRoot.querySelector('#sync-status').remove()")
            assert browser.execute_script(INVITE_DETAILS_JS)['state']=='ready'
            checks.append('sync_overlay_not_mistaken_for_permanent_no_add')
            browser.execute_script("const r=document.createElement('div');r.id='geometry';r.dataset.testid='dm-conversation-scroller';r.style.cssText='height:100px;width:300px;overflow-y:auto';for(let i=0;i<20;i++){const a=document.createElement('a');a.href='/i/chat/gGeom'+i;a.textContent='Group '+i;a.style.cssText='display:block;height:30px';r.appendChild(a)}const spinner=document.createElement('div');spinner.setAttribute('role','progressbar');spinner.style.display='none';r.appendChild(spinner);document.body.appendChild(r)")
            probe=browser.execute_script(CHAT_LIST_PROBE_JS)
            assert probe['geometry']['at_bottom'] is False and probe['loading'] is False
            browser.execute_script("document.getElementById('geometry').scrollTop=99999")
            assert browser.execute_script(CHAT_LIST_PROBE_JS)['geometry']['at_bottom'] is True
            checks.append('real_chat_container_geometry_and_hidden_spinner')
            browser.execute_script("document.getElementById('geometry').remove()")
            browser.execute_script("const r=document.createElement('div');r.id='shadow-geometry';r.style.cssText='height:100px;width:300px;overflow-y:auto';const host=document.createElement('div');host.style.display='block';r.appendChild(host);const shadow=host.attachShadow({mode:'open'});for(let i=0;i<20;i++){const a=document.createElement('a');a.href='/i/chat/gShadow'+i;a.textContent='Group '+i;a.style.cssText='display:block;height:30px';shadow.appendChild(a)}document.body.appendChild(r)")
            assert browser.execute_script(CHAT_LIST_PROBE_JS)['geometry']['at_bottom'] is False
            browser.execute_script("document.getElementById('shadow-geometry').scrollTop=99999")
            assert browser.execute_script(CHAT_LIST_PROBE_JS)['geometry']['at_bottom'] is True
            checks.append('chat_scroller_found_across_shadow_host')
            browser.execute_script("document.getElementById('shadow-geometry').remove()")

            settings=default_settings();settings['trade'].update(action_delay_seconds=0,load_wait_seconds=0,login_poll_seconds=0,login_poll_rounds=1)
            session=TradeSession(Config(Path(folder)/'data'),MagicMock(),settings)
            session.username='fixture';session.manager.accounts['fixture']=AccountState('fixture',browser=browser);session._bind()
            session._page_gate=AsyncMock(return_value=None)
            navigations=[]
            async def get(url):
                before=browser.execute_script("return {added:window.fixtureAdded,stored:sessionStorage.getItem('added'),clicks:window.fixtureAddClicks,intent:window.fixtureIntent}")
                browser.get(fixture)
                after=browser.execute_script("return {added:window.fixtureAdded,stored:sessionStorage.getItem('added'),clicks:window.fixtureAddClicks}")
                navigations.append({'before':before,'after':after})
            session.actions.get=get
            session.members=AsyncMock(side_effect=AssertionError('Trade must not scan the roster'))
            group={'url':'https://x.com/i/chat/g123','id':'fixture','x_id':'g123'}
            async def grey_get(url):
                browser.get(fixture+'#grey')
                browser.refresh()
            session.actions.get=grey_get
            result=await session.inspect_candidate({**group,'target_x_id':'42'},'partner')
            assert result['status']=='eligible' and result['invitation_ready'] is False,result
            assert (await session.verify_membership({**group,'target_x_id':'42'},'partner'))['status']=='not_added'
            assert (await session.invite(group,'partner',lambda:None))['status']=='error'
            assert browser.execute_script('return window.fixtureAddClicks')==0
            session.members.assert_not_awaited()
            checks.append('grey_unchecked_exact_id_kept_without_roster_or_invitation')
            session.actions.get=get
            result=await session.invite(group,'partner',lambda:browser.execute_script('window.fixtureIntent=true'))
            assert result['status']=='confirmed',{'result':result,'navigations':navigations}
            assert browser.execute_script('return window.fixtureAddClicks')==1
            checks.append('shadow_dialog_exact_user_journal_click_and_roster')
            # Once observed in the roster, another call must not send again.
            result=await session.invite(group,'partner',lambda:None)
            assert result['status']=='already_member'
            assert browser.execute_script('return window.fixtureAddClicks')==1
            checks.append('already_member_not_resent')
            browser.get(fixture)
            browser.execute_script('sessionStorage.clear()')
            async def no_add_get(url):
                browser.get(fixture);browser.execute_script("document.querySelector('[data-testid=xchatEmbedRoute]').shadowRoot.querySelector('#open-add').remove()")
            session.actions.get=no_add_get
            result=await session.invite(group,'partner',lambda:None)
            assert result['status']=='unavailable',result
            assert browser.execute_script('return window.fixtureAddClicks')==0
            checks.append('missing_button_no_mutation')
            for fragment, expected in [('xchat','confirmed'),('existing','already_member')]:
                browser.execute_script('sessionStorage.clear()')
                browser.get(fixture+'#'+fragment)
                browser.refresh()
                async def xchat_get(url):
                    browser.get(fixture+'#'+fragment)
                    browser.refresh()
                session.actions.get=xchat_get
                result=await session.invite(group,'partner',lambda:browser.execute_script('window.fixtureIntent=true'))
                assert result['status']==expected,result
                assert browser.execute_script('return window.fixtureAddClicks')==(1 if expected=='confirmed' else 0)
                checks.append('xchat_div_row_next_and_intent' if fragment=='xchat' else 'xchat_disabled_existing_not_resent')
            session.members.assert_not_awaited()
            checks.append('no_full_roster_scans')
            browser.get(fixture)
            browser.execute_script("const b=document.querySelector('[data-testid=\"42-unfollow\"]');b.setAttribute('data-testid','42-follow');b.onclick=()=>{window.fixtureFollowClicks++;b.setAttribute('data-testid','42-unfollow')};")
            session.relationship=AsyncMock(return_value={'following':False,'follows_us':True,'x_id':'42'})
            result=await session.follow('partner',lambda:browser.execute_script('window.followIntent=true'))
            assert result['following'] is True and browser.execute_script('return window.fixtureFollowClicks')==1
            checks.append('exact_donor_follow_once')
            session.relationship=AsyncMock(return_value={'following':True,'x_id':'42'})
            await session.follow('partner',lambda:None)
            assert browser.execute_script('return window.fixtureFollowClicks')==1
            checks.append('already_following_never_unfollows')
            for fragment in ('two-step','slow-selection','delayed-membership','stuck-submit','wrong-confirmation'):
                browser.get(fixture);browser.execute_script('sessionStorage.clear()')
                async def scenario_get(url):
                    browser.get(fixture+'#'+fragment)
                    browser.refresh()
                session.actions.get=scenario_get
                session.settings['collection'].update(login_poll_rounds=12,login_poll_seconds=.04)
                result=await session.invite({**group,'target_x_id':'42'},'partner',lambda:browser.execute_script('window.fixtureIntent=true'))
                expected='requires_manual' if fragment in ('stuck-submit','wrong-confirmation') else 'confirmed'
                assert result['status']==expected, {'scenario':fragment,'result':result}
                assert browser.execute_script('return window.fixtureAddClicks')==(0 if expected=='requires_manual' else 1)
                checks.append(fragment+'_no_duplicate_invitation')
            browser.get(fixture)
            network_actions=SafeActions(browser,settings,proxy_configured=True)
            browser.execute_script("document.body.innerHTML='<p>Post text mentions ERR_PROXY_CONNECTION_FAILED</p>'")
            await network_actions.check_connection()
            browser.execute_script("document.body.innerHTML='<main id=main-frame-error><div class=error-code>ERR_TUNNEL_CONNECTION_FAILED</div></main>'")
            try:
                await network_actions.check_connection()
                raise AssertionError('Network error document was ignored')
            except ConnectionFailure as failure:
                assert failure.result['status']=='proxy_error'
            checks.append('chrome_error_document_recognized_without_false_post_match')
            print(json.dumps({'synthetic_data':True,'real_x_access':False,'visible_browser':False,'checks':checks,'passed':True}))
            return 0
        finally:
            browser.quit()
            fixture_server.shutdown()
            fixture_server.server_close()
            fixture_thread.join(5)


if __name__=='__main__':
    base=Path(os.environ.get('LOCALAPPDATA',''))/'MurerGroupStats/browser-test'
    parser=argparse.ArgumentParser();parser.add_argument('--chrome',default=str(base/'chrome-win64/chrome.exe'));parser.add_argument('--driver',default=str(base/'chromedriver-win64/chromedriver.exe'))
    args=parser.parse_args();sys.exit(asyncio.run(run(args.chrome,args.driver)))
