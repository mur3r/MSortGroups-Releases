"""Opt-in initial iChat passcode creation, separate from unlock and reset."""
from xgenius.core.dom import DEEP_QUERY_JS
from xgenius.core.network import ConnectionFailure


ICHAT_SETUP_PROBE_JS = DEEP_QUERY_JS + r"""
const pageUrl=new URL(location.href);
if(pageUrl.protocol!=='https:'||!['x.com','www.x.com'].includes(pageUrl.hostname)||!/^\/i\/chat(?:\/|$)/.test(pageUrl.pathname))return {state:'absent'};
const visible=e=>!!e&&!!(e.offsetWidth||e.offsetHeight||e.getClientRects().length);
const roots=deepQueryAll('form,[role="dialog"],[data-testid="xchat-pin-setup"]').filter(visible);
for(const host of deepQueryAll('[data-testid="xchatEmbedRoute"],#xchatEmbedRoute'))if(host.shadowRoot)roots.push(host.shadowRoot);
const create=/(?:create|set up|choose|set)\s+(?:your\s+|a\s+|new\s+)*(?:pin|password|passcode)|(?:созда\S*|зада\S*|установ\S*)\s+(?:свой\s+|нов\S*\s+)?(?:pin|пин|парол|код.парол)/i;
const confirm=/(?:confirm|re.enter|repeat)\s+(?:your\s+|the\s+|new\s+)*(?:pin|password|passcode)|(?:подтверд\S*|повтор\S*)\s+(?:свой\s+|нов\S*\s+)?(?:pin|пин|парол|код.парол)/i;
const forbidden=/(?:reset|recover|change)\s+(?:your\s+|a\s+|new\s+)*(?:pin|password|passcode)|(?:сброс|восстанов|смен)\S*\s+(?:pin|пин|парол|код.парол)|verification|authentication|2fa|код\s+(?:проверки|подтверждения)/i;
const matches=[];
let seenSetup=false;
for(const root of roots){
 const heading=deepQueryAll('h1,h2,h3,[role="heading"],legend,[data-testid="pin-title"]',root).filter(visible).map(e=>(e.innerText||e.textContent||'').trim()).join(' ');
 const stage=confirm.test(heading)?'confirm':create.test(heading)?'create':null;
 if(!stage)continue;
 seenSetup=true;
 if(forbidden.test(heading)||/\/pin\/(?:recover|recovery|reset|change)(?:\/|$)/i.test(pageUrl.pathname))return {state:'manual',reason:'reset_or_recovery'};
 if(deepQueryAll('iframe[src*="captcha"],iframe[src*="arkose"],input[autocomplete="one-time-code"],input[name="verif_code"]',root).some(visible))return {state:'manual',reason:'verification'};
 const inputs=deepQueryAll('input',root).filter(visible).filter(e=>!['hidden','submit','button'].includes(e.type));
 const fields=inputs.filter(e=>e.type==='password'||(['text','tel','number'].includes(e.type)&&['numeric','decimal'].includes(e.inputMode)));
 if(fields.length!==inputs.length)continue;
 const segmented=fields.length>=4&&fields.length<=12&&fields.every(e=>e.maxLength===1);
 const paired=fields.length===2&&fields.every(e=>e.type==='password'&&e.maxLength!==1);
 const single=fields.length===1&&(fields[0].type==='password'||['numeric','decimal'].includes(fields[0].inputMode));
 const buttons=deepQueryAll('button,input[type="submit"]',root).filter(visible).filter(e=>/^(?:continue|next|create|create (?:passcode|password|pin)|set up|set up (?:passcode|password|pin)|set (?:passcode|password|pin)|confirm|done|get started|продолжить|далее|создать|создать пароль|подтвердить|готово|начать|настроить)$/i.test((e.innerText||e.value||e.getAttribute('aria-label')||'').trim()));
 if(buttons.length>1||(!segmented&&buttons.length!==1))continue;
 if(!fields.length&&stage==='create'&&buttons.length===1){matches.push({state:'intro',fields:[],button:buttons[0],signature:heading});continue;}
 if(!single&&!segmented&&!paired)continue;
 if(paired&&stage!=='create')continue;
 matches.push({state:paired?'paired':stage,fields,segmented,button:buttons[0]||null,
   numeric:segmented||fields.every(e=>['numeric','decimal'].includes(e.inputMode)),
   min_length:segmented?fields.length:Math.max(0,...fields.map(e=>e.minLength)),
   max_length:segmented?fields.length:Math.min(128,...fields.map(e=>e.maxLength>0?e.maxLength:128)),signature:heading});
}
const unique=[];
for(const item of matches)if(!unique.some(other=>other.state===item.state&&other.fields.length===item.fields.length&&other.fields.every((f,i)=>f===item.fields[i])&&other.button===item.button))unique.push(item);
if(unique.length===1)return unique[0];
return seenSetup||/\/pin\/(?:create|setup|confirm)(?:\/|$)/i.test(pageUrl.pathname)?{state:'manual',reason:'unsupported_setup'}:{state:'absent'};
"""


class IChatSetup:
    def __init__(self,on_event=None):
        self.attempted=False
        self.on_event=on_event

    async def emit(self,actions,event):
        actions.record('step','iChat: '+event,details={'phase':'initial_setup'})
        if self.on_event:
            await self.on_event({'event':event})

    async def manual(self,actions,reason):
        await self.emit(actions,'setup_manual')
        return {'status':'requires_manual','manual_kind':'ichat_setup',
                'reason':reason+'. Завершите настройку в Chrome или измените параметры iChat и нажмите «Продолжить после ручного подтверждения»'}

    async def check(self,actions,password,enabled=False,identity_verified=True):
        probe=await actions.script(ICHAT_SETUP_PROBE_JS)
        if not isinstance(probe,dict) or probe.get('state')=='absent':
            return None
        if probe.get('state')=='manual':
            return await self.manual(actions,'Экран настройки iChat не распознан как безопасное первоначальное создание пароля/PIN')
        if not enabled:
            return await self.manual(actions,'На аккаунте не настроен пароль/PIN iChat. Автоматическое создание выключено')
        if not identity_verified:
            return await self.manual(actions,'Перед созданием PIN нужно подтвердить владельца сессии. Откройте собственный профиль X в этом Chrome и продолжите')
        if not password:
            return await self.manual(actions,'Для первоначальной настройки заранее задайте пароль/PIN iChat в карточке аккаунта')
        if self.attempted:
            return await self.manual(actions,'Автоматическая настройка iChat уже выполнялась; повторный ввод отключён')
        if probe.get('state')=='confirm':
            return await self.manual(actions,'Открыто подтверждение ранее начатой настройки iChat; завершите его вручную')
        if any(ord(c)<32 or ord(c)==127 or 0xE000<=ord(c)<=0xF8FF for c in password):
            return await self.manual(actions,'Сохранённый пароль/PIN iChat содержит недопустимые символы')
        entered=set()
        clicked=set()
        confirmed=False
        collection=actions.settings.get('collection',actions.settings)
        rounds=max(1,int(collection.get('login_poll_rounds',12)))
        previous_state=None
        idle=0
        try:
            for _ in range(rounds*4+4):
                state=probe.get('state')
                idle=idle+1 if state==previous_state else 0
                previous_state=state
                if idle>=rounds:
                    return await self.manual(actions,'iChat не перешёл к следующему шагу настройки; проверьте сообщение на форме')
                if state=='absent':
                    if not confirmed:
                        await actions.sleep(float(collection.get('login_poll_seconds',2.5)))
                        probe=await actions.script(ICHAT_SETUP_PROBE_JS)
                        continue
                    await self.emit(actions,'setup_completed')
                    return None
                if state=='manual' and probe.get('reason')=='unsupported_setup' and entered:
                    await actions.sleep(float(collection.get('login_poll_seconds',2.5)))
                    probe=await actions.script(ICHAT_SETUP_PROBE_JS)
                    continue
                if state not in ('intro','create','paired','confirm'):
                    return await self.manual(actions,'После шага настройки iChat запросил другое действие')
                if state=='confirm' and not entered.intersection({'create','paired'}):
                    return await self.manual(actions,'Не подтверждён первый ввод нового PIN iChat')
                if (state=='confirm' and 'paired' in entered) or (state=='paired' and 'create' in entered):
                    return await self.manual(actions,'После двух вводов iChat запросил дополнительное подтверждение')
                if state not in entered:
                    fields=probe.get('fields',[])
                    if state!='intro':
                        if not probe.get('min_length',0)<=len(password)<=probe.get('max_length',128) or (probe.get('numeric') and (not password.isascii() or not password.isdigit())):
                            return await self.manual(actions,'Сохранённый пароль/PIN не соответствует длине или формату формы iChat')
                    entered.add(state)  # Mark before input; an interrupted secret is never replayed.
                    if state!='intro':
                        self.attempted=True
                    if state=='paired':
                        for field in fields:
                            await actions.setup_input(field,password)
                        confirmed=True
                    elif state!='intro':
                        if probe.get('segmented'):
                            for field,char in zip(fields,password):
                                await actions.setup_input(field,char,segmented=True)
                        else:
                            await actions.setup_input(fields[0],password)
                        if state=='confirm':
                            confirmed=True
                    await self.emit(actions,'setup_confirmation_entered' if confirmed else 'setup_started')
                    current=await actions.script(ICHAT_SETUP_PROBE_JS)
                    if current.get('state')!=state or current.get('fields')!=fields:
                        probe=current
                        continue
                    probe=current
                button=probe.get('button')
                if state not in clicked and button is not None and await actions.call(button.is_enabled):
                    clicked.add(state)
                    await actions.click(button)
                    await self.emit(actions,'setup_submitted')
                await actions.sleep(float(collection.get('login_poll_seconds',2.5)))
                probe=await actions.script(ICHAT_SETUP_PROBE_JS)
            return await self.manual(actions,'iChat не подтвердил создание пароля/PIN; автоматический повтор отключён')
        except Exception as error:
            if type(error).__name__ in ('StopRequested','PauseRequested','JobStopped'):
                raise
            if isinstance(error,ConnectionFailure):
                raise
            # Driver errors may echo typed secrets. Only a fixed public reason is returned.
            return await self.manual(actions,'Автоматическая настройка iChat остановилась; проверьте открытое окно Chrome')
