import asyncio
from contextlib import asynccontextmanager
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import sqlite3
import threading
import time
from uuid import uuid4

from fastapi import FastAPI, HTTPException, Request, Query
from fastapi.exceptions import RequestValidationError
from fastapi.responses import FileResponse, JSONResponse, Response, StreamingResponse
from fastapi.staticfiles import StaticFiles
from starlette.middleware.trustedhost import TrustedHostMiddleware

from .analytics import analyze
from . import __version__
from .exporting import TABLES, csv_report, excel_report, filtered_rows
from .importing import preview_import, validate_account
from .jobs import JobManager
from .rules import default_settings, validate_settings, speed_presets, trade_speed_presets, validate_trade_settings
from .runtime import browser_check, read_configuration, save_configuration
from .secrets import SECRET_FIELDS, SecretStore, validate_ichat_password
from .storage import Store, encode, utcnow
from .trade import TradeManager, usernames
from .updates import UpdateManager
from .eventlog import EventLog, DOMAINS, LEVELS, KINDS


class Application:
    def __init__(self, data_dir=None, secrets=None, session_factory=None, trade_session_factory=None):
        self.configuration = read_configuration()
        if data_dir:
            self.configuration['data_dir'] = str(data_dir)
        self.events = EventLog(self.configuration['data_dir'])
        self.events.emit('system', 'lifecycle', 'Запуск программы', details={'version': __version__})
        self.store = Store(self.configuration['data_dir'])
        self.store.audit = self.events.emit
        self.store.protect = self.events.protect
        self.secrets = secrets or SecretStore()
        self.secrets.protect = self.events.protect
        for account in self.store.accounts():
            self.secrets.get(account['id'])
        if not self.store.settings()[0]:
            self.store.save_settings(default_settings())
        else:
            current, _ = self.store.settings()
            merged = validate_settings(current)
            if current != merged:
                self.store.save_settings(merged)
        self.lock = threading.RLock()
        self.analysis_cache = {}
        self.analysis_cache_times = {}
        self.settings_revisions = {}
        self.subscribers = set()
        self.loop = None
        self.shutdown_callback = None
        self.shutting_down = False
        self.installing = False
        self.jobs = JobManager(self.store, self.secrets, self.configuration, self.publish, session_factory)
        self.jobs.snapshot_callback = self.snapshot
        self.trades = TradeManager(self.store, self.secrets, self.jobs, self.configuration, self.publish, trade_session_factory)
        self.database_ok = self.store.rows('PRAGMA quick_check')[0]['quick_check'] == 'ok'
        self.updates = UpdateManager(self.store, self.secrets.backend, self.update_busy_reason, self.publish)
        self.events.emit('system', 'result', 'База данных проверена', level='info' if self.database_ok else 'error',
                         details={'database_ok': self.database_ok, 'schema_versions': [r['version'] for r in self.store.rows('SELECT version FROM schema_migrations')]})
        last_update = self.updates.status().get('last_result')
        if last_update:
            self.events.emit('updates', 'result', 'Результат предыдущей установки обновления', details=last_update)

    def update_busy_reason(self):
        if self.shutting_down or self.installing:
            return 'Программа завершает работу или устанавливает обновление.'
        if self.jobs.priority_owner:
            return 'Сначала завершите текущий Trade, включая ожидающий подтверждения обмен.'
        if any(t.is_alive() for t in list(self.jobs.threads.values()) + list(self.trades.threads.values())):
            return 'Дождитесь завершения сбора/Trade или остановите задание. Пауза не освобождает программу для обновления.'
        if self.jobs.browser_cleanup_failed:
            return 'Закрытие браузеров не подтверждено. Перезапустите приложение перед обновлением.'
        return ''

    def publish(self, message):
        if message.get('type') in ('analysis', 'settings', 'accounts'):
            with self.lock:
                self.analysis_cache.clear()
                self.analysis_cache_times.clear()
        if self.loop and not self.loop.is_closed():
            def deliver():
                for queue in list(self.subscribers):
                    if queue.full():
                        queue.get_nowait()
                    queue.put_nowait(message)
            try:
                self.loop.call_soon_threadsafe(deliver)
            except RuntimeError:
                pass  # A final worker update may race the closed event loop.

    def public_accounts(self):
        return [{**a, **self.secrets.flags(a['id'])} for a in self.store.accounts()]

    def calculate(self, account_ids=None, group_ids=None, run_id=None, mode='current'):
        key = (tuple(account_ids) if account_ids is not None else None, tuple(group_ids) if group_ids is not None else None, run_id, mode)
        with self.lock:
            # Current activity/freshness changes as time passes without writes.
            # Frozen historical snapshots use their fixed reference date.
            if key in self.analysis_cache and (run_id or time.monotonic() - self.analysis_cache_times.get(key, 0) < 30):
                return self.analysis_cache[key]
            started = time.monotonic()
            self.events.emit('data', 'step', 'Расчёт анализа: начало', level='debug', run_id=run_id,
                             details={'account_ids': account_ids, 'group_ids': group_ids, 'mode': mode})
            settings, version = self.store.settings()
            dataset = None
            reference_time = None
            if run_id:
                rows = self.store.rows('SELECT * FROM run_snapshots WHERE job_id=?', (run_id,))
                if not rows:
                    raise ValueError('Сохранённый снимок ещё не доступен')
                dataset = json.loads(rows[0]['dataset'])
                reference_time = rows[0]['created_at']
                if mode == 'collection':
                    job = self.store.job(run_id)
                    settings, version = job['settings'], job['settings_version']
            dataset = dataset or self.store.dataset()
            result = analyze(dataset, settings, account_ids=account_ids, group_ids=group_ids, now=reference_time)
            result['settings_version'] = version
            result['settings'] = settings
            result['run_id'] = run_id
            result['mode'] = mode
            result['calculated_at'] = utcnow()
            result['reference_time'] = reference_time or result['calculated_at']
            self.analysis_cache[key] = result
            self.analysis_cache_times[key] = time.monotonic()
            self.events.emit('data', 'result', 'Анализ рассчитан', run_id=run_id,
                             details={'duration_ms': round((time.monotonic()-started)*1000), 'settings_version': version,
                                      'groups': len(result.get('groups', [])), 'participants': len(result.get('participants', []))})
            return result

    def snapshot(self, job_id):
        # Frozen observations and collection-time rules support honest history.
        with self.lock:
            self.analysis_cache.clear()
            job = self.store.job(job_id)
            dataset = self.store.dataset()
            result = analyze(dataset, job['settings'], account_ids=job['account_ids'])
            self.store.execute('INSERT OR REPLACE INTO run_snapshots VALUES(?,?,?,?,?)',
                (job_id, utcnow(), encode(dataset), encode(result), job['settings_version']))
            self.events.emit('data', 'checkpoint', 'Снимок данных и анализа задания сохранён', run_id=job_id)

    def save_account(self, values, account_id=None):
        with self.jobs.lock:
            return self._save_account(values, account_id)

    def _save_account(self, values, account_id=None):
        values = validate_account(values, partial=account_id is not None)
        values.pop('ichat_password_confirmation',None)
        existing = None
        if account_id:
            existing = self.store.account(account_id)
            if not existing:
                raise ValueError('Аккаунт не найден')
            if self.jobs.priority_owner or any(t.is_alive() for t in self.jobs.threads.values()):
                secret_keys = set(values) & set(SECRET_FIELDS)
                same_public = all((value or None) == (existing.get(key) or None)
                                  for key, value in values.items() if key not in SECRET_FIELDS and key!='ichat_auto_setup')
                if not secret_keys <= {'ichat_password'} or not same_public or not (secret_keys or 'ichat_auto_setup' in values):
                    raise ValueError('Редактирование аккаунтов доступно после завершения текущего задания')
                self._assert_ichat_editable([account_id])
        account_id = account_id or str(uuid4())
        if 'username' in values and any(a['id'] != account_id and a['username'] == values['username'] for a in self.store.accounts()):
            raise sqlite3.IntegrityError('duplicate account username')
        public = {k: v for k, v in values.items() if k not in SECRET_FIELDS}
        # Vault errors are shown without including credentials; no plaintext fallback.
        previous = self.secrets.get(account_id)
        if values.get('ichat_auto_setup',(existing or {}).get('ichat_auto_setup',False)) and not values.get('ichat_password',previous['ichat_password']):
            raise ValueError('Для автоматической настройки заранее задайте пароль/PIN iChat или выключите тумблер')
        changed = {key for key in SECRET_FIELDS if key in values and values[key] is not None}
        try:
            self.secrets.set(account_id, values)
            self.store.save_account(public, account_id)
        except Exception as error:
            try:
                self.secrets.set(account_id, {key: previous[key] for key in changed})
            except Exception:
                raise ValueError('Не удалось сохранить секреты; проверьте состояние учётных данных в хранилище Windows') from error
            raise ValueError('Не удалось сохранить секреты в хранилище Windows') from error
        self.publish({'type': 'accounts'})
        return next(a for a in self.public_accounts() if a['id'] == account_id)

    def _assert_ichat_editable(self, account_ids):
        if self.jobs.priority_owner:
            run = self.trades.run(self.jobs.priority_owner)
            trade_accounts = {run['config']['receive_account_id'],run['config']['send_account_id']} | {account['id'] for account in [*run['plan'].get('send_accounts',[]),*run['plan'].get('candidate_accounts',[])]}
            if run['progress'].get('source_account_id'):
                trade_accounts.add(run['progress']['source_account_id'])
            if run['status'] != 'requires_manual' or run['progress'].get('manual_kind')=='invitation' or not set(account_ids) <= trade_accounts:
                raise ValueError('Во время Trade пароль iChat меняется только при ручном ожидании входа')
        for job_id, thread in self.jobs.threads.items():
            if not thread.is_alive():
                continue
            job = self.store.job(job_id)
            if job is None:
                raise ValueError('Дождитесь завершения текущего задания перед изменением паролей iChat')
            targets = set(account_ids).intersection(job['account_ids'])
            if not targets:
                continue
            if job['status'] not in ('requires_manual', 'paused') or any(
                self.store.account(aid)['status'] not in ('requires_manual', 'paused') for aid in targets):
                raise ValueError('Пароль iChat можно менять после задания либо когда аккаунт ожидает ручного действия или паузы')

    def bulk_ichat_password(self, body):
        if set(body) - {'account_ids', 'password', 'confirmation', 'auto_setup', 'overwrite', 'clear'}:
            raise ValueError('Неизвестные параметры назначения пароля iChat')
        account_ids = body.get('account_ids')
        if not isinstance(account_ids, list) or not account_ids or any(not isinstance(x, str) for x in account_ids):
            raise ValueError('Явно выберите аккаунты для назначения пароля iChat')
        if len(set(account_ids)) != len(account_ids):
            raise ValueError('Аккаунты не должны повторяться')
        overwrite, clear = body.get('overwrite', False), body.get('clear', False)
        auto_setup = body.get('auto_setup')
        if auto_setup is not None and not isinstance(auto_setup,bool):
            raise ValueError('auto_setup должен быть логическим значением')
        if not isinstance(overwrite, bool) or not isinstance(clear, bool):
            raise ValueError('overwrite и clear должны быть логическими значениями')
        if clear:
            if 'password' in body or 'confirmation' in body or auto_setup is True or body.get('overwrite') is not True:
                raise ValueError('Удаление должно быть явно выбрано отдельно от назначения пароля')
            password = ''
        else:
            password = validate_ichat_password(body.get('password'), allow_empty=False)
            if ('confirmation' in body or auto_setup is True) and body.get('confirmation')!=password:
                raise ValueError('Пароль/PIN iChat и подтверждение не совпадают')
        # Start and edit share a lock: credentials cannot change during a command.
        with self.jobs.lock:
            known = {a['id']: a for a in self.store.accounts()}
            if any(aid not in known or known[aid]['archived'] for aid in account_ids):
                raise ValueError('Все выбранные аккаунты должны находиться в рабочем списке')
            self._assert_ichat_editable(account_ids)
            previous = {aid: self.secrets.get(aid)['ichat_password'] for aid in account_ids}
            targets = [aid for aid in account_ids if overwrite or not previous[aid]]
            changed = []
            try:
                for aid in targets:
                    # Include the current account in rollback if a vault backend
                    # fails after writing rather than before it.
                    changed.append(aid)
                    self.secrets.set(aid, {'ichat_password': password})
                if clear or auto_setup is not None:
                    with self.store.connection() as db:
                        for aid in targets:
                            db.execute('INSERT OR REPLACE INTO application_meta VALUES(?,?)',
                                ('ichat_auto_setup:'+aid,'true' if auto_setup and not clear else 'false'))
            except Exception as error:
                rollback_failed = False
                for aid in changed:
                    try:
                        self.secrets.set(aid, {'ichat_password': previous[aid]})
                    except Exception:
                        rollback_failed = True
                message = 'Не удалось сохранить пароли iChat в хранилище Windows'
                if rollback_failed:
                    message += '; проверьте состояние сохранения у выбранных аккаунтов'
                raise ValueError(message) from error
        self.publish({'type': 'accounts'})
        return {'updated': len(targets), 'skipped': len(account_ids)-len(targets), 'total': len(account_ids)}


def ids(value):
    return [x for x in value.split(',') if x] if value is not None else None


def create_app(data_dir=None, secrets=None, session_factory=None, trade_session_factory=None):
    state = Application(data_dir, secrets, session_factory, trade_session_factory)

    @asynccontextmanager
    async def lifespan(app):
        state.loop = asyncio.get_running_loop()
        state.events.start()
        state.events.emit('system', 'lifecycle', 'Локальный интерфейс готов к работе')
        state.updates.start_auto_check()
        try:
            yield
        finally:
            state.events.emit('system', 'lifecycle', 'Завершение программы: остановка заданий и браузеров')
            try:
                state.updates.close()
                await asyncio.to_thread(state.trades.close)
                await asyncio.to_thread(state.jobs.close)
            finally:
                state.events.emit('system', 'lifecycle', 'Программа завершена')
                state.events.close()
                state.loop = None

    app = FastAPI(title='Murer Group Stats', lifespan=lifespan, docs_url='/api/docs')
    app.state.application = state
    mutation_lock = asyncio.Lock()
    app.add_middleware(TrustedHostMiddleware, allowed_hosts=['127.0.0.1', 'localhost', 'testserver'])

    @app.middleware('http')
    async def audit_requests(request, call_next):
        started = time.monotonic()
        path = request.url.path
        try:
            response = await call_next(request)
        except Exception as error:
            state.events.emit('system', 'error', 'Необработанная ошибка запроса', level='error',
                              details={'method': request.method, 'error_type': type(error).__name__})
            raise
        # Polling, SSE and reading/exporting the journal never generate events.
        # Request bodies, headers, query strings and response bodies stay private.
        if path.startswith('/api/') and not path.startswith('/api/logs') and (
                request.method not in ('GET','HEAD','OPTIONS') or response.status_code >= 400 or
                path.startswith(('/api/export', '/api/compare')) or path.endswith('/export')):
            route = request.scope.get('route')
            template = getattr(route, 'path', '/api/[неизвестный маршрут]')
            domain = 'trade' if template.startswith('/api/trade') else 'updates' if template.startswith('/api/updates') else 'auth' if template.startswith(('/api/accounts','/api/import')) else 'data' if template.startswith(('/api/settings','/api/rule','/api/export','/api/groups','/api/compare')) else 'system'
            state.events.emit(domain, 'export' if 'export' in template else 'request',
                f'{request.method} {template} · HTTP {response.status_code}',
                level='error' if response.status_code >= 500 else 'warning' if response.status_code >= 400 else 'info',
                details={'duration_ms': round((time.monotonic()-started)*1000),
                         'route_ids': request.path_params, 'status_code': response.status_code})
        return response

    @app.middleware('http')
    async def local_only(request, call_next):
        origin = request.headers.get('origin')
        expected = str(request.base_url).rstrip('/')
        if request.method not in ('GET', 'HEAD', 'OPTIONS') and ((origin and origin != expected) or request.headers.get('sec-fetch-site') == 'cross-site'):
            state.events.emit('system', 'request', 'Отклонён запрос из внешнего источника', level='warning')
            return JSONResponse({'detail': 'Доступ разрешён только из локального интерфейса'}, status_code=403)
        if request.method not in ('GET', 'HEAD', 'OPTIONS'):
            async with mutation_lock:
                if state.updates.trial or state.installing:
                    state.events.emit('updates', 'request', 'Изменение данных отложено: идёт проверка установки', level='warning')
                    return JSONResponse({'detail': 'Устанавливается обновление. Дождитесь проверки запуска.'}, status_code=503)
                response = await call_next(request)
        else:
            response = await call_next(request)
        response.headers['X-Content-Type-Options'] = 'nosniff'
        response.headers['Referrer-Policy'] = 'no-referrer'
        if request.url.path.startswith('/api/') or request.url.path == '/':
            response.headers['Cache-Control'] = 'no-store'
        return response

    @app.exception_handler(ValueError)
    async def invalid(request, error):
        return JSONResponse({'detail': str(error)}, status_code=422)

    @app.exception_handler(RequestValidationError)
    async def invalid_request(request, error):
        # FastAPI's default error includes rejected input. A secret-bearing
        # account request must not echo its body, even when malformed.
        return JSONResponse({'detail': [{'loc': list(item['loc']), 'msg': item['msg'], 'type': item['type']}
                                        for item in error.errors()]}, status_code=422)

    @app.exception_handler(sqlite3.IntegrityError)
    async def conflict(request, error):
        return JSONResponse({'detail': 'Аккаунт с таким username уже существует либо связь некорректна'}, status_code=409)

    @app.get('/api/health')
    def health():
        return {'status': 'ok', 'version': __version__, 'application': 'Murer Group Stats',
                'database_ok': state.database_ok, 'startup_nonce': os.environ.get('MURER_UPDATE_NONCE'),
                'launch_session': os.environ.get('MURER_LAUNCHER_SESSION')}

    def log_filters(domains: str | None = None, levels: str | None = None, kinds: str | None = None,
                    accounts: str | None = None, run_id: str = '', q: str = '', before: int = 0, until: int = 0):
        if before < 0 or until < 0:
            raise ValueError('Курсор журнала не может быть отрицательным')
        for value, allowed in ((domains, DOMAINS), (levels, LEVELS), (kinds, KINDS)):
            if value is not None and any(v not in allowed for v in ids(value)):
                raise ValueError('Неизвестный фильтр журнала')
        account_filter = [a if a != '@none' else '' for a in ids(accounts)] if accounts is not None else None
        return dict(domains=ids(domains), levels=ids(levels), kinds=ids(kinds), accounts=account_filter,
                    run_id=run_id, q=q, before=before, until=until)

    @app.get('/api/logs/options')
    def log_options():
        return {'domains': DOMAINS, 'levels': LEVELS, 'kinds': KINDS}

    @app.get('/api/logs')
    def logs(domains: str | None = None, levels: str | None = None, kinds: str | None = None,
             accounts: str | None = None, run_id: str = '', q: str = '', before: int = 0, until: int = 0,
             limit: int = Query(default=100, ge=1, le=500)):
        return state.events.query(limit=limit, **log_filters(domains, levels, kinds, accounts, run_id, q, before, until))

    @app.get('/api/logs/export')
    def log_export(domains: str | None = None, levels: str | None = None, kinds: str | None = None,
                   accounts: str | None = None, run_id: str = '', q: str = '', until: int = 0):
        filters = log_filters(domains, levels, kinds, accounts, run_id, q, until=until)
        # A bounded snapshot, captured under the journal lock. Export never
        # follows a growing stream and cannot include events from the future.
        with state.events.lock:
            filters['until'] = until or state.events.query(limit=1)['latest_id']
            rows = []
            while True:
                page = state.events.query(limit=500, **filters)
                rows.extend(page['items'])
                if not page['has_more']:
                    break
                filters['before'] = page['next_before']
        content = '\n'.join(encode(row) for row in rows)
        return Response(content, media_type='application/x-ndjson', headers={
            'Content-Disposition': 'attachment; filename="murer-logs.jsonl"',
            'X-Log-Warning': 'memory-fallback' if page['warning'] else ''})

    @app.get('/api/updates')
    def update_status():
        return state.updates.status()

    @app.put('/api/updates/settings')
    def update_settings(body: dict):
        return state.updates.configure(body)

    @app.post('/api/updates/check')
    def update_check():
        return state.updates.check()

    @app.post('/api/updates/download')
    def update_download():
        return state.updates.download()

    @app.post('/api/updates/install')
    def update_install():
        if not state.shutdown_callback or not state.loop:
            raise HTTPException(409, 'Установка доступна при запуске через start.cmd.')
        result = state.updates.request_install()
        state.installing = True
        state.publish({'type': 'update_install', **result})
        state.loop.call_soon_threadsafe(lambda: state.loop.call_later(.5, state.shutdown_callback))
        return result

    @app.post('/api/updates/rollback')
    def update_rollback():
        if not state.shutdown_callback or not state.loop:
            raise HTTPException(409, 'Возврат версии доступен при запуске через start.cmd.')
        result = state.updates.request_install(True)
        state.installing = True
        state.publish({'type': 'update_install', **result})
        state.loop.call_soon_threadsafe(lambda: state.loop.call_later(.5, state.shutdown_callback))
        return result

    @app.post('/api/shutdown')
    async def shutdown():
        if not state.shutdown_callback:
            raise HTTPException(409, 'В этом режиме завершите сервер из окна запуска')
        state.shutting_down = True
        state.publish({'type': 'shutdown'})
        state.shutdown_callback()
        return {'status': 'stopping', 'message': 'Задания сохраняются; принадлежащие приложению браузеры будут закрыты'}

    @app.get('/api/bootstrap')
    def bootstrap():
        settings, version = state.store.settings()
        return {'accounts': state.public_accounts(), 'settings': settings, 'defaults': default_settings(),
                'settings_version': version, 'setup': state.configuration, 'jobs': state.store.jobs(),
                'rule_sets': rule_sets(), 'speed_presets': speed_presets(), 'trade_active_id': state.jobs.priority_owner,
                'trade_attention':state.trades.attention(),
                'app_version': __version__, 'update_status': state.updates.status()}

    @app.get('/api/trade')
    def trade_overview():
        settings, version = state.store.settings()
        return {'config': state.trades.configuration_value(), 'accounts': state.trades.accounts(),
                'speed_settings': settings['trade'], 'speed_defaults': default_settings()['trade'],
                'speed_presets': trade_speed_presets(), 'settings_version': version,
                'history': state.trades.history(), 'capabilities': state.store.rows('SELECT c.*,g.name AS group_name FROM trade_capabilities c JOIN groups g ON g.id=c.group_id'),
                'relationships': state.store.rows('SELECT account_id,username,following,follows_us,observed_at FROM trade_relationships'),
                'active_id': state.jobs.priority_owner,'attention':state.trades.attention()}

    @app.get('/api/trade/status')
    def trade_status():
        return {'active_id':state.jobs.priority_owner,'attention':state.trades.attention()}

    @app.put('/api/trade/settings')
    def trade_speed_update(body: dict):
        if set(body) != {'settings', 'previous'}:
            raise ValueError('Укажите настройки Trade и их предыдущие значения')
        trade = validate_trade_settings(body['settings'])
        with state.lock:
            settings, _ = state.store.settings()
            if body['previous'] != settings['trade']:
                raise HTTPException(409, 'Настройки Trade изменены в другом окне. Загрузите сохранённые значения и повторите изменение.')
            settings['trade'] = trade
            version = state.store.save_settings(settings)
        state.store.event('trade', 'settings', 'Скорость Trade сохранена; применяется при следующем запуске или продолжении',
                          details={'settings_version': version, 'trade': trade})
        state.publish({'type': 'settings', 'settings_version': version})
        return {'settings': trade, 'version': version}

    @app.post('/api/trade/preview')
    def trade_preview(body: dict):
        return state.trades.preview(body)

    @app.get('/api/trade/runs/{run_id}')
    def trade_detail(run_id: str):
        return state.trades.run(run_id)

    @app.post('/api/trade/runs/{run_id}/start')
    def trade_start(run_id: str, body: dict):
        if state.shutting_down:
            raise ValueError('Приложение завершает работу')
        if set(body)-{'checks_only','verify_only','preparation_id'} or any(not isinstance(body.get(key, False), bool) for key in ('checks_only','verify_only')) or (body.get('checks_only') and body.get('verify_only')):
            raise ValueError('Некорректный режим запуска Trade')
        return state.trades.start(run_id, body.get('checks_only', False), body.get('verify_only', False),preparation_id=body.get('preparation_id'))

    @app.post('/api/trade/runs/{run_id}/prepare')
    def trade_prepare(run_id: str):
        if state.shutting_down:
            raise ValueError('Приложение завершает работу')
        return state.trades.start(run_id,prepare_only=True)

    @app.post('/api/trade/runs/{run_id}/confirm-incoming')
    def trade_confirm_incoming(run_id: str, body: dict):
        if set(body)!={'acknowledgement'}:
            raise ValueError('Подтвердите личную проверку входящих групп')
        return state.trades.confirm_incoming(run_id,body['acknowledgement'])

    @app.post('/api/trade/runs/{run_id}/incoming')
    def trade_incoming(run_id: str):
        if not state.trades.run(run_id)['baseline']:
            raise ValueError('Сначала запустите Trade, чтобы сохранить начальный список групп')
        return state.trades.start(run_id, incoming_only=True)

    @app.post('/api/trade/runs/{run_id}/accounts')
    def trade_add_sender(run_id: str, body: dict):
        if set(body) != {'account_id'} or not isinstance(body['account_id'],str):
            raise ValueError('Выберите аккаунт для продолжения Trade')
        return state.trades.add_account(run_id,body['account_id'])

    @app.post('/api/trade/runs/{run_id}/finish')
    def trade_finish(run_id: str, body: dict):
        if set(body)-{'accept_unverified'} or not isinstance(body.get('accept_unverified',False),bool):
            raise ValueError('Некорректное завершение Trade')
        return state.trades.finish(run_id,body.get('accept_unverified',False))

    @app.post('/api/trade/members/recheck')
    def trade_member_recheck(body: dict):
        if state.jobs.priority_owner:
            raise ValueError('Завершите активный Trade перед сбросом сохранённой отметки')
        if set(body) != {'group_id','username'}:
            raise ValueError('Укажите группу и получателя')
        name = usernames([body['username']])[0]
        if not isinstance(body['group_id'],str) or not state.store.rows('SELECT id FROM groups WHERE id=?',(body['group_id'],)):
            raise ValueError('Группа не найдена')
        with state.store.connection() as db:
            db.execute('DELETE FROM trade_member_observations WHERE group_id=? AND username=?',(body['group_id'],name))
            db.execute('INSERT OR REPLACE INTO trade_member_rechecks VALUES(?,?,?)',(body['group_id'],name,utcnow()))
        return {'status':'cleared'}

    @app.post('/api/trade/runs/{run_id}/command/{action}')
    def trade_command(run_id: str, action: str):
        return state.trades.command(run_id, action)

    @app.post('/api/trade/capabilities/recheck')
    def trade_recheck(body: dict):
        if state.jobs.priority_owner:
            raise ValueError('Дождитесь завершения Trade')
        if set(body) != {'group_id','account_id'} or not state.store.rows('SELECT group_id FROM trade_capabilities WHERE group_id=? AND account_id=?', (body.get('group_id'),body.get('account_id'))):
            raise ValueError('Сохранённое ограничение этой группы и аккаунта не найдено')
        state.store.execute("UPDATE trade_capabilities SET state='unknown',reason='Запрошена повторная проверка' WHERE group_id=? AND account_id=?", (body.get('group_id'), body.get('account_id')))
        return {'status': 'unknown'}

    @app.get('/api/trade/runs/{run_id}/export')
    def trade_export(run_id: str):
        run = state.trades.run(run_id)
        rows = [{'direction':'outgoing','recipient': item['recipient'], 'group': item['group_name'], 'url': item['url'],
                 'quality': item['quality'], 'score': item['score'], 'status': item['status'], 'reason': item['reason'],
                 'source_account_id':item['source_account_id'] or run['config']['send_account_id'], 'date': item['updated_at']} for item in run['attempts']]
        rows.extend({'direction':'incoming','recipient':run['plan']['receive_username'],'group':group.get('name') or group['x_id'],
                     'url':group['url'],'status':'observed_new','reason':run['incoming'].get('attribution',''),
                     'source_account_id':run['config']['receive_account_id'],'date':run['incoming'].get('checked_at')} for group in run['incoming'].get('groups',[]))
        return Response(csv_report(rows, metadata={'created_at':run['created_at'], 'settings_version':run['settings_version'], 'quality':run['config']['quality'], 'per_recipient':run['config']['count'],
                    'incoming_expected':run['plan']['total_requested'],'incoming_observed':run['incoming'].get('observed_count'),
                    'incoming_verdict':run['incoming'].get('verdict','not_checked')}),
            media_type='text/csv; charset=utf-8', headers={'Content-Disposition':f'attachment; filename="trade-{run_id}.csv"'})

    @app.get('/api/accounts')
    def accounts():
        return state.public_accounts()

    @app.get('/api/accounts/{account_id}/username-history')
    def account_username_history(account_id: str):
        if not state.store.account(account_id):
            raise HTTPException(404,'Аккаунт не найден')
        return state.store.rows('SELECT old_username,username,x_id,origin,observed_at FROM account_identity_events WHERE account_id=? ORDER BY id DESC',(account_id,))

    @app.post('/api/accounts')
    def account_add(body: dict):
        return state.save_account(body)

    @app.post('/api/accounts/ichat-password/bulk')
    def ichat_password_bulk(body: dict):
        return state.bulk_ichat_password(body)

    @app.patch('/api/accounts/{account_id}')
    def account_edit(account_id: str, body: dict):
        return state.save_account(body, account_id)

    @app.delete('/api/accounts/{account_id}')
    def account_delete(account_id: str):
        return state.save_account({'archived': True}, account_id)

    @app.post('/api/import/preview')
    def import_preview(body: dict):
        return preview_import(body.get('text', ''), [a['username'] for a in state.store.accounts()])[0]

    @app.post('/api/import')
    def import_apply(body: dict):
        preview, valid = preview_import(body.get('text', ''), [a['username'] for a in state.store.accounts()])
        if preview['errors']:
            raise ValueError('Исправьте ошибки предварительного просмотра перед импортом')
        existing = {a['username']: a['id'] for a in state.store.accounts()}
        results = [state.save_account(values, existing.get(values['username'])) for values in valid]
        return {'accounts': results, 'imported': len(results)}

    @app.get('/api/analysis')
    def analysis(account_ids: str | None = None, group_ids: str | None = None, run_id: str | None = None,
                 mode: str = 'current', include_posts: bool = False):
        result = state.calculate(ids(account_ids), ids(group_ids), run_id, mode)
        if include_posts:
            return result
        # Tables need aggregate evidence, not every card body in the whole base.
        # Detail and full export still use the unchanged cached observations.
        return {**result, 'participants': [{k: v for k, v in participant.items() if k != 'posts'}
                                          for participant in result['participants']]}

    @app.get('/api/compare')
    def compare(kind: str, a: str, b: str, account_ids: str | None = None, group_ids: str | None = None,
                run_id: str | None = None, mode: str = 'current'):
        from .analytics import compare_pair
        settings, version = state.store.settings()
        dataset, reference = None, None
        if run_id:
            rows = state.store.rows('SELECT dataset,created_at FROM run_snapshots WHERE job_id=?', (run_id,))
            if not rows:
                raise ValueError('Снимок не найден')
            dataset, reference = json.loads(rows[0]['dataset']), rows[0]['created_at']
            if mode == 'collection':
                job = state.store.job(run_id)
                settings, version = job['settings'], job['settings_version']
        return {**compare_pair(dataset or state.store.dataset(), settings, kind, a, b,
                    account_ids=ids(account_ids), group_ids=ids(group_ids), now=reference), 'settings_version': version}

    @app.get('/api/groups/{group_id}')
    def group_detail(group_id: str):
        group = next((g for g in state.calculate()['groups'] if g['id'] == group_id), None)
        if not group:
            raise HTTPException(404, 'Группа не найдена')
        return group

    @app.get('/api/participants/{participant_id}')
    def participant_detail(participant_id: str, account_ids: str | None = None, group_ids: str | None = None,
                           run_id: str | None = None, mode: str = 'current'):
        result = state.calculate(ids(account_ids), ids(group_ids), run_id, mode)
        participant = next((p for p in result['participants'] if p['id'] == participant_id), None)
        if not participant:
            raise HTTPException(404, 'Участник не найден в выбранной области')
        return participant

    @app.patch('/api/groups/{group_id}')
    def group_edit(group_id: str, body: dict):
        values = {}
        if 'allowance' in body:
            allowance = body['allowance']
            if allowance is not None and (isinstance(allowance, bool) or not isinstance(allowance, int) or allowance < 0):
                raise ValueError('Разрешённое количество должно быть целым неотрицательным числом')
            values['allowance'] = allowance
        if 'unlimited' in body:
            if not isinstance(body['unlimited'], bool):
                raise ValueError('Некорректный режим ограничения')
            values['unlimited'] = int(body['unlimited'])
        for field in ('pinned_account_ids', 'exempt_account_ids'):
            if field in body:
                known = {a['id'] for a in state.store.accounts()}
                pinned = body[field]
                if not isinstance(pinned, list) or any(x not in known for x in pinned):
                    raise ValueError('Неизвестный закреплённый аккаунт или исключение')
                values[field] = encode(list(dict.fromkeys(pinned)))
        if not values:
            raise ValueError('Нет настроек группы для сохранения')
        state.store.execute('UPDATE groups SET '+','.join(k+'=?' for k in values)+' WHERE id=?', (*values.values(), group_id))
        state.publish({'type': 'analysis'})
        return {'saved': True}

    @app.put('/api/settings')
    def settings_update(body: dict, request: Request):
        sections = request.headers.get('x-settings-sections')
        sections = sections.split(',') if sections is not None else None
        if sections is not None and (not sections or set(sections) - {'collection', 'humanization', 'evaluation', 'own_accounts'}):
            raise ValueError('Неизвестный раздел настроек')
        client = request.headers.get('x-settings-client')
        revision = request.headers.get('x-settings-revision')
        if revision is not None:
            try:
                revision = int(revision)
            except ValueError:
                raise ValueError('Некорректная версия изменения настроек')
        with state.lock:
            # The collection editor must not overwrite a newer Trade draft from another tab.
            current, _ = state.store.settings()
            settings = validate_settings({**current, **{key: body[key] for key in sections if key in body}} if sections is not None else body)
            if client and revision is not None:
                if revision <= state.settings_revisions.get(client, -1):
                    raise HTTPException(409, 'Более новое изменение уже сохранено')
                state.settings_revisions[client] = revision
            version = state.store.save_settings(settings)
            state.analysis_cache.clear()
            result = state.calculate()
        state.publish({'type': 'settings', 'settings_version': version})
        return {'settings': settings, 'version': version, 'analysis': result}

    @app.get('/api/rule-sets')
    def rule_sets():
        return [{**row, 'settings': json.loads(row['settings'])} for row in state.store.rows('SELECT * FROM rule_sets ORDER BY created_at DESC')]

    @app.post('/api/rule-sets')
    def rule_set_add(body: dict):
        name = str(body.get('name', '')).strip()[:100]
        if not name:
            raise ValueError('Введите название набора правил')
        settings = validate_settings(body.get('settings') or state.store.settings()[0])
        rid = str(uuid4())
        state.store.execute('INSERT INTO rule_sets VALUES(?,?,?,?)', (rid, name, encode(settings), utcnow()))
        return {'id': rid, 'name': name, 'settings': settings}

    @app.post('/api/rule-sets/{rule_id}/apply')
    def rule_set_apply(rule_id: str, request: Request):
        rows = state.store.rows('SELECT settings FROM rule_sets WHERE id=?', (rule_id,))
        if not rows:
            raise HTTPException(404, 'Набор не найден')
        return settings_update(json.loads(rows[0]['settings']), request)

    @app.get('/api/jobs')
    def jobs():
        return state.store.jobs()

    @app.post('/api/jobs')
    def job_start(body: dict):
        if state.shutting_down:
            raise ValueError('Приложение завершает работу')
        check = browser_check(state.configuration['chrome_path'], state.configuration['driver_path'])
        if not check['compatible'] and session_factory is None:
            raise ValueError('Проверьте пути и совместимость Chrome/ChromeDriver в настройках: '+ '; '.join(check['errors']))
        return state.jobs.start(body.get('account_ids', []), body.get('mode', 'collect'), body.get('group_ids'))

    @app.post('/api/jobs/{job_id}/{action}')
    def job_command(job_id: str, action: str):
        return state.jobs.command(job_id, action)

    @app.get('/api/history')
    def history():
        snapshots = {r['job_id']: r for r in state.store.rows('SELECT job_id,created_at,settings_version FROM run_snapshots')}
        return [{**job, 'snapshot': snapshots.get(job['id']), 'errors': state.store.rows('SELECT * FROM errors WHERE job_id=?', (job['id'],))} for job in state.store.jobs()]

    @app.get('/api/history/{job_id}/changes')
    def history_changes(job_id: str):
        from .history import changes_between
        rows = state.store.rows('SELECT * FROM run_snapshots WHERE job_id=?', (job_id,))
        if not rows:
            raise ValueError('Снимок ещё не сохранён')
        current = rows[0]
        earlier = state.store.rows('SELECT * FROM run_snapshots WHERE created_at<? ORDER BY created_at DESC LIMIT 1', (current['created_at'],))
        if not earlier:
            return {'previous_job_id': None, 'current_job_id': job_id, 'groups': [], 'reason': 'Это первый сохранённый снимок; сравнение ещё недоступно'}
        previous = earlier[0]
        old_analysis = json.loads(previous['analysis'])
        new_analysis = json.loads(current['analysis'])
        old_job, new_job = state.store.job(previous['job_id']), state.store.job(job_id)
        same_scope = set(old_job['account_ids']) == set(new_job['account_ids']) and set(old_job['group_ids']) == set(new_job['group_ids'])
        old_analysis['settings'], new_analysis['settings'] = old_job['settings'], new_job['settings']
        result = changes_between(json.loads(previous['dataset']), json.loads(current['dataset']), old_analysis, new_analysis)
        if not same_scope:
            for group in result['groups']:
                group['scores_comparable'], group['score_difference'] = False, None
        return {**result, 'previous_job_id': previous['job_id'], 'current_job_id': job_id,
            'previous_at': previous['created_at'], 'current_at': current['created_at'], 'same_collection_scope': same_scope,
            'same_rules': old_job['settings'] == new_job['settings']}

    @app.post('/api/setup/check')
    def setup_check(body: dict):
        result = browser_check(body.get('chrome_path', ''), body.get('driver_path', ''))
        if body.get('launch') and result['compatible']:
            from .diagnostics import launch_check
            result.update(asyncio.run(launch_check(body['chrome_path'], body['driver_path'])))
        return result

    @app.post('/api/setup')
    def setup_save(body: dict):
        with state.jobs.lock:
            return setup_save_locked(body)

    def setup_save_locked(body):
        if state.jobs.priority_owner or any(t.is_alive() for t in state.jobs.threads.values()):
            raise ValueError('Пути браузера можно менять после окончания задания')
        config = {**state.configuration, **{k: str(body[k]) for k in ('data_dir', 'chrome_path', 'driver_path') if k in body}}
        target = Path(config['data_dir']).resolve()
        if target != state.store.data_dir.resolve():
            if state.store.accounts() or state.store.rows('SELECT id FROM groups LIMIT 1') or state.store.jobs():
                raise ValueError('Папка данных уже содержит базу. Для переноса остановите приложение и скопируйте всю папку; затем измените bootstrap.json по инструкции README.')
            new_store = Store(target)
            state.events.emit('system', 'settings', 'Выбрана другая папка локальных данных')
            new_events = EventLog(target)
            new_events.protect(state.events.private)
            state.events.close()
            if state.loop:
                new_events.start()
            state.events = new_events
            new_store.audit, new_store.protect = new_events.emit, new_events.protect
            state.secrets.protect = new_events.protect
            new_events.emit('system', 'lifecycle', 'Журнал подключён к выбранной папке данных')
            if not new_store.settings()[0]:
                new_store.save_settings(state.store.settings()[0])
            else:
                previous_settings, _ = new_store.settings()
                migrated_settings = validate_settings(previous_settings)
                if migrated_settings != previous_settings:
                    new_store.save_settings(migrated_settings)
            state.store = new_store
            state.jobs.store = new_store
            state.trades.store = new_store
            state.updates.store = new_store
            state.jobs.recover_store()
            state.trades.recover_store()
        config['data_dir'] = str(target)
        config['configured'] = True
        config['browser_check'] = browser_check(config['chrome_path'], config['driver_path'])
        state.configuration.clear()
        state.configuration.update(config)
        if data_dir is None:
            save_configuration(config)
        state.publish({'type': 'settings'})
        return config

    @app.get('/api/export')
    def export(format: str = 'csv', table: str = 'groups', account_ids: str | None = None, group_ids: str | None = None,
               search: str = '', columns: str | None = None, sort: str | None = None, descending: bool = False,
               run_id: str | None = None, mode: str = 'current', row_ids: str | None = None):
        if table not in TABLES or format not in ('csv', 'xlsx'):
            raise ValueError('Неподдерживаемая таблица или формат')
        with state.lock, state.store.lock:
            state.analysis_cache.clear()
            result = state.calculate(ids(account_ids), ids(group_ids), run_id, mode)
            if run_id:
                export_dataset = json.loads(state.store.rows('SELECT dataset FROM run_snapshots WHERE job_id=?', (run_id,))[0]['dataset'])
            else:
                export_dataset = state.store.dataset()
        metadata = {'Дата экспорта': utcnow(), 'Аккаунты области': ids(account_ids), 'Группы сравнения': ids(group_ids),
                    'Версия правил': result['settings_version'], 'Правила': result['settings'], 'Полнота': result.get('coverage'),
                    'Сводка': result['summary'], 'Снимок': run_id, 'Режим': mode}
        accounts = export_dataset.get('accounts', []) if run_id else state.public_accounts()
        if account_ids is not None:
            selected_accounts = set(ids(account_ids))
            accounts = [a for a in accounts if a['id'] in selected_accounts]
        if format == 'csv':
            source_rows = accounts if table == 'accounts' else result.get(table, [])
            rows = filtered_rows(source_rows, '' if row_ids is not None else search,
                                 None if row_ids is not None else sort, descending)
            if row_ids is not None:
                try:
                    selected = json.loads(row_ids)
                except json.JSONDecodeError as error:
                    raise ValueError('Некорректный набор строк экспорта') from error
                if not isinstance(selected, list) or any(not isinstance(x, str) for x in selected):
                    raise ValueError('Некорректный набор строк экспорта')
                selected_order = {key: index for index, key in enumerate(selected)}
                def identity(row):
                    if table == 'overlaps':
                        return f"{row['group_a_id']}:{row['group_b_id']}"
                    if table == 'account_overlaps':
                        return f"{row['account_a_id']}:{row['account_b_id']}"
                    if table == 'own_accounts':
                        return str(row['group_id'])
                    if table == 'recommendations':
                        return f"{row.get('group_id', '')}:{row.get('kind', '')}:{row.get('text', '')}"
                    return str(row['id'])
                rows = [row for row in rows if identity(row) in selected_order]
                rows.sort(key=lambda row: selected_order[identity(row)])
            for row in rows:
                row['export_metadata'] = metadata
            body = csv_report(rows, ids(columns), metadata)
            media = 'text/csv; charset=utf-8'
        else:
            body = excel_report(result, accounts, metadata, export_dataset)
            media = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
        return Response(body, media_type=media, headers={'Content-Disposition': f'attachment; filename="murer-{table}.{format}"'})

    @app.post('/api/export')
    def export_post(body: dict):
        allowed = {'format', 'table', 'account_ids', 'group_ids', 'search', 'columns', 'sort', 'descending', 'run_id', 'mode', 'row_ids'}
        if set(body)-allowed:
            raise ValueError('Неизвестные параметры экспорта')
        body = dict(body)
        for key in ('account_ids', 'group_ids', 'columns'):
            if isinstance(body.get(key), list):
                body[key] = ','.join(str(x) for x in body[key])
        if isinstance(body.get('row_ids'), list):
            body['row_ids'] = encode(body['row_ids'])
        if 'descending' in body and isinstance(body['descending'], str):
            body['descending'] = body['descending'].lower() == 'true'
        return export(**body)

    @app.get('/api/events')
    async def events(request: Request):
        queue = asyncio.Queue(maxsize=128)
        state.subscribers.add(queue)
        async def stream():
            try:
                yield 'data: {"type":"connected"}\n\n'
                while not await request.is_disconnected():
                    try:
                        event = await asyncio.wait_for(queue.get(), timeout=20)
                        yield 'data: '+encode(event)+'\n\n'
                        if event.get('type') == 'shutdown':
                            return
                    except asyncio.TimeoutError:
                        yield ': keepalive\n\n'
            finally:
                state.subscribers.discard(queue)
        return StreamingResponse(stream(), media_type='text/event-stream', headers={'Cache-Control': 'no-cache'})

    dist = Path(__file__).resolve().parent.parent / 'frontend' / 'dist'
    if (dist / 'index.html').is_file():
        app.mount('/assets', StaticFiles(directory=dist / 'assets', check_dir=False), name='assets')
        @app.get('/{path:path}')
        def frontend(path: str):
            if path.startswith('api/'):
                raise HTTPException(404)
            candidate = (dist / path).resolve()
            if dist.resolve() in candidate.parents and candidate.is_file():
                return FileResponse(candidate)
            if not (dist / 'index.html').is_file():
                return JSONResponse({'detail': 'Интерфейс пересобирается. Обновите страницу после окончания сборки.'}, status_code=503)
            return FileResponse(dist / 'index.html')
    else:
        @app.get('/')
        def missing_frontend():
            return JSONResponse({'detail': 'Интерфейс не собран. Запустите install.cmd.'}, status_code=503)
    return app
