import csv
import io
import json
import re
from .secrets import validate_ichat_password


def validate_account(values, partial=False):
    if not isinstance(values, dict):
        raise ValueError('Аккаунт должен быть объектом JSON')
    allowed = {'username', 'password', 'ichat_password', 'ichat_password_confirmation', 'ichat_auto_setup', 'proxy', 'user_agent', 'headless', 'group', 'auth_token', 'ct0_token', 'x_id', 'is_ours', 'archived'}
    extra = set(values) - allowed
    if extra:
        raise ValueError('Неизвестные поля: ' + ', '.join(sorted(extra)))
    data = dict(values)
    if data.get('ichat_password') is not None:
        validate_ichat_password(data['ichat_password'])
    if not partial or 'username' in data:
        username = str(data.get('username', '')).strip().lstrip('@')
        if not re.fullmatch(r'[A-Za-z0-9_]{1,15}', username):
            raise ValueError('Username: 1–15 латинских букв, цифр или _')
        data['username'] = username.lower()
    if data.get('x_id') and not re.fullmatch(r'\d+', str(data['x_id'])):
        raise ValueError('ID X должен содержать только цифры')
    for field in ('headless', 'is_ours', 'archived', 'ichat_auto_setup'):
        if field in data and not isinstance(data[field], bool):
            if data[field] in ('true', 'false', '1', '0', ''):
                data[field] = data[field] in ('true', '1')
            else:
                raise ValueError(field + ': требуется true или false')
    confirmation = data.get('ichat_password_confirmation')
    if confirmation is not None:
        validate_ichat_password(confirmation)
        if confirmation != data.get('ichat_password'):
            raise ValueError('Пароль/PIN iChat и подтверждение не совпадают')
    if data.get('ichat_auto_setup') and data.get('ichat_password') and confirmation is None:
        raise ValueError('Для автоматической настройки подтвердите пароль/PIN iChat вторым вводом')
    if data.get('proxy') and (not isinstance(data['proxy'], str) or '\n' in data['proxy'] or len(data['proxy']) > 1000):
        raise ValueError('Некорректный формат прокси')
    for field in ('password', 'auth_token', 'ct0_token', 'proxy', 'user_agent', 'group'):
        if field in data and data[field] is not None:
            if not isinstance(data[field], str) or len(data[field]) > 2000:
                raise ValueError(field + ': требуется строка до 2000 символов')
    return data


def preview_import(text, existing=()):
    if len(text) > 5_000_000:
        raise ValueError('Файл импорта превышает 5 МБ')
    try:
        if text.lstrip().startswith(('{', '[')):
            data = json.loads(text)
            data = data.get('accounts', []) if isinstance(data, dict) else data
            if not isinstance(data, list):
                raise ValueError('Ожидается массив accounts')
        else:
            dialect = csv.Sniffer().sniff(text[:4000], delimiters=',;\t')
            data = list(csv.DictReader(io.StringIO(text), dialect=dialect))
    except (ValueError, csv.Error) as error:
        raise ValueError('Не удалось прочитать JSON/CSV: проверьте формат') from error
    rows, valid, seen = [], [], set()
    existing = {x.lower(): x for x in existing}
    for index, values in enumerate(data, 1):
        errors = []
        try:
            values = validate_account(values)
            username = values['username']
            if username in seen:
                errors.append('Повтор username в файле')
            seen.add(username)
            if not errors:
                valid.append(values)
        except ValueError as error:
            errors.append(str(error))
            username = str(values.get('username', '')) if isinstance(values, dict) else ''
        rows.append({'index': index, 'username': username, 'valid': not errors, 'errors': errors, 'action': 'update' if username in existing else 'add'})
    return {'rows': rows, 'errors': [f"Строка {r['index']}: {e}" for r in rows for e in r['errors']], 'valid_count': len(valid)}, valid
