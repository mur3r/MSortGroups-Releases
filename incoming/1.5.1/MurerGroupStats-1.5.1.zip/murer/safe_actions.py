"""Read-only Selenium actions. These helpers never press Enter or send messages."""
from __future__ import annotations

import asyncio
import inspect
import random
import time
from typing import Callable

from human1 import Humanizer
from selenium.webdriver.support.ui import WebDriverWait
from xgenius.core.dom import DEEP_QUERY_JS
from xgenius.core.chat_list import CHAT_SCROLLER_JS
from xgenius.core.network import ConnectionFailure, connection_failure, probe_connection


async def invoke(callback: Callable | None, *args):
    if callback is None:
        return None
    result = callback(*args)
    return await result if inspect.isawaitable(result) else result


class SafeActions:
    def __init__(self, browser, settings, checkpoint=None, audit=None, proxy_configured=False):
        self.browser = browser
        self.settings = settings
        self.checkpoint = checkpoint
        self.baseline = Humanizer()
        self.audit = audit
        self.proxy_configured = proxy_configured

    def record(self, kind, message, **context):
        if self.audit:
            error_type = (context.get('details') or {}).get('error_type')
            level = ('warning' if error_type in ('TimeoutException','NoSuchElementException','StaleElementReferenceException') else 'error') if kind == 'error' else 'debug'
            self.audit(message, domain='browser', kind=kind, level=level, **context)

    async def boundary(self):
        await invoke(self.checkpoint)

    async def call(self, function, *, action='Команда WebDriver', details=None, record=True):
        await self.boundary()
        started = time.monotonic()
        if record:
            self.record('command', action + ': начало', details=details)
        # Caller owns this browser's sequential queue; every call is awaited.
        try:
            result = await asyncio.get_running_loop().run_in_executor(None, function)
        except Exception as error:
            if record:
                self.record('error', action + ': ошибка', details={'error_type': type(error).__name__})
            failure = connection_failure(error,self.proxy_configured)
            if failure:
                raise ConnectionFailure(failure) from error
            raise
        if record:
            self.record('command', action + ': завершено', details={'duration_ms': round((time.monotonic()-started)*1000),
                'result_type': type(result).__name__, 'items': len(result) if isinstance(result, (list, tuple)) else None})
        return result

    async def sleep(self, seconds):
        remaining = max(0.0, float(seconds))
        if remaining >= .5:
            self.record('wait', 'Задержка между действиями', details={'seconds': remaining})
        while remaining > 0:
            await self.boundary()
            portion = min(remaining, 0.25)
            await asyncio.sleep(portion)
            remaining -= portion

    async def delay(self):
        human = self.settings.get("humanization", {})
        collection = self.settings.get("collection", self.settings)
        if human.get("enabled", False):
            low = float(human.get("action_delay_min", self.baseline.pause_between_actions[0]))
            high = float(human.get("action_delay_max", self.baseline.pause_between_actions[1]))
            await self.sleep(random.uniform(low, high))
        else:
            await self.sleep(collection.get("action_delay_seconds", 0.5))

    async def get(self, url):
        self.record('navigation', 'Открытие страницы', details={'url': url})
        await self.call(lambda: self.browser.get(url), action='Переход по адресу')
        await self.check_connection()
        await self.delay()

    async def check_connection(self):
        result = await self.call(lambda: probe_connection(self.browser,self.proxy_configured),
                                 action='Проверка сетевой ошибки Chrome',record=False)
        if result:
            raise ConnectionFailure(result)

    async def script(self, script, *args):
        return await self.call(lambda: self.browser.execute_script(script, *args), action='Чтение и обработка DOM')

    async def wait(self, selector, timeout=15):
        def ready(browser):
            element = browser.execute_script(DEEP_QUERY_JS + 'return deepQuery(arguments[0]);',selector)
            if not element:
                failure = probe_connection(browser,self.proxy_configured)
                if failure:
                    raise ConnectionFailure(failure)
            return element or False
        return await self.call(lambda: WebDriverWait(self.browser, timeout).until(ready),
            action='Ожидание элемента', details={'selector': selector, 'timeout': timeout})

    async def find_all(self, selector):
        return await self.script(DEEP_QUERY_JS + 'return deepQueryAll(arguments[0]);', selector)

    async def click(self, element):
        # Deliberately reject known write controls even if a selector is wrong.
        label = await self.call(lambda: " ".join(str(element.get_attribute(key) or "")
            for key in ("data-testid", "aria-label", "title")))
        if any(token in label.lower() for token in ("send", "отправ", "retweet", "repost", "like", "follow", "leave", "join")):
            self.record('error', 'Нажатие запрещено: элемент изменяет аккаунт')
            raise ValueError("Действие изменяет аккаунт и запрещено сборщиком")
        await self.call(element.click, action='Нажатие безопасного элемента')
        await self.delay()

    async def search_input(self, element, text):
        """Character input for search only; rejects composers and line breaks."""
        if "\n" in text or "\r" in text or any(0xE000 <= ord(char) <= 0xF8FF for char in text):
            raise ValueError("Поисковый запрос не может содержать перевод строки")
        attrs = await self.call(lambda: {
            key: str(element.get_attribute(key) or "")
            for key in ("type", "role", "data-testid", "aria-label", "placeholder")})
        marker = " ".join(attrs.values()).lower()
        if any(value in marker for value in ("composer", "message", "сообщен")) or not (
            attrs["type"] == "search" or "search" in marker or "поиск" in marker):
            raise ValueError("Безопасный ввод разрешён только в поле поиска")
        self.record('input', 'Ввод поискового запроса: начало')
        await self.call(element.clear, record=False)
        human = self.settings.get("humanization", {})
        speed = self.baseline.typing_speed["normal"]
        for char in text:
            await self.call(lambda char=char: element.send_keys(char), record=False)
            if human.get("enabled", False):
                await self.sleep(random.uniform(float(human.get("typing_delay_min", speed[0])),
                                               float(human.get("typing_delay_max", speed[1]))))

        self.record('input', 'Ввод поискового запроса: завершено')

    async def setup_input(self,element,text,*,segmented=False):
        from .ichat_setup import ICHAT_SETUP_PROBE_JS
        probe=await self.script(ICHAT_SETUP_PROBE_JS)
        if probe.get('state') not in ('create','paired','confirm') or element not in probe.get('fields',[]):
            raise ValueError('Поле первоначальной настройки iChat больше не подтверждено')
        await self.unlock_input(element,text,segmented=segmented,initial_setup=True)

    async def unlock_input(self, element, text, *, segmented=False,initial_setup=False):
        """Only IChatUnlock's verified gate calls this; never press Enter.

        Recheck the element immediately before input, since a page may change
        between detecting an unlock form and operating on its fields.
        """
        if not text or any(ord(char) < 32 or ord(char) == 127 or 0xE000 <= ord(char) <= 0xF8FF for char in text):
            raise ValueError("Некорректные символы пароля/PIN iChat")
        attrs = await self.call(lambda: {key: str(element.get_attribute(key) or "")
            for key in ("type", "maxlength", "inputmode", "name", "id", "autocomplete", "data-testid", "aria-label", "placeholder")})
        marker = " ".join(attrs.values()).lower()
        forbidden=("one-time-code", "verif", "otp", "captcha", "composer", "recovery") + (() if initial_setup else ("confirm", "new-password"))
        if any(value in marker for value in forbidden):
            raise ValueError("Поле не является существующим паролем/PIN iChat")
        if segmented:
            if attrs["maxlength"] != "1" or not text.isascii() or not text.isdigit() or len(text) != 1:
                raise ValueError("Сегмент PIN должен содержать одну цифру")
            if attrs["type"] not in ("password", "text", "tel", "number") or not (
                attrs["inputmode"] in ("numeric", "decimal") or any(value in marker for value in ("pin", "пин", "digit", "цифр"))):
                raise ValueError("Поле не является сегментом PIN")
        elif attrs["type"] != "password" and not (initial_setup and attrs['inputmode'] in ('numeric','decimal') and attrs['type'] in ('text','tel','number')):
            raise ValueError("Ожидалось поле пароля iChat")
        self.record('input', 'Ввод данных разблокировки iChat: начало (значение скрыто)')
        await self.call(element.clear, record=False)
        human = self.settings.get("humanization", {})
        speed = self.baseline.typing_speed["normal"]
        for char in text:
            await self.call(lambda char=char: element.send_keys(char), record=False)
            if human.get("enabled", False):
                await self.sleep(random.uniform(float(human.get("typing_delay_min", speed[0])),
                                               float(human.get("typing_delay_max", speed[1]))))

        self.record('input', 'Ввод данных разблокировки iChat: завершено')

    async def scroll(self, scope_selector=None):
        human = self.settings.get("humanization", {})
        collection = self.settings.get("collection", self.settings)
        pixels = int(random.uniform(human.get("scroll_step_min", 300), human.get("scroll_step_max", 700))) if human.get("enabled", False) else int(collection.get("scroll_step_pixels", 600))
        self.record('scroll', 'Прокрутка списка', details={'pixels': pixels, 'scope': scope_selector})
        result = await self.script(DEEP_QUERY_JS + CHAT_SCROLLER_JS + r"""
const root = arguments[0]==='[data-testid="dm-conversation-scroller"]' ? chatScroller() : arguments[0] ? deepQuery(arguments[0]) : document.scrollingElement;
if (!root) return {found:false};
let scroller = root;
if (root !== document.scrollingElement && root.scrollHeight <= root.clientHeight + 4) {
  const candidates = deepQueryAll('*', root).filter(el => {
    const style = getComputedStyle(el);
    return /(auto|scroll)/.test(style.overflowY) && el.scrollHeight > el.clientHeight + 4;
  });
  if (candidates.length) scroller = candidates[0];
}
const before = scroller.scrollTop;
scroller.scrollTop += arguments[1];
return {found:true, before,after:scroller.scrollTop,height:scroller.scrollHeight,
  at_bottom:scroller.scrollTop + scroller.clientHeight >= scroller.scrollHeight - 4};
""", scope_selector, pixels)
        await self.sleep(random.uniform(human.get("scroll_pause_min", 0.5), human.get("scroll_pause_max", 1.5)) if human.get("enabled", False) else float(collection.get("scroll_pause_seconds", 0.2)))
        return result
