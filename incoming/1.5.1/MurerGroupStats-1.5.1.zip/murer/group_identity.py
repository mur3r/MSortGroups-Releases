"""Account-independent identity of XChat links, including legacy records."""
from urllib.parse import unquote, urlsplit


def group_key(group):
    try:
        url = urlsplit(group.get('url') or '')
        path = unquote(url.path).rstrip('/')
        if url.hostname in ('x.com', 'www.x.com', 'twitter.com', 'www.twitter.com') and path.startswith('/i/chat/'):
            chat_id = path[len('/i/chat/'):]
            if chat_id and '/' not in chat_id:
                return '/i/chat/' + chat_id
    except ValueError:
        pass
    return str(group.get('x_id') or group['id'])
