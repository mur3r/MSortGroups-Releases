"""Transactional SQLite observations. Partial scans retain historical members."""
from contextlib import contextmanager
from collections import defaultdict
from datetime import datetime, timezone
import json
import re
from pathlib import Path
import sqlite3
import threading
from uuid import uuid4


def utcnow():
    return datetime.now(timezone.utc).isoformat()


def encode(value):
    return json.dumps(value, ensure_ascii=False, allow_nan=False)


class AccountIdentityConflict(ValueError):
    pass


class Store:
    def __init__(self, data_dir):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.path = self.data_dir / 'murer.sqlite3'
        self.lock = threading.RLock()
        self.audit = None
        self.protect = lambda values: None
        with self.connection() as db:
            db.execute('PRAGMA journal_mode=WAL')
            for path in sorted((Path(__file__).parent / 'migrations').glob('*.sql')):
                version = int(path.name.split('_')[0])
                db.execute('CREATE TABLE IF NOT EXISTS schema_migrations(version INTEGER PRIMARY KEY, applied_at TEXT NOT NULL)')
                if not db.execute('SELECT 1 FROM schema_migrations WHERE version=?', (version,)).fetchone():
                    # DDL and its version marker must commit together. Without
                    # BEGIN, a failed multi-ALTER migration leaves half a schema.
                    db.executescript('BEGIN IMMEDIATE;\n' + path.read_text(encoding='utf-8'))
                    db.execute('INSERT INTO schema_migrations VALUES(?,?)', (version, utcnow()))
                    db.commit()

    @contextmanager
    def connection(self):
        with self.lock:
            db = sqlite3.connect(self.path, timeout=30)
            db.row_factory = sqlite3.Row
            db.execute('PRAGMA foreign_keys=ON')
            try:
                yield db
                db.commit()
            except BaseException:
                db.rollback()
                raise
            finally:
                db.close()

    def rows(self, sql, parameters=()):
        with self.connection() as db:
            return [dict(row) for row in db.execute(sql, parameters)]

    def execute(self, sql, parameters=()):
        with self.connection() as db:
            return db.execute(sql, parameters).lastrowid

    def event(self, domain, kind, message, **context):
        if self.audit:
            self.audit(domain, kind, message, **context)

    def accounts(self, include_archived=True):
        rows = self.rows("SELECT a.*,COALESCE(m.value='true',0) AS ichat_auto_setup FROM accounts a LEFT JOIN application_meta m ON m.key='ichat_auto_setup:'||a.id ORDER BY a.created_at")
        rows = [self._account_row(row) for row in rows]
        return rows if include_archived else [r for r in rows if not r['archived']]

    @staticmethod
    def _account_row(row):
        row = dict(row)
        row['group'] = row.pop('group_name')
        for field in ('headless', 'is_ours', 'archived', 'ichat_auto_setup'):
            row[field] = bool(row.get(field,False))
        return row

    def account(self, account_id):
        rows = self.rows("SELECT a.*,COALESCE(m.value='true',0) AS ichat_auto_setup FROM accounts a LEFT JOIN application_meta m ON m.key='ichat_auto_setup:'||a.id WHERE a.id=?", (account_id,))
        return self._account_row(rows[0]) if rows else None

    def save_account(self, data, account_id=None):
        account_id = account_id or str(uuid4())
        existing = self.account(account_id) or {}
        values = {**existing, **data}
        profile_key=existing.get('profile_key') or values['username']
        if not existing and self.rows('SELECT id FROM accounts WHERE profile_key=?',(profile_key,)):
            profile_key=account_id
        with self.connection() as db:
            db.execute('''INSERT INTO accounts(id,username,x_id,group_name,user_agent,headless,is_ours,archived,created_at,profile_key)
            VALUES(?,?,?,?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET username=excluded.username,
            x_id=excluded.x_id,group_name=excluded.group_name,user_agent=excluded.user_agent,
            headless=excluded.headless,is_ours=excluded.is_ours,archived=excluded.archived''',
            (account_id, values['username'], values.get('x_id'), values.get('group') or '',
             values.get('user_agent'), int(values.get('headless', False)), int(values.get('is_ours', True)),
             int(values.get('archived', False)), existing.get('created_at', utcnow()),
             profile_key))
            if 'ichat_auto_setup' in data:
                db.execute('INSERT OR REPLACE INTO application_meta VALUES(?,?)',
                           ('ichat_auto_setup:'+account_id,'true' if data['ichat_auto_setup'] else 'false'))
        self.event('auth', 'settings', 'Аккаунт сохранён', account_id=account_id,
                   details={'username': values['username'], 'new': not existing, 'archived': values.get('archived', False)})
        return account_id

    def sync_account_identity(self, account_id, identity):
        username,xid=identity.get('username',''),identity.get('x_id','')
        if identity.get('verified') is not True or identity.get('origin')!='x_self_profile' or not re.fullmatch(r'[a-z0-9_]{1,15}',username) or not isinstance(xid,str) or not re.fullmatch(r'\d+',xid):
            raise AccountIdentityConflict('Фактический логин X не подтверждён; запись аккаунта не изменена')
        now=identity.get('observed_at') or utcnow()
        with self.connection() as db:
            db.execute('BEGIN IMMEDIATE')
            old=db.execute('SELECT * FROM accounts WHERE id=?',(account_id,)).fetchone()
            if not old:
                raise AccountIdentityConflict('Запись аккаунта не найдена')
            collision=db.execute('SELECT id FROM accounts WHERE id!=? AND (lower(username)=? OR x_id=?)',(account_id,username,xid)).fetchone()
            if collision:
                raise AccountIdentityConflict(f'Фактический аккаунт @{username} уже связан с другой записью. Автоматическое объединение отключено; устраните дубликат в разделе «Аккаунты».')
            if old['x_id'] and str(old['x_id'])!=xid:
                raise AccountIdentityConflict(f'У открытого @{username} другой ID X, чем у этой записи. Проверьте данные входа; история разных аккаунтов не объединена.')
            changed=old['username']!=username
            if changed or old['x_id']!=xid:
                db.execute('INSERT INTO account_identity_events(account_id,old_username,username,old_x_id,x_id,origin,observed_at) VALUES(?,?,?,?,?,?,?)',
                    (account_id,old['username'],username,old['x_id'],xid,identity['origin'],now))
            db.execute('UPDATE accounts SET username=?,x_id=?,username_verified_at=?,previous_username=CASE WHEN username!=? THEN username ELSE previous_username END WHERE id=?',
                (username,xid,now,username,account_id))
        self.event('auth', 'result', 'Личность аккаунта сверена с X', account_id=account_id,
                   details={'username': username, 'changed': changed})
        return self.account(account_id), changed

    def account_status(self, account_id, status, reason=''):
        self.execute('UPDATE accounts SET status=?,reason=? WHERE id=?', (status, reason, account_id))
        self.event('auth', 'status', 'Состояние аккаунта: ' + status, account_id=account_id,
                   level='error' if status in ('error','proxy_error') else 'info', details={'reason': reason})

    def settings(self):
        rows = self.rows('SELECT * FROM settings_versions ORDER BY id DESC LIMIT 1')
        return (json.loads(rows[0]['settings']), rows[0]['id']) if rows else (None, 0)

    def save_settings(self, settings):
        version = self.execute('INSERT INTO settings_versions(created_at,settings) VALUES(?,?)', (utcnow(), encode(settings)))
        self.event('data', 'settings', 'Сохранена версия настроек', details={'version': version})
        return version

    def upsert_group(self, group, account_id):
        now = group.get('observed_at') or utcnow()
        x_id = str(group['x_id'])
        with self.connection() as db:
            old = db.execute('SELECT id FROM groups WHERE x_id=?', (x_id,)).fetchone()
            group_id = old['id'] if old else str(uuid4())
            db.execute('''INSERT INTO groups(id,x_id,name,url,declared_count,membership_status,observed_at,reason)
                VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(x_id) DO UPDATE SET name=excluded.name,url=excluded.url,
                declared_count=COALESCE(excluded.declared_count,groups.declared_count)''',
                (group_id, x_id, group.get('name') or x_id, group['url'], group.get('declared_count'),
                 group.get('membership_status', 'partial'), now, group.get('reason', '')))
            db.execute('''INSERT INTO account_groups(account_id,group_id,first_seen,last_seen,present,uncertain)
                VALUES(?,?,?,?,1,0) ON CONFLICT(account_id,group_id)
                DO UPDATE SET last_seen=excluded.last_seen,present=1,uncertain=0''', (account_id, group_id, now, now))
        self.event('data', 'result', 'Группа и доступ аккаунта сохранены', account_id=account_id,
                   level='debug', details={'group_id': group_id, 'x_id': x_id, 'name': group.get('name'), 'new': not old})
        return group_id

    def save_discovery(self, account_id, groups, status):
        """Reconcile confirmed discovery only; a stalled list retains old access.

        Historical account/group rows are never deleted. Upserting the observed
        groups is idempotent and keeps this helper safe before or after a resume.
        """
        complete = status in ('full', 'complete', 'confirmed_end')
        with self.lock:
            group_ids = [self.upsert_group(group, account_id) for group in groups]
            with self.connection() as db:
                if complete:
                    db.execute('UPDATE account_groups SET present=0,uncertain=0 WHERE account_id=?', (account_id,))
                else:
                    db.execute('UPDATE account_groups SET uncertain=1 WHERE account_id=? AND present=1', (account_id,))
                db.executemany('UPDATE account_groups SET present=1,uncertain=0 WHERE account_id=? AND group_id=?',
                    [(account_id, group_id) for group_id in group_ids])
        self.event('data', 'result', 'Список доступных групп сохранён', account_id=account_id,
                   details={'groups_count': len(group_ids), 'status': status})
        return group_ids

    def identify(self, participant, db=None):
        if db is None:
            with self.connection() as conn:
                return self.identify(participant, conn)
        username = str(participant.get('username') or '').strip().lstrip('@').lower()
        x_id = str(participant['x_id']) if participant.get('x_id') else None
        if not username and not x_id:
            raise ValueError('У участника нет username или стабильного ID X')
        matches = list(db.execute('SELECT p.* FROM participants p JOIN participant_aliases a ON a.participant_id=p.id WHERE a.username=?', (username,)))
        row = db.execute('SELECT * FROM participants WHERE x_id=?', (x_id,)).fetchone() if x_id else None
        origin = participant.get('identity_origin') or ('x_id' if x_id else 'username')
        if row is None and x_id and len(matches) == 1 and not matches[0]['x_id']:
            row = matches[0]
            origin = 'username_upgraded_to_x_id'
        if row is None and not x_id and len(matches) == 1:
            row = matches[0]
        if row is None and not x_id and len(matches) > 1:
            # A reused/ambiguous handle cannot prove which stable identity this is.
            raise ValueError(f'Неоднозначный username @{username}; нужен стабильный ID X')
        pid = row['id'] if row else str(uuid4())
        # Seeing a historical alias without its stable ID cannot prove a rename.
        # Keep the latest ID-backed handle and its URL until a verified ID updates it.
        alias_only = bool(row and not x_id and username != row['username'])
        saved_username = row['username'] if alias_only else username or (row['username'] if row else '')
        saved_url = row['url'] if alias_only else participant.get('url') or (f'https://x.com/{saved_username}' if saved_username else f'https://x.com/i/user/{x_id}')
        if alias_only:
            origin = 'historical_username_alias'
        db.execute('''INSERT INTO participants VALUES(?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET
            x_id=COALESCE(excluded.x_id,participants.x_id),username=excluded.username,
            name=COALESCE(excluded.name,participants.name),url=excluded.url,identity_origin=excluded.identity_origin''',
            (pid, x_id or (row['x_id'] if row else None), saved_username, participant.get('name'), saved_url, origin, utcnow()))
        if username:
            db.execute('INSERT OR REPLACE INTO participant_aliases VALUES(?,?,?)', (pid, username, utcnow()))
        return pid

    def save_members(self, job_id, group_id, account_id, result):
        now = utcnow()
        status = result.get('status', 'partial')
        ids, ambiguous = [], []
        with self.connection() as db:
            for participant in result.get('participants', []):
                try:
                    pid = self.identify(participant, db)
                except ValueError as error:
                    ambiguous.append(str(error))
                    continue
                if pid not in ids:
                    ids.append(pid)
            if ambiguous:
                status = 'partial'
            declared = result.get('declared_count')
            if declared is None:
                row = db.execute('SELECT declared_count FROM groups WHERE id=?', (group_id,)).fetchone()
                declared = row['declared_count'] if row else None
            mismatch = status == 'full' and isinstance(declared, (int, float)) and declared != len(ids)
            if mismatch:
                status = 'partial'
            # Only a confirmed complete list provides evidence of departures.
            if status == 'full':
                db.execute('UPDATE group_members SET present=0,uncertain=0 WHERE group_id=?', (group_id,))
            else:
                db.execute('UPDATE group_members SET uncertain=1 WHERE group_id=? AND present=1', (group_id,))
            for pid in ids:
                db.execute('''INSERT INTO group_members VALUES(?,?,?,?,1,?) ON CONFLICT(group_id,participant_id)
                    DO UPDATE SET last_seen=excluded.last_seen,present=1,uncertain=excluded.uncertain''',
                    (group_id, pid, now, now, int(status != 'full')))
                db.execute('DELETE FROM trade_member_rechecks WHERE group_id=? AND username IN (SELECT username FROM participants WHERE id=?)',(group_id,pid))
            if status == 'full':
                db.execute('DELETE FROM trade_member_rechecks WHERE group_id=?',(group_id,))
            if status == 'full':
                # A complete roster is the only evidence that invalidates a
                # remembered Trade membership. Keep immutable Trade history.
                db.execute("""DELETE FROM trade_member_observations AS t WHERE t.group_id=? AND NOT EXISTS (
                    SELECT 1 FROM group_members gm JOIN participants p ON p.id=gm.participant_id
                    WHERE gm.group_id=t.group_id AND gm.present=1 AND
                    ((t.x_id IS NOT NULL AND p.x_id=t.x_id) OR
                     (t.x_id IS NULL AND p.username=t.username)))""",(group_id,))
            reason = '; '.join(filter(None, [result.get('reason', '')] + ambiguous +
                ([f'Заявлено {declared}, найдено {len(ids)}; полнота состава не подтверждена'] if mismatch else [])))
            db.execute('UPDATE groups SET membership_status=?,observed_at=?,reason=?,declared_count=COALESCE(?,declared_count) WHERE id=?',
                       (status, now, reason, result.get('declared_count'), group_id))
            db.execute('INSERT INTO membership_observations VALUES(?,?,?,?,?,?,?,?)',
                       (str(uuid4()), job_id, group_id, account_id, now, status, encode(ids), reason))
        self.event('data', 'result', 'Список участников сохранён', account_id=account_id, run_id=job_id,
                   details={'group_id': group_id, 'found': len(ids), 'status': status, 'reason': reason})
        return ids

    def save_profile(self, job_id, participant_id, account_id, observation):
        now = observation.get('observed_at') or utcnow()
        observation = {**observation, 'observed_at': now, 'source_account_id': account_id}
        # A retry within the same run replaces the same access attempt atomically.
        oid = f'{job_id}:{participant_id}:{account_id}'
        with self.connection() as db:
            old = db.execute('SELECT status,data FROM profile_observations WHERE id=?', (oid,)).fetchone()
            if old and old['status'] in ('full', 'partial') and observation.get('status') in ('error', 'unavailable'):
                oid += ':failed'
            elif old and old['status'] in ('full', 'partial') and observation.get('status') == 'partial':
                previous = json.loads(old['data'])
                lost_metric = any(isinstance(previous.get(key), dict) and previous[key].get('value') is not None and
                    (not isinstance(observation.get(key), dict) or observation[key].get('value') is None)
                    for key in ('followers', 'posts_total'))
                lost_sample = len(observation.get('posts', [])) < len(previous.get('posts', []))
                lost_coverage = previous.get('period_complete') and not observation.get('period_complete')
                if lost_metric or lost_sample or lost_coverage:
                    # A bounded, repeatable attempt key preserves useful evidence
                    # without creating another row on every retry of this run.
                    oid += ':partial'
            db.execute('''INSERT INTO profile_observations VALUES(?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET
                observed_at=excluded.observed_at,status=excluded.status,data=excluded.data''',
                       (oid, participant_id, job_id, account_id, now, observation.get('status', 'partial'), encode(observation)))
            db.execute('DELETE FROM post_observations WHERE observation_id=?', (oid,))
            for index, post in enumerate(observation.get('posts', [])):
                key = str(post.get('id') or post.get('url') or f'unknown:{index}')
                db.execute('INSERT OR IGNORE INTO post_observations VALUES(?,?,?)', (oid, key, encode(post)))
        self.event('data', 'result', 'Наблюдение профиля сохранено', account_id=account_id, run_id=job_id,
                   details={'participant_id': participant_id, 'status': observation.get('status'),
                            'posts_count': len(observation.get('posts', [])), 'reason': observation.get('reason')})
        return observation

    def dataset(self):
        with self.connection() as db:
            accounts = [self._account_row(row) for row in db.execute("SELECT a.*,COALESCE(m.value='true',0) AS ichat_auto_setup FROM accounts a LEFT JOIN application_meta m ON m.key='ichat_auto_setup:'||a.id ORDER BY a.created_at")]
            groups = [dict(r) for r in db.execute('SELECT * FROM groups')]
            account_groups, historical_accounts = defaultdict(list), defaultdict(list)
            uncertain_accounts, group_members = defaultdict(list), defaultdict(list)
            for row in db.execute('SELECT account_id,group_id,present,uncertain FROM account_groups'):
                historical_accounts[row['group_id']].append(row['account_id'])
                if row['present']:
                    account_groups[row['group_id']].append(row['account_id'])
                    if row['uncertain']:
                        uncertain_accounts[row['group_id']].append(row['account_id'])
            membership_dates = defaultdict(list)
            for row in db.execute('SELECT participant_id,group_id,last_seen FROM group_members WHERE present=1'):
                group_members[row['group_id']].append(row['participant_id'])
                membership_dates[row['group_id']].append(row['last_seen'])
            for group in groups:
                group['account_ids'] = account_groups[group['id']]
                group['historical_account_ids'] = historical_accounts[group['id']]
                group['uncertain_account_ids'] = uncertain_accounts[group['id']]
                group['participant_ids'] = group_members[group['id']]
                dates = membership_dates[group['id']]
                group['membership_observed_from'] = min(dates) if dates else None
                group['membership_observed_to'] = max(dates) if dates else None
                group['pinned_account_ids'] = json.loads(group['pinned_account_ids'])
                group['exempt_account_ids'] = json.loads(group['exempt_account_ids'])
                group['unlimited'] = bool(group['unlimited']) if group['unlimited'] is not None else None
            participants = [dict(r) for r in db.execute('SELECT * FROM participants')]
            aliases, observations = defaultdict(list), defaultdict(list)
            for row in db.execute('SELECT participant_id,username FROM participant_aliases'):
                aliases[row['participant_id']].append(row['username'])
            for row in db.execute('SELECT participant_id,data FROM profile_observations ORDER BY observed_at DESC'):
                observations[row['participant_id']].append(json.loads(row['data']))
            for p in participants:
                p['aliases'] = aliases[p['id']]
                p['observations'] = observations[p['id']]
        return {'accounts': accounts, 'groups': groups, 'participants': participants}

    def jobs(self):
        rows = self.rows('SELECT * FROM jobs ORDER BY created_at DESC')
        for row in rows:
            for field in ('account_ids', 'group_ids', 'settings', 'progress'):
                row[field] = json.loads(row[field])
        return rows

    def participant(self, participant_id):
        rows = self.rows('SELECT * FROM participants WHERE id=?', (participant_id,))
        if not rows:
            raise ValueError('Участник не найден')
        participant = rows[0]
        participant['observations'] = [json.loads(r['data']) for r in self.rows(
            'SELECT data FROM profile_observations WHERE participant_id=? ORDER BY observed_at DESC', (participant_id,))]
        return participant

    def job(self, job_id):
        rows = self.rows('SELECT * FROM jobs WHERE id=?', (job_id,))
        if not rows:
            return None
        row = rows[0]
        for field in ('account_ids', 'group_ids', 'settings', 'progress'):
            row[field] = json.loads(row[field])
        return row

    def job_update(self, job_id, **values):
        summary = {k: values[k] for k in ('status','error','finished_at') if k in values}
        allowed = {'status', 'progress', 'error', 'finished_at'}
        values = {k: encode(v) if k == 'progress' else v for k, v in values.items() if k in allowed}
        values['updated_at'] = utcnow()
        self.execute('UPDATE jobs SET ' + ','.join(k+'=?' for k in values) + ' WHERE id=?', (*values.values(), job_id))
        if summary:
            self.event('collection', 'status', 'Состояние задания: ' + str(summary.get('status', 'обновлено')),
                       run_id=job_id, level='error' if summary.get('status') == 'error' else 'info', details=summary)

    def step(self, job_id, key, status, data=None):
        self.execute('INSERT OR REPLACE INTO job_steps VALUES(?,?,?,?,?)', (job_id, key, status, encode(data or {}), utcnow()))
        self.event('collection', 'checkpoint', 'Результат шага сохранён: ' + status,
                   run_id=job_id, details={'step': key})

    def done_step(self, job_id, key):
        rows = self.rows('SELECT data FROM job_steps WHERE job_id=? AND step_key=? AND status=?', (job_id, key, 'done'))
        return json.loads(rows[0]['data']) if rows else None

    def error(self, job_id, account_id, target, stage, message):
        self.execute('INSERT INTO errors VALUES(?,?,?,?,?,?,?)', (str(uuid4()), job_id, account_id, target, stage, message, utcnow()))
        self.event('collection', 'error', message, level='error', account_id=account_id, run_id=job_id,
                   details={'stage': stage, 'target': target})
