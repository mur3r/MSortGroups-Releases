"""iChat group discovery. No sender list is treated as group membership."""
import asyncio
import inspect
import re
from copy import deepcopy
from datetime import datetime, timezone

from xgenius.core import classify_driver_error
from xgenius.core.network import connection_failure
from xgenius.core.dom import DEEP_QUERY_JS
from xgenius.core.chat_list import CHAT_SCROLLER_JS

CHAT_LIST_PROBE_JS = DEEP_QUERY_JS + CHAT_SCROLLER_JS + r"""
const anchors = deepQueryAll("a[href*='/i/chat/']");
const groups = anchors.map(a => ({url:a.href,
  name:(a.innerText || a.getAttribute('aria-label') || '').split('\n')[0].trim()}));
const text = deepQueryAll('[role="status"], [data-testid="emptyState"], [data-testid="chat-list-end"]')
  .map(el => el.innerText || '').join('\n').toLowerCase();
const scroller=chatScroller();
const geometry=scroller?{height:scroller.scrollHeight,top:scroller.scrollTop,viewport:scroller.clientHeight,
 at_bottom:scroller.scrollTop+scroller.clientHeight>=scroller.scrollHeight-4}:null;
const visible=e=>!!e&&(e.offsetWidth||e.offsetHeight||e.getClientRects().length)&&getComputedStyle(e).visibility!=='hidden';
const loading=(scroller?.getAttribute('aria-busy')==='true')||deepQueryAll('[role="progressbar"],[aria-busy="true"]',scroller||document).some(visible);
return {groups, loading, geometry,
  confirmed_end:/no more conversations|end of conversations|больше нет чатов|конец списка чатов/.test(text),
  url:location.href};
"""

async def _callback(callback, *args):
    if callback:
        result = callback(*args)
        if inspect.isawaitable(result):
            await result

class GroupCollector:
    def __init__(self, logger):
        self.logger = logger

    async def find_groups(self, browser, username: str, **kwargs) -> set:
        """Backward-compatible links. Rich callers should use discover_groups."""
        result = await self.discover_groups(browser, username, **kwargs)
        return {group["url"] for group in result["groups"]}

    async def discover_groups(self, browser, username: str, settings=None,
                              checkpoint=None, progress=None, actions=None, page_gate=None):
        settings = settings or {}
        settings = settings.get("collection", settings)
        limit = int(settings.get("group_scroll_limit", 30))
        idle_limit = int(settings.get("idle_scroll_limit", 4))
        load_wait = float(settings.get("load_wait_seconds", 1))
        groups = {}
        if browser is None:
            return {"groups": [], "status": "error", "reason": "Браузер отсутствует"}
        loop = asyncio.get_running_loop()
        async def command(function):
            await _callback(checkpoint)
            return await loop.run_in_executor(None, function)
        async def pause():
            if actions:
                await actions.sleep(load_wait)
            else:
                await asyncio.sleep(load_wait)
        try:
            if actions:
                await actions.get("https://x.com/i/chat")
            else:
                await command(lambda: browser.get("https://x.com/i/chat"))
            await pause()
            idle = bottom_stable = 0
            last_geometry = None
            for step in range(limit):
                if page_gate:
                    gate = page_gate()
                    if inspect.isawaitable(gate):
                        gate = await gate
                    if gate:
                        return {"groups": list(groups.values()), **gate}
                probe = await command(lambda: browser.execute_script(CHAT_LIST_PROBE_JS))
                probe = probe if isinstance(probe, dict) else {}
                if "/i/chat" not in probe.get("url", ""):
                    return {"groups": list(groups.values()), "status": "unavailable",
                            "reason": "iChat не открылся; проверьте вход или ручное подтверждение"}
                before = len(groups)
                for item in probe.get("groups", []):
                    url = str(item.get("url", "")).split("?", 1)[0].rstrip("/")
                    match = re.fullmatch(r"https?://(?:www\.)?x\.com/i/chat/(g[^/?#]+)", url)
                    if not match:
                        continue
                    group_id = match.group(1)
                    groups[group_id] = {"x_id": group_id, "url": url,
                        "name": item.get("name") or group_id, "declared_count": None,
                        "membership_status": "partial"}
                await _callback(progress, {"operation": "Поиск групповых чатов",
                    "groups_found": len(groups), "scroll": step + 1, "scroll_limit": limit,
                    "checkpoint_data": {"kind": "groups", "groups": deepcopy(list(groups.values())),
                        "status": "partial", "observed_at": datetime.now(timezone.utc).isoformat(),
                        "reason": "Промежуточный список; поиск ещё не завершён"}})
                if probe.get("confirmed_end") and not probe.get("loading"):
                    return {"groups": list(groups.values()), "status": "full",
                            "reason": "Интерфейс подтвердил окончание списка чатов"}
                idle = 0 if len(groups) > before else idle + 1
                geometry = probe.get('geometry')
                if (isinstance(geometry,dict) and geometry.get('at_bottom') is True
                        and geometry.get('viewport',0)>0 and geometry.get('height',0)>0
                        and not probe.get('loading') and len(groups)==before):
                    bottom_stable = bottom_stable+1 if geometry==last_geometry else 1
                else:
                    bottom_stable = 0
                last_geometry = geometry
                if bottom_stable >= idle_limit:
                    return {'groups':list(groups.values()),'status':'full',
                            'reason':f'Конец контейнера чатов подтверждён {bottom_stable} последовательными проверками без загрузки и новых чатов',
                            'end_evidence':{'kind':'stable_scroll_bottom','checks':bottom_stable,'geometry':geometry}}
                if idle >= idle_limit and not probe.get("loading"):
                    if not bottom_stable:
                        return {"groups": list(groups.values()), "status": "partial",
                                "reason": "Загрузка временно остановилась; конец списка не подтверждён"}
                if actions:
                    await actions.scroll('[data-testid="dm-conversation-scroller"]')
                else:
                    await command(lambda: browser.execute_script(DEEP_QUERY_JS + CHAT_SCROLLER_JS +
                        "const list=chatScroller();if(list){list.scrollTop+=Math.max(500,list.clientHeight*.8);}else{window.scrollBy(0,Math.max(500,innerHeight*.8));}"))
                await pause()
            return {"groups": list(groups.values()), "status": "partial",
                    "reason": "Достигнут настроенный предел прокрутки списка чатов"}
        except Exception as exc:
            if type(exc).__name__ in ("StopRequested", "PauseRequested", "JobStopped"):
                raise
            failure = connection_failure(exc)
            if failure:
                return {"groups":list(groups.values()),**failure}
            reason = "Браузер закрыт" if classify_driver_error(exc) == "closed" else "Ошибка загрузки списка чатов"
            self.logger.warning(reason, username)
            return {"groups": list(groups.values()), "status": "partial" if groups else "error", "reason": reason}
