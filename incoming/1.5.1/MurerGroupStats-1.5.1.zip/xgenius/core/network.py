"""Recognize Chrome connection failures without exposing proxy credentials."""
import re


NETWORK_ERROR_JS = r"""
const frame=document.querySelector('#main-frame-error');
if(!location.href.startsWith('chrome-error:')&&!document.documentURI.startsWith('chrome-error:')&&!frame)return null;
const code=(document.querySelector('.error-code,#error-code')?.textContent||'').match(/(?:NET::)?ERR_[A-Z0-9_]+/i);
return code?code[0].toUpperCase():'CHROME_NETWORK_ERROR';
"""

PROXY_CODES = {'ERR_PROXY_CONNECTION_FAILED', 'ERR_TUNNEL_CONNECTION_FAILED',
               'ERR_NO_SUPPORTED_PROXIES', 'ERR_PROXY_AUTH_UNSUPPORTED',
               'ERR_PROXY_CERTIFICATE_INVALID', 'ERR_INVALID_AUTH_CREDENTIALS',
               'ERR_SOCKS_CONNECTION_FAILED', 'ERR_SOCKS_CONNECTION_HOST_UNREACHABLE'}
NETWORK_CODES = {'ERR_CONNECTION_REFUSED', 'ERR_CONNECTION_RESET', 'ERR_CONNECTION_CLOSED',
                 'ERR_CONNECTION_TIMED_OUT', 'ERR_TIMED_OUT', 'ERR_ADDRESS_UNREACHABLE',
                 'ERR_NAME_NOT_RESOLVED', 'ERR_INTERNET_DISCONNECTED', 'ERR_NETWORK_CHANGED',
                 'ERR_EMPTY_RESPONSE', 'CHROME_NETWORK_ERROR'}


class ConnectionFailure(RuntimeError):
    def __init__(self, result):
        self.result = {**result,'connection_error':True,
                       'reason':result.get('reason') or 'Не удалось подключиться через прокси; проверьте адрес и авторизацию'}
        super().__init__(self.result['reason'])


def connection_failure(error, proxy_configured=False):
    if isinstance(error, ConnectionFailure):
        return error.result
    text = str(error).upper()
    codes = re.findall(r'\b(?:ERR_[A-Z0-9_]+|CHROME_NETWORK_ERROR)\b', text)
    code = next((value for value in codes if value in PROXY_CODES | NETWORK_CODES), None)
    explicit_proxy = code in PROXY_CODES or bool(re.search(r'\bPROXY\b|PROXYERROR',text))
    if not explicit_proxy and code is None:
        return None  # Local WebDriver disconnects are not evidence of a bad proxy.
    via_proxy = explicit_proxy or proxy_configured
    reason = ('Прокси недоступен или отклоняет подключение. Проверьте адрес, срок действия и авторизацию прокси.'
              if via_proxy else 'Не удалось загрузить страницу: ошибка сетевого подключения.')
    return {'status':'proxy_error' if via_proxy else 'error','reason':reason,
            'connection_error':True,'network_code':code or 'PROXY_CONFIGURATION_ERROR'}


def probe_connection(browser, proxy_configured=False):
    code = browser.execute_script(NETWORK_ERROR_JS)
    return connection_failure(code, proxy_configured) if isinstance(code,str) else None
