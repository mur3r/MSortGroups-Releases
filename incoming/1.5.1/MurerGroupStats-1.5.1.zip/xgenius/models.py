from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Optional, Set
from selenium import webdriver
from human1 import Humanizer

class AuthStatus(Enum):
    OK = "OK"
    PAGE_DOWN = "PAGE_DOWN"
    NEED_RELOGIN = "NEED_RELOGIN"
    LOCKED = "LOCKED"

@dataclass
class AccountCredentials:
    username: str
    password: str
    proxy: Optional[str] = None
    user_agent: Optional[str] = None
    headless: bool = False
    group: Optional[str] = ""
    auth_token: Optional[str] = None
    ct0_token: Optional[str] = None
    ichat_password: Optional[str] = None
    ichat_auto_setup: bool = False

@dataclass
class BrowserConfig:
    headless: bool = False
    window_size: tuple[int, int] = (1920, 1080)

@dataclass
class AccountState:
    username: str
    browser: Optional[webdriver.Chrome] = None
    is_active: bool = False
    is_paused: bool = False
    is_scanning: bool = False
    is_parsing: bool = False
    status_reason: str = ""
    groups: Set[str] = field(default_factory=set)
    followers_count: int = 0
    last_action_time: datetime = field(default_factory=datetime.now)
    humanizer: Humanizer = field(default_factory=Humanizer)
    need_relogin: bool = False
    auth_token: Optional[str] = None
    ct0_token: Optional[str] = None
    relogin_in_progress: bool = False
    parked: bool = False
