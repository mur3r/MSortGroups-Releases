import { useState } from 'react'
import { Copy, Play, RefreshCw } from 'lucide-react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Textarea } from '@/components/ui/textarea'
import { DataTable } from '@/components/DataTable'
import { date, number, type Row } from '@/lib/api'

export function TradeContract({ run, disabled, onPrepare, onStart }: { run: Row; disabled: boolean; onPrepare: () => void; onStart: () => void }) {
  const [copied, setCopied] = useState(false)
  const prep = run.plan.preparation ?? {}, ready = prep.state === 'ready'
  const accounts: Row[] = prep.required_accounts ?? []
  const assignments: Row[] = prep.assignments ?? []
  const messages = run.config.recipients.map((recipient: string) => {
    const links = accounts.filter(account => account.recipients.includes(recipient)).map(account => account.url)
    return links.length ? `@${recipient}, подпишись на эти аккаунты для обмена:\n${links.join('\n')}` : ''
  }).filter(Boolean).join('\n\n')
  const final = ['completed','closed_unverified'].includes(run.status)
  return <Card aria-label="Точный план Trade"><CardHeader><CardTitle className="text-base">Точный план Trade</CardTitle><CardDescription>По {number(run.config.count)} новых групп каждому · качество: {run.plan.quality_label}. Подготовка проверяет группы и ID без подписок и приглашений. {prep.created_at && `Проверено: ${date(prep.created_at)}.`}</CardDescription></CardHeader>
    <CardContent className="space-y-5">
      {run.error && <Alert variant="destructive" role="alert"><AlertDescription>{run.error}</AlertDescription></Alert>}
      <p className="text-sm" role="status">{run.progress?.operation ?? 'Нажмите «Подготовить точный план», чтобы проверить аккаунты и группы в браузере.'}</p>
      {Object.keys(prep.identities ?? {}).length > 0 && <div className="flex flex-wrap gap-3 text-xs">{Object.entries(prep.identities).map(([name, identity]) => <span key={name}>@{name} · ID {(identity as Row).x_id}</span>)}</div>}
      {['preparation_blocked','preparation_shortage','awaiting_subscriptions','awaiting_review'].includes(run.status) && <Alert variant="destructive"><AlertDescription>{run.progress?.operation} {Object.entries(prep.missing ?? {}).some(([, count]) => Number(count)>0) && `Не хватает: ${Object.entries(prep.missing).filter(([, count]) => Number(count)>0).map(([name,count]) => `@${name}: ${count}`).join('; ')}.`}</AlertDescription></Alert>}
      {(prep.errors ?? []).map((error: Row,index: number) => <p key={index} className="text-sm text-destructive">{error.recipient && '@'+error.recipient+': '}{error.reason}</p>)}
      {ready && accounts.length > 0 && <div className="space-y-3 rounded-lg border p-4"><p className="font-medium text-sm">Передайте получателю ссылки на эти наши аккаунты</p><p className="text-xs text-muted-foreground">Только с них будут выполняться добавления. После подписки получателя нажмите «Начать Trade». Программа проверит все подписки до первого приглашения.</p>
        <DataTable rows={accounts} columns={[{key:'username',label:'Наш аккаунт',render: row => <a href={row.url} target="_blank" rel="noreferrer" className="text-primary">@{row.username} ↗</a>},{key:'recipients',label:'Кто должен подписаться',render: row => row.recipients.map((name: string) => '@'+name).join(', ')},{key:'groups_count',label:'Добавлений'}]} />
        <Textarea aria-label="Сообщение со ссылками для получателя" readOnly rows={Math.min(12,Math.max(4,messages.split('\n').length))} value={messages} />
        <Button type="button" variant="outline" onClick={async () => { try { await navigator.clipboard.writeText(messages); setCopied(true) } catch { setCopied(false) } }}><Copy className="size-4" />{copied ? 'Скопировано' : 'Скопировать ссылки для получателя'}</Button>
      </div>}
      {!!prep.subscription_checks?.length && <DataTable rows={prep.subscription_checks} rowKey={row => row.account_id+':'+row.recipient} columns={[{key:'recipient',label:'Получатель',render: row => '@'+row.recipient},{key:'account_username',label:'Должен подписаться на',render: row => <a className="text-primary" href={row.url} target="_blank" rel="noreferrer">@{row.account_username}</a>},{key:'follows_us',label:'Обратная подписка',render: row => row.follows_us && row.identity_confirmed ? 'Подтверждена' : 'Не подтверждена'},{key:'following',label:'Наша подписка',render: row => row.following === true ? 'Подтверждена' : 'Проверим при запуске'}]} />}
      {!!assignments.length && <DataTable rows={assignments} rowKey={row => row.id+':'+row.recipient} columns={[{key:'recipient',label:'Кого добавляем',render: row => '@'+row.recipient},{key:'target_x_id',label:'ID получателя'},{key:'name',label:'Конкретная группа',render: row => <a className="text-primary" href={row.url} target="_blank" rel="noreferrer">{row.name} ↗</a>},{key:'source_username',label:'С какого аккаунта',render: row => '@'+row.source_username},{key:'quality',label:'Качество'},{key:'quality_checked_at',label:'Оценка сохранена',render: row => row.quality_checked_at ? date(row.quality_checked_at) : 'Нет сохранённой оценки'},{key:'invitation_ready',label:'Проверка',render: row => row.invitation_ready === false ? 'ID отсутствует; доступ перепроверим после подписки' : 'ID и доступ проверены'}]} />}
      {!!run.plan.excluded?.length && <details><summary className="cursor-pointer py-3 text-sm">Исключённые группы и причины ({run.plan.excluded.length})</summary><DataTable rows={run.plan.excluded.map((row: Row,index: number) => ({...row,id:'excluded-'+index}))} columns={[{key:'name',label:'Группа'},{key:'recipient',label:'Получатель'},{key:'reason',label:'Причина',render: row => <span className="block whitespace-normal max-w-md">{row.reason}{row.blocking_run_id && ` · Trade ${row.blocking_run_id}`}</span>}]} /></details>}
      {!final && <div className="flex flex-wrap gap-2"><Button variant="outline" disabled={disabled || run.worker_active} onClick={onPrepare}><RefreshCw className="size-4" />{prep.created_at ? 'Пересобрать точный план' : 'Подготовить точный план'}</Button><Button disabled={disabled || !run.can_start} onClick={onStart}><Play className="size-4" />Начать Trade</Button></div>}
      <p role="status" aria-live="polite" className="text-sm">{run.progress?.operation}</p>
      <p className="text-xs text-muted-foreground">Если выбранная группа или аккаунт изменится, отправка остановится до пересборки плана. При нехватке групп частичный обмен сам не начнётся.</p>
    </CardContent></Card>
}
