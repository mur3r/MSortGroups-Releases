import { AlertTriangle, Play, Square } from 'lucide-react'
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert'
import { Button } from '@/components/ui/button'
import type { Row } from '@/lib/api'

export function TradeAttention({ run, onContinue, onStop, disabled = false }: { run: Row; onContinue: () => void; onStop: () => void; disabled?: boolean }) {
  if (run.status !== 'requires_manual') return null
  const invitation = run.progress?.manual_kind === 'invitation'
  return <Alert variant="destructive" role="alert" aria-live="assertive" aria-label="Trade ожидает ручного действия" className="space-y-3">
    <AlertTriangle className="size-4" /><AlertTitle className="line-clamp-none whitespace-normal break-words">Trade приостановлен — требуется ваше действие</AlertTitle>
    <AlertDescription className="space-y-3">
      {run.progress?.current_account && <p>Наш аккаунт: <strong>@{run.progress.current_account}</strong></p>}
      <p className="whitespace-normal [overflow-wrap:anywhere]">{run.progress?.manual_reason || 'Завершите подтверждение в открытом окне Chrome.'}</p>
      {!invitation && <p>Пароль/PIN и автоматическое создание можно настроить в карточке этого аккаунта. После сохранения вернитесь сюда и нажмите «Продолжить после ручного подтверждения».</p>}
      <div className="flex flex-wrap gap-2"><Button disabled={disabled || !run.worker_active} onClick={onContinue}><Play className="size-4" />{invitation ? 'Проверить результат добавления' : 'Продолжить после ручного подтверждения'}</Button><Button variant="outline" disabled={disabled} onClick={onStop}><Square className="size-4" />Остановить Trade</Button></div>
    </AlertDescription>
  </Alert>
}
