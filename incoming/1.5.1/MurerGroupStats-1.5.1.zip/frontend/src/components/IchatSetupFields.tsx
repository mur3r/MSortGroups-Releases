import { Switch } from '@/components/ui/switch'
import { Label } from '@/components/ui/label'
import { Input } from '@/components/ui/input'

export function IchatSetupFields({ id, enabled, onEnabled, confirmation, onConfirmation, requireConfirmation, disabled = false }: {
  id: string; enabled: boolean; onEnabled: (value: boolean) => void; confirmation: string;
  onConfirmation: (value: string) => void; requireConfirmation: boolean; disabled?: boolean
}) {
  return <div className="space-y-3 rounded-lg border p-3">
    <div className="flex gap-3 items-start"><Switch id={id} checked={enabled} onCheckedChange={onEnabled} disabled={disabled} /><Label htmlFor={id} className="leading-relaxed">Создавать пароль/PIN iChat автоматически</Label></div>
    <p className="text-xs text-muted-foreground">Если iChat ещё не настроен, программа создаст пароль/PIN из поля выше и введёт его повторно для подтверждения. Выключено — программа попросит завершить настройку вручную. Существующий пароль не изменяется.</p>
    {enabled && requireConfirmation && <div className="space-y-2"><Label htmlFor={id+'-confirm'}>Повторите пароль/PIN iChat</Label><Input id={id+'-confirm'} type="password" autoComplete="new-password" value={confirmation} disabled={disabled} onChange={event => onConfirmation(event.target.value)} /></div>}
    {enabled && !requireConfirmation && <p className="text-xs text-muted-foreground">Для создания будет использован сохранённый пароль/PIN iChat. Чтобы задать другой, заполните поле пароля и подтверждение.</p>}
  </div>
}
