"""Trade API, durable intent and real worker arbitration with synthetic sessions."""
import asyncio
import json
from pathlib import Path
import tempfile
import threading
import time
import unittest
from unittest.mock import patch

from fastapi.testclient import TestClient
from murer.api import create_app
from murer.secrets import SecretStore
from murer.trade import TradeManager, usernames
from murer.storage import encode, utcnow
from tests.test_storage_api import FakeSession, MemoryVault, Scenario


class ExchangeScenario:
    def __init__(self):
        self.stats = Scenario()
        self.stats.groups = [{**g, 'x_id': 'g'+g['x_id'], 'url': g['url'].replace('/chat/', '/chat/g')} for g in self.stats.groups]
        self.stats.people = {'g'+key: people for key, people in self.stats.people.items()}
        self.stats.command_delay = .03
        self.stats_open = self.trade_open = 0
        self.guard = threading.Lock()
        self.invites = []
        self.unavailable = set()
        self.blocked = set()
        self.uncertain = False
        self.verify_status = 'confirmed'
        self.login_status = 'active'
        self.manual_after_intent = False
        self.continued_pin = None
        self.incoming_reads = 0
        self.incoming_complete = True
        self.incoming_extra = 2
        self.follow_calls = []
        self.follow_accounts = []
        self.login_accounts = []
        self.login_failures = {}
        self.blocked_accounts = set()
        self.require_follow = False
        self.discovery_accounts = []
        self.following = set()
        self.already = set()
        self.group_lists = {}
        self.hold = threading.Event()
        self.hold.set()
        self.started = threading.Event()

    def stats_factory(self, config, logger, settings, checkpoint, progress):
        owner = self
        class Stats(FakeSession):
            opened = False
            async def login(self, credentials):
                with owner.guard:
                    assert owner.trade_open == 0, 'Statistics ran while Trade owned browsers'
                    owner.stats_open += 1
                    self.opened = True
                return await super().login(credentials)
            async def close(self):
                await super().close()
                with owner.guard:
                    if self.opened:
                        owner.stats_open -= 1
                        self.opened = False
        instance = Stats(self.stats, checkpoint)
        self.stats.instances.append(instance)
        return instance

    def trade_factory(self, config, logger, settings, checkpoint, progress):
        owner = self
        class Actions:
            async def sleep(self, seconds):
                checkpoint()
                await asyncio.sleep(0)
        class Trade:
            actions = Actions()
            opened = False
            async def login(self, credentials):
                checkpoint()
                self.username = credentials.username
                owner.login_accounts.append(self.username)
                with owner.guard:
                    assert owner.stats_open == 0, 'Trade ran before statistics closed its browsers'
                    assert owner.trade_open == 0, 'Trade opened two account browsers at once'
                    owner.trade_open += 1
                    self.opened = True
                return {'status': owner.login_failures.get(self.username,owner.login_status)}
            async def continue_login(self, credentials):
                owner.continued_pin = credentials.ichat_password
                return {'status': 'active'}
            async def relationship(self, username):
                checkpoint()
                return {'following': (self.username, username) in owner.following if owner.require_follow else True, 'follows_us': None if username in owner.blocked or (self.username,username) in owner.blocked_accounts else True, 'x_id':'42' if username=='partner' else '43'}
            async def discover_groups(self, credentials):
                checkpoint()
                owner.discovery_accounts.append(credentials.username)
                if credentials.username in owner.group_lists:
                    return {'status':'full','groups':owner.group_lists[credentials.username]}
                owner.incoming_reads += 1
                groups = list(owner.stats.groups)
                if owner.incoming_reads > 1:
                    groups += [{'x_id':'g990000'+str(i),'name':'Synthetic incoming '+str(i),'url':'https://x.com/i/chat/g990000'+str(i)} for i in range(owner.incoming_extra)]
                return {'status':'full' if owner.incoming_complete else 'partial','groups':groups,'reason':'Synthetic incoming list'}
            async def follow(self, username, before_send, allow_send=True):
                checkpoint()
                if allow_send and (self.username, username) not in owner.following:
                    before_send()
                    owner.follow_calls.append(username)
                    owner.following.add((self.username, username))
                    owner.follow_accounts.append((self.username, username))
                return {'following':True,'follows_us':True,'username':username,'x_id':'42'}
            async def invite(self, group, target, before_send):
                checkpoint()
                owner.invites.append((group['id'], target))
                if (group['id'],target) in owner.already:
                    return {'status':'already_member','x_id':'42','reason':'Synthetic existing member'}
                if group['id'] in owner.unavailable:
                    return {'status': 'unavailable', 'reason': 'Synthetic no add button'}
                before_send()
                owner.started.set()
                if owner.manual_after_intent:
                    owner.manual_after_intent = False
                    return {'status':'requires_manual'}
                while not owner.hold.is_set():
                    checkpoint()
                    await asyncio.sleep(.01)
                if owner.uncertain:
                    return {'status': 'uncertain', 'reason': 'Synthetic missing confirmation'}
                owner.stats.people.setdefault(group['x_id'],[]).append({'username': target})
                return {'status': 'confirmed', 'reason': 'Synthetic member roster confirmation'}
            async def verify_membership(self, group, target):
                return {'status': owner.verify_status, 'reason': 'Synthetic read-only reconciliation'}
            async def close(self):
                with owner.guard:
                    if self.opened:
                        owner.trade_open -= 1
                        self.opened = False
        return Trade()


class TradeTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.scenario = ExchangeScenario()
        self.app = create_app(Path(self.temporary.name), SecretStore(MemoryVault()), self.scenario.stats_factory, self.scenario.trade_factory)
        self.state = self.app.state.application
        self.client = TestClient(self.app)
        self.client.__enter__()
        self.addCleanup(self.client.__exit__, None, None, None)
        settings, _ = self.state.store.settings()
        settings['collection'].update(profile_delay_seconds=0, group_delay_seconds=0, account_delay_seconds=0, account_start_interval_seconds=0)
        self.state.store.save_settings(settings)
        self.owner = self.client.post('/api/accounts', json={'username':'owner', 'password':'fixture-private-trade-password'}).json()
        self.second = self.client.post('/api/accounts', json={'username':'secondowner'}).json()
        for group in self.scenario.stats.groups:
            self.state.store.upsert_group(group, self.owner['id'])
        self.config = {'receive_account_id':self.owner['id'], 'send_account_id':self.owner['id'], 'donors':['partner'], 'recipients':['partner'], 'count':1, 'quality':'any'}

    def wait(self, condition, timeout=10):
        until = time.monotonic()+timeout
        while time.monotonic() < until:
            if condition():
                return
            time.sleep(.01)
        self.fail('Synthetic trade worker timed out')

    def preview(self, **changes):
        result = self.client.post('/api/trade/preview', json={**self.config, **changes})
        self.assertEqual(result.status_code, 200, result.text)
        return result.json()

    def start(self, plan, **mode):
        result = self.client.post(f"/api/trade/runs/{plan['id']}/start", json=mode)
        self.assertEqual(result.status_code, 200, result.text)
        return plan['id']

    def finished(self, rid):
        self.wait(lambda: not self.state.trades.threads[rid].is_alive())
        self.assertEqual(self.state.jobs.priority_owner, rid if self.state.trades.run(rid)['priority_held'] else None)
        self.assertEqual(self.scenario.trade_open, 0)
        return self.client.get('/api/trade/runs/'+rid).json()

    def stats_job(self):
        return self.state.jobs.start([self.owner['id']], 'collect')['id']

    def test_immediate_trade_empty_database_discovers_links_and_follows_both_accounts(self):
        self.state.store.execute('DELETE FROM account_groups')
        self.scenario.require_follow = True
        # Distinct accounts and counterparties exercise both subscription paths.
        self.scenario.group_lists['owner'] = list(self.scenario.stats.groups)
        plan = self.preview(receive_account_id=self.second['id'], donors=['donor'])
        self.assertEqual(plan['plan']['groups'], [])
        with patch('murer.analytics.analyze', side_effect=AssertionError('No quality analysis for immediate Trade')):
            result = self.finished(self.start(plan))
        self.assertEqual(result['status'], 'awaiting_completion')
        self.assertEqual(result['confirmed_count'], 1)
        self.assertEqual(set(self.scenario.follow_accounts), {('secondowner','donor'), ('owner','partner')})
        self.assertIn('owner', self.scenario.discovery_accounts)
        self.assertTrue(result['confirmed'][0]['url'].startswith('https://x.com/i/chat/'))
        self.assertTrue(result['plan']['groups'])
        self.assertEqual(self.state.store.rows('SELECT * FROM run_snapshots'), [])

    def test_same_account_empty_pool_reuses_baseline_discovery_and_follows_once(self):
        self.state.store.execute('DELETE FROM account_groups')
        self.scenario.require_follow = True
        result = self.finished(self.start(self.preview()))
        self.assertEqual(result['confirmed_count'], 1)
        self.assertEqual(self.scenario.discovery_accounts, ['owner','owner'])
        self.assertEqual(self.scenario.follow_accounts, [('owner','partner')])

    def test_missing_reverse_follow_can_resume_without_duplicate_follow_or_invite(self):
        self.scenario.require_follow = True
        self.scenario.blocked.add('recipient')
        plan = self.preview(receive_account_id=self.second['id'], recipients=['recipient'])
        first = self.finished(self.start(plan))
        self.assertEqual(first['status'], 'awaiting_review')
        self.assertEqual(self.scenario.invites, [])
        self.assertIn(('owner','recipient'), self.scenario.follow_accounts)
        baseline = first['baseline']
        self.scenario.blocked.clear()
        result = self.finished(self.start(plan))
        self.assertEqual(result['confirmed_count'], 1)
        self.assertEqual(result['baseline'], baseline)
        self.assertEqual(self.scenario.follow_accounts.count(('owner','recipient')), 1)
        self.assertEqual(len(self.scenario.invites), 1)

    def test_uncertain_outgoing_follow_is_verified_without_resending(self):
        factory = self.state.trades.session_factory
        follow_modes = []
        def uncertain(*args):
            browser = factory(*args)
            original = browser.follow
            async def follow(name, before_send, allow_send=True):
                if name != 'recipient':
                    return await original(name, before_send, allow_send)
                follow_modes.append(allow_send)
                if allow_send:
                    before_send()
                return {'following':None,'follows_us':True}
            browser.follow = follow
            return browser
        self.state.trades.session_factory = uncertain
        plan = self.preview(recipients=['recipient'])
        first = self.finished(self.start(plan))
        self.assertEqual(first['status'], 'awaiting_review')
        self.finished(self.start(plan))
        self.assertEqual(follow_modes, [True, False])
        self.assertEqual(self.scenario.invites, [])

    def test_handles_unlimited_lists_and_validates_configuration(self):
        self.assertEqual(usernames('@USER user, other;OTHER'), ['user','other'])
        self.assertEqual(len(usernames([f'user{i}' for i in range(300)])), 300)
        for field, value in [('count',0),('count',True),('count',1.5),('quality','unknown'),('recipients',[]),('donors',[]),('recipients',['owner']),('recipients',['bad/name']),('send_account_id','missing')]:
            response = self.client.post('/api/trade/preview', json={**self.config, field:value})
            self.assertEqual(response.status_code, 422, (field,response.text))
        data = self.client.get('/api/trade').json()
        self.assertEqual(data['accounts'][0]['group_count'], 2)
        self.assertNotIn('fixture-private-trade-password', json.dumps(data))

    def test_verified_username_change_updates_current_trade_plan_and_keeps_id(self):
        factory=self.state.trades.session_factory
        def renamed(*args):
            config=args[0]
            browser=factory(*args)
            login=browser.login
            async def confirmed(credentials):
                result=await login(credentials)
                config.account_identity_handler({'verified':True,'username':'actualowner','x_id':'111',
                    'origin':'x_self_profile','observed_at':'2026-10-16T12:00:00+00:00'})
                credentials.username='actualowner'
                return result
            browser.login=confirmed
            return browser
        self.state.trades.session_factory=renamed
        plan=self.preview()
        result=self.finished(self.start(plan))
        self.assertEqual(result['confirmed_count'],1)
        self.assertEqual(self.state.store.account(self.owner['id'])['username'],'actualowner')
        self.assertEqual(result['plan']['send_username'],'actualowner')
        self.assertEqual(result['plan']['receive_username'],'actualowner')
        self.assertEqual(result['plan']['send_accounts'][0]['id'],self.owner['id'])
        self.assertEqual(result['plan']['send_accounts'][0]['username'],'actualowner')
        self.assertEqual(len(result['plan']['account_name_updates']),1)
        # Continuation validates the updated frozen handles against the same ID.
        self.finished(self.start(plan,checks_only=True))

    def test_strict_quality_excludes_unknown_and_any_keeps_it(self):
        self.assertEqual(len(self.preview()['plan']['groups']), 2)
        strict = self.preview(quality='good')
        self.assertEqual(strict['plan']['groups'], [])
        self.assertEqual(len(strict['plan']['excluded']), 2)
        self.assertGreater(strict['plan']['shortage'], 0)

    def test_missing_add_button_is_cached_and_loop_continues_for_each_recipient(self):
        plan = self.preview(recipients=['partner','secondpartner'])
        blocked = plan['plan']['groups'][0]['id']
        self.scenario.unavailable.add(blocked)
        result = self.finished(self.start(plan))
        self.assertEqual(result['status'], 'awaiting_completion', result)
        self.assertEqual(result['confirmed_count'], 2)
        self.assertEqual({item['recipient'] for item in result['confirmed']}, {'partner','secondpartner'})
        self.assertEqual(sum(gid==blocked for gid,_ in self.scenario.invites), 1)
        self.state.trades.finish(plan['id'])
        next_plan = self.preview()
        self.assertNotIn(blocked, [group['id'] for group in next_plan['plan']['groups']])
        self.assertEqual(self.client.post('/api/trade/capabilities/recheck', json={'account_id':self.owner['id'],'group_id':blocked}).status_code, 200)
        self.assertIn(blocked, [group['id'] for group in self.preview()['plan']['groups']])
        report = self.client.get(f"/api/trade/runs/{plan['id']}/export")
        self.assertEqual(report.status_code, 200)
        self.assertIn('https://x.com/i/chat/g', report.content.decode('utf-8-sig'))
        self.assertNotIn('fixture-private-trade-password', report.content.decode('utf-8-sig'))

    def test_trade_preempts_collection_and_automatically_resumes_without_browser_overlap(self):
        plan = self.preview()
        job_id = self.stats_job()
        self.wait(lambda: self.scenario.stats.count('members') > 0)
        result = self.finished(self.start(plan))
        self.assertEqual(result['status'], 'awaiting_completion', result)
        self.assertEqual(self.state.store.job(job_id)['status'], 'suspended_trade')
        self.assertEqual(self.scenario.stats.count('login'), 1)
        self.state.trades.finish(plan['id'])
        self.wait(lambda: not self.state.jobs.threads[job_id].is_alive())
        self.assertEqual(self.state.store.job(job_id)['status'], 'completed')
        self.assertGreaterEqual(self.scenario.stats.count('login'), 2)
        self.assertEqual(self.scenario.stats_open, 0)

    def test_manually_paused_collection_stays_paused_after_trade(self):
        plan = self.preview()
        job_id = self.stats_job()
        self.wait(lambda: self.scenario.stats.count('login') > 0)
        self.state.jobs.command(job_id, 'pause')
        self.finished(self.start(plan))
        self.state.trades.finish(plan['id'])
        self.assertEqual(self.state.store.job(job_id)['status'], 'interrupted')
        self.assertFalse(self.state.jobs.threads[job_id].is_alive())

    def test_manual_login_collection_does_not_silently_resume_after_trade(self):
        plan = self.preview()
        self.scenario.stats.manual_once = True
        job_id = self.stats_job()
        self.wait(lambda: self.state.store.job(job_id)['status']=='requires_manual')
        self.finished(self.start(plan))
        self.state.trades.finish(plan['id'])
        self.assertEqual(self.state.store.job(job_id)['status'], 'interrupted')

    def test_mutual_follow_gate_and_read_only_checks_send_no_invitation(self):
        plan = self.preview()
        self.scenario.blocked.add('partner')
        result = self.finished(self.start(plan))
        self.assertEqual(result['status'], 'awaiting_review')
        self.assertIn('Взаимная подписка',result['progress']['operation'])
        self.assertEqual(result['progress']['relationship_blocks'],[{'account_id':self.owner['id'],'username':'partner'}])
        self.assertEqual(self.scenario.invites, [])
        result = self.finished(self.start(plan, checks_only=True))
        self.assertEqual(result['status'], 'awaiting_review')
        self.assertEqual(self.scenario.invites, [])
        self.scenario.blocked.clear()
        result=self.finished(self.start(plan))
        self.assertEqual(result['confirmed_count'],1)
        self.assertEqual(result['progress']['relationship_blocks'],[])

    def test_uncertain_action_consumes_no_success_and_is_not_resent_on_resume(self):
        self.scenario.uncertain = True
        plan = self.preview(count=2)
        result = self.finished(self.start(plan))
        self.assertEqual(result['status'], 'awaiting_review')
        self.assertEqual(result['confirmed_count'], 0)
        self.assertEqual(len(self.scenario.invites), 1)
        self.assertEqual(result['items'][0]['status'], 'uncertain')
        self.finished(self.start(plan))
        self.assertEqual(len(self.scenario.invites), 1)
        self.scenario.verify_status = 'not_added'
        reconciled = self.finished(self.start(plan, verify_only=True))
        self.assertEqual(reconciled['items'][0]['status'], 'not_added')
        self.assertEqual(len(self.scenario.invites), 1)

    def test_uncertain_membership_can_be_verified_after_group_disappears_from_pool(self):
        self.scenario.uncertain = True
        plan = self.preview()
        first = self.finished(self.start(plan))
        refreshed = {**first['plan'], 'groups':[]}
        self.state.trades.update(plan['id'], plan=refreshed)
        result = self.finished(self.start(plan, verify_only=True))
        self.assertEqual(result['confirmed_count'], 1)
        self.assertEqual(len(self.scenario.invites), 1)

    def test_priority_blocks_other_jobs_and_stop_preserves_uncertain_intent(self):
        self.scenario.hold.clear()
        plan = self.preview()
        rid = self.start(plan)
        self.wait(self.scenario.started.is_set)
        self.assertEqual(self.client.post('/api/jobs',json={'account_ids':[self.owner['id']],'mode':'login'}).status_code,422)
        self.assertEqual(self.client.post(f'/api/trade/runs/{rid}/start',json={}).status_code,422)
        self.client.post(f'/api/trade/runs/{rid}/command/stop')
        result = self.finished(rid)
        self.assertEqual(result['status'], 'stopped')
        self.assertEqual(result['items'][0]['status'], 'uncertain')
        self.scenario.hold.set()

    def test_restart_marks_sending_uncertain_and_keeps_confirmed_history(self):
        plan = self.preview()
        self.finished(self.start(plan))
        self.state.store.execute("UPDATE trade_items SET status='sending' WHERE run_id=?", (plan['id'],))
        self.state.store.execute("UPDATE trade_runs SET status='running' WHERE id=?", (plan['id'],))
        recovered = TradeManager(self.state.store,self.state.secrets,self.state.jobs,self.state.configuration,lambda _:None,self.scenario.trade_factory)
        result = recovered.run(plan['id'])
        self.assertEqual(result['status'],'interrupted')
        self.assertEqual(result['items'][0]['status'],'uncertain')

    def test_distinct_receiver_and_sender_are_opened_sequentially(self):
        result = self.finished(self.start(self.preview(receive_account_id=self.second['id'])))
        self.assertEqual(result['status'],'awaiting_completion')

    def test_unavailable_capability_is_specific_to_our_account(self):
        group = self.scenario.stats.groups[0]
        gid = self.state.store.upsert_group(group,self.second['id'])
        self.state.store.execute('INSERT INTO trade_capabilities VALUES(?,?,?,?,?)', (gid,self.owner['id'],'unavailable','Synthetic context', '2026-10-15T00:00:00+00:00'))
        self.assertNotIn(gid,[g['id'] for g in self.preview()['plan']['groups']])
        self.assertIn(gid,[g['id'] for g in self.preview(send_account_id=self.second['id'])['plan']['groups']])

    def test_plan_keeps_rule_version_and_rejects_changed_our_handle(self):
        plan = self.preview()
        settings,_ = self.state.store.settings()
        settings['evaluation']['weights']['U'] = 99
        self.state.store.save_settings(settings)
        frozen = self.state.trades.run(plan['id'])
        self.assertEqual(frozen['settings_version'],plan['settings_version'])
        self.assertEqual(frozen['settings'],plan['settings'])
        self.state.store.execute('UPDATE accounts SET username=? WHERE id=?',('renamedowner',self.owner['id']))
        self.assertEqual(self.client.post(f"/api/trade/runs/{plan['id']}/start",json={}).status_code,422)

    def test_storage_failure_during_cleanup_releases_exclusive_priority(self):
        execute = self.state.store.execute
        def fail_finalization(sql,*args):
            if sql.startswith("UPDATE trade_items SET status='uncertain',reason='Подтверждение не получено"):
                raise OSError('Synthetic storage failure')
            return execute(sql,*args)
        plan = self.preview()
        with patch.object(self.state.store,'execute',side_effect=fail_finalization):
            self.finished(self.start(plan))
        self.assertTrue(self.state.trades.controls[plan['id']].cleanup_failed)

    def test_trade_manual_gate_reloads_pin_and_only_verifies_after_intent(self):
        self.scenario.manual_after_intent = True
        plan = self.preview()
        rid = self.start(plan)
        self.wait(lambda:self.state.trades.run(rid)['status']=='requires_manual')
        self.assertEqual(self.state.store.account(self.owner['id'])['status'],'requires_manual')
        self.assertEqual(self.client.patch('/api/accounts/'+self.owner['id'],json={'ichat_password':'fixture-pin'}).status_code,200)
        self.assertEqual(self.client.post(f'/api/trade/runs/{rid}/command/continue').status_code,200)
        result = self.finished(rid)
        self.assertEqual(result['status'],'awaiting_completion')
        self.assertEqual(self.scenario.continued_pin,'fixture-pin')
        self.assertEqual(len(self.scenario.invites),1)

    def test_failed_trade_login_preserves_proxy_error_instead_of_active(self):
        self.scenario.login_status = 'proxy_error'
        result = self.finished(self.start(self.preview()))
        self.assertEqual(result['status'],'error')
        self.assertEqual(self.state.store.account(self.owner['id'])['status'],'proxy_error')
        self.assertEqual(self.scenario.invites,[])

    def test_existing_member_is_saved_and_excluded_from_future_exchange(self):
        plan = self.preview()
        gid = plan['plan']['groups'][0]['id']
        self.scenario.already.add((gid,'partner'))
        result = self.finished(self.start(plan))
        self.assertEqual(len(result['already_members']),1)
        self.assertEqual(result['confirmed_count'],1)
        links = self.state.store.rows('SELECT gm.* FROM group_members gm JOIN participants p ON p.id=gm.participant_id WHERE gm.group_id=? AND p.username=?',(gid,'partner'))
        self.assertEqual(len(links),1)
        self.assertEqual(links[0]['uncertain'],0)
        self.assertEqual(self.state.store.rows('SELECT origin FROM trade_member_observations WHERE group_id=? AND username=?',(gid,'partner'))[0]['origin'],'already_member')
        self.state.trades.finish(plan['id'])
        previous = sum(group_id==gid for group_id,_ in self.scenario.invites)
        observed_at = self.state.store.rows('SELECT observed_at FROM trade_member_observations WHERE group_id=? AND username=?',(gid,'partner'))[0]['observed_at']
        next_plan = self.preview()
        self.finished(self.start(next_plan))
        self.assertEqual(sum(group_id==gid for group_id,_ in self.scenario.invites),previous)
        self.assertEqual(self.state.store.rows('SELECT observed_at FROM trade_member_observations WHERE group_id=? AND username=?',(gid,'partner'))[0]['observed_at'],observed_at)

    def test_shortage_adds_sender_in_same_run_without_resetting_baseline_or_quota(self):
        self.scenario.incoming_extra = 3
        plan = self.preview(count=3)
        first = self.finished(self.start(plan))
        self.assertEqual(first['status'],'awaiting_account')
        self.assertEqual(first['remaining']['partner'],1)
        baseline = first['baseline']
        shared = self.scenario.stats.groups[0]
        self.state.store.upsert_group(shared,self.second['id'])
        extra = {'x_id':'g777','name':'Extra sender group','url':'https://x.com/i/chat/g777'}
        self.state.store.upsert_group(extra,self.second['id'])
        self.scenario.stats.people['g777'] = []
        response = self.client.post(f"/api/trade/runs/{plan['id']}/accounts",json={'account_id':self.second['id']})
        self.assertEqual(response.status_code,200,response.text)
        self.assertEqual(response.json()['plan']['groups'][0]['source_account_id'],self.second['id'])
        result = self.finished(self.start(plan))
        self.assertEqual(result['confirmed_count'],3)
        self.assertEqual(result['baseline'],baseline)
        self.assertEqual(len({item['group_id'] for item in result['confirmed']}),3)
        self.assertEqual(sum(item['source_account_id']==self.second['id'] for item in result['confirmed']),1)
        self.assertEqual(result['status'],'awaiting_completion')
        self.assertEqual(self.state.jobs.priority_owner,plan['id'])
        self.assertEqual(self.client.post(f"/api/trade/runs/{plan['id']}/finish",json={}).status_code,200)
        self.assertIsNone(self.state.jobs.priority_owner)

    def test_extra_sender_is_tried_before_old_sources_with_temporary_errors(self):
        factory=self.state.trades.session_factory
        failed_calls=[]
        def temporary_errors(*args):
            browser=factory(*args)
            original_login,original_invite=browser.login,browser.invite
            async def login(credentials):
                browser.test_username=credentials.username
                return await original_login(credentials)
            async def invite(group,target,before_send):
                if browser.test_username==self.owner['username']:
                    failed_calls.append(group['id'])
                    return {'status':'error','reason':'Synthetic temporary synchronization'}
                return await original_invite(group,target,before_send)
            browser.login,browser.invite=login,invite
            return browser
        self.state.trades.session_factory=temporary_errors
        plan=self.preview()
        first=self.finished(self.start(plan))
        self.assertEqual(first['status'],'awaiting_account')
        self.assertEqual(len(failed_calls),2)
        self.state.store.upsert_group({'x_id':'g777','name':'Extra sender group','url':'https://x.com/i/chat/g777'},self.second['id'])
        self.state.trades.add_account(plan['id'],self.second['id'])
        result=self.finished(self.start(plan))
        self.assertEqual(result['confirmed_count'],1)
        self.assertEqual(result['confirmed'][0]['source_account_id'],self.second['id'])
        self.assertEqual(len(failed_calls),2,'Old temporary errors should not delay the selected extra sender')

    def test_incoming_rechecks_preserve_baseline_and_never_invite_or_follow_again(self):
        self.scenario.incoming_extra=0
        plan=self.preview()
        first=self.finished(self.start(plan))
        self.assertEqual(first['status'],'awaiting_incoming')
        self.assertEqual(self.client.post(f"/api/trade/runs/{plan['id']}/finish",json={}).status_code,422)
        calls=len(self.scenario.invites)
        self.scenario.incoming_extra=1
        response=self.client.post(f"/api/trade/runs/{plan['id']}/incoming")
        self.assertEqual(response.status_code,200,response.text)
        result=self.finished(plan['id'])
        self.assertEqual(result['incoming']['observed_count'],1)
        self.assertTrue(result['can_finish'])
        self.assertEqual(result['baseline'],first['baseline'])
        self.assertEqual(len(self.scenario.invites),calls)
        self.assertEqual(self.scenario.follow_calls,['partner'])
        self.assertEqual(len(result['incoming_checks']),2)
        self.state.trades.finish(plan['id'])
        # Historical recheck temporarily reserves the queue, then releases it.
        self.assertEqual(self.client.post(f"/api/trade/runs/{plan['id']}/incoming").status_code,200)
        result=self.finished(plan['id'])
        self.assertEqual(result['status'],'completed')
        self.assertIsNone(self.state.jobs.priority_owner)

    def test_partial_baseline_never_gives_confident_incoming_completion(self):
        self.scenario.incoming_complete=False
        plan=self.preview()
        result=self.finished(self.start(plan))
        self.assertEqual(result['incoming']['verdict'],'preliminary')
        self.assertFalse(result['can_finish'])
        self.assertEqual(self.client.post(f"/api/trade/runs/{plan['id']}/finish",json={}).status_code,422)
        response=self.client.post(f"/api/trade/runs/{plan['id']}/finish",json={'accept_unverified':True})
        self.assertEqual(response.status_code,200,response.text)
        self.assertEqual(response.json()['status'],'closed_unverified')
        self.assertIsNone(self.state.jobs.priority_owner)

    def test_checks_only_never_follows_and_does_not_hold_queue(self):
        result=self.finished(self.start(self.preview(),checks_only=True))
        self.assertEqual(result['status'],'checked')
        self.assertEqual(self.scenario.follow_calls,[])
        self.assertEqual(self.scenario.incoming_reads,0)
        self.assertIsNone(self.state.jobs.priority_owner)

    def test_restart_keeps_waiting_trade_exclusive_until_user_finishes(self):
        plan=self.preview(count=3)
        self.finished(self.start(plan))
        self.state.jobs.priority_owner=None
        recovered=TradeManager(self.state.store,self.state.secrets,self.state.jobs,self.state.configuration,lambda _:None,self.scenario.trade_factory)
        self.assertEqual(self.state.jobs.priority_owner,plan['id'])
        with self.assertRaises(ValueError):
            self.state.jobs.start([self.owner['id']],'collect')
        recovered.finish(plan['id'],accept_unverified=True)
        self.assertIsNone(self.state.jobs.priority_owner)

    def test_quality_uses_latest_snapshot_for_each_group_not_latest_account_run(self):
        group = self.state.store.dataset()['groups'][0]
        settings, version = self.state.store.settings()
        for jid, when, rows in [
            ('earlier', '2026-10-15T10:00:00+00:00', [{'id':group['id'],'category':'Хорошая','preliminary':False,'score':90}]),
            ('unrelated', '2026-10-16T10:00:00+00:00', [{'id':'different-group','category':'Плохая','preliminary':False,'score':10}])]:
            self.state.store.execute('INSERT INTO jobs VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',
                (jid,'collect','[]','[]','completed',when,when,encode(settings),version,'{}',None,when))
            self.state.store.execute('INSERT INTO run_snapshots VALUES(?,?,?,?,?)',
                (jid,when,'{}',encode({'groups':rows}),version))
        pool, _ = self.state.trades._pool(self.owner['id'],'good')
        self.assertEqual(len(pool), 1)
        self.assertEqual(pool[0]['id'], group['id'])
        self.assertEqual(pool[0]['quality_checked_at'], '2026-10-15T10:00:00+00:00')

    def test_uncertain_intent_keeps_target_id_for_later_reconciliation(self):
        self.scenario.uncertain = True
        plan = self.preview()
        result = self.finished(self.start(plan))
        item = next(row for row in result['items'] if row['status']=='uncertain')
        self.assertEqual(json.loads(item['evidence'])['target_x_id'], '42')
        factory = self.state.trades.session_factory
        observed = []
        def record_verification(*args):
            browser = factory(*args)
            verify = browser.verify_membership
            async def wrapped(group, target):
                observed.append(group.get('target_x_id'))
                return await verify(group,target)
            browser.verify_membership = wrapped
            return browser
        self.state.trades.session_factory = record_verification
        self.finished(self.start(plan,verify_only=True))
        self.assertEqual(observed, ['42'])

    def test_trade_waits_for_collection_cleanup_and_aborts_if_close_failed(self):
        factory = self.state.jobs.session_factory
        def failing(*args):
            browser = factory(*args)
            close = browser.close
            async def wrapped():
                await close()
                raise OSError('Synthetic close failure')
            browser.close = wrapped
            return browser
        self.state.jobs.session_factory = failing
        self.scenario.stats.command_delay = .1
        jid = self.stats_job()
        self.wait(lambda: self.scenario.stats_open==1)
        result = self.finished(self.start(self.preview()))
        self.assertEqual(result['status'], 'error')
        self.assertEqual(self.scenario.invites, [])
        self.assertEqual(self.state.store.job(jid)['status'], 'error')
        self.assertTrue(self.state.jobs.browser_cleanup_failed)

    def test_trade_planning_does_not_recalculate_analysis(self):
        with patch('murer.analytics.analyze',side_effect=AssertionError('Trade must use a saved result')):
            plan=self.preview()
            self.assertEqual(len(plan['plan']['groups']),2)

    def test_additional_sender_without_statistics_only_discovers_chats(self):
        self.scenario.incoming_extra=3
        plan=self.preview(count=3)
        self.finished(self.start(plan))
        extra={'x_id':'g555','name':'New sender chat','url':'https://x.com/i/chat/g555'}
        self.scenario.group_lists['secondowner']=[extra]
        self.scenario.stats.people['g555']=[]
        self.state.trades.add_account(plan['id'],self.second['id'])
        result=self.finished(self.start(plan))
        self.assertEqual(result['confirmed_count'],3)
        self.assertTrue(any(g['x_id']=='g555' for g in result['plan']['groups']))
        self.assertEqual(self.scenario.stats.count('profile'),0)

    def test_application_restart_restores_prior_collection_after_finish(self):
        plan=self.preview()
        jid=self.stats_job()
        self.wait(lambda:self.scenario.stats.count('members')>0)
        self.finished(self.start(plan))
        recovered=create_app(self.state.store.data_dir,self.state.secrets,self.scenario.stats_factory,self.scenario.trade_factory).state.application
        try:
            self.assertEqual(recovered.jobs.priority_owner,plan['id'])
            self.assertEqual(recovered.store.job(jid)['status'],'interrupted')
            recovered.trades.finish(plan['id'])
            self.wait(lambda:not recovered.jobs.threads[jid].is_alive())
            self.assertEqual(recovered.store.job(jid)['status'],'completed')
        finally:
            recovered.trades.close()
            recovered.jobs.close()

    def test_historical_incoming_recheck_does_not_require_archived_sender(self):
        plan=self.preview(receive_account_id=self.second['id'])
        self.finished(self.start(plan))
        self.state.trades.finish(plan['id'])
        self.state.store.execute('UPDATE accounts SET archived=1 WHERE id=?',(self.owner['id'],))
        self.assertEqual(self.client.post(f"/api/trade/runs/{plan['id']}/incoming").status_code,200)
        result=self.finished(plan['id'])
        self.assertEqual(result['status'],'completed')
        self.assertIsNone(self.state.jobs.priority_owner)

    def test_failed_historical_recheck_preserves_previous_snapshot_and_completion(self):
        plan=self.preview()
        before=self.finished(self.start(plan))['incoming']
        self.state.trades.finish(plan['id'])
        factory=self.scenario.trade_factory
        def failed(*args):
            browser=factory(*args)
            async def error(credentials):
                raise RuntimeError('Synthetic incoming load failed')
            browser.discover_groups=error
            return browser
        self.state.trades.session_factory=failed
        self.assertEqual(self.client.post(f"/api/trade/runs/{plan['id']}/incoming").status_code,200)
        result=self.finished(plan['id'])
        self.assertEqual(result['status'],'completed')
        self.assertEqual(result['incoming'],before)
        self.assertTrue(result['error'])
        self.assertIsNone(self.state.jobs.priority_owner)

    def test_extra_sender_manual_pin_edit_is_allowed_and_redacted(self):
        self.state.secrets.set(self.second['id'],{'ichat_password':'synthetic-original-pin'})
        plan=self.preview(count=3)
        self.finished(self.start(plan))
        self.state.store.upsert_group({'x_id':'g777','name':'Extra','url':'https://x.com/i/chat/g777'},self.second['id'])
        self.state.trades.add_account(plan['id'],self.second['id'])
        factory=self.scenario.trade_factory
        def manual(*args):
            browser=factory(*args)
            login=browser.login
            async def start(credentials):
                result=await login(credentials)
                if credentials.username=='secondowner':
                    return {'status':'requires_manual','reason':'Synthetic gate synthetic-original-pin'}
                return result
            browser.login=start
            return browser
        self.state.trades.session_factory=manual
        self.start(plan)
        self.wait(lambda:self.state.trades.run(plan['id'])['status']=='requires_manual')
        self.assertNotIn('synthetic-original-pin',self.state.trades.run(plan['id'])['progress']['manual_reason'])
        self.assertEqual(self.client.patch('/api/accounts/'+self.second['id'],json={'ichat_password':'synthetic-updated-pin'}).status_code,200)
        self.client.post(f"/api/trade/runs/{plan['id']}/command/continue")
        self.finished(plan['id'])
        self.assertEqual(self.scenario.continued_pin,'synthetic-updated-pin')

    def test_shared_group_retry_preserves_both_source_attempts(self):
        plan=self.preview(count=2)
        blocked=plan['plan']['groups'][0]
        self.scenario.unavailable.add(blocked['id'])
        first=self.finished(self.start(plan))
        self.assertEqual(first['remaining']['partner'],1)
        # The second account has permission for that same group.
        self.state.store.upsert_group(blocked,self.second['id'])
        self.scenario.unavailable.clear()
        self.state.trades.add_account(plan['id'],self.second['id'])
        result=self.finished(self.start(plan))
        self.assertEqual(result['confirmed_count'],2)
        attempts=[item for item in result['attempts'] if item['group_id']==blocked['id']]
        self.assertEqual([item['status'] for item in attempts],['unavailable','confirmed'])
        self.assertEqual([item['source_account_id'] for item in attempts],[self.owner['id'],self.second['id']])
        exported=self.client.get(f"/api/trade/runs/{plan['id']}/export").content.decode('utf-8-sig')
        self.assertIn('Synthetic no add button',exported)


if __name__ == '__main__':
    unittest.main()
