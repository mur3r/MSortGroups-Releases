"""Invitation guards with isolated synthetic elements, never real X actions."""
from pathlib import Path
import tempfile
import unittest
from unittest.mock import AsyncMock, MagicMock, patch

from murer.trade_browser import TradeSession
from murer.collector import SeleniumSession
from murer.rules import default_settings
from xgenius.config import Config
from xgenius.models import AccountState, AccountCredentials


class TradeBrowserTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        settings = default_settings()
        settings['collection'].update(action_delay_seconds=0,load_wait_seconds=0,login_poll_rounds=1,login_poll_seconds=0)
        self.session = TradeSession(Config(Path(self.temp.name)), MagicMock(), settings)
        self.session.username = 'fixture'
        self.session.manager.accounts['fixture'] = AccountState('fixture',browser=MagicMock())
        self.session._bind()
        self.session._page_gate = AsyncMock(return_value=None)
        self.session._click_first = AsyncMock(return_value=True)
        self.session.actions.get = AsyncMock()
        self.session.actions.sleep = AsyncMock()
        self.session.actions.wait = AsyncMock()
        self.session.actions.script = AsyncMock()
        self.session.members = AsyncMock(return_value={'status':'full','participants':[]})
        self.group = {'id':'fixture','x_id':'g123','url':'https://x.com/i/chat/g123'}
        self.intent = MagicMock()

    def form(self, selected='partner'):
        search, checkbox, confirm = MagicMock(), MagicMock(), MagicMock()
        search.get_attribute.side_effect = lambda key: {'type':'search','placeholder':'Search people'}.get(key,'')
        checkbox.get_attribute.return_value = ''
        confirm.is_enabled.return_value = True
        confirm.get_attribute.return_value = ''
        empty = {'state':'ready','input':search,'users':[],'button':confirm}
        target = {'username':'partner','control':checkbox,'disabled':False,'checked':False}
        checked = {**target,'username':selected,'checked':True}
        self.session.actions.script.side_effect = [{'state':'ready','button':MagicMock()},empty,{**empty,'users':[target]},{**empty,'users':[checked]}]
        return search, checkbox, confirm

    async def test_exact_user_intent_precedes_click_then_membership_confirms(self):
        search, checkbox, confirm = self.form()
        events = []
        self.intent.side_effect = lambda: events.append('intent')
        confirm.click.side_effect = lambda: events.append('click')
        self.session.verify_membership = AsyncMock(return_value={'status':'confirmed'})
        result = await self.session.invite(self.group,'partner',self.intent)
        self.assertEqual(result['status'],'confirmed')
        self.assertEqual(events,['intent','click'])
        self.assertEqual([call.args[0] for call in search.send_keys.call_args_list],list('partner'))
        checkbox.click.assert_called_once()
        confirm.click.assert_called_once()

    async def test_wrong_selected_person_never_reaches_mutation(self):
        _, _, confirm = self.form('different')
        self.assertEqual((await self.session.invite(self.group,'partner',self.intent))['status'],'error')
        self.intent.assert_not_called()
        confirm.click.assert_not_called()

    async def test_known_target_id_cannot_be_replaced_by_handle_only_result(self):
        self.form()
        result = await self.session.invite({**self.group,'target_x_id':'42'},'partner',self.intent)
        self.assertEqual(result['status'], 'error')
        self.intent.assert_not_called()

    async def test_selected_stable_identity_is_checked_again_before_intent(self):
        _, _, confirm = self.form()
        values = list(self.session.actions.script.side_effect)
        values[2]['users'][0]['x_id'] = '42'
        values[3]['users'][0]['x_id'] = '43'
        self.session.actions.script.side_effect = values
        result = await self.session.invite({**self.group,'target_x_id':'42'},'partner',self.intent)
        self.assertEqual(result['status'], 'error')
        self.intent.assert_not_called()
        confirm.click.assert_not_called()

    async def test_xchat_existing_disabled_selected_result_never_invites(self):
        self.form()
        values = list(self.session.actions.script.side_effect)
        values[2]['users'][0].update(disabled=True,checked=True)
        self.session.actions.script.side_effect = values
        result = await self.session.invite(self.group,'partner',self.intent)
        self.assertEqual(result['status'],'already_member')
        self.intent.assert_not_called()

    async def test_already_member_is_not_a_new_addition(self):
        self.form()
        values = list(self.session.actions.script.side_effect)
        values[2]['users'][0].update(disabled=True,checked=True)
        self.session.actions.script.side_effect = values
        self.assertEqual((await self.session.invite(self.group,'partner',self.intent))['status'],'already_member')
        self.session.members.assert_not_awaited()
        self.intent.assert_not_called()

    async def test_missing_button_and_unloaded_panel_are_distinct(self):
        for state, expected in [('unavailable','unavailable'),('unknown','error')]:
            self.session.actions.script.return_value = {'state':state}
            result = await self.session.invite(self.group,'partner',self.intent)
            self.assertEqual(result['status'],expected)
        self.intent.assert_not_called()

    async def test_group_sync_waits_before_opening_recipient_search(self):
        self.form()
        values=list(self.session.actions.script.side_effect)
        self.session.actions.script.side_effect=[{'state':'loading','reason':'Sync is in progress'},*values]
        self.session.verify_membership=AsyncMock(return_value={'status':'confirmed'})
        self.assertEqual((await self.session.invite(self.group,'partner',self.intent))['status'],'confirmed')
        self.intent.assert_called_once()

    async def test_group_still_syncing_is_not_cached_as_unavailable(self):
        self.session.actions.script.return_value={'state':'loading','reason':'Sync is in progress'}
        result=await self.session.invite(self.group,'partner',self.intent)
        self.assertEqual(result['status'],'error')
        self.assertIn('Sync',result['reason'])
        self.intent.assert_not_called()

    async def test_matching_owner_profile_is_required_after_cookie_login(self):
        credentials=AccountCredentials(username='fixture',password='')
        self.session.actions.script.return_value={'state':'confirmed','username':'fixture'}
        with patch.object(SeleniumSession,'login',new=AsyncMock(return_value={'status':'active'})) as login:
            result=await self.session.login(credentials)
        login.assert_awaited_once_with(credentials)
        self.assertEqual(result['status'],'active')
        self.session.actions.get.assert_awaited_once_with('https://x.com/fixture')

    async def test_wrong_owner_cookie_session_requires_manual_before_trade(self):
        credentials=AccountCredentials(username='fixture',password='')
        self.session.actions.script.return_value={'state':'mismatch'}
        result=await self.session._verify_owner(credentials,{'status':'active'})
        self.assertEqual(result['status'],'requires_manual')
        self.assertIn('другому аккаунту',result['reason'])
        self.assertIn('@fixture',result['reason'])
        self.intent.assert_not_called()

    async def test_owner_must_be_verified_again_after_manual_continue(self):
        credentials=AccountCredentials(username='fixture',password='')
        self.session.actions.script.return_value={'state':'mismatch'}
        with patch.object(SeleniumSession,'continue_login',new=AsyncMock(return_value={'status':'active'})):
            self.assertEqual((await self.session.continue_login(credentials))['status'],'requires_manual')

    async def test_owner_guard_preserves_login_failure_and_unrecognized_profile(self):
        credentials=AccountCredentials(username='fixture',password='')
        failure={'status':'proxy_error','reason':'Synthetic network failure'}
        self.assertEqual(await self.session._verify_owner(credentials,failure),failure)
        self.session.actions.get.assert_not_awaited()
        self.session.actions.script.return_value={'state':'loading'}
        self.assertEqual((await self.session._verify_owner(credentials,{'status':'active'}))['status'],'requires_manual')

    async def test_unrecognized_recipient_and_non_xchat_url_are_rejected(self):
        for group, name in [({**self.group,'url':'https://evil.invalid/i/chat/g123'},'partner'),(self.group,'bad/name')]:
            self.assertEqual((await self.session.invite(group,name,self.intent))['status'],'error')
        self.intent.assert_not_called()
        self.session.members.assert_not_awaited()

    async def test_absence_is_not_proven_by_partial_members(self):
        self.session._recipient_picker = AsyncMock(return_value={'target':None,'form':{}})
        self.assertEqual((await self.session.verify_membership(self.group,'partner'))['status'],'uncertain')
        self.session._recipient_picker.return_value = {'target':{'disabled':False,'checked':False,'x_id':'42'},'form':{}}
        self.assertEqual((await self.session.verify_membership(self.group,'partner'))['status'],'not_added')

    async def test_follow_intent_precedes_only_exact_follow_click(self):
        self.session.relationship = AsyncMock(return_value={'following':False,'x_id':'42'})
        button = MagicMock()
        button.is_enabled.return_value = True
        events=[]
        button.click.side_effect=lambda:events.append('click')
        self.session.actions.script.side_effect=[button,{'following':True,'x_id':'42'}]
        result=await self.session.follow('partner',lambda:events.append('intent'))
        self.assertTrue(result['following'])
        self.assertEqual(events,['intent','click'])
        button.click.assert_called_once()

    async def test_unknown_follow_outcome_does_not_click_again(self):
        self.session.relationship = AsyncMock(return_value={'following':False,'x_id':'42'})
        result=await self.session.follow('partner',self.intent,allow_send=False)
        self.assertFalse(result['following'])
        self.intent.assert_not_called()
        self.session.actions.script.assert_not_awaited()


if __name__=='__main__':
    unittest.main()
