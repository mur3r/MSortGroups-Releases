"""Explicit group invitations, isolated from the statistics read-only policy.

Invitations require an exact uniquely selected handle in an Add-members dialog.
Counterparty follows require the matching profile header and stable-ID Follow button.
Changed markup fails closed; live writes require user-selected test targets.
"""
import re
from selenium.common.exceptions import TimeoutException

from .collector import SeleniumSession
from xgenius.core.dom import DEEP_QUERY_JS

OWNER_PROFILE_JS = DEEP_QUERY_JS + r"""
const visible=el=>!!el&&!!(el.offsetWidth||el.offsetHeight||el.getClientRects().length);
const main=deepQuery('[data-testid="primaryColumn"]')||deepQuery('main');
const name=main?.querySelector('[data-testid="UserName"]');
const handle=(name?.innerText||'').match(/@([A-Za-z0-9_]{1,15})\b/);
if(!handle||handle[1].toLowerCase()!==arguments[0])return {state:'loading'};
const edit=Array.from(main.querySelectorAll('[data-testid="editProfileButton"],a[href="/settings/profile"]')).filter(visible);
if(edit.length)return {state:'confirmed',username:handle[1].toLowerCase()};
const actions=main.querySelector('[data-testid="userActions"]');
const foreign=Array.from(actions?.parentElement?.querySelectorAll('[data-testid]')||[])
 .some(el=>visible(el)&&/^\d+-(?:unfollow|follow)$/.test(el.getAttribute('data-testid')||''));
return {state:foreign?'mismatch':'loading'};
"""

RELATIONSHIP_JS = DEEP_QUERY_JS + r"""
const visible=el=>!!el&&!!(el.offsetWidth||el.offsetHeight||el.getClientRects().length);
const main=deepQuery('[data-testid="primaryColumn"]')||deepQuery('main');
if(!main)return {following:null,follows_us:null,reason:'Шапка профиля не найдена'};
const name=main.querySelector('[data-testid="UserName"]');
const handle=name?(name.innerText||'').match(/@([A-Za-z0-9_]{1,15})\b/):null;
if(!handle||handle[1].toLowerCase()!==arguments[0])return {following:null,follows_us:null,reason:'Личность профиля не подтверждена'};
const actions=main.querySelector('[data-testid="userActions"]');
const root=actions?actions.parentElement:null;
const buttons=root?Array.from(root.querySelectorAll('[data-testid]')).filter(visible):[];
const following=buttons.some(el=>/^\d+-unfollow$/.test(el.getAttribute('data-testid')||''))?true:
 buttons.some(el=>/^\d+-follow$/.test(el.getAttribute('data-testid')||''))?false:null;
const indicator=main.querySelector('[data-testid="userFollowIndicator"]');
const follows=visible(indicator)&&/^(?:follows you|читает вас|подписан(?:а)? на вас)$/i.test((indicator.innerText||'').trim());
const ids=buttons.map(el=>(el.getAttribute('data-testid')||'').match(/^(\d+)-(?:unfollow|follow)$/)).filter(Boolean).map(m=>m[1]);
return {following,follows_us:follows?true:null,x_id:new Set(ids).size===1?ids[0]:null,username:handle[1].toLowerCase(),reason:follows?'Признак Follows you в шапке профиля':'Обратная подписка не подтверждена'};
"""

INVITE_DETAILS_JS = DEEP_QUERY_JS + r"""
const visible=el=>!!el&&!!(el.offsetWidth||el.offsetHeight||el.getClientRects().length);
const panels=deepQueryAll('[role="dialog"],[data-testid="DMConversationDetails"],[data-testid="DmConversationDetails"]').filter(visible);
const syncing=panels.some(panel=>/sync is in progress|synchroni[sz](?:ation|ing)|ид[её]т синхронизаци|выполняется синхронизаци/i.test(panel.innerText||''));
const loading=panels.some(panel=>deepQueryAll('[role="progressbar"],[aria-busy="true"],svg.animate-spin,[data-testid*="loading"],[data-testid*="spinner"]',panel).some(visible));
if(syncing||loading)return {state:'loading',reason:'XChat синхронизирует сведения группы; нужно дождаться загрузки'};
const members=panels.filter(el=>/members|participants|участник/i.test(el.innerText||''));
if(!members.length)return {state:'unknown',reason:'Сведения группы не загрузились'};
const buttons=members.flatMap(panel=>deepQueryAll('button,[role="button"]',panel)).filter(visible).filter(el=>
 /^(?:add|add (?:members|people|participants)|invite (?:members|people)|добавить|добавить участников|добавить людей|пригласить участников)$/i.test((el.innerText||'').trim()||(el.getAttribute('aria-label')||'').trim()));
const unique=[...new Set(buttons)];
if(unique.length===1)return {state:unique[0].disabled||unique[0].getAttribute('aria-disabled')==='true'?'unavailable':'ready',button:unique[0]};
if(unique.length>1)return {state:'unknown',reason:'Неоднозначная кнопка добавления'};
if(members.some(panel=>deepQuery('[role="progressbar"]',panel)))return {state:'unknown',reason:'Сведения ещё загружаются'};
return {state:'unavailable',reason:'В загруженных сведениях нет кнопки добавления участников для этого аккаунта'};
"""

INVITE_FORM_JS = DEEP_QUERY_JS + r"""
const visible=el=>!!el&&!!(el.offsetWidth||el.offsetHeight||el.getClientRects().length);
const panels=deepQueryAll('[role="dialog"],[data-testid="add-members-dialog"]').filter(visible);
const forms=panels.map(panel=>{
 const title=deepQueryAll('h1,h2,h3,[role="heading"]',panel).map(el=>el.innerText||'').join(' ')
  +' '+(panel.innerText||'').split('\n').map(t=>t.trim()).filter(t=>/^(?:add (?:members|people|participants)|добавить участников|добавить людей)$/i.test(t)).join(' ');
 if(!/add (?:members|people|participants)|invite (?:members|people)|добавить участников|добавить людей|пригласить участников/i.test(title))return null;
 const inputs=deepQueryAll('input',panel).filter(visible).filter(el=>
  ['search','text'].includes(el.type)&&/search|поиск/i.test([el.type,el.placeholder,el.getAttribute('aria-label'),el.getAttribute('data-testid')].join(' ')));
 if(inputs.length!==1||deepQuery('[contenteditable="true"],[data-testid="dmComposerTextInput"]',panel))return null;
 const rows=deepQueryAll('[data-testid="UserCell"],[role="option"],[data-testid="add-member-result"],[data-testid^="new-dm-user-suggestion-"]',panel).filter(visible);
 const users=rows.map(row=>{
  const handles=deepQueryAll('a[href]',row).map(a=>new URL(a.href).pathname.match(/^\/([A-Za-z0-9_]{1,15})\/?$/)).filter(Boolean).map(m=>m[1].toLowerCase());
  if(!handles.length){const match=(row.innerText||'').match(/@([A-Za-z0-9_]{1,15})\b/);if(match)handles.push(match[1].toLowerCase());}
  const names=[...new Set(handles)];if(names.length!==1)return null;
  const xchatId=(row.getAttribute('data-testid')||'').match(/^new-dm-user-suggestion-(\d+)$/);
  const checkbox=deepQuery('[role="checkbox"],input[type="checkbox"]',row);
  const control=checkbox||(xchatId?row:null);
  const checked=checkbox?(checkbox.getAttribute('aria-checked')==='true'||checkbox.checked===true):!!xchatId&&!!deepQuery('svg[data-icon="icon-checkmark-circle-fill"]',row);
  return {username:names[0],control,checked,disabled:!control||!!control.disabled||control.getAttribute('aria-disabled')==='true'||row.getAttribute('aria-disabled')==='true',x_id:row.getAttribute('data-user-id')||(xchatId?xchatId[1]:null)};
 }).filter(Boolean);
 const buttons=deepQueryAll('button',panel).filter(visible).filter(button=>/^(?:next|далее|add(?: \d+)?|add members|добавить(?: \d+)?|добавить участников)$/i.test((button.innerText||'').trim()||(button.getAttribute('aria-label')||'').trim()));
 return {input:inputs[0],users,button:buttons.length===1?buttons[0]:null};
}).filter(Boolean);
return forms.length===1?{state:'ready',...forms[0]}:{state:'unknown'};
"""


from .eventlog import session_step


class TradeSession(SeleniumSession):
    async def _verify_owner(self, credentials, result):
        """A valid cookie can belong to a different user than the saved handle."""
        if result.get('status') != 'active':
            return result
        if result.get('identity',{}).get('verified') is True:
            return result  # Base session already confirmed its own profile.
        async with self.queue, self._scanning():
            await self.actions.get('https://x.com/'+credentials.username.lower())
            await self.actions.sleep(self.collection['load_wait_seconds'])
            gate=await self._page_gate()
            if gate:
                return gate
            try:
                await self.actions.wait('[data-testid="UserName"]',self.collection['element_timeout_seconds'])
            except TimeoutException:
                return {'status':'requires_manual','reason':'Не удалось сверить логин открытого аккаунта X. Откройте его профиль в Chrome и продолжите Trade.'}
            for _ in range(self.collection['login_poll_rounds']):
                owner=await self.actions.script(OWNER_PROFILE_JS,credentials.username.lower())
                if owner.get('state')=='confirmed':
                    return result
                if owner.get('state')=='mismatch':
                    return {'status':'requires_manual','reason':f'Сессия Chrome принадлежит другому аккаунту X: выбран @{credentials.username}. Переключите Chrome на этот аккаунт или остановите Trade и исправьте логин/данные входа в программе.'}
                await self.actions.sleep(self.collection['login_poll_seconds'])
            return {'status':'requires_manual','reason':f'Принадлежность сессии аккаунту @{credentials.username} не подтверждена. Проверьте открытый профиль и продолжите Trade.'}

    async def login(self, credentials):
        return await self._verify_owner(credentials,await super().login(credentials))

    async def continue_login(self, credentials):
        return await self._verify_owner(credentials,await super().continue_login(credentials))

    @session_step('trade', 'Проверка взаимных подписок')
    async def relationship(self, username):
        if not re.fullmatch(r'[a-z0-9_]{1,15}', username):
            raise ValueError('Некорректный ник Trade')
        async with self.queue, self._scanning():
            await self.actions.get('https://x.com/'+username)
            await self.actions.sleep(self.collection['load_wait_seconds'])
            gate = await self._page_gate()
            if gate:
                return gate
            try:
                await self.actions.wait('[data-testid="UserName"]', self.collection['element_timeout_seconds'])
            except TimeoutException:
                return await self._page_gate() or {'following':None,'follows_us':None,'reason':'Шапка профиля не загрузилась'}
            return await self.actions.script(RELATIONSHIP_JS, username)

    @session_step('trade', 'Подписка по плану Trade')
    async def follow(self, username, before_send, allow_send=True):
        """Only explicitly selected counterparties. Never click an unfollow control."""
        value = await self.relationship(username)
        if value.get('status') in ('requires_manual', 'session_expired') or value.get('following') is True:
            return value
        if not allow_send:
            return {**value, 'reason': 'Предыдущая подписка не подтверждена; повторное нажатие отключено'}
        if value.get('following') is not False or not value.get('x_id'):
            return {**value, 'reason': 'Точная кнопка подписки не подтверждена'}
        async with self.queue, self._scanning():
            button = await self.actions.script(DEEP_QUERY_JS + r"""
const main=deepQuery('[data-testid="primaryColumn"]')||deepQuery('main');
const name=main?.querySelector('[data-testid="UserName"]');
const handle=(name?.innerText||'').match(/@([A-Za-z0-9_]{1,15})\b/);
if(!handle||handle[1].toLowerCase()!==arguments[0])return null;
const actions=main.querySelector('[data-testid="userActions"]');
const candidates=Array.from(actions?.parentElement?.querySelectorAll('[data-testid]')||[])
 .filter(e=>e.getAttribute('data-testid')===arguments[1]+'-follow' && (e.offsetWidth||e.offsetHeight||e.getClientRects().length));
return candidates.length===1?candidates[0]:null;
""", username, value['x_id'])
            if button is None or not await self.actions.call(button.is_enabled):
                return {**value, 'reason': 'Кнопка подписки недоступна'}
            before_send()
            await self.actions.call(button.click)
            await self.actions.delay()
            for _ in range(self.collection['login_poll_rounds']):
                current = await self.actions.script(RELATIONSHIP_JS, username)
                if current.get('following') is True:
                    return current
                await self.actions.sleep(self.collection['login_poll_seconds'])
            return {**value, 'following': None, 'reason': 'Подписка отправлена, результат не подтверждён (возможна заявка)'}

    async def _recipient_picker(self, group, username):
        """Search one exact handle. Caller owns the queue; no roster scan."""
        if not re.fullmatch(r'[a-z0-9_]{1,15}', username) or not re.fullmatch(r'https://(?:www\.)?x\.com/i/chat/g[^/?#]+', group.get('url','')):
            return {'status':'error','reason':'Ник или ссылка не подтверждены как XChat'}
        await self.actions.get(group['url'])
        await self.actions.sleep(self.collection['load_wait_seconds'])
        gate = await self._page_gate()
        if gate:
            return gate
        try:
            await self.actions.wait('[data-testid="dm-conversation-header"] div.cursor-pointer,[data-testid="DMConversationInfoButton"],[data-testid="dmConversationInfo"],button[aria-label="Conversation info"],button[aria-label="Group info"],button[aria-label="Информация о группе"]', self.collection['element_timeout_seconds'])
        except TimeoutException:
            return await self._page_gate() or {'status':'error','reason':'Шапка группы не загрузилась; ограничение добавления не утверждается'}
        info_selectors = [
            '[data-testid="dm-conversation-header"] div.cursor-pointer',
            '[data-testid="DMConversationInfoButton"]','[data-testid="dmConversationInfo"]',
            'button[aria-label="Conversation info"]','button[aria-label="Group info"]',
            'button[aria-label="Информация о группе"]',
        ]
        clicked = await self._click_first(info_selectors)
        for _ in range(self.collection['login_poll_rounds']):
            if clicked:
                break
            await self.actions.sleep(self.collection['login_poll_seconds'])
            clicked = await self._click_first(info_selectors)
        if not clicked:
            return {'status': 'error', 'reason': 'Не удалось открыть сведения; ограничение группы не утверждается'}
        await self.actions.wait('[role="dialog"],[data-testid="DMConversationDetails"]', self.collection['element_timeout_seconds'])
        await self.actions.sleep(self.collection['load_wait_seconds'])
        details = await self.actions.script(INVITE_DETAILS_JS)
        for _ in range(self.collection['login_poll_rounds']):
            if details.get('state') not in ('loading','unknown'):
                break
            await self.actions.sleep(self.collection['login_poll_seconds'])
            gate = await self._page_gate()
            if gate:
                return gate
            details = await self.actions.script(INVITE_DETAILS_JS)
        if details.get('state') != 'ready':
            return {'status': 'unavailable' if details.get('state') == 'unavailable' else 'error', 'reason': details.get('reason','Кнопка добавления недоступна')}
        await self.actions.click(details['button'])  # Opens the picker, no invitation yet.
        form = None
        for _ in range(self.collection['login_poll_rounds']):
            form = await self.actions.script(INVITE_FORM_JS)
            if form.get('state') == 'ready':
                break
            await self.actions.sleep(self.collection['login_poll_seconds'])
        if not form or form.get('state') != 'ready':
            return {'status': 'error', 'reason': 'Форма добавления не распознана; участник не выбирался'}
        await self.actions.search_input(form['input'], username)
        target = None
        for _ in range(self.collection['login_poll_rounds']):
            await self.actions.sleep(self.collection['load_wait_seconds'])
            form = await self.actions.script(INVITE_FORM_JS)
            matches = [user for user in form.get('users', []) if user['username'] == username]
            if len(matches) == 1:
                target = matches[0]
                break
        if target and group.get('target_x_id') and str(target.get('x_id') or '') != str(group['target_x_id']):
            return {'status':'error','reason':'ID найденного профиля отсутствует или отличается от проверенного получателя'}
        return {'form': form, 'target': target}

    @session_step('trade', 'Проверка участия в группе')
    async def verify_membership(self, group, username):
        async with self.queue, self._scanning():
            result = await self._recipient_picker(group, username)
            if result.get('status'):
                if result['status'] in ('requires_manual','session_expired'):
                    return result
                return {'status':'uncertain','reason':result.get('reason','Поиск участника недоступен')}
            target = result.get('target')
            if target and target['disabled'] and target['checked']:
                return {'status':'confirmed','reason':'Точный участник уже отмечен в поиске XChat','x_id':target.get('x_id')}
            if target and not target['disabled'] and not target['checked']:
                return {'status':'not_added','reason':'X предлагает добавить точного получателя; он не отмечен как участник','x_id':target.get('x_id')}
            return {'status':'uncertain','reason':'Поиск не подтвердил присутствие или отсутствие получателя'}

    @session_step('trade', 'Приглашение участника по плану Trade')
    async def invite(self, group, username, before_send):
        if not re.fullmatch(r'[a-z0-9_]{1,15}', username) or not re.fullmatch(r'https://(?:www\.)?x\.com/i/chat/g[^/?#]+', group.get('url','')):
            return {'status':'error','reason':'Ник или ссылка не подтверждены как XChat'}
        async with self.queue, self._scanning():
            result = await self._recipient_picker(group, username)
            if result.get('status'):
                return result
            form, target = result['form'], result['target']
            if target and target['disabled'] and target['checked']:
                return {'status':'already_member','reason':'В форме XChat участник уже отмечен и недоступен для повторного добавления','x_id':target.get('x_id')}
            if not target or target['disabled'] or target['checked']:
                return {'status': 'error', 'reason': 'Точный пользователь недоступен для выбора; добавление не выполнялось'}
            # The narrow write policy permits selecting only this exact result.
            await self.actions.call(target['control'].click)
            form = await self.actions.script(INVITE_FORM_JS)
            selected = [user for user in form.get('users', []) if user['checked'] and not user['disabled']]
            button = form.get('button')
            if form.get('state') != 'ready' or len(selected) != 1 or selected[0]['username'] != username or button is None:
                return {'status': 'error', 'reason': 'Однозначный выбор одного получателя не подтверждён; отправка отменена'}
            expected_id = group.get('target_x_id') or target.get('x_id')
            if expected_id and str(selected[0].get('x_id') or '') != str(expected_id):
                return {'status':'error','reason':'ID выбранного получателя не подтверждён перед добавлением'}
            if not await self.actions.call(button.is_enabled):
                return {'status': 'error', 'reason': 'X не разрешает добавление выбранного получателя'}
            before_send()
            # Explicitly authorized only here. Statistics SafeActions is unchanged.
            await self.actions.call(button.click)
            await self.actions.sleep(self.collection['load_wait_seconds'])
        return await self.verify_membership(group, username)
